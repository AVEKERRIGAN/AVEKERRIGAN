# Превью Hoarder 1.1.0

Для работы мода превью не нужно: графика встроена в DLL.

- [Видео анимаций — 26 секунд](https://github.com/AVEKERRIGAN/AVEKERRIGAN/raw/refs/heads/mod-downloads-v2/downloads/Hoarder_Animations_1.1.0.mp4)
- [Интерактивное офлайн-превью — сохранить HTML и открыть браузером](https://github.com/AVEKERRIGAN/AVEKERRIGAN/raw/refs/heads/mod-downloads-v2/downloads/Hoarder_Preview_1.1.0.html)
- [Меню покупки](https://github.com/AVEKERRIGAN/AVEKERRIGAN/raw/refs/heads/mod-downloads-v2/downloads/Hoarder_BuyMenu_1.1.0.png)
- [Раскрытие xWays и +1](https://github.com/AVEKERRIGAN/AVEKERRIGAN/raw/refs/heads/mod-downloads-v2/downloads/Hoarder_xWays_Open_1.1.0.png)
- [Закрытые клетки с цепями](https://github.com/AVEKERRIGAN/AVEKERRIGAN/raw/refs/heads/mod-downloads-v2/downloads/Hoarder_xWays_Closed_1.1.0.png)

Это отдельное 2D-превью, не запись из Unity.
