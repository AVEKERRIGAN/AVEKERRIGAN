using System;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
namespace PocketPhone;
public sealed class PhoneUI : MonoBehaviour
{
    public RectTransform Root;
    readonly PhoneIcons _icons=new();
    readonly Dictionary<string,Image> _buttons=new();
    TMP_FontAsset _font;Sprite _round;Texture2D _roundTexture;
    TMP_Text _time,_status,_toast,_volumeText,_address,_loadStatus,_browserTitle;
    RectTransform _volumeFill,_volumeKnob;
    GameObject _settings,_loading,_toastRoot;
    float _toastUntil;Image _online,_loadRing;
    public bool MenuOpen {get;private set;}
    public bool EditingAddress {get;private set;}
    public static readonly PhoneRect VolumeRect=new(44,651,392,30),AddressRect=new(40,708,400,44),ReloadRect=new(40,780,190,44),RestartRect=new(240,780,190,44),MenuRect=new(22,554,436,330);
    static Color Bg=new(.043f,.063f,.105f),Panel=new(.10f,.14f,.21f),Accent=new(.22f,.9f,.79f),Ink=new(.92f,.96f,1),Muted=new(.54f,.64f,.77f);
    public void Build(Transform parent,Texture screen,Camera camera)
    {
        transform.SetParent(parent,false);
        Root=gameObject.GetComponent<RectTransform>()??gameObject.AddComponent<RectTransform>();
        var canvas=gameObject.AddComponent<Canvas>();canvas.renderMode=RenderMode.WorldSpace;canvas.worldCamera=camera;
        canvas.sortingOrder=25;canvas.overrideSorting=true;
        Root.sizeDelta=new Vector2(PhoneLayout.Width,PhoneLayout.Height);Root.pivot=new Vector2(.5f,.5f);
        transform.localPosition=new Vector3(0,0,PhoneDesign.DisplayZ);transform.localRotation=Quaternion.identity;
        transform.localScale=Vector3.one*(PhoneModel.DisplayWidth/PhoneLayout.Width);
        _font=TMP_Settings.defaultFontAsset ?? FindObjectsByType<TMP_Text>(FindObjectsSortMode.None).Select(t=>t.font).FirstOrDefault(f=>f!=null);
        MakeRound();
        Block(Root,new PhoneRect(0,0,480,960),Bg,18);
        _time=Text(Root,new PhoneRect(18,3,120,25),"POCKET",15,Ink);
        Block(Root,new PhoneRect(203,5,74,20),new Color(.014f,.018f,.032f),12);
        _online=Block(Root,new PhoneRect(361,11,7,7),Muted,4);
        _status=Text(Root,new PhoneRect(373,4,61,22),"OFFLINE",11,Muted);
        Button("close",PhoneLayout.Close,"close",null);
        App("tiktok",PhoneLayout.TikTok,"TikTok",new Color(.045f,.08f,.115f));
        App("instagram",PhoneLayout.Instagram,"Reels",new Color(.18f,.075f,.16f));
        var web=Box(Root,PhoneLayout.Web);var raw=web.gameObject.AddComponent<RawImage>();raw.texture=screen;raw.raycastTarget=false;
        _loading=Box(Root,PhoneLayout.Web).gameObject;
        Block(_loading.transform as RectTransform,new PhoneRect(0,0,PhoneLayout.Web.W,PhoneLayout.Web.H),new Color(.055f,.08f,.13f),0);
        var ring=Icon(_loading.transform as RectTransform,new PhoneRect(193,258,70,70),"refresh",Accent);_loadRing=ring;
        Text(_loading.transform as RectTransform,new PhoneRect(30,347,396,55),"Видео между спинами",27,Ink,TextAlignmentOptions.Center);
        Text(_loading.transform as RectTransform,new PhoneRect(30,408,396,68),"Открой TikTok или Instagram\nи смотри между спинами",20,Muted,TextAlignmentOptions.Center,true);
        _loadStatus=Text(_loading.transform as RectTransform,new PhoneRect(35,510,386,150),"",17,Muted,TextAlignmentOptions.Center,true);
        Block(Root,new PhoneRect(0,899,480,61),new Color(.065f,.088f,.14f),0);
        Button("back",PhoneLayout.Back,"back",null);
        Button("keyboard",PhoneLayout.Keyboard,"keyboard","Текст");
        Button("sound",PhoneLayout.Sound,"sound",null);
        Button("settings",PhoneLayout.Settings,"settings",null);
        Button("spin",PhoneLayout.Spin,"spin","E · СПИН");
        var menu=Box(Root,MenuRect);_settings=menu.gameObject;
        Block(menu,new PhoneRect(0,0,MenuRect.W,MenuRect.H),Panel,18);
        _browserTitle=Text(menu,new PhoneRect(20,18,320,36),"Браузер",27,Ink);
        Text(menu,new PhoneRect(20,64,240,24),"Громкость видео",18,Muted);
        _volumeText=Text(menu,new PhoneRect(336,64,70,24),"60%",18,Accent,TextAlignmentOptions.Right);
        Block(menu,new PhoneRect(22,112,392,6),new Color(.22f,.28f,.37f),3);
        _volumeFill=Block(menu,new PhoneRect(22,112,235,6),Accent,3).rectTransform;
        _volumeKnob=Block(menu,new PhoneRect(247,105,20,20),Ink,10).rectTransform;
        _address=Text(menu,new PhoneRect(20,161,390,44),"Адрес страницы",19,Ink);
        var field=Block(menu,new PhoneRect(18,154,400,44),new Color(.035f,.052f,.088f),10);field.transform.SetSiblingIndex(_address.transform.GetSiblingIndex());
        Icon(menu,new PhoneRect(360,164,26,26),"go",Accent);
        MenuButton(menu,new PhoneRect(18,226,190,44),"refresh","Обновить");
        MenuButton(menu,new PhoneRect(218,226,190,44),"settings","Перезапуск");
        Text(menu,new PhoneRect(20,281,396,31),"Колёсико — листать · ПКМ — отдалить",15,Muted,TextAlignmentOptions.Center);
        _settings.SetActive(false);
        var toast=Box(Root,new PhoneRect(22,833,436,58));_toastRoot=toast.gameObject;
        Block(toast,new PhoneRect(0,0,436,58),new Color(.06f,.15f,.17f,.96f),12);
        _toast=Text(toast,new PhoneRect(14,7,408,44),"",18,Ink,TextAlignmentOptions.Center,true);_toastRoot.SetActive(false);
        int layer=(camera.cullingMask&1)!=0?0:Enumerable.Range(0,32).First(i=>(camera.cullingMask&(1<<i))!=0);
        foreach(var t in GetComponentsInChildren<Transform>(true))t.gameObject.layer=layer;
    }
    void App(string name,PhoneRect rect,string title,Color color)
    {var b=Block(Root,rect,color,14);_buttons[name]=b;Icon(b.rectTransform,new PhoneRect(14,7,32,32),name,Color.white);Text(b.rectTransform,new PhoneRect(54,2,rect.W-62,rect.H-4),title,23,Ink);}
    void Button(string id,PhoneRect rect,string icon,string label)
    {
        var b=Block(Root,rect,id=="spin"?Accent:new Color(.09f,.12f,.18f),12);_buttons[id]=b;
        bool text=label!=null;Icon(b.rectTransform,new PhoneRect(text?12:(rect.W-25)*.5f,(rect.H-25)*.5f,25,25),icon,id=="spin"?Bg:Ink);
        if(text)Text(b.rectTransform,new PhoneRect(43,0,rect.W-48,rect.H),label,id=="spin"?18:18,id=="spin"?Bg:Ink);
    }
    void MenuButton(RectTransform parent,PhoneRect rect,string icon,string label)
    {var b=Block(parent,rect,new Color(.16f,.21f,.30f),10);Icon(b.rectTransform,new PhoneRect(12,11,22,22),icon,Ink);Text(b.rectTransform,new PhoneRect(42,0,rect.W-48,rect.H),label,18,Ink);}
    public void Refresh(bool ready,bool hasFrame,bool typing,bool instagram,float volume,bool spinAvailable,bool running,string status,string browserName="")
    {
        _browserTitle.text=string.IsNullOrEmpty(browserName)?"Браузер":browserName;
        _status.text=ready?"ONLINE":"…";_online.color=ready?Accent:Muted;
        _time.text=DateTime.Now.ToString("HH:mm");
        _loading.SetActive(!hasFrame||(!ready&&running));_loadStatus.text=running?status:"ПКМ — открыть браузер";
        if(_loading.activeSelf)_loadRing.rectTransform.localRotation=Quaternion.Euler(0,0,-Time.unscaledTime*90);
        _buttons["tiktok"].color=instagram?new Color(.045f,.065f,.1f):new Color(.05f,.20f,.22f);
        _buttons["instagram"].color=instagram?new Color(.32f,.11f,.25f):new Color(.16f,.07f,.14f);
        _buttons["keyboard"].color=typing?new Color(.07f,.27f,.27f):new Color(.09f,.12f,.18f);
        _buttons["spin"].color=spinAvailable?Accent:new Color(.32f,.40f,.47f);
        _buttons["sound"].GetComponentsInChildren<Image>().Last().sprite=_icons.Get(volume>.005f?"sound":"mute");
        _volumeText.text=Mathf.RoundToInt(volume*100)+"%";
        _volumeFill.sizeDelta=new Vector2(392*volume,6);_volumeKnob.anchoredPosition=new Vector2(12+392*volume,-105);
        _toastRoot.SetActive(Time.unscaledTime<_toastUntil);
    }
    public void Toast(string text){_toast.text=text;_toastUntil=Time.unscaledTime+3.3f;_toastRoot.SetActive(true);}
    public void Menu(bool value,string url){MenuOpen=value;EditingAddress=false;_settings.SetActive(value);_address.text=Uri.TryCreate(url,UriKind.Absolute,out var uri)?uri.Host:"Адрес страницы";_address.gameObject.SetActive(true);}
    public void EditAddress(bool value){EditingAddress=value;_address.gameObject.SetActive(!value);}
    public bool Point(Camera camera,Vector2 screen,out Vector2 point)
    {
        point=default;var ray=camera.ScreenPointToRay(screen);var plane=new Plane(Root.forward,Root.position);
        if(!plane.Raycast(ray,out float d))return false;var local=Root.InverseTransformPoint(ray.GetPoint(d));
        point=new Vector2(local.x+PhoneLayout.Width*.5f,PhoneLayout.Height*.5f-local.y);
        return point.x>=0&&point.y>=0&&point.x<PhoneLayout.Width&&point.y<PhoneLayout.Height;
    }
    public Rect GuiField(Camera camera)
    {
        var rect=AddressRect;var a=camera.WorldToScreenPoint(Root.TransformPoint(new Vector3(rect.X-240,480-rect.Y,0)));var b=camera.WorldToScreenPoint(Root.TransformPoint(new Vector3(rect.X+rect.W-240,480-rect.Y-rect.H,0)));
        return new Rect(a.x+8,Screen.height-a.y+4,b.x-a.x-48,a.y-b.y-8);
    }
    public void Hover(string name)
    {foreach(var p in _buttons)p.Value.transform.localScale=Vector3.one*(p.Key==name?1.025f:1);}
    RectTransform Box(RectTransform parent,PhoneRect rect)
    {var go=new GameObject("PhoneUI",typeof(RectTransform));var rt=go.GetComponent<RectTransform>();rt.SetParent(parent,false);rt.anchorMin=rt.anchorMax=new Vector2(0,1);rt.pivot=new Vector2(0,1);rt.anchoredPosition=new Vector2(rect.X,-rect.Y);rt.sizeDelta=new Vector2(rect.W,rect.H);return rt;}
    Image Block(RectTransform parent,PhoneRect rect,Color color,float radius)
    {var rt=Box(parent,rect);var im=rt.gameObject.AddComponent<Image>();im.color=color;im.raycastTarget=false;if(radius>0){im.sprite=_round;im.type=Image.Type.Sliced;im.pixelsPerUnitMultiplier=12/radius;}return im;}
    Image Icon(RectTransform parent,PhoneRect rect,string icon,Color tint)
    {var rt=Box(parent,rect);var im=rt.gameObject.AddComponent<Image>();im.sprite=_icons.Get(icon);im.color=tint;im.raycastTarget=false;im.preserveAspect=true;return im;}
    TMP_Text Text(RectTransform parent,PhoneRect rect,string value,float size,Color color,TextAlignmentOptions align=TextAlignmentOptions.Left,bool wrap=false)
    {var rt=Box(parent,rect);var t=rt.gameObject.AddComponent<TextMeshProUGUI>();if(_font!=null)t.font=_font;t.text=value;t.fontSize=size;t.color=color;t.alignment=align;t.textWrappingMode=wrap?TextWrappingModes.Normal:TextWrappingModes.NoWrap;t.overflowMode=TextOverflowModes.Ellipsis;t.raycastTarget=false;return t;}
    void MakeRound()
    {
        const int n=64;var pixels=new Color32[n*n];for(int y=0;y<n;y++)for(int x=0;x<n;x++)
        {float qx=Mathf.Max(Mathf.Abs(x+.5f-n*.5f)-(n*.5f-12),0),qy=Mathf.Max(Mathf.Abs(y+.5f-n*.5f)-(n*.5f-12),0);float a=Mathf.Clamp01(12.5f-Mathf.Sqrt(qx*qx+qy*qy));pixels[y*n+x]=new Color32(255,255,255,(byte)(a*255));}
        _roundTexture=new Texture2D(n,n,TextureFormat.RGBA32,false);_roundTexture.SetPixels32(pixels);_roundTexture.Apply();_roundTexture.filterMode=FilterMode.Bilinear;
        _round=Sprite.Create(_roundTexture,new Rect(0,0,n,n),new Vector2(.5f,.5f),100,0,SpriteMeshType.FullRect,new Vector4(12,12,12,12));
    }
    void OnDestroy(){_icons.Dispose();if(_round!=null)Destroy(_round);if(_roundTexture!=null)Destroy(_roundTexture);}
}
