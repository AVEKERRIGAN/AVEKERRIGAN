using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using BepInEx;
using BepInEx.Configuration;
using Mirror;
using UnityEngine;
using UnityEngine.InputSystem;
namespace PocketPhone;
[BepInPlugin("com.avekerrigan.pocketphone", "Pocket Phone", "1.4.0")]
[DefaultExecutionOrder(10000)]
public sealed class Plugin : BaseUnityPlugin
{
    readonly BrowserClient _browser=new(); readonly List<InputAction> _disabled=new();
    PhoneModel _model; PhoneUI _ui; Texture2D _display;readonly NativePhoneHands _hands=new();
    bool _held,_zoom,_typing,_addressFocus,_focusAddress,_pocketing,_hasFrame,_instagram,_volumeDrag,_oldVisible,_oldHeadLocked; float _ease,_reveal,_volume=.6f,_tap=10;Vector2 _sway;Quaternion _lastView;
    CursorLockMode _oldCursor; PlayerController _lockedController;
    InteractableEventTrigger _spin; GameBase _game;
    string _url="https://www.tiktok.com/foryou",_spinStatus="Наведитесь на слот перед открытием телефона";
    Vector2 _mouseDown; bool _drag; GUIStyle _fieldStyle;readonly ScrollInput _scroll=new();
    string _helper,_profile,_lastBrowserStatus; ConfigEntry<float> _scale,_handScale,_grip; ConfigEntry<int> _fps; ConfigEntry<string> _home,_browserChoice,_browserPath;
    Keyboard _keyboard; string _pendingSite; char _surrogate;
    ConfigEntry<bool> _guestMode;
    void Awake()
    {
        string root=Path.GetDirectoryName(typeof(Plugin).Assembly.Location);
        _helper=Path.Combine(root,"PhoneBrowser.exe"); _profile=Path.Combine(Paths.ConfigPath,"PocketPhone","BrowserProfile");
        _scale=Config.Bind("Display","Scale",1f,"Phone size: 0.65..1.25; preserves page proportions.");
        _handScale=Config.Bind("Hands","Scale",.55f,"Size of the original hands while gripping the phone (0.2..1.2).");
        _grip=Config.Bind("Hands","GripWidth",.068f,"Grip distance from phone centre in model units (0.04..0.12).");
        _fps=Config.Bind("Display","MaximumFps",24,"Browser screen update rate: 8..30 FPS.");
        _home=Config.Bind("Browser","Home","https://www.tiktok.com/foryou","Default HTTPS page.");
        _browserChoice=Config.Bind("Browser","Selection","auto","auto uses the Windows default Chromium browser. Or: chrome, edge, opera, operagx, yandex, brave, vivaldi, chromium.");
        _browserPath=Config.Bind("Browser","ExecutablePath","","Optional absolute path to a Chromium browser EXE; uses a separate phone profile.");
        _guestMode=Config.Bind("Browser","GuestMode",true,"Close optional TikTok login invitations using their dismiss buttons. Manual login and required authentication remain available. Restart the phone browser after changing this setting.");
        _url=PhoneProtocol.Website(_home.Value,out var home)?home:"https://www.tiktok.com/foryou";_instagram=new Uri(_url).Host.Contains("instagram");
        Logger.LogInfo("PocketPhone 1.4.0: guest mode, default Chromium browser, feed gestures; P phone, RMB zoom, E spin, Esc close.");
    }
    Camera View => Extensions.MonoSingleton<LocalManager>.Instance != null ? Extensions.MonoSingleton<LocalManager>.Instance.mainCamera : Camera.main;
    void Update()
    {
        if (NetworkClient.localPlayer==null) { if(_held) PutAway(); return; }
        var k=Keyboard.current; var mouse=Mouse.current; if(k==null||mouse==null)return;
        if(k.pKey.wasPressedThisFrame && !_typing && !GuiTyping()) { if(_held)Pocket();else if(InputEvents.ActiveLayer==InputLayer.Default)Equip(); }
        if(!_held)return;
        if(_pocketing)return;
        var pc=NetworkClient.localPlayer.GetComponent<PlayerController>();
        if(pc!=null && pc.State==PlayerController.PlayerState.Ragdoll){PutAway();return;}
        var inventory=NetworkClient.localPlayer.GetComponent<PlayerInventory>();
        if(inventory!=null&&inventory.NetworkholdingItem!=null){PutAway();return;}
        if(k.escapeKey.wasPressedThisFrame && _zoom) { Zoom(false); return; }
        if(mouse.rightButton.wasPressedThisFrame) Zoom(!_zoom);
        if(k.qKey.wasPressedThisFrame && !_typing && !GuiTyping()) { Pocket();return; }
        if(_zoom)
        {
            Pointer(mouse);
            if(k.eKey.wasPressedThisFrame && !_typing && !GuiTyping()) {Spin();_ui.Toast(_spinStatus);}
            if(_typing)
            {
                if(k.backspaceKey.wasPressedThisFrame) _browser.Send(new{type="key",key="Backspace"});
                if(k.enterKey.wasPressedThisFrame) _browser.Send(new{type="key",key="Enter"});
                if(k.tabKey.wasPressedThisFrame) _browser.Send(new{type="key",key="Tab"});
                if(k.upArrowKey.wasPressedThisFrame) _browser.Send(new{type="key",key="ArrowUp"});
                if(k.downArrowKey.wasPressedThisFrame) _browser.Send(new{type="key",key="ArrowDown"});
                if((k.leftCtrlKey.isPressed||k.rightCtrlKey.isPressed)&&k.vKey.wasPressedThisFrame) _browser.Send(new{type="text",text=GUIUtility.systemCopyBuffer});
            }
        }
        if(_browser.Ready && _pendingSite!=null) { _browser.Send(new{type="navigate",url=_pendingSite});_pendingSite=null;_browser.Send(new{type="volume",value=_volume});_browser.Send(new{type="fps",value=Mathf.Clamp(_fps.Value,8,30)}); }
        if(_browser.Running&&_lastBrowserStatus!=_browser.Status){_lastBrowserStatus=_browser.Status;Logger.LogInfo("Phone browser: "+_lastBrowserStatus);}
        var frame=_browser.Frame();
        if(frame!=null && _display!=null) try { _hasFrame=ImageConversion.LoadImage(_display,frame,false); } catch(Exception e){Logger.LogWarning("Phone frame: "+e.GetType().Name);}
    }
    bool GuiTyping() => _addressFocus;
    void Equip()
    {
        var cam=View;if(cam==null)return;
        var inv=NetworkClient.localPlayer.GetComponent<PlayerInventory>();
        if(inv!=null && inv.NetworkholdingItem!=null) { _spinStatus="Сначала уберите предмет из рук";Logger.LogInfo(_spinStatus);return; }
        _held=true;_pocketing=false;_reveal=0;_ease=0;_tap=10;_sway=Vector2.zero;
        if(_display==null)
        {
            _display=new Texture2D(PhoneProtocol.Width,PhoneProtocol.Height,TextureFormat.RGB24,false);
            var pixels=new Color32[PhoneProtocol.Width*PhoneProtocol.Height]; for(int i=0;i<pixels.Length;i++)pixels[i]=new Color32(15,20,32,255);
            _display.SetPixels32(pixels);_display.Apply();
        }
        var go=new GameObject("PocketPhone_Held");_model=go.AddComponent<PhoneModel>();_model.Build();
        _lastView=cam.transform.rotation;_hands.Attach(NetworkClient.localPlayer.gameObject,cam);
        var ui=new GameObject("PocketPhone_Display",typeof(RectTransform));_ui=ui.AddComponent<PhoneUI>();_ui.Build(go.transform,_display,cam);
        foreach(var child in go.GetComponentsInChildren<Transform>(true))child.gameObject.layer=ui.layer;
        Logger.LogInfo("Phone native hand grip: "+(_hands.Ready?"attached":"hand bones unavailable"));
    }
    void Pocket()
    {if(_pocketing)return;Zoom(false);_pocketing=true;_browser.Stop();_pendingSite=null;}
    void PutAway()
    {
        Zoom(false);_held=false;_pocketing=false;_browser.Stop();_pendingSite=null;_hands.Release();
        if(_model!=null)Destroy(_model.gameObject);_model=null;_ui=null;_game=null;_spin=null;
    }
    void Zoom(bool value)
    {
        if(_zoom==value)return;
        _zoom=value;
        if(value)
        {
            SelectSlot();_ui?.Toast(_spinStatus);_oldCursor=Cursor.lockState;_oldVisible=Cursor.visible;
            var reader=InputReader.Instance;
            var actions=reader!=null?typeof(InputReader).GetField("_inputActions",BindingFlags.Instance|BindingFlags.NonPublic)?.GetValue(reader) as InputActions:null;
            if(actions!=null)foreach(var a in actions.asset.FindActionMap("Player"))
                if(a.name!="PushToTalk"&&a.enabled){_disabled.Add(a);a.Disable();}
            InputEvents.OnMoveEvent?.Invoke(Vector2.zero);InputEvents.OnAimEvent?.Invoke(Vector2.zero);InputEvents.UpdateInteract(false);
            _lockedController=NetworkClient.localPlayer?.GetComponent<PlayerController>();
            if(_lockedController!=null && _lockedController.head!=null){_oldHeadLocked=_lockedController.head.isLocked;_lockedController.head.isLocked=true;}
            if(!_browser.Running) { StartBrowser();_pendingSite=_url; }
            else _browser.Send(new{type="active",value=true});
            _keyboard=Keyboard.current;if(_keyboard!=null)_keyboard.onTextInput+=TextInput;
        }
        else
        {
            _typing=false;_drag=false;_scroll.Reset();_addressFocus=false;_volumeDrag=false;_ui?.Menu(false,_url);_surrogate='\0';
            if(_keyboard!=null)_keyboard.onTextInput-=TextInput;_keyboard=null;
            foreach(var a in _disabled)a.Enable();_disabled.Clear();
            if(_lockedController!=null && _lockedController.head!=null)_lockedController.head.isLocked=_oldHeadLocked;
            _lockedController=null;Cursor.lockState=_oldCursor;Cursor.visible=_oldVisible;
            _browser.Send(new{type="active",value=false});GUIUtility.keyboardControl=0;
        }
    }
    void TextInput(char c)
    {
        var k=Keyboard.current;
        if(!_zoom||!_typing||GuiTyping()||char.IsControl(c)||(k?.leftCtrlKey.isPressed??false)||(k?.rightCtrlKey.isPressed??false))return;
        if(char.IsHighSurrogate(c)){_surrogate=c;return;}
        string text=char.IsLowSurrogate(c)&&_surrogate!='\0'?new string(new[]{_surrogate,c}):c.ToString();
        _surrogate='\0';_browser.Send(new{type="text",text});
    }
    void SelectSlot()
    {
        _spin=null;_game=null;var cam=View;var player=NetworkClient.localPlayer;if(cam==null||player==null)return;
        var pi=player.GetComponent<PlayerInteract>();float reach=pi!=null?pi.raycastDistance:3f;var aimed=pi?.TargetInteractable as InteractableEventTrigger;
        float best=float.MaxValue;
        foreach(var game in FindObjectsByType<GameBase>(FindObjectsSortMode.None))
        {
            foreach(var entry in SpinButtons(game))
            {
                if(entry is not InteractableEventTrigger button || button==null)continue;
                var offset=button.transform.position-cam.transform.position;float distance=offset.magnitude;
                if(distance>reach || Vector3.Dot(offset.normalized,cam.transform.forward)<.25f)continue;
                float score=button==aimed?-100f:distance+Vector3.Angle(offset,cam.transform.forward)*.04f;
                if(score<best){best=score;_spin=button;_game=game;}
            }
        }
        _spinStatus=_game!=null?"E — спин: "+_game.GameName:"Слот не выбран: закройте экран и наведитесь на автомат";
    }
    static IEnumerable SpinButtons(GameBase game)
    {
        var field=game.GetType().GetField("playButtons",BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic);
        if(field?.GetValue(game) is IEnumerable buttons) { foreach(var entry in buttons)yield return entry;yield break; }
        if(game is not Slots)yield break;
        foreach(var button in game.GetComponentsInChildren<InteractableEventTrigger>())
        {
            var ev=button.serverOnInteractEvent;if(ev==null)continue;
            for(int i=0;i<ev.GetPersistentEventCount();i++)
                if(ev.GetPersistentMethodName(i)=="TryStartGame" && ev.GetPersistentTarget(i)==game){yield return button;break;}
        }
    }
    void Spin()
    {
        var player=NetworkClient.localPlayer; if(player==null||_spin==null||_game==null){_spinStatus="Нет выбранного слота. Наведитесь на него и откройте телефон заново.";return;}
        var pi=player.GetComponent<PlayerInteract>();var cam=View;
        if(pi==null||cam==null||Vector3.Distance(cam.transform.position,_spin.transform.position)>pi.raycastDistance){_spinStatus="Подойдите ближе к выбранному автомату";return;}
        if(_game.isPlaying){_spinStatus="Идёт вращение — дождитесь результата";return;}
        var inv=player.GetComponent<PlayerInventory>();
        if(inv!=null&&inv.NetworkholdingItem!=null){_spinStatus="Уберите другой предмет из рук";return;}
        if(!_spin.IsInteractable||!_spin.MeetRequirements){_spinStatus="Кнопка запуска сейчас недоступна";return;}
        try{_spin.OnInteract(pi);_spinStatus="Спин отправлен: "+_game.GameName;}catch(Exception e){Logger.LogWarning("Phone spin: "+e.Message);_spinStatus="Не удалось нажать кнопку слота";}
    }
    void LateUpdate()
    {
        if(!_held)return;
        var cam=View;if(cam==null)return;
        float dt=Mathf.Min(Time.unscaledDeltaTime,.1f);
        _reveal=Mathf.MoveTowards(_reveal,_pocketing?0:1,dt/.36f);
        _ease=Mathf.MoveTowards(_ease,_zoom?1:0,dt/.30f);
        float opened=PhoneLayout.Smooth(_ease),shown=PhoneLayout.Smooth(_reveal);
        _tap+=dt;float pulse=PhoneLayout.Pulse(_tap);
        var look=Quaternion.Inverse(_lastView)*cam.transform.rotation;_lastView=cam.transform.rotation;
        var angles=look.eulerAngles;float yaw=Mathf.DeltaAngle(0,angles.y)/Mathf.Max(.001f,dt)/60,pitch=Mathf.DeltaAngle(0,angles.x)/Mathf.Max(.001f,dt)/60;
        _sway=Vector2.Lerp(_sway,new Vector2(Mathf.Clamp(yaw,-4,4),Mathf.Clamp(pitch,-4,4)),PhoneLayout.Follow(dt,.10f));
        float fraction=Mathf.Lerp(.34f,.77f,opened)*Mathf.Clamp(_scale.Value,.65f,1.25f);
        fraction=Mathf.Min(fraction,.87f);
        float depth=Mathf.Max(cam.nearClipPlane+.16f,Mathf.Lerp(.62f,.45f,opened));
        float span=2*depth*Mathf.Tan(cam.fieldOfView*Mathf.Deg2Rad*.5f);
        float modelScale=PhoneLayout.Scale(cam.fieldOfView,depth,fraction,PhoneModel.Height);
        float cx=Mathf.Lerp(.75f,.74f,opened),cy=Mathf.Lerp(.69f,.50f,opened);
        var position=new Vector3((cx-.5f)*span*cam.aspect,(.5f-cy)*span-span*.7f*(1-shown),depth);
        var pc=NetworkClient.localPlayer?.GetComponent<PlayerController>();float speed=pc!=null?Vector3.ProjectOnPlane(pc.serverVelocity,Vector3.up).magnitude:0;
        float motion=(1-opened)*Mathf.Clamp01(speed*.4f);
        position+=new Vector3(Mathf.Sin(Time.unscaledTime*7)*span*.003f*motion,Mathf.Cos(Time.unscaledTime*14)*span*.004f*motion+Mathf.Sin(Time.unscaledTime*1.9f)*span*.001f,0);
        position.y-=pulse*span*.0025f;
        Quaternion rotation=Quaternion.Euler(Mathf.Lerp(-7,0,opened)+_sway.y*(1-opened)*.45f+18*(1-shown),Mathf.Lerp(-9,0,opened)-_sway.x*(1-opened)*.45f,Mathf.Lerp(-5,0,opened)+pulse*.5f);
        _model.transform.localScale=Vector3.one*modelScale;
        _model.transform.SetPositionAndRotation(cam.transform.TransformPoint(position),cam.transform.rotation*rotation);
        _hands.Apply(_model.transform,dt,_reveal,_handScale.Value,Mathf.Clamp(_grip.Value,.04f,.12f));
        _ui.Refresh(_browser.Ready,_hasFrame,_typing,_instagram,_volume,_game!=null&&!_game.isPlaying,_browser.Running,_browser.Status,_browser.BrowserName);
        if(_zoom){Cursor.lockState=CursorLockMode.None;Cursor.visible=true;}
        if(_pocketing&&_reveal<=0)PutAway();
    }
    void Navigate(string url)
    {
        _scroll.Reset();
        if(!PhoneProtocol.Website(url,out string safe)){_spinStatus="Нужен полный адрес https://…";return;}
        _url=safe;_typing=false;_instagram=new Uri(safe).Host.Contains("instagram");_ui?.Menu(false,_url);_addressFocus=false;GUIUtility.keyboardControl=0;
        if(_browser.Ready)_browser.Send(new{type="navigate",url=safe});else _pendingSite=safe;
    }
    void OnGUI()
    {
        if(!_held||_ui==null)return;
        if(!_zoom&&!_pocketing)
        {
            var style=new GUIStyle(GUI.skin.label){fontSize=15,normal={textColor=new Color(.85f,.92f,1)}};
            GUI.Label(new Rect(24,Screen.height-48,600,30),"ПКМ — телефон    P / Q — в карман",style);
        }
        if(!_zoom||!_ui.EditingAddress)return;
        if(_fieldStyle==null)_fieldStyle=new GUIStyle(GUI.skin.textField){fontSize=18,padding=new RectOffset(8,4,4,4),normal={background=null,textColor=Color.white},focused={background=null,textColor=Color.white}};
        var rect=_ui.GuiField(View);if(rect.width<=0||rect.height<=0)return;
        GUI.SetNextControlName("address");_url=GUI.TextField(rect,_url,1000,_fieldStyle);if(_focusAddress){GUI.FocusControl("address");_focusAddress=false;}
        _addressFocus=GUI.GetNameOfFocusedControl()=="address";
        if(Event.current.type==EventType.KeyDown&&Event.current.keyCode==KeyCode.Return){Navigate(_url);Event.current.Use();}
    }
    void Tap(){_hands.Tap();_tap=0;}
    void StartBrowser()=>_browser.Start(_helper,_profile,_browserChoice.Value,_browserPath.Value,_guestMode.Value);
    void Scroll(int x,int y,int delta)=>_browser.Send(new{type="scroll",x,y,delta,sent=DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()});
    void Volume(float x){float v=Mathf.Clamp01((x-PhoneUI.VolumeRect.X)/PhoneUI.VolumeRect.W);if(Mathf.Abs(v-_volume)>.005f){_volume=v;_browser.Send(new{type="volume",value=_volume});}}
    void Pointer(Mouse mouse)
    {
        if(_ui==null||_ease<.95f||View==null)return;
        bool hit=_ui.Point(View,mouse.position.ReadValue(),out var p);
        if(!hit){_scroll.Reset();_ui.Hover(null);if(mouse.leftButton.wasReleasedThisFrame){_drag=false;_volumeDrag=false;}return;}
        string hovered=PhoneLayout.TikTok.Contains(p.x,p.y)?"tiktok":PhoneLayout.Instagram.Contains(p.x,p.y)?"instagram":PhoneLayout.Back.Contains(p.x,p.y)?"back":PhoneLayout.Keyboard.Contains(p.x,p.y)?"keyboard":PhoneLayout.Sound.Contains(p.x,p.y)?"sound":PhoneLayout.Settings.Contains(p.x,p.y)?"settings":PhoneLayout.Spin.Contains(p.x,p.y)?"spin":null;
        _ui.Hover(hovered);
        if(_volumeDrag&&mouse.leftButton.isPressed)Volume(p.x);
        if(mouse.leftButton.wasPressedThisFrame)
        {
            _scroll.Reset();
            if(PhoneLayout.Close.Contains(p.x,p.y)){Tap();Zoom(false);return;}
            if(PhoneLayout.TikTok.Contains(p.x,p.y)){Tap();Navigate("https://www.tiktok.com/foryou");return;}
            if(PhoneLayout.Instagram.Contains(p.x,p.y)){Tap();Navigate("https://www.instagram.com/reels/");return;}
            if(PhoneLayout.Back.Contains(p.x,p.y)){Tap();_browser.Send(new{type="back"});return;}
            if(PhoneLayout.Keyboard.Contains(p.x,p.y)){Tap();_typing=!_typing;_ui.Menu(false,_url);_addressFocus=false;GUIUtility.keyboardControl=0;_ui.Toast(_typing?"Клавиатура включена · E вводит текст":"E — спин · колёсико — прокрутка");return;}
            if(PhoneLayout.Sound.Contains(p.x,p.y)||PhoneLayout.Settings.Contains(p.x,p.y)){Tap();_ui.Menu(!_ui.MenuOpen,_url);_typing=false;_addressFocus=false;GUIUtility.keyboardControl=0;return;}
            if(PhoneLayout.Spin.Contains(p.x,p.y)){Tap();Spin();_ui.Toast(_spinStatus);return;}
            if(_ui.MenuOpen)
            {
                if(PhoneUI.VolumeRect.Contains(p.x,p.y)){_volumeDrag=true;Volume(p.x);return;}
                if(PhoneUI.AddressRect.Contains(p.x,p.y)){if(_ui.EditingAddress&&p.x>PhoneUI.AddressRect.X+PhoneUI.AddressRect.W-44)Navigate(_url);else{_ui.EditAddress(true);_typing=false;_focusAddress=true;}return;}
                if(PhoneUI.ReloadRect.Contains(p.x,p.y)){Tap();_browser.Send(new{type="reload"});_ui.Menu(false,_url);return;}
                if(PhoneUI.RestartRect.Contains(p.x,p.y)){Tap();_browser.Stop();_hasFrame=false;StartBrowser();_pendingSite=_url;_ui.Menu(false,_url);return;}
                if(!PhoneUI.MenuRect.Contains(p.x,p.y)){_ui.Menu(false,_url);_addressFocus=false;GUIUtility.keyboardControl=0;}return;
            }
            if(PhoneLayout.WebPoint(p.x,p.y,out _,out _)){_mouseDown=p;_drag=true;_addressFocus=false;GUIUtility.keyboardControl=0;}
        }
        if(!_ui.MenuOpen&&PhoneLayout.WebPoint(p.x,p.y,out int x,out int y))
        {
            float wheel=mouse.scroll.ReadValue().y;
            if(Mathf.Abs(wheel)>.1f)_scroll.Add(x,y,Mathf.Clamp(-wheel*3,-900,900),Time.unscaledTime);
            if(_scroll.Take(Time.unscaledTime,out int sx,out int sy,out int delta))Scroll(sx,sy,delta);
            if(mouse.leftButton.wasReleasedThisFrame&&_drag)
            {
                float dy=_mouseDown.y-p.y;
                if(Mathf.Abs(dy)>22){_scroll.Reset();if(PhoneLayout.WebPoint(_mouseDown.x,_mouseDown.y,out int dx,out int dyStart))Scroll(dx,dyStart,(int)(dy*PhoneProtocol.Height/PhoneLayout.Web.H));}
                else{Tap();_browser.Send(new{type="click",x,y});}_drag=false;
            }
        }
        if(mouse.leftButton.wasReleasedThisFrame){_drag=false;_volumeDrag=false;}
    }
    void OnDestroy(){PutAway();if(_display!=null)Destroy(_display);}
    void OnApplicationQuit(){PutAway();}
}
