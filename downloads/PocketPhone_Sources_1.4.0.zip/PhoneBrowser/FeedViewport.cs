using System.Text.Json;
namespace PhoneBrowser;
public static class FeedViewport
{
    public static readonly string Script=Load();
    static string Load()
    {using var stream=typeof(FeedViewport).Assembly.GetManifestResourceStream("PhoneBrowser.FeedViewport.js")??throw new IOException("Missing feed viewport script");using var reader=new StreamReader(stream);return reader.ReadToEnd();}
    public static async Task Scroll(Cdp cdp,int x,int y,int delta)
    {
        var reply=await cdp.Call("Runtime.evaluate",new{expression=$"window.__pocketPhoneFeed?.scroll({x},{y},{delta})??({{mode:'wheel'}})",returnByValue=true});
        if(reply.TryGetProperty("exceptionDetails",out _))throw new IOException("Feed controls failed. Reload the page.");
        var result=reply.GetProperty("result").GetProperty("value");
        switch(result.GetProperty("mode").GetString())
        {
            case "wheel":await cdp.Call("Input.dispatchMouseEvent",new{type="mouseWheel",x,y,deltaX=0,deltaY=delta});break;
            case "click":await Click(cdp,result.GetProperty("x").GetDouble(),result.GetProperty("y").GetDouble());break;
            case "key":await Key(cdp,result.GetProperty("key").GetString()!);break;
        }
    }
    public static async Task Click(Cdp cdp,double x,double y)
    {
        string point=JsonSerializer.Serialize(new{x,y});
        await cdp.Call("Runtime.evaluate",new{expression=$"((p)=>{{window.__pocketPhoneFeed?.beforeClick(p.x,p.y);window.__pocketPhoneGuest?.beforeClick(p.x,p.y);}})({point})"});
        await cdp.Call("Input.dispatchMouseEvent",new{type="mouseMoved",x,y});
        await cdp.Call("Input.dispatchMouseEvent",new{type="mousePressed",x,y,button="left",clickCount=1});
        await cdp.Call("Input.dispatchMouseEvent",new{type="mouseReleased",x,y,button="left",clickCount=1});
    }
    public static async Task Key(Cdp cdp,string key)
    {
        int code=key switch{"Backspace"=>8,"Enter"=>13,"Tab"=>9,"ArrowUp"=>38,"ArrowDown"=>40,"ArrowLeft"=>37,_=>39};
        await cdp.Call("Input.dispatchKeyEvent",new{type="keyDown",key,code=key,windowsVirtualKeyCode=code});
        await cdp.Call("Input.dispatchKeyEvent",new{type="keyUp",key,code=key,windowsVirtualKeyCode=code});
    }
}
