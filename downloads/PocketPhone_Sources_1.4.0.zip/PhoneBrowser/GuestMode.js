// Dismiss optional TikTok login invitations through the site's own controls.
// Never remove an authentication wall, navigate around it or alter session data.
(()=>{
 if(window.__pocketPhoneGuest)return;
 let enabled=window.__pocketPhoneGuestEnabled!==false,pending=0,intentUntil=0;
 const preserved=new WeakSet(),attempts=new WeakMap();
 const roots='[role="dialog"],[aria-modal="true"],[data-e2e="login-modal"],[class*="DivModalContainer"]';
 const login=/\b(?:log\s*in|sign\s*in|sign\s*up)\b|войти|вход\s+в|зарегистрир|авторизац/i;
 const dismiss=/^(?:close(?: (?:dialog|modal))?|dismiss|not now|maybe later|continue as guest|continue without (?:an )?account|закрыть(?: (?:окно|диалог))?|не сейчас|позже|продолжить без (?:входа|аккаунта))$/i;
 const authAction=/\b(?:log\s*in|sign\s*in|sign\s*up|comments?|likes?|follow)\b|войти|зарегистрир|комментар|нравится|подписаться/i;
 const visible=e=>{const r=e.getBoundingClientRect(),s=getComputedStyle(e);return s.display!=='none'&&s.visibility!=='hidden'&&r.width>1&&r.height>1&&r.bottom>0&&r.right>0&&r.top<innerHeight&&r.left<innerWidth;};
 const scope=()=>{const h=location.hostname.toLowerCase();return (h==='tiktok.com'||h.endsWith('.tiktok.com'))&&!/^\/(?:login|signup|auth)(?:\/|$)/i.test(location.pathname);};
 const label=e=>(e.getAttribute('aria-label')||e.getAttribute('title')||e.querySelector('svg[aria-label]')?.getAttribute('aria-label')||e.textContent||'').trim();
 const isAuth=root=>login.test((root.innerText||'').slice(0,5000));
 function beforeClick(x,y){
  markIntent(document.elementFromPoint(x,y));
 }
 function markIntent(e){
  if(!enabled||!scope())return;
  if(!e?.closest)return;
  const root=e.closest(roots);
  if(root&&isAuth(root)){preserved.add(root);return;}
  const action=e.closest('button,a,[role="button"],[data-e2e]');
  if(action&&authAction.test(label(action)+' '+(action.getAttribute('data-e2e')||'')))intentUntil=performance.now()+3000;
 }
 function scan(){
  pending=0;if(!enabled||!scope())return;
  for(const root of document.querySelectorAll(roots)){
   if(!visible(root)){preserved.delete(root);attempts.delete(root);continue;}
   if(!isAuth(root)||preserved.has(root))continue;
   if(performance.now()<intentUntil){preserved.add(root);continue;}
   // Captcha/verification is never an optional login invitation.
   if(root.querySelector('iframe[src*="captcha"],[data-e2e*="captcha"]')||/captcha|verify you are|проверка безопасности/i.test(root.innerText||''))continue;
   const close=[...root.querySelectorAll('button,[role="button"],[data-e2e="modal-close-inner-button"],[data-e2e="modal-close-button"],[data-e2e="login-modal-close"]')].find(e=>visible(e)&&!e.disabled&&e.getAttribute('aria-disabled')!=='true'&&(
    dismiss.test(label(e))||/^(?:modal-close-inner-button|modal-close-button|login-modal-close)$/.test(e.getAttribute('data-e2e')||'')
   ));
   if(!close)continue; // Mandatory wall remains visible; no CSS hiding/removal.
   const previous=attempts.get(root)||{count:0,time:-Infinity};
   if(previous.count>=3||performance.now()-previous.time<1500)continue;
   attempts.set(root,{count:previous.count+1,time:performance.now()});close.click();
  }
 }
 function schedule(){if(!pending&&enabled)pending=setTimeout(scan,350);}
 new MutationObserver(schedule).observe(document,{subtree:true,childList:true,attributes:true,attributeFilter:['style','class','hidden','aria-hidden']});
 document.addEventListener('click',e=>{if(e.isTrusted)markIntent(e.target);},true);
 document.addEventListener('beforeinput',e=>{if(e.isTrusted){const root=e.target.closest?.(roots);if(root)preserved.add(root);}},true);
 document.addEventListener('DOMContentLoaded',schedule);
 window.__pocketPhoneGuest={beforeClick,setEnabled(value){enabled=!!value;window.__pocketPhoneGuestEnabled=enabled;if(!enabled&&pending){clearTimeout(pending);pending=0;}schedule();}};
 schedule();
})();
