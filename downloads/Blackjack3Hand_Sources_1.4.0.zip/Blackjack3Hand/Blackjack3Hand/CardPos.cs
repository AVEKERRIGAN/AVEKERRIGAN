using System;

namespace Blackjack3Hand;

[Serializable]
public class CardPos
{
	public uint n;

	public int a;

	public int i;

	public int c;
}
