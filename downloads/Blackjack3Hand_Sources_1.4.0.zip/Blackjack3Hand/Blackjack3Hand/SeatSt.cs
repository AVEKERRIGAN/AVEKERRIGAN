using System;

namespace Blackjack3Hand;

[Serializable]
public class SeatSt
{
	public string who;

    public uint owner;
    public bool occupied;

	public string bet;

	public string h0;

	public string h1;

	public int nh;

	public string r0;

	public string r1;

	public string t0;

	public string t1;

	public string b0;

	public string b1;
}
