using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using Extensions;
using HarmonyLib;
using Mirror;
using Mirror.RemoteCalls;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Rendering;
using UnityEngine.UI;

namespace Blackjack3Hand;

public partial class BJ3Game : GameBase
{
	private enum Phase
	{
		Betting,
		Dealing,
		Playing,
		Dealer,
		Results
	}

	private class Hand
	{
		public List<CardData> cards = new List<CardData>();

		public List<GameObject> objs = new List<GameObject>();

		public BigNumber bet;

		public bool done;

		public bool doubled;

		public bool fromSplit;

		public bool splitAces;

		public string result = "";
	}

	private class Seat
	{
		public PlayerProfile owner;

		public BigNumber bet;

		public List<Hand> hands = new List<Hand>();
	}

	private class Stack
	{
		public GameObject root;

		public List<Transform> chips = new List<Transform>();

		public TextMesh label;

		public string last;
	}

	private const string RpcSig = "System.Void Blackjack3Hand.BJ3Game::UserRpcState(System.String)";

	public GameObject cardPrefab;

	public Transform playerArea;

	public Transform dealerArea;

	public float cardSpacing = 0.5f;

	public float cardMoveSpeed = 5f;

	public List<Transform> areas = new List<Transform>();

	public List<InteractableEventTrigger> seatButtons = new List<InteractableEventTrigger>();

	public InteractableEventTrigger dealButton;

	public List<TextMesh> labels = new List<TextMesh>();

	public static readonly List<BJ3Game> All = new List<BJ3Game>();

	public float SeatFrac = 0.4f;

	private static bool _reg;

	private Phase _ph;

	private readonly Seat[] _seats = new Seat[3]
	{
		new Seat(),
		new Seat(),
		new Seat()
	};

	private readonly List<CardData> _dealer = new List<CardData>();

	private readonly List<GameObject> _dealerObjs = new List<GameObject>();

	private readonly List<CardData> _shoe = new List<CardData>();

	private int _actSeat = -1;

	private int _actHand = -1;

	private float _deadline;

	private string _msg = "Press BET at a seat";

	private bool _holeHidden;

	private Coroutine _round;

	private int _pendingArea;

	private float _nextBroadcast;

	private bool _dealPressed;

	private bool _csLogged;

	private bool _rxLogged;

	private StateMsg _st;

	private float _stTime;

	private readonly Dictionary<uint, (int a, int i, int c)> _cardTargets = new Dictionary<uint, (int, int, int)>();

	private int _lastFrame = -1;

	private Keypad _kp;

	private float _kpCheck;

	private static readonly AccessTools.FieldRef<Keypad, string> KpInput = AccessTools.FieldRefAccess<Keypad, string>("_currentInput");

	private static readonly AccessTools.FieldRef<Keypad, string> KpErr = AccessTools.FieldRefAccess<Keypad, string>("_errorMessage");

	private static readonly AccessTools.FieldRef<Keypad, RawImage> KpTarget = AccessTools.FieldRefAccess<Keypad, RawImage>("keypadRenderTarget");

	private float _dupCheck;

	public float SeatCardFan = 0.55f;

	public float DealerCardFan = 0.7f;

	private bool _fanLogged;

	private float _cardW = -1f;

	private readonly HashSet<uint> _hostDone = new HashSet<uint>();

	private float _cardL = -1f;

	private readonly string[] _handTot = new string[7];

	private readonly TextMesh[] _tot = new TextMesh[7];

	private readonly bool[] _totLogged = new bool[7];

	private readonly TextMesh[] _betLbl = new TextMesh[7];

	private readonly float[] _awaySince = new float[3];

	private float _nextSeatWatch;

	private readonly Stack[] _stacks = new Stack[7];

	private static Material[] _chipMats;

	private static readonly Color[] ChipCol = new Color[6]
	{
		new Color(0.85f, 0.12f, 0.12f),
		new Color(0.1f, 0.35f, 0.85f),
		new Color(0.08f, 0.55f, 0.2f),
		new Color(0.08f, 0.08f, 0.08f),
		new Color(0.55f, 0.15f, 0.7f),
		new Color(0.95f, 0.75f, 0.15f)
	};

	private static MoneyManager Money => NetworkSingleton<MoneyManager>.Instance;

	private void OnEnable()
	{
		if (!All.Contains(this))
		{
			All.Add(this);
		}
	}

	private void OnDestroy()
	{
		ReleaseSurfaceMaterials();
		All.Remove(this);
	}

	public void SetName()
	{
		gameName = "Blackjack 3-Hand";
	}

	public override bool Weaved()
	{
		return true;
	}

	public static void RegisterRpcs()
	{
		if (_reg)
		{
			return;
		}
		_reg = true;
		RemoteProcedureCalls.RegisterRpc(typeof(BJ3Game), "System.Void Blackjack3Hand.BJ3Game::UserRpcState(System.String)", delegate(NetworkBehaviour obj, NetworkReader reader, NetworkConnectionToClient conn)
		{
			if (NetworkClient.active)
			{
				((BJ3Game)obj).UserRpcState(reader.ReadString());
			}
		});
	}

	public override void OnStartServer()
	{
		base.OnStartServer();
		canBet = true;
		for (int i = 0; i < seatButtons.Count; i++)
		{
			InteractableEventTrigger interactableEventTrigger = seatButtons[i];
			if (interactableEventTrigger == null)
			{
				continue;
			}
			int seat = i / 5;
			int act = i % 5;
			if (interactableEventTrigger.serverOnInteractEvent == null)
			{
				interactableEventTrigger.serverOnInteractEvent = new UnityEvent<PlayerInteract>();
			}
			interactableEventTrigger.serverOnInteractEvent.AddListener(delegate(PlayerInteract pi)
			{
				try
				{
					OnAction(seat, act, pi);
				}
				catch (Exception ex)
				{
					BJ3Plugin.Log.LogError("[BJ3] action error: " + ex);
				}
			});
		}
		if (dealButton != null)
		{
			if (dealButton.serverOnInteractEvent == null)
			{
				dealButton.serverOnInteractEvent = new UnityEvent<PlayerInteract>();
			}
			dealButton.serverOnInteractEvent.AddListener(delegate(PlayerInteract pi)
			{
				try
				{
					Deal(pi);
				}
				catch (Exception ex)
				{
					BJ3Plugin.Log.LogError("[BJ3] deal error: " + ex);
				}
			});
		}
		BJ3Plugin.V($"OnStartServer: {seatButtons.Count} seat buttons hooked, deal={dealButton != null}, keypad={keypad != null}");
	}

	private static PlayerProfile Prof(PlayerInteract pi)
	{
		if (!(pi != null) || !pi.TryGetComponent<PlayerProfile>(out var component))
		{
			return null;
		}
		return component;
	}

	[Server]
	private void OnAction(int seat, int act, PlayerInteract pi)
	{
		PlayerProfile playerProfile = Prof(pi);
		if (playerProfile == null)
		{
			return;
		}
		Seat seat2 = _seats[seat];
		BJ3Plugin.V($"{playerProfile.playerName} pressed {act} on seat {seat + 1} (phase {_ph})");
		if (act == 0)
		{
			Bet(seat, playerProfile);
		}
		else
		{
			if (_ph != Phase.Playing || _actSeat != seat || seat2.owner != playerProfile)
			{
				return;
			}
			Hand hand = seat2.hands[_actHand];
			switch (act)
			{
			default:
				return;
			case 1:
			{
				DealTo(hand, 1 + seat * 2 + _actHand);
				int num2 = Value(hand.cards);
				if (num2 > 21)
				{
					hand.done = true;
					hand.result = "BUST";
				}
				else if (num2 == 21)
				{
					hand.done = true;
				}
				break;
			}
			case 2:
				hand.done = true;
				break;
			case 3:
				if (hand.cards.Count != 2 || hand.doubled)
				{
					return;
				}
				if (!Money.TryChangeBalance(-hand.bet, playerProfile, ChangeType.Bet))
				{
					_msg = playerProfile.playerName + ": not enough money to double";
					break;
				}
				hand.bet *= 2;
				hand.doubled = true;
				DealTo(hand, 1 + seat * 2 + _actHand);
				if (Value(hand.cards) > 21)
				{
					hand.result = "BUST";
				}
				hand.done = true;
				break;
			case 4:
			{
				if (seat2.hands.Count != 1 || hand.cards.Count != 2 || hand.cards[0].GetBlackjackValue() != hand.cards[1].GetBlackjackValue())
				{
					return;
				}
				if (!Money.TryChangeBalance(-hand.bet, playerProfile, ChangeType.Bet))
				{
					_msg = playerProfile.playerName + ": not enough money to split";
					break;
				}
				Hand hand2 = new Hand
				{
					bet = hand.bet,
					fromSplit = true
				};
				hand.fromSplit = true;
				hand2.cards.Add(hand.cards[1]);
				hand2.objs.Add(hand.objs[1]);
				hand.cards.RemoveAt(1);
				hand.objs.RemoveAt(1);
				seat2.hands.Add(hand2);
				bool num = hand.cards[0].Rank == Rank.Ace;
				DealTo(hand, 1 + seat * 2);
				DealTo(hand2, 2 + seat * 2);
				if (num)
				{
					hand.splitAces = (hand2.splitAces = true);
					hand.done = (hand2.done = true);
					break;
				}
				if (Value(hand.cards) == 21)
				{
					hand.done = true;
				}
				if (Value(hand2.cards) == 21)
				{
					hand2.done = true;
				}
				break;
			}
			}
			_deadline = Time.time + BJ3Plugin.TurnTime.Value;
			Broadcast();
		}
	}

	[Server]
	private void Bet(int seat, PlayerProfile p)
	{
		Seat seat2 = _seats[seat];
		if (_ph != Phase.Betting)
		{
			return;
		}
		if (seat2.owner != null && seat2.owner != p)
		{
			_msg = $"Seat {seat + 1}: TAKEN ({seat2.owner.playerName})";
			Broadcast();
			return;
		}
		if (seat2.owner == p)
		{
			Money.TryChangeBalance(seat2.bet, p, ChangeType.Bet);
			seat2.owner = null;
			seat2.bet = BigNumber.Zero;
			_msg = $"{p.playerName} left seat {seat + 1}";
			Broadcast();
			return;
		}
		BigNumber bigNumber = base.currentBet;
		if (bigNumber < base.MinBet || bigNumber > base.MaxBet || !Money.TryChangeBalance(-bigNumber, p, ChangeType.Bet))
		{
			try
			{
				keypad.ServerInvalidBetAmountFb();
			}
			catch
			{
			}
			_msg = p.playerName + ": invalid bet or not enough money";
			Broadcast();
			return;
		}
		seat2.owner = p;
		seat2.bet = bigNumber;
		_msg = $"{p.playerName} bets {bigNumber} on seat {seat + 1}";
		if (_round == null)
		{
			_round = StartCoroutine(RoundRoutine());
		}
		Broadcast();
	}

	[Server]
	private void Deal(PlayerInteract pi)
	{
		PlayerProfile p = Prof(pi);
		BJ3Plugin.V($"DEAL pressed by {Name(p)} (phase {_ph})");
		if (_ph == Phase.Betting)
		{
			if (!_seats.Any((Seat s) => s.owner != null))
			{
				_msg = "Press BET at a seat first";
				Broadcast();
			}
			else
			{
				_dealPressed = true;
			}
		}
	}

	private IEnumerator RoundRoutine()
	{
		_ph = Phase.Betting;
		_dealPressed = false;
		float auto = BJ3Plugin.BetTime.Value;
		_deadline = ((auto > 0f) ? (Time.time + auto) : 0f);
		_msg = "Bets placed - press DEAL";
		while (!_dealPressed && (auto <= 0f || Time.time < _deadline))
		{
			if (!_seats.Any((Seat s) => s.owner != null))
			{
				_round = null;
				_msg = "Press BET at a seat";
				Broadcast();
				yield break;
			}
			yield return null;
		}
		_dealPressed = false;
		if (!_seats.Any((Seat s) => s.owner != null))
		{
			_round = null;
			yield break;
		}
		gameTurn++;
		_ph = Phase.Dealing;
		_msg = "Dealing...";
		if (_shoe.Count < 72)
		{
			Shuffle();
		}
		Seat[] seats = _seats;
		foreach (Seat seat in seats)
		{
			seat.hands.Clear();
			if (seat.owner != null)
			{
				seat.hands.Add(new Hand
				{
					bet = seat.bet
				});
			}
		}
		for (int r = 0; r < 2; r++)
		{
			for (int i = 0; i < 3; i++)
			{
				if (_seats[i].hands.Count > 0)
				{
					DealTo(_seats[i].hands[0], 1 + i * 2);
					Broadcast();
					yield return new WaitForSeconds(0.4f);
				}
			}
			DealDealer(r == 1);
			Broadcast();
			yield return new WaitForSeconds(0.4f);
		}
		seats = _seats;
		for (int num = 0; num < seats.Length; num++)
		{
			foreach (Hand hand in seats[num].hands)
			{
				if (Value(hand.cards) == 21)
				{
					hand.done = true;
					hand.result = "BLACKJACK";
				}
			}
		}
		bool dealerBJ = Value(_dealer) == 21;
		if (dealerBJ && (_dealer[0].Rank == Rank.Ace || _dealer[0].GetBlackjackValue() == 10))
		{
			_msg = "Dealer has BLACKJACK";
			Reveal();
			Broadcast();
			yield return new WaitForSeconds(1.2f);
		}
		else
		{
			dealerBJ = false;
			_ph = Phase.Playing;
			for (int r = 0; r < 3; r++)
			{
				for (int i = 0; i < _seats[r].hands.Count; i++)
				{
					Hand h = _seats[r].hands[i];
					if (!h.done)
					{
						_actSeat = r;
						_actHand = i;
						_deadline = Time.time + BJ3Plugin.TurnTime.Value;
						_msg = $"Seat {r + 1}: {Name(_seats[r].owner)}" + ((_seats[r].hands.Count > 1) ? $" (hand {i + 1})" : "");
						Broadcast();
						while (!h.done && Time.time < _deadline && _seats[r].owner != null)
						{
							yield return null;
						}
						if (!h.done)
						{
							h.done = true;
							_msg = $"Seat {r + 1}: time out - stand";
						}
						Broadcast();
						yield return new WaitForSeconds(0.3f);
					}
				}
			}
			BJ3Game bJ3Game = this;
			BJ3Game bJ3Game2 = this;
			int num = -1;
			bJ3Game2._actHand = -1;
			bJ3Game._actSeat = num;
			_ph = Phase.Dealer;
			_msg = "Dealer plays";
			Reveal();
			Broadcast();
			yield return new WaitForSeconds(0.8f);
			bool need = _seats.SelectMany((Seat s) => s.hands).Any((Hand hand) => Value(hand.cards) <= 21 && !(hand.result == "BLACKJACK"));
			while (need && Value(_dealer) < 17)
			{
				DealDealer(hidden: false);
				Broadcast();
				yield return new WaitForSeconds(0.8f);
			}
		}
		_ph = Phase.Results;
		int num2 = Value(_dealer);
		for (int num3 = 0; num3 < 3; num3++)
		{
			Seat seat2 = _seats[num3];
			foreach (Hand hand2 in seat2.hands)
			{
				int num4 = Value(hand2.cards);
				bool flag = hand2.result == "BLACKJACK" && !hand2.fromSplit;
				ChangeType changeType = ChangeType.GameResult;
				double num5;
				if (num4 > 21)
				{
					num5 = 0.0;
					hand2.result = "BUST";
				}
				else if (dealerBJ)
				{
					if (flag)
					{
						num5 = 1.0;
						changeType = ChangeType.Misc;
						hand2.result = "PUSH";
					}
					else
					{
						num5 = 0.0;
						hand2.result = "LOSE";
					}
				}
				else if (flag)
				{
					num5 = 2.5 * base.EstimatedValue;
					hand2.result = "BLACKJACK 3:2";
				}
				else if (num2 > 21 || num4 > num2)
				{
					num5 = 2.0 * base.EstimatedValue;
					hand2.result = "WIN";
				}
				else if (num4 == num2)
				{
					num5 = 1.0;
					changeType = ChangeType.Misc;
					hand2.result = "PUSH";
				}
				else
				{
					num5 = 0.0;
					hand2.result = "LOSE";
				}
				if (seat2.owner == null)
				{
					hand2.result += " (left)";
					continue;
				}
				try
				{
					interactingPlayer = seat2.owner;
					Payout(num5, changeType, new Dictionary<string, object>
					{
						{ "playerHandValue", num4 },
						{ "dealerHandValue", num2 },
						{ "seat", num3 }
					}, hand2.bet);
					if (num5 > 0.0)
					{
						hand2.result += $" +{hand2.bet * num5}";
					}
				}
				catch (Exception ex)
				{
					BJ3Plugin.Log.LogError("[BJ3] payout failed: " + ex);
				}
				BJ3Plugin.V($"Seat {num3 + 1} {Name(seat2.owner)}: {num4} vs dealer {num2} -> {hand2.result} (bet {hand2.bet}, x{num5:0.###})");
			}
			seat2.bet = BigNumber.Zero;
		}
		_msg = ((num2 > 21) ? "Dealer BUSTS" : $"Dealer: {num2}");
		Broadcast();
		yield return new WaitForSeconds(4f);
		Cleanup();
		seats = _seats;
		foreach (Seat obj in seats)
		{
			obj.owner = null;
			obj.hands.Clear();
		}
		interactingPlayer = null;
		_ph = Phase.Betting;
		_msg = "Place your bets";
		_round = null;
		Broadcast();
	}

	private static string Name(PlayerProfile p)
	{
		if (!(p != null))
		{
			return "-";
		}
		return p.playerName;
	}

	[Server]
	private void Shuffle()
	{
		_shoe.Clear();
		int num = Mathf.Clamp(BJ3Plugin.Decks.Value, 1, 8);
		for (int i = 0; i < num; i++)
		{
			foreach (Suit value2 in Enum.GetValues(typeof(Suit)))
			{
				foreach (Rank value3 in Enum.GetValues(typeof(Rank)))
				{
					_shoe.Add(new CardData(value2, value3));
				}
			}
		}
		System.Random seededRandom = GetSeededRandom(7777 + gameTurn);
		for (int num2 = _shoe.Count - 1; num2 > 0; num2--)
		{
			int index = seededRandom.Next(0, num2 + 1);
			CardData value = _shoe[num2];
			_shoe[num2] = _shoe[index];
			_shoe[index] = value;
		}
		BJ3Plugin.V($"Shoe shuffled: {_shoe.Count} cards");
	}

	private CardData Draw()
	{
		if (_shoe.Count == 0)
		{
			Shuffle();
		}
		CardData result = _shoe[0];
		_shoe.RemoveAt(0);
		return result;
	}

	[Server]
	private void DealTo(Hand h, int area)
	{
		CardData cardData = Draw();
		h.cards.Add(cardData);
		h.objs.Add(SpawnCard(cardData, area, hidden: false));
	}

	[Server]
	private void DealDealer(bool hidden)
	{
		CardData cardData = Draw();
		_dealer.Add(cardData);
		_dealerObjs.Add(SpawnCard(cardData, 0, hidden));
		if (hidden)
		{
			_holeHidden = true;
		}
	}

	[Server]
	private void Reveal()
	{
		if (!_holeHidden)
		{
			return;
		}
		_holeHidden = false;
		foreach (GameObject dealerObj in _dealerObjs)
		{
			if (dealerObj != null)
			{
				dealerObj.GetComponent<Card>()?.RpcSetFaceDown(faceDown: false);
			}
		}
	}

	[Server]
	private GameObject SpawnCard(CardData c, int area, bool hidden)
	{
		if (cardPrefab == null)
		{
			return null;
		}
		GameObject gameObject = UnityEngine.Object.Instantiate(cardPrefab);
		NetworkServer.Spawn(gameObject);
		Card component = gameObject.GetComponent<Card>();
		component?.ServerSetCardData(c);
		if (area < areas.Count && areas[area] != null)
		{
			gameObject.transform.SetParent(areas[area]);
			gameObject.transform.localPosition = Vector3.zero;
			gameObject.transform.localRotation = Quaternion.identity;
		}
		_pendingArea = area;
		component?.RpcSetFaceDown(hidden);
		return gameObject;
	}

	[Server]
	private void Cleanup()
	{
		foreach (GameObject item in _seats.SelectMany((Seat s) => s.hands).SelectMany((Hand h) => h.objs).Concat(_dealerObjs))
		{
			if (item != null)
			{
				NetworkServer.Destroy(item);
			}
		}
		_dealer.Clear();
		_dealerObjs.Clear();
		_holeHidden = false;
	}

	protected override void OnDisable()
	{
		try
		{
			if (!NetworkServer.active)
			{
				return;
			}
			Seat[] seats = _seats;
			foreach (Seat seat in seats)
			{
				if (!(seat.owner == null))
				{
					BigNumber bigNumber = ((seat.hands.Count > 0) ? seat.hands.Aggregate(BigNumber.Zero, (BigNumber a, Hand h) => a + h.bet) : seat.bet);
					if (_ph != Phase.Results && bigNumber > BigNumber.Zero)
					{
						Money.TryChangeBalance(bigNumber, seat.owner, ChangeType.Bet);
					}
					seat.owner = null;
					seat.bet = BigNumber.Zero;
					seat.hands.Clear();
				}
			}
			Cleanup();
		}
		catch
		{
		}
	}

	public static int Value(List<CardData> cards)
	{
		int num = 0;
		int num2 = 0;
		foreach (CardData card in cards)
		{
			if (card.Rank == Rank.Ace)
			{
				num2++;
				num += 11;
			}
			else
			{
				num += card.GetBlackjackValue();
			}
		}
		while (num > 21 && num2 > 0)
		{
			num -= 10;
			num2--;
		}
		return num;
	}

	private static string Txt(List<CardData> cards, int hideIdx = -1)
	{
		if (cards.Count == 0)
		{
			return "";
		}
		IEnumerable<string> values = cards.Select((CardData c, int i) => (i != hideIdx) ? (c.GetDisplayString() + "hdcs"[(int)c.Suit]) : "??");
		return string.Join(" ", values) + " = " + ((hideIdx >= 0) ? (Value(cards.Where((CardData c, int i) => i != hideIdx).ToList()) + "+?") : Value(cards).ToString());
	}

	[Server]
	private void Broadcast()
	{
		if (!NetworkServer.active)
		{
			return;
		}
		_nextBroadcast = Time.time + 1f;
		StateMsg stateMsg = new StateMsg
		{
			ph = (int)_ph,
            selectedBet = currentBet.ToString(),
			tl = Mathf.Max(0f, _deadline - Time.time),
			act = ((_actSeat < 0) ? (-1) : (_actSeat * 2 + _actHand)),
			msg = _msg,
			dl = Txt(_dealer, _holeHidden ? 1 : (-1)),
			dt = TotalText(_dealer, natural: true, _holeHidden ? 1 : (-1))
		};
		stateMsg.s = _seats.Select((Seat s) => new SeatSt
		{
			who = ((s.owner != null) ? s.owner.playerName : ""),
            owner = s.owner != null ? s.owner.netId : 0,
            occupied = s.owner != null,
			bet = ((s.owner == null) ? "" : ((s.hands.Count > 0) ? s.hands.Aggregate(BigNumber.Zero, (BigNumber a, Hand h) => a + h.bet) : s.bet).ToString()),
			nh = s.hands.Count,
			h0 = ((s.hands.Count > 0) ? Txt(s.hands[0].cards) : ""),
			h1 = ((s.hands.Count > 1) ? Txt(s.hands[1].cards) : ""),
			b0 = ((s.owner == null) ? "" : ((s.hands.Count > 0) ? s.hands[0].bet : s.bet).ToString()),
			b1 = ((s.owner != null && s.hands.Count > 1) ? s.hands[1].bet.ToString() : ""),
			t0 = ((s.hands.Count > 0) ? TotalText(s.hands[0].cards, !s.hands[0].fromSplit) : ""),
			t1 = ((s.hands.Count > 1) ? TotalText(s.hands[1].cards, natural: false) : ""),
			r0 = ((s.hands.Count > 0) ? s.hands[0].result : ""),
			r1 = ((s.hands.Count > 1) ? s.hands[1].result : "")
		}).ToArray();
		List<CardPos> cps = new List<CardPos>();
		Add(_dealerObjs, 0);
		for (int num = 0; num < 3; num++)
		{
			for (int num2 = 0; num2 < _seats[num].hands.Count; num2++)
			{
				Add(_seats[num].hands[num2].objs, 1 + num * 2 + num2);
			}
		}
		stateMsg.c = cps.ToArray();
		stateMsg.cs = string.Join("|", cps.Select((CardPos p) => $"{p.n},{p.a},{p.i},{p.c}"));
		if (!_csLogged && cps.Count > 0)
		{
			_csLogged = true;
			BJ3Plugin.V("Broadcast card layout: " + stateMsg.cs);
		}
		NetworkWriterPooled writer = NetworkWriterPool.Get();
		string json = StateCodec.Encode(stateMsg);
        // The host uses the same validated packet as remote clients.
        UserRpcState(json);
        writer.WriteString(json);
		SendRPCInternal("System.Void Blackjack3Hand.BJ3Game::UserRpcState(System.String)", "System.Void Blackjack3Hand.BJ3Game::UserRpcState(System.String)".GetStableHashCode(), writer, 0, includeOwner: true);
		NetworkWriterPool.Return(writer);
		void Add(List<GameObject> objs, int area)
		{
			for (int i = 0; i < objs.Count; i++)
			{
				NetworkIdentity networkIdentity = ((objs[i] != null) ? objs[i].GetComponent<NetworkIdentity>() : null);
				if (networkIdentity != null)
				{
					cps.Add(new CardPos
					{
						n = networkIdentity.netId,
						a = area,
						i = i,
						c = objs.Count
					});
				}
			}
		}
	}

	public void UserRpcState(string json)
	{
		try
		{
			_st = StateCodec.Decode(json);
			_stTime = Time.time;
		}
		catch (Exception ex)
		{
			BJ3Plugin.Log.LogError("[BJ3] bad state: " + ex.Message);
			return;
		}
		_cardTargets.Clear();
		if (!string.IsNullOrEmpty(_st.cs))
		{
			string[] array = _st.cs.Split('|');
			for (int i = 0; i < array.Length; i++)
			{
				string[] array2 = array[i].Split(',');
				if (array2.Length == 4 && uint.TryParse(array2[0], out var result) && int.TryParse(array2[1], out var result2) && int.TryParse(array2[2], out var result3) && int.TryParse(array2[3], out var result4))
				{
					_cardTargets[result] = (result2, result3, result4);
				}
			}
		}
		else if (_st.c != null)
		{
			CardPos[] c = _st.c;
			foreach (CardPos cardPos in c)
			{
				_cardTargets[cardPos.n] = (cardPos.a, cardPos.i, cardPos.c);
			}
		}
		if (!_rxLogged && _cardTargets.Count > 0)
		{
			_rxLogged = true;
			BJ3Plugin.V($"Client got {_cardTargets.Count} card targets");
		}
		Render();
	}

	public void Frame()
	{
		if (Time.frameCount == _lastFrame)
		{
			return;
		}
		_lastFrame = Time.frameCount;
		try
		{
			FrameInner();
		}
		catch (Exception ex)
		{
			if (Time.frameCount % 600 == 0)
			{
				BJ3Plugin.Log.LogError("[BJ3] frame error: " + ex);
			}
		}
	}

	private void FixKeypadScale()
	{
		if (Time.time < _kpCheck)
		{
			return;
		}
		_kpCheck = Time.time + 0.5f;
		if (_kp == null || !_kp)
		{
			_kp = ((keypad != null) ? keypad : GetComponentsInChildren<Keypad>(includeInactive: true).FirstOrDefault());
		}
		if (_kp == null)
		{
			return;
		}
		Transform transform = _kp.transform;
		Vector3 lossyScale = transform.lossyScale;
		if (Mathf.Abs(lossyScale.x - 1f) > 0.02f && lossyScale.x > 0.001f)
		{
			transform.localScale = new Vector3(transform.localScale.x / lossyScale.x, transform.localScale.y / lossyScale.y, transform.localScale.z / lossyScale.z);
			try
			{
				AccessTools.Method(typeof(Keypad), "RequestRender")?.Invoke(_kp, null);
			}
			catch
			{
			}
			BJ3Plugin.V($"Keypad kept at normal size (was {lossyScale.x:0.##}x because of TableScale)");
		}
	}

	private Keypad PickKeypad()
	{
		if (base.keypad != null)
		{
			return base.keypad;
		}
		Keypad[] array = UnityEngine.Object.FindObjectsByType<Keypad>(FindObjectsSortMode.None);
		foreach (Keypad keypad in array)
		{
			if (keypad != null && keypad.NetworkcasinoGame == this)
			{
				return keypad;
			}
		}
		return GetComponentsInChildren<Keypad>(includeInactive: true).FirstOrDefault();
	}

	[Server]
	private void KillDuplicateKeypads()
	{
		if (Time.time < _dupCheck || base.keypad == null)
		{
			return;
		}
		_dupCheck = Time.time + 2f;
		Keypad[] array = UnityEngine.Object.FindObjectsByType<Keypad>(FindObjectsSortMode.None);
		foreach (Keypad keypad in array)
		{
			if (!(keypad == null) && !(keypad == base.keypad))
			{
				GameBase networkcasinoGame = keypad.NetworkcasinoGame;
				if ((networkcasinoGame == null || !networkcasinoGame.gameObject.activeInHierarchy || networkcasinoGame is Blackjack) && (keypad.transform.position - base.keypad.transform.position).sqrMagnitude < 4f)
				{
					BJ3Plugin.Log.LogInfo(string.Format("[BJ3] Removing duplicate keypad '{0}' at {1} (game={2})", keypad.name, keypad.transform.position, (networkcasinoGame != null) ? networkcasinoGame.name : "none"));
					NetworkServer.Destroy(keypad.gameObject);
				}
			}
		}
	}

	private void DriveKeypadScreen() => DrawBetMonitor();

	private void FrameInner()
	{
		FixKeypadScale();
		if (NetworkServer.active)
		{
			try
			{
				KillDuplicateKeypads();
			}
			catch
			{
			}
		}
		try
		{
			DriveKeypadScreen();
		}
		catch (Exception ex)
		{
			if (Time.frameCount % 600 == 0)
			{
				BJ3Plugin.Log.LogError("[BJ3] keypad screen error: " + ex);
			}
		}
		if (BJ3Plugin.Instance != null)
		{
			BJ3Plugin.Instance.Tick();
		}
		if (NetworkServer.active)
		{
			try
			{
				ServerSeatWatch();
			}
			catch (Exception ex2)
			{
				if (Time.frameCount % 600 == 0)
				{
					BJ3Plugin.Log.LogError("[BJ3] seat watch: " + ex2);
				}
			}
		}
		if (NetworkServer.active && ((Time.time > _nextBroadcast && (_round != null || _st == null)) || Time.time > _nextBroadcast + 2f))
		{
			Broadcast();
		}
		if (!NetworkClient.active)
		{
			return;
		}
		if (NetworkServer.active)
		{
			_hostDone.Clear();
			Lay(_dealerObjs, 0);
			for (int i = 0; i < 3; i++)
			{
				for (int j = 0; j < _seats[i].hands.Count; j++)
				{
					Lay(_seats[i].hands[j].objs, 1 + i * 2 + j);
				}
			}
			if (!_fanLogged && _dealerObjs.Count >= 2)
			{
				_fanLogged = true;
				BJ3Plugin.V("Host fan: dealer cards at " + string.Join(" ", from o in _dealerObjs
					where o
					select o.transform.position.ToString("F2")));
			}
		}
		foreach (KeyValuePair<uint, (int, int, int)> cardTarget in _cardTargets)
		{
			if (_hostDone.Contains(cardTarget.Key) || !NetworkClient.spawned.TryGetValue(cardTarget.Key, out var value) || value == null)
			{
				continue;
			}
			var (num, i2, c) = cardTarget.Value;
			if (num < areas.Count && !(areas[num] == null))
			{
				Transform transform = value.transform;
				Transform transform2 = areas[num];
				if (transform.parent != transform2)
				{
					transform.SetParent(transform2, worldPositionStays: true);
				}
				transform.rotation = transform2.rotation;
				Vector3 target = CardWorld(num, i2, c, transform);
				transform.position = Vector3.MoveTowards(transform.position, target, Mathf.Max(cardMoveSpeed, 1f) * base.transform.lossyScale.x * Time.deltaTime);
			}
		}
		if (!_fanLogged && _cardTargets.Count >= 2)
		{
			_fanLogged = true;
			foreach (KeyValuePair<uint, (int, int, int)> cardTarget2 in _cardTargets)
			{
				var (num2, num3, num4) = cardTarget2.Value;
				BJ3Plugin.V(string.Format("  card {0} area {1} {2}/{3} -> {4} areaScale {5}", cardTarget2.Key, num2, num3 + 1, num4, (num2 < areas.Count && (bool)areas[num2]) ? CardWorld(num2, num3, num4, null).ToString("F3") : "?", (num2 < areas.Count && (bool)areas[num2]) ? areas[num2].lossyScale.ToString("F3") : "?"));
			}
		}
		Camera main = Camera.main;
		if (main != null)
		{
			foreach (TextMesh label in labels)
			{
				if (label != null)
				{
					Vector3 forward = label.transform.position - main.transform.position;
					forward.y = 0f;
					if (forward.sqrMagnitude > 0.0001f)
					{
						label.transform.rotation = Quaternion.LookRotation(forward);
					}
				}
			}
		}
		if (_st != null && Time.frameCount % 15 == 0)
		{
			Render();
		}
		try
		{
			UpdateTotals();
		}
		catch (Exception ex3)
		{
			if (Time.frameCount % 600 == 0)
			{
				BJ3Plugin.Log.LogError("[BJ3] totals error: " + ex3);
			}
		}
		try
		{
			UpdateChips();
			HideFloatingText();
		}
		catch (Exception ex4)
		{
			if (Time.frameCount % 600 == 0)
			{
				BJ3Plugin.Log.LogError("[BJ3] chips error: " + ex4);
			}
		}
		void Lay(List<GameObject> objs, int area)
		{
			for (int k = 0; k < objs.Count; k++)
			{
				GameObject gameObject = objs[k];
				if (!(gameObject == null) && area < areas.Count && !(areas[area] == null))
				{
					Transform transform3 = gameObject.transform;
					Transform transform4 = areas[area];
					if (transform3.parent != transform4)
					{
						transform3.SetParent(transform4, worldPositionStays: true);
					}
					transform3.rotation = transform4.rotation;
					transform3.position = Vector3.MoveTowards(transform3.position, CardWorld(area, k, objs.Count, transform3), Mathf.Max(cardMoveSpeed, 1f) * base.transform.lossyScale.x * Time.deltaTime);
					NetworkIdentity component = gameObject.GetComponent<NetworkIdentity>();
					if (component != null)
					{
						_hostDone.Add(component.netId);
					}
				}
			}
		}
	}

	private static string Clean(string s)
	{
		s = Regex.Replace(s, "</?size[^>]*>", "");
		return s.Replace("#ffd84a", "#ffd84aff").Replace("#5f5", "#55ff55ff").Replace("#ccc", "#ccccccff")
			.Replace("#f66", "#ff6666ff");
	}

	private void MeasureCard(Transform card)
	{
		if (_cardW > 0f || card == null)
		{
			return;
		}
		Renderer componentInChildren = card.GetComponentInChildren<Renderer>();
		if (!(componentInChildren == null))
		{
			Vector3 vector = Vector3.Scale(componentInChildren.localBounds.size, componentInChildren.transform.lossyScale);
			float[] array = new float[3]
			{
				Mathf.Abs(vector.x),
				Mathf.Abs(vector.y),
				Mathf.Abs(vector.z)
			}.OrderByDescending((float v) => v).ToArray();
			float x = base.transform.lossyScale.x;
			_cardL = Mathf.Clamp(array[0], 0.05f, 0.4f * x);
			_cardW = Mathf.Clamp(array[1], 0.04f, 0.3f * x);
			BJ3Plugin.V($"Card measured {_cardW:0.###} x {_cardL:0.###} m (local bounds {componentInChildren.localBounds.size}, scale {componentInChildren.transform.lossyScale})");
		}
	}

	private int HandsAt(int seat)
	{
		if (_st == null || _st.s == null || seat >= _st.s.Length)
		{
			return 1;
		}
		return Mathf.Max(1, _st.s[seat].nh);
	}

	private void SeatFrame(int area, out Vector3 center, out Vector3 right, out Vector3 toDealer, out float width)
	{
		Vector3 position = areas[0].position;
		right = ((areas.Count > 5 && (bool)areas[5] && (bool)areas[1]) ? (areas[5].position - areas[1].position) : base.transform.right);
		right.y = 0f;
		right.Normalize();
		if (area == 0)
		{
			center = position;
			toDealer = Vector3.zero;
			width = 1.6f * base.transform.lossyScale.x;
			Vector3 vector = (areas[3] ? (areas[3].position - position) : (-base.transform.forward));
			vector.y = 0f;
			toDealer = -vector.normalized;
			return;
		}
		int num = (area - 1) / 2;
		int num2 = (area - 1) % 2;
		Vector3 position2 = areas[1 + num * 2].position;
		float num3 = ((areas.Count > 3 && (bool)areas[3] && (bool)areas[1]) ? Vector3.Distance(Flat(areas[3].position), Flat(areas[1].position)) : 0.6f);
		toDealer = position - position2;
		toDealer.y = 0f;
		toDealer.Normalize();
		width = num3 * 0.94f;
		if (HandsAt(num) > 1)
		{
			width *= 0.5f;
			position2 += right * ((num2 == 0) ? (-1f) : 1f) * num3 * 0.25f;
		}
		center = position2;
	}

	private float StairStep(int area, int c, float cl)
	{
		float num = cl * 0.28f * BJ3Plugin.CardStair.Value;
		if (area == 0 || c <= 1 || areas[0] == null)
		{
			return num;
		}
		int num2 = (area - 1) / 2;
		Transform transform = areas[1 + num2 * 2];
		if (transform == null)
		{
			return num;
		}
		float num3 = Vector3.Distance(Flat(areas[0].position), Flat(transform.position));
		return Mathf.Min(num, Mathf.Max(0f, num3 * 0.5f - cl) / (float)(c - 1));
	}

	private static Vector3 Flat(Vector3 v)
	{
		v.y = 0f;
		return v;
	}

	private Vector3 CardWorld(int area, int i, int c, Transform card)
	{
		MeasureCard(card);
		float x = base.transform.lossyScale.x;
		float num = ((_cardW > 0f) ? _cardW : (0.17f * x));
		float cl = ((_cardL > 0f) ? _cardL : (0.24f * x));
		SeatFrame(area, out var center, out var right, out var toDealer, out var width);
		float num2 = num * ((area == 0) ? 1.08f : 0.42f) * BJ3Plugin.CardGap.Value;
		float num3 = Mathf.Max(width - num, 0f);
		if (c > 1 && (float)(c - 1) * num2 > num3)
		{
			num2 = Mathf.Max(num3 / (float)(c - 1), num * 0.25f);
		}
		float num4 = ((c <= 1) ? 0f : ((float)(-(c - 1)) * num2 / 2f + (float)i * num2));
		float num5 = ((area == 0) ? 0f : ((float)i * StairStep(area, c, cl)));
		return center + right * num4 + toDealer * num5 + Vector3.up * (0.004f * (float)i);
	}

	private string LocalTotal(int a)
	{
		List<(int, CardData)> list = new List<(int, CardData)>();
		foreach (KeyValuePair<uint, (int, int, int)> cardTarget in _cardTargets)
		{
			if (cardTarget.Value.Item1 == a && NetworkClient.spawned.TryGetValue(cardTarget.Key, out var value) && !(value == null))
			{
				Card component = value.GetComponent<Card>();
				if (!(component == null))
				{
					list.Add((cardTarget.Value.Item2, component.NetworkcardData));
				}
			}
		}
		if (list.Count == 0)
		{
			return "";
		}
		int seat = (a - 1) / 2;
		bool flag = HandsAt(seat) > 1;
		return TotalText((from x in list
			orderby x.Item1
			select x.Item2).ToList(), !flag);
	}

	private void UpdateTotals()
	{
		if (_st == null) return;
		_handTot[0] = _st.dt ?? "";
		for (int i = 1; i < 7; i++)
		{
			var seat = _st.s != null && (i - 1) / 2 < _st.s.Length ? _st.s[(i - 1) / 2] : null;
			_handTot[i] = LocalTotal(i);
			if (string.IsNullOrEmpty(_handTot[i]) && seat != null) _handTot[i] = (i - 1) % 2 == 0 ? seat.t0 : seat.t1;
		}
		HideFloatingText(); DrawTableLabels();
	}

	[Server]
	private void ServerSeatWatch()
	{
		if (Time.time < _nextSeatWatch)
		{
			return;
		}
		_nextSeatWatch = Time.time + 0.5f;
		float num = BJ3Plugin.WalkAwayDistance.Value * Mathf.Max(1f, base.transform.lossyScale.x);
		for (int i = 0; i < 3; i++)
		{
			Seat seat = _seats[i];
			if ((object)seat.owner == null)
			{
				_awaySince[i] = 0f;
			}
			else if (seat.owner == null)
			{
				seat.owner = null;
				_awaySince[i] = 0f;
				_msg = $"Seat {i + 1} is free (player left)";
				foreach (Hand hand in seat.hands)
				{
					hand.done = true;
				}
				if (_ph == Phase.Betting)
				{
					seat.bet = BigNumber.Zero;
				}
				BJ3Plugin.Log.LogInfo($"[BJ3] Seat {i + 1}: owner disconnected - seat freed");
				Broadcast();
			}
			else
			{
				if (num <= 0f)
				{
					continue;
				}
				float num2 = Vector3.Distance(Flat(seat.owner.transform.position), Flat(base.transform.position));
				if (num2 <= num)
				{
					_awaySince[i] = 0f;
				}
				else if (_awaySince[i] <= 0f)
				{
					_awaySince[i] = Time.time;
				}
				else
				{
					if (Time.time - _awaySince[i] < 4f)
					{
						continue;
					}
					_awaySince[i] = 0f;
					if (_ph == Phase.Betting)
					{
						try
						{
							if (seat.bet > BigNumber.Zero)
							{
								Money.TryChangeBalance(seat.bet, seat.owner, ChangeType.Bet);
							}
						}
						catch
						{
						}
						_msg = $"{seat.owner.playerName} walked away - seat {i + 1} is free (bet refunded)";
						BJ3Plugin.Log.LogInfo($"[BJ3] Seat {i + 1}: {seat.owner.playerName} walked away ({num2:0.0} m) - refunded and freed");
						seat.owner = null;
						seat.bet = BigNumber.Zero;
						Broadcast();
					}
					else
					{
						if (_ph != Phase.Playing || _actSeat != i)
						{
							continue;
						}
						foreach (Hand hand2 in seat.hands)
						{
							hand2.done = true;
						}
						_msg = $"Seat {i + 1}: {seat.owner.playerName} walked away - stand";
						Broadcast();
					}
				}
			}
		}
	}

	private static Material ChipMat(int i)
	{
		if (_chipMats == null)
		{
			_chipMats = new Material[ChipCol.Length];
			Shader shader = Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard") ?? Shader.Find("Universal Render Pipeline/Unlit") ?? Shader.Find("Unlit/Color");
			for (int j = 0; j < ChipCol.Length; j++)
			{
				Material material = new Material(shader)
				{
					name = "BJ3_Chip" + j
				};
				material.color = ChipCol[j];
				if (material.HasProperty("_BaseColor"))
				{
					material.SetColor("_BaseColor", ChipCol[j]);
				}
				if (material.HasProperty("_Smoothness"))
				{
					material.SetFloat("_Smoothness", 0.55f);
				}
				_chipMats[j] = material;
			}
		}
		return _chipMats[i % _chipMats.Length];
	}

	private static int ChipCount(string bet)
	{
		if (!double.TryParse((bet ?? "").Replace(",", "").Replace("$", ""), NumberStyles.Float, CultureInfo.InvariantCulture, out var result) || result <= 0.0)
		{
			return 3;
		}
		return Mathf.Clamp(2 + (int)Math.Floor(Math.Log(result, 2.0) * 0.8), 2, 12);
	}

	public static string ChipText(string bet)
	{
		return "$" + bet;
	}

	private void UpdateChips()
	{
		if (_st == null || areas.Count < 7 || areas[0] == null)
		{
			return;
		}
		float num = base.transform.lossyScale.x * BJ3Plugin.ChipSize.Value;
		float num2 = ((_cardL > 0f) ? _cardL : (0.24f * base.transform.lossyScale.x));
		Camera main = Camera.main;
		for (int i = 1; i < 7; i++)
		{
			int num3 = (i - 1) / 2;
			int num4 = (i - 1) % 2;
			SeatSt seatSt = ((_st.s != null && num3 < _st.s.Length) ? _st.s[num3] : null);
			string text = null;
			if (seatSt != null && !string.IsNullOrEmpty(seatSt.who))
			{
				text = ((seatSt.nh <= 1) ? ((num4 != 0) ? null : (string.IsNullOrEmpty(seatSt.b0) ? seatSt.bet : seatSt.b0)) : ((num4 == 0) ? seatSt.b0 : seatSt.b1));
			}
			Stack stack = _stacks[i];
			if (string.IsNullOrEmpty(text) || areas[1 + num3 * 2] == null)
			{
				if (stack != null && stack.root.activeSelf)
				{
					stack.root.SetActive(value: false);
				}
				continue;
			}
			if (stack == null)
			{
				Stack[] stacks = _stacks;
				int num5 = i;
				Stack obj = new Stack
				{
					root = new GameObject($"BJ3_Chips{i}")
				};
				Stack stack2 = obj;
				stacks[num5] = obj;
				stack = stack2;
				stack.root.transform.SetParent(base.transform, worldPositionStays: true);
				GameObject gameObject = new GameObject("BJ3_ChipLabel");
				gameObject.transform.SetParent(stack.root.transform, worldPositionStays: false);
				TextMesh textMesh = (stack.label = gameObject.AddComponent<TextMesh>());
				Font font = BJ3Plugin.LabelFont();
				if (font != null)
				{
					textMesh.font = font;
					gameObject.GetComponent<MeshRenderer>().sharedMaterial = font.material;
				}
				textMesh.anchor = TextAnchor.LowerCenter;
				textMesh.alignment = TextAlignment.Center;
				textMesh.fontSize = 96;
				textMesh.fontStyle = FontStyle.Bold;
				textMesh.richText = true;
				textMesh.color = new Color(1f, 0.85f, 0.3f);
			}
			if (!stack.root.activeSelf)
			{
				stack.root.SetActive(value: true);
			}
			SeatFrame(i, out var center, out var _, out var toDealer, out var _);
			Vector3 position = center - toDealer * (num2 * 0.95f) + Vector3.up * 0.002f;
			Transform transform = stack.root.transform;
			transform.position = position;
			transform.rotation = Quaternion.LookRotation((toDealer.sqrMagnitude > 0.0001f) ? toDealer : base.transform.forward, Vector3.up);
			transform.localScale = Vector3.one * (1f / Mathf.Max(0.001f, base.transform.lossyScale.x));
			int num6 = ChipCount(text);
			if (stack.last != text)
			{
				stack.last = text;
				while (stack.chips.Count < num6)
				{
					GameObject gameObject2 = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
					gameObject2.name = "BJ3_Chip";
					Collider component = gameObject2.GetComponent<Collider>();
					if (component != null)
					{
						UnityEngine.Object.Destroy(component);
					}
					gameObject2.transform.SetParent(transform, worldPositionStays: false);
					gameObject2.GetComponent<MeshRenderer>().shadowCastingMode = ShadowCastingMode.Off;
					stack.chips.Add(gameObject2.transform);
				}
				float num7 = 0.075f * num;
				float num8 = 0.011f * num;
				System.Random random = new System.Random(i * 31 + num6);
				for (int j = 0; j < stack.chips.Count; j++)
				{
					Transform transform2 = stack.chips[j];
					bool flag = j < num6;
					transform2.gameObject.SetActive(flag);
					if (flag)
					{
						transform2.localScale = new Vector3(num7, num8 * 0.5f, num7);
						transform2.localPosition = new Vector3((float)(random.NextDouble() - 0.5) * num7 * 0.08f, num8 * ((float)j + 0.5f), (float)(random.NextDouble() - 0.5) * num7 * 0.08f);
						transform2.GetComponent<MeshRenderer>().sharedMaterial = ChipMat((j % 3 == 2) ? 5 : ((num6 + j / 3) % 5));
					}
				}
				stack.label.text = ChipText(text);
				stack.label.characterSize = 0.012f * num;
				stack.label.transform.localPosition = new Vector3(0f, num8 * (float)num6 + 0.03f * num, 0f);
			}
			if (main != null)
			{
				Transform transform3 = stack.label.transform;
				Vector3 forward = transform3.position - main.transform.position;
				forward.y = 0f;
				if (forward.sqrMagnitude > 0.0001f)
				{
					transform3.rotation = Quaternion.LookRotation(forward);
				}
			}
		}
	}

	public static string TotalText(List<CardData> cards, bool natural, int hideIdx = -1)
	{
		List<CardData> list = ((hideIdx >= 0) ? cards.Where((CardData c, int i) => i != hideIdx).ToList() : cards);
		if (list.Count == 0)
		{
			return "";
		}
		int num = 0;
		int num2 = 0;
		foreach (CardData item in list)
		{
			if (item.Rank == Rank.Ace)
			{
				num2++;
				num++;
			}
			else
			{
				num += item.GetBlackjackValue();
			}
		}
		int num3 = Value(list);
		if (num3 > 21)
		{
			return "BUST";
		}
		if (natural && list.Count == 2 && num3 == 21)
		{
			return "BJ";
		}
		string text = ((num2 > 0 && num + 10 <= 21 && num3 != num && num3 != 21) ? $"{num}/{num3}" : num3.ToString());
		if (hideIdx < 0)
		{
			return text;
		}
		return text + "+?";
	}

	private Vector3 CardLocal(int area, int i, int c)
	{
		float num = cardSpacing * ((area == 0) ? DealerCardFan : SeatCardFan);
		if (area != 0 && c > 5)
		{
			num = num * 5f / (float)c;
		}
		return new Vector3((c <= 1) ? 0f : ((float)(-(c - 1)) * num / 2f + (float)i * num), 0.004f * (float)i, 0f);
	}

	private void Render()
	{
		if (_st == null) return;
		HideFloatingText(); DrawTableLabels(); DrawButtonLabels(); DrawBetMonitor();
		for (int seat = 0; seat < 3; seat++)
		{
			SeatSt state = _st.s != null && seat < _st.s.Length ? _st.s[seat] : null;
			bool occupied = SeatViewPolicy.Occupied(state);
			for (int button = 0; button < 5 && seat * 5 + button < seatButtons.Count; button++)
			{
				var trigger = seatButtons[seat * 5 + button]; if (trigger == null) continue;
				foreach (var text in trigger.GetComponentsInChildren<TMP_Text>(true))
				{
					if (button == 0) text.text = occupied ? "ЗАНЯТА" : "СТАВКА";
					if(_displayFont!=null)text.font=_displayFont;text.color=Color.white;
                    FitButtonText(text, trigger.transform);
				}
				if (button == 0) MarkOccupied(trigger, occupied);
			}
		}
	}
}
