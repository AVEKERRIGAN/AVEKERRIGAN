using System;

namespace Blackjack3Hand;

[Serializable]
public class StateMsg
{
	public int ph;
    public string selectedBet;

	public float tl;

	public int act;

	public string dl;

	public string msg;

	public SeatSt[] s;

	public CardPos[] c;

	public int[] hide;

	public string cs;

	public string dt;
}
