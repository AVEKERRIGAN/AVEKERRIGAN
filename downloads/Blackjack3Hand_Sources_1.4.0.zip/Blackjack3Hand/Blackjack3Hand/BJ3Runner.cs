using UnityEngine;

namespace Blackjack3Hand;

public class BJ3Runner : MonoBehaviour
{
	public static BJ3Runner Inst;

	private void Awake()
	{
		Inst = this;
	}

	private void LateUpdate()
	{
		for (int num = BJ3Game.All.Count - 1; num >= 0; num--)
		{
			BJ3Game bJ3Game = BJ3Game.All[num];
			if (bJ3Game != null)
			{
				bJ3Game.Frame();
			}
		}
	}

	private void Update()
	{
		if (BJ3Plugin.Instance != null)
		{
			BJ3Plugin.Instance.Tick();
		}
	}
}
