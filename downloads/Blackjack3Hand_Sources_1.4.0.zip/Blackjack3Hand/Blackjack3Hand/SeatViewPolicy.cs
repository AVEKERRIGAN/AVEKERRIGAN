namespace Blackjack3Hand;
public static class SeatViewPolicy
{
    public static bool Occupied(SeatSt seat)=>seat!=null&&(seat.occupied||seat.owner!=0);
    public static bool Mine(SeatSt seat,uint local)=>local!=0&&Occupied(seat)&&seat.owner==local;
}
