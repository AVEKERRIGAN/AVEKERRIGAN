using System;
using Newtonsoft.Json;
namespace Blackjack3Hand;
// Managed serialization is required for nested classes from a dynamically loaded mod.
public static class StateCodec
{
    static readonly JsonSerializerSettings Settings = new JsonSerializerSettings { TypeNameHandling = TypeNameHandling.None, MaxDepth = 16 };
    public static string Encode(StateMsg state) => JsonConvert.SerializeObject(state, Settings);
    public static StateMsg Decode(string json)
    {
        if (string.IsNullOrEmpty(json) || json.Length > 65536) throw new ArgumentException("Invalid blackjack state size");
        var state = JsonConvert.DeserializeObject<StateMsg>(json, Settings);
        if (state == null || state.s == null || state.s.Length != 3 || Array.Exists(state.s, s => s == null)) throw new ArgumentException("Incomplete blackjack seat state");
        return state;
    }
}
