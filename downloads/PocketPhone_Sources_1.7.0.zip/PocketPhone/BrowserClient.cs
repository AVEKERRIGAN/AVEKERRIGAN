using System;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
namespace PocketPhone;
public sealed class BrowserClient
{
    sealed class Session
    {
        public readonly BlockingCollection<string> Commands = new(128);
        public readonly TaskCompletionSource<bool> Done = new(TaskCreationOptions.RunContinuationsAsynchronously);
        public Process Process; public volatile bool Stop;
        public byte[] Frame,SharedFrame;public readonly ConcurrentQueue<byte[]> Audio=new();public int AudioCount; public string Status = "Запускаю браузер…",BrowserName=""; public volatile bool Ready;
    }
    Session _session; Task _previous = Task.CompletedTask;
    public string Status => _session?.Status ?? "Телефон выключен";
    public bool Ready => _session?.Ready ?? false;
    public string BrowserName => _session?.BrowserName ?? "";
    public bool Running => _session != null;
    public byte[] Frame() { var s = _session; return s != null ? Interlocked.Exchange(ref s.Frame, null) : null; }
    public byte[] SharedFrame(){var s=_session;return s!=null?Interlocked.Exchange(ref s.SharedFrame,null):null;}
    public byte[] Audio(){var s=_session;if(s==null||!s.Audio.TryDequeue(out var pcm))return null;Interlocked.Decrement(ref s.AudioCount);return pcm;}
    public void Start(string helper, string profile,string browser="auto",string executable="",bool guestMode=true)
    {
        if (_session != null) return;
        var session = new Session(); _session = session; var previous = _previous;
        Task.Run(async () =>
        {
            try
            {
                await previous;
                if(session.Stop)return;
                if (!File.Exists(helper)) throw new FileNotFoundException("Не найден PhoneBrowser.exe. Распакуйте всю папку PocketPhone.");
                var info = new ProcessStartInfo { FileName = helper, Arguments = PhoneProtocol.Quote(profile) + " " + Process.GetCurrentProcess().Id+" --browser "+PhoneProtocol.Quote(browser)+" --browser-path "+PhoneProtocol.Quote(executable)+" --guest-mode "+(guestMode?"true":"false"), UseShellExecute = false, CreateNoWindow = true, RedirectStandardInput = true, RedirectStandardOutput = true, RedirectStandardError = true, StandardOutputEncoding = Encoding.UTF8, StandardErrorEncoding = Encoding.UTF8 };
                var process = Process.Start(info); session.Process = process;
                process.ErrorDataReceived += (_, _) => { }; process.BeginErrorReadLine();
                _ = Task.Run(() =>
                {
                    try
                    {
                        using var input = new StreamWriter(process.StandardInput.BaseStream, new UTF8Encoding(false));
                        foreach (string command in session.Commands.GetConsumingEnumerable()) { if(session.Stop && command != "{\"type\":\"close\"}")continue; input.WriteLine(command); input.Flush(); }
                    }
                    catch { }
                });
                string line;
                while ((line = process.StandardOutput.ReadLine()) != null)
                {
                    if (line.Length > 1500000 || session.Stop) continue;
                    try
                    {
                        var json = JObject.Parse(line); string kind = (string)json["type"];
                        if (kind == "frame") { byte[] bytes = Convert.FromBase64String((string)json["data"]); if (bytes.Length <= 1000000) Interlocked.Exchange(ref session.Frame, bytes); }
                        else if(kind=="shareframe"){byte[] bytes=Convert.FromBase64String((string)json["data"]??"");if(bytes.Length<=96*1024)Interlocked.Exchange(ref session.SharedFrame,bytes);}
                        else if(kind=="audio"){byte[] bytes=Convert.FromBase64String((string)json["data"]??"");if(bytes.Length==960&&Interlocked.Increment(ref session.AudioCount)<=25)session.Audio.Enqueue(bytes);else if(bytes.Length==960)Interlocked.Decrement(ref session.AudioCount);}
                        else if(kind=="audio_status")session.Status=(string)json["text"]??"Звук друзьям недоступен";
                        else if (kind == "ready") {session.BrowserName=(string)json["browser"]??"";session.Ready = true;}
                        else if (kind == "status") { string text = (string)json["text"] ?? ""; session.Status = text.Length > 240 ? text.Substring(0, 240) : text; }
                    }
                    catch { }
                }
                session.Ready = false;
                if (!session.Stop) session.Status = "Браузер закрылся. Нажмите «Перезапуск».";
            }
            catch (Exception e) { session.Ready = false; session.Status = e.Message; }
            finally { session.Ready = false; session.Done.TrySetResult(true); }
        });
    }
    public void Send(object message)
    {
        var session = _session; if (session == null || session.Stop) return;
        try { session.Commands.TryAdd(JsonConvert.SerializeObject(message)); } catch (InvalidOperationException) { }
    }
    public void Stop()
    {
        var session = _session; _session = null; if (session == null) return;
        session.Stop = true; _previous = session.Done.Task;
        try { session.Commands.TryAdd("{\"type\":\"close\"}"); session.Commands.CompleteAdding(); } catch { }
        Task.Run(async () =>
        {
            await Task.Delay(20000);
            try { var p = session.Process; if (p != null) { if (!p.HasExited) p.Kill(); p.Dispose(); } } catch { }
        });
    }
}
