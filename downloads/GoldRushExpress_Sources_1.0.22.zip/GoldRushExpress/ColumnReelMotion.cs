using System;
namespace GoldRushExpress
{
    public static class ColumnReelMotion
    {
        public static int Travel(float duration,int rows)=>Math.Max(rows+1,(int)Math.Round(duration*4.5f));
        public static CellReelMotion.StripSlot Slot(float position,int image)
        {int index=(int)Math.Floor(position)+1-image;return new CellReelMotion.StripSlot(index,index-position);}
        public static int FinalRow(int index,int travel,int rows)
        {int row=travel-index;return row>=0&&row<rows?row:-1;}
        public static int InitialRow(int index,int rows)
        {int row=-index;return row>=0&&row<rows?row:-1;}
    }
}
