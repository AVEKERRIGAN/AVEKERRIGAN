using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace GoldRushExpress
{
    /// Themed cabinet: gold/purple tint, logo topper and animated side light strips (client-side cosmetic objects).
    public partial class TrainGame
    {
        readonly List<SpriteRenderer> _strips = new List<SpriteRenderer>();

        static Texture2D _marqueeTex;

        void BuildCabinet()
        {
            var skip = new List<Transform>();
            if (keypadSpawnPoint != null) skip.Add(keypadSpawnPoint);
            foreach (var b in new[] { turboButton, buyButton, betMinusButton, betPlusButton }.Concat(playButtons)) if (b != null) skip.Add(b.transform);
            if (_ui != null) skip.Add(_ui);
            if (payoutText != null) skip.Add(payoutText.transform);
            var rends = GetComponentsInChildren<Renderer>(true).Where(r => !(r is ParticleSystemRenderer) && !(r is SpriteRenderer) && !skip.Any(t => r.transform == t || r.transform.IsChildOf(t))).ToList();
            int tint = 0, marq = 0;
            foreach (var r in rends)
            {
                var mats = r.materials; bool ch = false;
                foreach (var m in mats)
                {
                    if (m == null) continue;
                    if (m.HasProperty("_AlbedoMap") && m.GetTexture("_AlbedoMap") != null && !(m.GetTexture("_AlbedoMap") is RenderTexture))
                    {   // vanilla neon marquee atlas (generic slot sign): UV-matched themed replacement with the slot's name (Puppy Palace 1.6.2 pattern)
                        if (_marqueeTex == null) _marqueeTex = LoadPng("topscreen");
                        if (_marqueeTex != null) { m.SetTexture("_AlbedoMap", _marqueeTex); ch = true; marq++; }
                        continue;
                    }
                    string colProp = m.HasProperty("_BaseColor") ? "_BaseColor" : m.HasProperty("_Color") ? "_Color" : null;
                    string mainProp = m.HasProperty("_BaseMap") ? "_BaseMap" : m.HasProperty("_MainTex") ? "_MainTex" : null;
                    if (colProp == null) continue;
                    if (mainProp != null && m.GetTexture(mainProp) is RenderTexture) continue;
                    string ln = (m.name + " " + r.name).ToLowerInvariant();
                    if (ln.Contains("glass") || ln.Contains("light") || ln.Contains("ligts") || ln.Contains("screen")) continue;
                    var col = m.GetColor(colProp); float lum = col.r * .3f + col.g * .59f + col.b * .11f;
                    var target = lum > .6f ? new Color(.95f, .88f, .72f) : lum > .25f ? new Color(.85f, .5f, .2f) : new Color(.22f, .16f, .14f); // dust / copper / iron
                    m.SetColor(colProp, new Color(target.r, target.g, target.b, col.a)); ch = true; tint++;
                }
                if (ch) r.materials = mats;
            }
            TrainPlugin.V($"Cabinet themed on original body: {tint} tinted slots, marquee={marq}");
        }

        static void SetWorldScale(Transform t, float s)
        {
            var p = t.parent != null ? t.parent.lossyScale : Vector3.one;
            t.localScale = new Vector3(s / Mathf.Max(1e-4f, Mathf.Abs(p.x)), s / Mathf.Max(1e-4f, Mathf.Abs(p.y)), s / Mathf.Max(1e-4f, Mathf.Abs(p.z)));
        }

        void UpdateCabinetFx()
        {
            if (_strips.Count == 0) return;
            float t = Time.time * (_anim != null ? 2.2f : .8f);
            for (int i = 0; i < _strips.Count; i++)
                if (_strips[i] != null) _strips[i].color = Color.Lerp(Color.white, new Color(.75f, .85f, 1f), .5f + .5f * Mathf.Sin(t * 2f + i * 1.5f));
        }
    }
}
