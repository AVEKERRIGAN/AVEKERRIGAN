using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
namespace GoldRushExpress
{
    public partial class TrainGame
    {
        // One strip per column, clipped only at the reel's top and bottom.
        // Held symbols have opaque backs above the moving strip.
        sealed class ReelColumn
        {
            readonly RectTransform root;
            readonly Image[] targets,images;
            readonly TMP_Text[] values,labels;
            readonly Vector2[] homes;
            readonly bool bonus;
            readonly float step,width,artSize,cellSize;
            readonly int seed;
            static readonly string[] FillerLabels={"x2","x5","x8","x12","x25","x50"};
            Sprite[] initial,final,fillers;
            Color[] initialColor,finalColor;
            Style[] finalStyle;
            bool[] moving; bool running;
            float duration;int travel;
            struct Style
            {
                public string Text;public Vector2 Position,Size;public Vector4 Margin;public Color Color;public float Font;
            }
            public ReelColumn(TrainGame game,RectTransform parent,Image[] targets,TMP_Text[] values,Vector2[] homes,float step,float width,float size,bool bonus,int seed)
            {
                this.targets=targets;this.values=values;this.homes=homes;this.step=step;this.width=width;this.bonus=bonus;this.seed=seed;
                cellSize=size;artSize=size*(bonus?.74f:.78f);
                var go=new GameObject("ReelColumn"+seed,typeof(RectTransform),typeof(RectMask2D));root=(RectTransform)go.transform;
                root.SetParent(parent,false);go.layer=parent.gameObject.layer;
                Place(root,new Vector2(homes[0].x,0),new Vector2(width*.95f,step*targets.Length));root.SetAsFirstSibling();
                images=new Image[targets.Length+2];labels=new TMP_Text[images.Length];
                for(int i=0;i<images.Length;i++)
                {
                    images[i]=Img("Strip"+i,root);Place(images[i].rectTransform,Vector2.zero,Vector2.one*artSize);images[i].preserveAspect=true;
                    labels[i]=game.Txt("Value"+i,images[i].transform,Gold);labels[i].text="";
                }
                go.SetActive(false);
            }
            public void Begin(bool[] move,Sprite[] result,Sprite[] filler,float seconds,Sprite[] from=null)
            {
                moving=move;fillers=filler;duration=seconds;travel=ColumnReelMotion.Travel(seconds,targets.Length);
                initial=new Sprite[targets.Length];final=new Sprite[targets.Length];finalStyle=new Style[targets.Length];
                initialColor=new Color[targets.Length];finalColor=new Color[targets.Length];
                for(int row=0;row<targets.Length;row++)
                {
                    initial[row]=moving[row]?(from!=null?from[row]:targets[row].sprite):Spr("sym_empty");
                    final[row]=moving[row]?result[row]:Spr("sym_empty");
                    initialColor[row]=bonus?new Color(1,1,1,.55f):targets[row].color;finalColor[row]=targets[row].color;
                    var value=values[row];if(moving[row]&&value!=null)
                    {
                        var offset=value.rectTransform.anchoredPosition;
                        if(value.transform.parent!=targets[row].transform)offset=(Vector2)targets[row].transform.InverseTransformPoint(value.rectTransform.position);
                        finalStyle[row]=new Style{Text=value.text,Position=offset,Size=value.rectTransform.sizeDelta,Margin=value.margin,Color=value.color,Font=value.fontSizeMax};
                    }
                    if(!moving[row])continue;
                    targets[row].sprite=result[row];targets[row].gameObject.SetActive(false);
                    if(value!=null&&value.transform.parent!=targets[row].transform)value.gameObject.SetActive(false);
                }
                running=true;root.gameObject.SetActive(true);Draw(0);
            }
            public void Draw(float elapsed)
            {
                if(!running)return;
                float pos=CellReelMotion.Position(elapsed,duration,travel);
                for(int i=0;i<images.Length;i++)
                {
                    var slot=ColumnReelMotion.Slot(pos,i);int endRow=ColumnReelMotion.FinalRow(slot.Index,travel,targets.Length);
                    int startRow=ColumnReelMotion.InitialRow(slot.Index,targets.Length),pick=Math.Abs(slot.Index+seed*3)%fillers.Length;
                    var image=images[i];var label=labels[i];
                    image.sprite=endRow>=0?final[endRow]:startRow>=0?initial[startRow]:fillers[pick];
                    image.color=endRow>=0?finalColor[endRow]:startRow>=0?initialColor[startRow]:Color.white;image.rectTransform.anchoredPosition=new Vector2(0,homes[0].y+slot.Offset*step);
                    image.rectTransform.localScale=Vector3.one;
                    Style style=default;
                    if(endRow>=0)style=finalStyle[endRow];
                    else if(bonus&&startRow<0)
                    {
                        string fillerText=FillerLabels[(Math.Abs(slot.Index+seed))%6];
                        bool card=pick>=3;var box=card?TrainPresentation.CardValue:TrainPresentation.CoinValueFor(pick==2?25:2);
                        style=new Style{Text=fillerText,Position=new Vector2(box.X*cellSize,box.Y*cellSize),Size=new Vector2(box.Width*cellSize,box.Height*cellSize),Color=new Color(1f,.93f,.65f),Font=cellSize*TrainPresentation.ValueFont};
                        if(pick==1)style.Text=""; // Empty gear has no value.
                    }
                    label.text=style.Text??"";
                    if(label.text.Length>0)
                    {
                        Place(label.rectTransform,style.Position,style.Size);label.margin=style.Margin;label.color=style.Color;
                        label.enableAutoSizing=false;label.fontSizeMax=style.Font;label.fontSize=style.Font;
                        label.fontStyle=FontStyles.Bold;
                    }
                }
            }
            public void Finish()
            {
                if(running)
                {
                    Draw(duration);
                    for(int row=0;row<targets.Length;row++)if(moving[row])
                    {
                        targets[row].gameObject.SetActive(true);targets[row].rectTransform.anchoredPosition=bonus?Vector2.zero:homes[row];targets[row].rectTransform.localScale=Vector3.one;
                        if(values[row]!=null&&values[row].transform.parent!=targets[row].transform)values[row].gameObject.SetActive(true);
                    }
                }
                running=false;root.gameObject.SetActive(false);
            }
        }
        readonly ReelColumn[] _columns=new ReelColumn[C],_bonusColumns=new ReelColumn[BC];
        readonly Image[] _baseHeldBack=new Image[N],_bonusHeldBack=new Image[BN];
        void BuildColumns(bool bonus)
        {
            var cells=bonus?_bcell:_cell;var values=bonus?_bval:_cellVal;var home=bonus?_bhome:_home;
            var grid=bonus?_bgrid:_grid;var columns=bonus?_bonusColumns:_columns;var backs=bonus?_bonusHeldBack:_baseHeldBack;
            float step=bonus?_bch:_ch,width=bonus?_bcw:_cw,size=bonus?_bcs:_cs;
            for(int c=0;c<columns.Length;c++)
            {
                var col=new Image[R];var val=new TMP_Text[R];var positions=new Vector2[R];
                for(int row=0;row<R;row++){int i=c*R+row;col[row]=cells[i];val[row]=values[i];positions[row]=home[i];}
                columns[c]=new ReelColumn(this,grid,col,val,positions,step,width,size,bonus,c);
            }
            for(int i=0;i<cells.Length;i++)
            {
                var back=Img("HeldBack"+i,grid,Spr("px"));back.preserveAspect=false;back.color=new Color(.07f,.06f,.065f,1);
                Place(back.rectTransform,home[i],new Vector2(width*.95f,step*.95f));back.transform.SetSiblingIndex(bonus?cells[i].transform.parent.GetSiblingIndex():cells[i].transform.GetSiblingIndex());
                back.gameObject.SetActive(false);backs[i]=back;
            }
            // Thin rails hide the texture's row gaps without clipping each icon into a box.
            for(int row=1;row<R;row++)
            {
                var rail=Img("RowRail"+row,grid,Spr("px"));rail.preserveAspect=false;rail.color=new Color(.16f,.125f,.12f);
                Place(rail.rectTransform,new Vector2(0,step*(R*.5f-row)),new Vector2(width*columns.Length,step*.035f));
            }
        }
        void ClearHeldBacks()
        {foreach(var b in _baseHeldBack)if(b!=null)b.gameObject.SetActive(false);foreach(var b in _bonusHeldBack)if(b!=null)b.gameObject.SetActive(false);}
    }
}
