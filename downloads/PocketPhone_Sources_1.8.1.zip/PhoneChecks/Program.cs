using System.Collections.Concurrent;
using System.Diagnostics;
using System.Text.Json;
using PocketPhone;
using PhoneBrowser;

int assertions=0;
void Check(bool value,string name){assertions++;if(!value)throw new Exception(name);}
async Task Until(Func<bool> test,string name,int ms=15000)
{var sw=Stopwatch.StartNew();while(!test()){if(sw.ElapsedMilliseconds>ms)throw new Exception("Timeout: "+name);await Task.Delay(50);}assertions++;}
foreach(string invalid in new[]{"javascript:alert(1)","file:///c:/test","http://tiktok.com","https://user:pass@tiktok.com","tiktok.com","",null})Check(!PhoneProtocol.Website(invalid,out _),"reject unsafe URL");
Check(PhoneProtocol.Website("https://www.instagram.com/reels/?a=1",out var valid)&&valid.Contains("instagram.com"),"valid HTTPS");
Check(PhoneProtocol.Point(100,200,100,200,216,384,out int x,out int y)&&x==0&&y==0,"top left");
Check(PhoneProtocol.Point(315.99f,583.99f,100,200,216,384,out x,out y)&&x==431&&y==767,"bottom right");
Check(!PhoneProtocol.Point(316,200,100,200,216,384,out _,out _),"outside right");
Check(!PhoneProtocol.Point(99,200,100,200,216,384,out _,out _),"outside left");
Check(!PhoneProtocol.Point(100,200,100,200,0,384,out _,out _),"zero width");
var controls=new[]{PhoneLayout.TikTok,PhoneLayout.Instagram,PhoneLayout.Close,PhoneLayout.Back,PhoneLayout.Keyboard,PhoneLayout.Sound,PhoneLayout.Settings,PhoneLayout.Spin};
foreach(var button in controls)
{
 Check(button.X>=0&&button.Y>=0&&button.X+button.W<=PhoneLayout.Width&&button.Y+button.H<=PhoneLayout.Height,"control inside display");
 Check(button.X+button.W<=PhoneLayout.Web.X||button.X>=PhoneLayout.Web.X+PhoneLayout.Web.W||button.Y+button.H<=PhoneLayout.Web.Y||button.Y>=PhoneLayout.Web.Y+PhoneLayout.Web.H,"controls do not cover browser viewport");
}
for(int i=0;i<controls.Length;i++)for(int j=i+1;j<controls.Length;j++)
{
 var a=controls[i];var b=controls[j];Check(a.X+a.W<=b.X||b.X+b.W<=a.X||a.Y+a.H<=b.Y||b.Y+b.H<=a.Y,"controls do not overlap");
}
Check(PhoneLayout.WebPoint(PhoneLayout.Web.X,PhoneLayout.Web.Y,out x,out y)&&x==0&&y==0,"world display maps browser top left");
Check(PhoneLayout.WebPoint(PhoneLayout.Web.X+PhoneLayout.Web.W-.01f,PhoneLayout.Web.Y+PhoneLayout.Web.H-.01f,out x,out y)&&x==431&&y==767,"world display maps browser bottom right");
Check(!PhoneLayout.WebPoint(PhoneLayout.Back.X+1,PhoneLayout.Back.Y+1,out _,out _),"toolbar clicks never enter browser");
Check(Math.Abs(PhoneLayout.Web.W/PhoneLayout.Web.H-(float)PhoneProtocol.Width/PhoneProtocol.Height)<1e-6f,"browser preserves portrait ratio");
foreach(int fps in new[]{24,60,144})
{
 float previous=0;bool monotonic=true;
 for(int frame=0;frame<=fps;frame++){float current=PhoneLayout.Smooth((float)frame/fps);monotonic&=current>=previous-1e-6f&&current>=0&&current<=1;previous=current;}
 Check(monotonic&&previous==1,"reveal animation bounded at "+fps+" FPS");
 float remaining=1;for(int frame=0;frame<fps;frame++)remaining*=1-PhoneLayout.Follow(1f/fps,.1f);
 Check(Math.Abs(remaining-Math.Exp(-10))<1e-6,"motion smoothing independent of frame rate");
}
Check(PhoneLayout.Smooth(-1)==0&&PhoneLayout.Smooth(2)==1,"reveal clamps interruptions");
Check(PhoneLayout.Pulse(0)==0&&PhoneLayout.Pulse(.28f)==0&&PhoneLayout.Pulse(.14f)>.9999,"tap animation starts and ends at rest");
foreach(float fov in new[]{45f,60f,90f,110f})foreach(float fraction in new[]{.34f,.77f})
{
 float scale=PhoneLayout.Scale(fov,.45f,fraction,.212f);
 float viewport=scale*.212f/(2*.45f*(float)Math.Tan(fov*Math.PI/360));
 Check(Math.Abs(viewport-fraction)<1e-6,"phone size stable across FOV");
}

// Selection is tested independently of Windows registry APIs; actual browser versions need Windows.
string chrome=@"C:\Program Files\Google\Chrome\Application\chrome.exe",edge=@"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe";
string yandex=@"C:\Users\Тест\AppData\Local\Yandex\YandexBrowser\Application\browser.exe";
string opera=@"C:\Users\Тест\AppData\Local\Programs\Opera GX\125.0.1.9\opera.exe";
var installed=new[]{chrome,edge,yandex,opera};bool Exists(string path)=>installed.Contains(path);
Check(BrowserFinder.Choose("auto","",yandex,installed,Exists).Family=="yandex","Windows default wins over Edge priority");
Check(BrowserFinder.Choose("auto","",opera,installed,Exists).Family=="operagx","default Opera GX");
Check(BrowserFinder.Choose("edge","",yandex,installed,Exists).Executable==edge,"manual browser overrides default");
Check(BrowserFinder.Choose("auto",chrome,yandex,installed,Exists).Executable==chrome,"portable path override");
Check(BrowserFinder.Choose("auto","",@"C:\Firefox\firefox.exe",installed,Exists).Family=="chrome","unsupported default falls back");
foreach(var (name,path) in new[]{("chrome",chrome),("edge",edge),("yandex",yandex),("operagx",opera),("opera",@"D:\Opera\opera.exe"),("brave",@"D:\Brave\brave.exe"),("vivaldi",@"D:\Vivaldi\vivaldi.exe"),("chromium",@"D:\Chromium\Application\chrome.exe")})
 Check(BrowserFinder.Identify(path,_=>true)?.Family==name,"identify "+name);
Check(BrowserFinder.Identify(@"D:\Unknown\browser.exe",_=>true)==null,"do not launch unrelated browser.exe");
Check(BrowserFinder.CommandExecutable("\""+yandex+"\" --single-argument \"%1\"")==yandex,"registry command extracts EXE only");
Check(BrowserFinder.CommandExecutable(chrome+" -- \"%1\"")==chrome,"unquoted registry EXE with spaces");
bool refused=false;try{BrowserFinder.Choose("firefox","",null,installed,Exists);}catch(IOException){refused=true;}Check(refused,"unsupported explicit choice reports error");
string launcherRoot=Path.Combine(Path.GetTempPath(),"phone-opera-"+Guid.NewGuid().ToString("N"));
try{
 foreach(string version in new[]{"99.0.0.0","125.0.0.0"}){Directory.CreateDirectory(Path.Combine(launcherRoot,version));File.WriteAllText(Path.Combine(launcherRoot,version,"opera.exe"),"");}
 Check(BrowserFinder.ResolveLauncher(Path.Combine(launcherRoot,"launcher.exe"))==Path.Combine(launcherRoot,"125.0.0.0","opera.exe"),"Opera launches latest executable rather than exiting launcher");
}finally{Directory.Delete(launcherRoot,true);}
JsonElement Command(object value){using var j=JsonDocument.Parse(JsonSerializer.Serialize(value));return j.RootElement.Clone();}
var inbox=new CommandInbox();
for(int i=0;i<10000;i++)inbox.Push(Command(new{type="scroll",x=10,y=20,delta=i}));
Check(inbox.Count==1,"wheel burst cannot create a backlog");
inbox.Push(Command(new{type="click",x=10,y=20}));inbox.Push(Command(new{type="scroll",x=10,y=20,delta=9}));
Check(inbox.Count==3,"coalescing keeps click barrier order");
Check((await inbox.Next(default)).Value.GetProperty("delta").GetInt32()==9999,"latest wheel survives stall");
Check((await inbox.Next(default)).Value.GetProperty("type").GetString()=="click","click kept in order");
await inbox.Next(default);
for(int i=0;i<CommandInbox.Capacity;i++)Check(inbox.Push(Command(new{type="key",key="Enter"})),"bounded command slot");
Check(!inbox.Push(Command(new{type="key",key="Tab"})),"inbox bounded");
Check(inbox.Push(Command(new{type="close"}))&&inbox.Count==1,"close preempts full inbox");
Check((await inbox.Next(default)).Value.GetProperty("type").GetString()=="close"&&await inbox.Next(default)==null,"close terminates reader");
foreach(int fps in new[]{30,60,144}){
 var gesture=new ScrollInput();int events=0,total=0;
 for(int i=0;i<fps;i++){gesture.Add(100,100,2,(double)i/fps);if(gesture.Take((double)i/fps,out _,out _,out int d)){events++;total+=d;}}
 if(gesture.Take(1.08,out _,out _,out int tail)){events++;total+=tail;}
 Check(events<=14&&total==fps*2,"wheel aggregation at "+fps+" FPS");
 gesture.Add(100,100,400,2);gesture.Reset();Check(!gesture.Take(2,out _,out _,out _),"closed screen discards pending wheel");
}

string Unquote(string argument)
{
 var b=new System.Text.StringBuilder();bool quoted=false;
 for(int i=0;i<argument.Length;){int slash=0;while(i<argument.Length&&argument[i]=='\\'){slash++;i++;}if(i<argument.Length&&argument[i]=='"'){b.Append('\\',slash/2);if(slash%2==1)b.Append('"');else quoted=!quoted;i++;}else{b.Append('\\',slash);if(i<argument.Length)b.Append(argument[i++]);}}
 return b.ToString();
}
foreach(string value in new[]{"","normal","C:\\Games\\GWYF mods\\profile\\","C:\\path\\with\"quotes", "a\nb\t$()`test", "кириллица\\"})Check(Unquote(PhoneProtocol.Quote(value))==value,"Windows quoting");
string root=args.Length>0?Path.GetFullPath(args[0]):Path.GetFullPath(Path.Combine(AppContext.BaseDirectory,"../../../..")),profile=Path.Combine(Path.GetTempPath(),"phone-integration-"+Guid.NewGuid().ToString("N"));
string helper=Path.Combine(root,"PhoneBrowser/test-dist/PhoneBrowser");
using var process=new Process{StartInfo=new ProcessStartInfo(helper){UseShellExecute=false,RedirectStandardInput=true,RedirectStandardOutput=true,RedirectStandardError=true}};
process.StartInfo.ArgumentList.Add(profile);process.StartInfo.ArgumentList.Add("0");process.StartInfo.ArgumentList.Add("--test-headless");
process.Start();var messages=new ConcurrentQueue<string>();int frames=0;byte[] latest=null,sharedLatest=null;int sharedFrames=0,invalidFrameSize=0;bool ready=false;
var reader=Task.Run(async()=>{string line;while((line=await process.StandardOutput.ReadLineAsync())!=null){using var j=JsonDocument.Parse(line);var t=j.RootElement.GetProperty("type").GetString();if(t=="ready")ready=true;else if(t=="frame"){latest=Convert.FromBase64String(j.RootElement.GetProperty("data").GetString());if(!SharedFrames.TryJpegSize(latest,out int width,out int height)||width!=PhoneProtocol.Width||height!=PhoneProtocol.Height)Interlocked.Increment(ref invalidFrameSize);Interlocked.Increment(ref frames);}else if(j.RootElement.GetProperty("type").GetString()=="shareframe"){var data=Convert.FromBase64String(j.RootElement.GetProperty("data").GetString());if(data.Length>0){sharedLatest=data;Interlocked.Increment(ref sharedFrames);}}else if(j.RootElement.TryGetProperty("text",out var text))messages.Enqueue(text.GetString());}});
var error=process.StandardError.ReadToEndAsync();
async Task Send(object command){await process.StandardInput.WriteLineAsync(JsonSerializer.Serialize(command));await process.StandardInput.FlushAsync();}
try
{
 await Until(()=>ready,"browser ready",40000);
 var portFile=Path.Combine(profile,"DevToolsActivePort");int port=int.Parse(File.ReadLines(portFile).First());
 using var http=new HttpClient();using var targets=JsonDocument.Parse(await http.GetStringAsync("http://127.0.0.1:"+port+"/json/list"));
 string socket=targets.RootElement.EnumerateArray().First(t=>t.GetProperty("type").GetString()=="page").GetProperty("webSocketDebuggerUrl").GetString();
 await using var cdp=new Cdp();await cdp.Connect(socket);
 await cdp.Call("Page.enable");var frame=await cdp.Call("Page.getFrameTree");string id=frame.GetProperty("frameTree").GetProperty("frame").GetProperty("id").GetString();
 string html="<meta name='viewport' content='width=device-width,initial-scale=1'><body style='margin:0;background:#28a6cb;height:5000px'><button id=b style='position:absolute;left:20px;top:40px;width:160px;height:70px' onclick='window.clicks=(window.clicks||0)+1'>Comments</button><textarea id=t style='position:absolute;left:20px;top:140px;width:300px;height:80px'></textarea><div style='position:absolute;top:700px;width:100%;height:2000px;background:linear-gradient(red,yellow)'></div></body>";
 await cdp.Call("Page.setDocumentContent",new{frameId=id,html});
 await Send(new{type="click",x=80,y=70});
 async Task<string> Eval(string exp){var r=await cdp.Call("Runtime.evaluate",new{expression=exp,returnByValue=true});return r.GetProperty("result").GetProperty("value").ToString();}
 var sw=Stopwatch.StartNew();while(await Eval("window.clicks||0")!="1"){if(sw.Elapsed.TotalSeconds>10)throw new Exception("click not delivered");await Task.Delay(50);}assertions++;
 await Send(new{type="click",x=100,y=170});await Send(new{type="text",text="привет TikTok"});await Send(new{type="key",key="Backspace"});
 sw.Restart();while(await Eval("document.getElementById('t').value")!="привет TikTo"){if(sw.Elapsed.TotalSeconds>10)throw new Exception("text input/backspace");await Task.Delay(50);}assertions++;
 await Send(new{type="scroll",x=200,y=600,delta=550});
 sw.Restart();while(int.Parse(await Eval("Math.round(window.scrollY)"))<100){if(sw.Elapsed.TotalSeconds>10)throw new Exception("scroll");await Task.Delay(50);}assertions++;
 await Send(new{type="volume",value=.27});
 sw.Restart();while(await Eval("window.__pocketPhoneVolume")!="0.27"){if(sw.Elapsed.TotalSeconds>10)throw new Exception("volume");await Task.Delay(50);}assertions++;
 await Until(()=>frames>=3&&latest!=null,"live frames");
 Check(latest[0]==255&&latest[1]==216,"JPEG frame");await File.WriteAllBytesAsync(Path.Combine(root,"phone-test-frame.jpg"),latest);

 // Intercept real HTTPS navigation with a local fixture: same host/routing hooks, no live-site claim.
 string feedHtml="""
 <meta name="viewport" content="width=device-width,initial-scale=1"><body style="margin:0;height:5000px;background:#132234">
 <video style="position:fixed;left:0;top:0;width:350px;height:690px;background:#314654"></video>
 <button data-e2e="video-switch-next" style="position:fixed;right:12px;top:50px;width:50px;height:50px" onclick="window.feedIndex=(window.feedIndex||0)+1">Next</button>
 <button data-e2e="video-switch-prev" style="position:fixed;right:12px;top:120px;width:50px;height:50px" onclick="window.feedIndex=(window.feedIndex||0)-1">Previous</button>
 <button id="open-comments" style="position:fixed;right:12px;top:190px;width:60px;height:45px" onclick="document.getElementById('comments').style.display='block'">Comments</button>
 <div id="comments" data-e2e="comment-list" role="dialog" style="display:none;position:fixed;left:90px;top:270px;width:330px;height:360px;overflow:auto;background:white"><div style="height:2000px">Comment list</div></div>
 </body>
 """;
 string cardsHtml="""
 <meta name="viewport" content="width=device-width,initial-scale=1"><body style="margin:0;height:2600px">
 <article data-e2e="recommend-list-item-container" style="height:700px"><video style="width:432px;height:700px;background:blue"></video></article>
 <article data-e2e="recommend-list-item-container" style="height:700px;margin-top:100px"><video style="width:432px;height:700px;background:green"></video></article>
 </body>
 """;
 cdp.Event+=(method,data)=>{if(method=="Fetch.requestPaused"){
   string url=data.GetProperty("request").GetProperty("url").GetString();
   string content=url.Contains("following")?cardsHtml:feedHtml;
   _=cdp.Call("Fetch.fulfillRequest",new{requestId=data.GetProperty("requestId").GetString(),responseCode=200,responseHeaders=new[]{new{name="Content-Type",value="text/html; charset=utf-8"}},body=Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(content))});
 }};
 await cdp.Call("Fetch.enable",new{patterns=new[]{new{urlPattern="https://www.tiktok.com/*",requestStage="Request"},new{urlPattern="https://www.instagram.com/*",requestStage="Request"}}});
 foreach(string site in new[]{"https://www.tiktok.com/foryou","https://www.instagram.com/reels/"}){
  await Send(new{type="navigate",url=site});
  sw.Restart();while(await Eval("location.href==="+JsonSerializer.Serialize(site)+" && document.readyState==='complete' && !!window.__pocketPhoneFeed && !!document.querySelector('[data-e2e=video-switch-next]')")!="True"){if(sw.Elapsed.TotalSeconds>10)throw new Exception("feed fixture navigation/injection");await Task.Delay(50);}assertions++;
  Check(await Eval("innerWidth===432&&innerHeight===768&&visualViewport.scale===1")=="True","fixed viewport size without mobile page zoom");
  await Send(new{type="scroll",x=100,y=100,delta=360});
  sw.Restart();while(await Eval("window.feedIndex||0")!="1"){if(sw.Elapsed.TotalSeconds>10)throw new Exception("feed advances via native button");await Task.Delay(50);}assertions++;
  for(int i=0;i<30;i++)await Send(new{type="scroll",x=100,y=100,delta=360});
  await Task.Delay(300);Check(await Eval("window.feedIndex") == "1"&&await Eval("window.scrollY")=="0","wheel burst neither skips many videos nor shifts page");
  await Send(new{type="click",x=399,y=211});
  sw.Restart();while(await Eval("getComputedStyle(document.getElementById('comments')).display")!="block"){if(sw.Elapsed.TotalSeconds>10)throw new Exception("comment opener");await Task.Delay(50);}assertions++;
  await Send(new{type="scroll",x=200,y=450,delta=250});
  sw.Restart();while(await Eval("document.getElementById('comments').scrollTop")!="250"){if(sw.Elapsed.TotalSeconds>10)throw new Exception("comment scroll routing");await Task.Delay(50);}assertions++;
  await cdp.Call("Runtime.evaluate",new{expression="document.getElementById('comments').scrollTop=2000"});
  await Send(new{type="scroll",x=200,y=450,delta=900});await Task.Delay(150);
  Check(await Eval("window.feedIndex") == "1"&&await Eval("window.scrollY")=="0","end of comments cannot scroll feed");
  await Task.Delay(550);await cdp.Call("Runtime.evaluate",new{expression="window.scrollTo(0,400)"});
  sw.Restart();while(await Eval("window.scrollY")!="0"){if(sw.Elapsed.TotalSeconds>5)throw new Exception("root viewport anchor");await Task.Delay(30);}assertions++;
  await cdp.Call("Runtime.evaluate",new{expression="document.getElementById('comments').style.display='none'"});
  await Send(new{type="scroll",x=100,y=100,delta=-360});
  sw.Restart();while(await Eval("window.feedIndex")!="0"){if(sw.Elapsed.TotalSeconds>5)throw new Exception("previous video");await Task.Delay(30);}assertions++;
 }

 // A feed without buttons retains native key shortcuts without browser default scrolling.
 await cdp.Call("Runtime.evaluate",new{expression="document.querySelectorAll('[data-e2e=video-switch-next],[data-e2e=video-switch-prev]').forEach(e=>e.remove());window.addEventListener('keydown',e=>{if(e.key==='ArrowDown')window.feedIndex++;});"});
 await Task.Delay(550);await Send(new{type="scroll",x=100,y=100,delta=360});
 sw.Restart();while(await Eval("window.feedIndex")!="1"){if(sw.Elapsed.TotalSeconds>5)throw new Exception("native key fallback");await Task.Delay(30);}assertions++;
 await Task.Delay(700);Check(await Eval("window.scrollY")=="0","native key fallback has no page-scroll default");
 await Send(new{type="scroll",x=100,y=100,delta=360,sent=DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()-2000});await Task.Delay(150);
 Check(await Eval("window.feedIndex")=="1","stalled old wheel command is discarded");

 // Clicking the site's own SVG-labelled pager is intentional navigation, not accidental scrolling.
 await cdp.Call("Runtime.evaluate",new{expression="let b=document.createElement('button');b.style='position:fixed;right:12px;top:50px;width:50px;height:50px';b.innerHTML='<svg aria-label=\"Next\" width=30 height=30></svg>';b.onclick=()=>{window.feedIndex++;window.scrollTo(0,120);};document.body.appendChild(b);"});
 await Send(new{type="click",x=400,y=75});
 sw.Restart();while(await Eval("window.feedIndex")!="2"||await Eval("window.scrollY")!="120"){if(sw.Elapsed.TotalSeconds>5)throw new Exception("manual native pager click");await Task.Delay(30);}assertions++;
 await Task.Delay(800);await cdp.Call("Runtime.evaluate",new{expression="window.scrollTo(0,400)"});await Task.Delay(100);
 Check(await Eval("window.scrollY")=="120","intentional native pagination preserves new anchor");
 await Send(new{type="navigate",url="https://www.tiktok.com/following"});
 sw.Restart();while(await Eval("document.querySelectorAll('article').length")!="2"){if(sw.Elapsed.TotalSeconds>10)throw new Exception("card fixture");await Task.Delay(30);}
 await Send(new{type="scroll",x=150,y=300,delta=360});
 sw.Restart();while(int.Parse(await Eval("Math.round(window.scrollY)"))<740){if(sw.Elapsed.TotalSeconds>10)throw new Exception("feed card snap");await Task.Delay(30);}assertions++;
 await Task.Delay(800);int cardAnchor=int.Parse(await Eval("Math.round(window.scrollY)"));
 await cdp.Call("Runtime.evaluate",new{expression="window.scrollBy(0,77)"});await Task.Delay(100);
 Check(int.Parse(await Eval("Math.round(window.scrollY)"))==cardAnchor,"completed card stays anchored");

 // New compact desktop TikTok layout: native wheel listener, one mounted video,
 // no pager and a sidebar that otherwise clips the portrait display.
 await Send(new{type="navigate",url="https://www.tiktok.com/@desktop/video/123"});
 sw.Restart();while(await Eval("location.pathname==='/@desktop/video/123' && !!window.__pocketPhoneFeed && document.readyState==='complete'")!="True"){if(sw.Elapsed.TotalSeconds>10)throw new Exception("desktop feed fixture");await Task.Delay(30);}
 await cdp.Call("Runtime.evaluate",new{expression="document.body.innerHTML=`<nav data-e2e=side-nav style=\"position:fixed;left:0;top:0;width:90px;height:768px;background:white\">Desktop sidebar</nav><main style=\"margin-left:90px;width:600px;background:white\"><article><div class=DivPlayerContainer style=\"width:530px;height:680px\"><video src=\"https://example.invalid/first.mp4\" style=\"width:530px;height:680px;object-fit:cover\"></video></div></article></main>`;window.feedIndex=0;window.addEventListener('wheel',e=>{window.feedIndex+=e.deltaY>0?1:-1;document.querySelector('video').src='https://example.invalid/clip'+window.feedIndex+'.mp4';});window.keyAdvances=0;window.addEventListener('keydown',e=>{if(e.key==='ArrowDown')window.keyAdvances++;});"});
 await Task.Delay(250);
 Check(await Eval("getComputedStyle(document.querySelector('nav')).display==='none'")=="True","compact desktop sidebar removed from feed");
 Check(await Eval("document.querySelector('main').getBoundingClientRect().left===0 && document.querySelector('main').getBoundingClientRect().right<=innerWidth")=="True","feed fits portrait width");
 Check(await Eval("getComputedStyle(document.querySelector('video')).objectFit==='contain' && document.querySelector('video').getBoundingClientRect().right<=innerWidth")=="True","video content contained without clipping");
 Check(await Eval("matchMedia('(prefers-color-scheme: dark)').matches && getComputedStyle(document.body).backgroundColor==='rgb(8, 9, 13)'")=="True","native dark media preference and dark feed background");
 await Send(new{type="scroll",x=200,y=320,delta=360});
 sw.Restart();while(await Eval("window.feedIndex")!="1"){if(sw.Elapsed.TotalSeconds>5)throw new Exception("native wheel-only feed");await Task.Delay(30);}assertions++;
 await Task.Delay(300);Check(await Eval("window.keyAdvances===0 && window.scrollY===0")=="True","successful native wheel never double-advances or scrolls the page");
 await Task.Delay(550);await Send(new{type="scroll",x=200,y=320,delta=-360});
 sw.Restart();while(await Eval("window.feedIndex")!="0"){if(sw.Elapsed.TotalSeconds>5)throw new Exception("wheel previous video");await Task.Delay(30);}assertions++;
 // An extra offset wrapper and an offscreen native action rail reproduce the supplied screenshot.
 await cdp.Call("Runtime.evaluate",new{expression="document.body.innerHTML=`<nav data-e2e=side-nav style=\"width:90px;position:fixed\">Sidebar</nav><div style=\"margin-left:86px;position:relative\"><main style=\"margin-left:90px;width:720px\"><article><div class=DivPlayerContainer style=\"width:530px;height:680px\"><video style=\"width:530px;height:680px\"></video></div><div id=actions style=\"position:absolute;left:520px;top:200px;width:60px\"><button data-e2e=like-icon>Like</button><button data-e2e=comment-icon>Comment</button><button data-e2e=share-icon>Repost</button></div></article></main></div>`;"});
 await Task.Delay(250);
 Check(await Eval("document.getElementById('actions').getBoundingClientRect().left>=0 && document.getElementById('actions').getBoundingClientRect().right<=60")=="True","like comment repost rail is fully visible on the left");
 Check(await Eval("document.querySelector('video').getBoundingClientRect().left>=60 && document.querySelector('video').getBoundingClientRect().right<=innerWidth")=="True","remaining sidebar offset removed from nested wrapper");
 await Until(()=>sharedFrames>0&&sharedLatest!=null,"public video emitted through helper IPC");Check(SharedFrames.SafeJpeg(sharedLatest),"actual shared screenshot is a bounded JPEG");
 await Task.Delay(1200);Check(invalidFrameSize==0,"sharing public video never changes the full phone compositor dimensions");
 string playerBounds=await Eval("JSON.stringify(document.querySelector('video').getBoundingClientRect().toJSON())");await Task.Delay(1200);Check(await Eval("JSON.stringify(document.querySelector('video').getBoundingClientRect().toJSON())")==playerBounds,"idle feed geometry does not pulse or enlarge on a timer");
 Check(await Eval("window.__pocketPhoneFeed.sharedVideo().width<=innerWidth && window.__pocketPhoneFeed.sharedVideo().height<=innerHeight")=="True","shared public video rectangle fits the viewport");
 // A separate cover and nested transformed video reproduce the doubled/offset screenshot.
 await cdp.Call("Runtime.evaluate",new{expression="document.querySelector('article').innerHTML=`<div class=DivVideoContainer style=\"width:530px;height:680px;position:relative\"><img id=poster class=VideoCover style=\"position:absolute;width:530px;height:680px\"><div class=DivVideoWrapper style=\"width:530px;height:680px;transform:translateX(70px)\"><div class=DivPlayerContainer style=\"width:530px;height:680px\"><video style=\"width:530px;height:680px;position:absolute;left:70px;transform:scale(1.2)\"></video></div></div></div><div id=actions><button data-e2e=like-icon>Like</button><button data-e2e=comment-icon>Comment</button></div>`;"});
 await Task.Delay(250);
 Check(await Eval("document.querySelectorAll('.pp-player').length===1 && document.querySelector('.pp-player').classList.contains('DivVideoContainer')")=="True","nested video wrappers share one outer stage");
 Check(await Eval("getComputedStyle(document.getElementById('poster')).display==='none'")=="True","separate cover cannot appear beside the video");
 Check(await Eval("(()=>{let v=document.querySelector('video').getBoundingClientRect(),p=document.querySelector('.pp-player').getBoundingClientRect();return Math.abs(v.left-p.left)<1 && Math.abs(v.top-p.top)<1 && Math.abs(v.width-p.width)<1 && Math.abs(v.height-p.height)<1 && v.right<=innerWidth;})()")=="True","nested transforms and widths never offset or crop the video");
 Check(await Eval("getComputedStyle(document.querySelector('video')).objectFit==='contain' && getComputedStyle(document.querySelector('video')).transform==='none'")=="True","video keeps its natural aspect ratio in one stage");
 await cdp.Call("Runtime.evaluate",new{expression="document.querySelector('.pp-player').innerHTML='<div class=DivVideoWrapper style=\"width:600px;transform:translateX(80px)\"><video style=\"position:absolute;left:90px;width:600px;height:900px\"></video></div>';"});
 await Task.Delay(250);
 Check(await Eval("(()=>{let v=document.querySelector('video').getBoundingClientRect();return v.left>=64 && v.right<=innerWidth && document.querySelectorAll('.pp-player').length===1;})()")=="True","replaced feed media is fitted once without stale player classes");
 await cdp.Call("Runtime.evaluate",new{expression="let d=document.createElement('div');d.id='privacy-login';d.setAttribute('role','dialog');d.style='position:fixed;inset:0;background:white;z-index:100';document.body.appendChild(d);"});
 Check(await Eval("window.__pocketPhoneFeed.sharedVideo()===null")=="True","login/dialog content is never selected for sharing");
 await Task.Delay(400);int beforePrivate=sharedFrames;await Task.Delay(400);Check(sharedFrames==beforePrivate,"helper stops emitting public frames while login dialog covers the video");
 await cdp.Call("Runtime.evaluate",new{expression="document.getElementById('privacy-login').remove();"});
 // Single video in a scrolling feed must use its actual scroll container.
 await cdp.Call("Runtime.evaluate",new{expression="document.body.innerHTML='<main id=feed-scroll style=\"position:fixed;inset:0;overflow-y:auto;height:768px\"><video style=\"display:block;width:400px;height:700px\"></video><div style=\"height:1600px\">More cards</div></main>';"});
 await Task.Delay(550);await Send(new{type="scroll",x=200,y=300,delta=360});
 sw.Restart();while(await Eval("document.getElementById('feed-scroll').scrollTop>0")!="True"){if(sw.Elapsed.TotalSeconds>5)throw new Exception("actual feed container scroll");await Task.Delay(30);}assertions++;
 Check(await Eval("window.keyAdvances===0")=="True","scroll container does not get unrelated keyboard pagination");
 // Guest mode exercises genuine CDP input and the embedded production script.
 await Send(new{type="navigate",url="https://www.tiktok.com/foryou"});
 sw.Restart();while(await Eval("!!window.__pocketPhoneGuest && !!document.querySelector('[data-e2e=video-switch-next]')")!="True"){if(sw.Elapsed.TotalSeconds>10)throw new Exception("guest fixture injection");await Task.Delay(50);}assertions++;
 string guestFixture="""
 window.dismissals=0;
 window.openNag=(variant='english')=>{
  document.getElementById('nag')?.remove();let d=document.createElement('div');d.id='nag';d.setAttribute('role','dialog');
  d.style='position:fixed;z-index:20;top:200px;left:40px;width:340px;height:230px;background:white;color:black';
  const heading=variant==='russian'?'Войти в TikTok':'Log in to TikTok';
  d.innerHTML='<h2>'+heading+'</h2>'+(variant==='comments'?'<div data-e2e="comment-list">Comments: Log in to comment</div>':'');
  if(variant==='captcha')d.innerHTML+='<p>Verify you are human: CAPTCHA</p>';
  if(variant!=='required'){
   let b=document.createElement(variant==='e2e'?'div':'button');b.id='dismiss';b.style='position:absolute;right:5px;top:5px;width:60px;height:30px';
   if(variant==='e2e'){b.dataset.e2e='modal-close-inner-button';b.innerHTML='<svg width=20 height=20></svg>';}
   else{b.setAttribute('aria-label',variant==='skip'?'Skip':variant==='russian-skip'?'Пропустить':variant==='russian'?'Закрыть окно':'Close');b.textContent='X';}
   b.onclick=()=>{window.dismissals++;d.remove();};d.appendChild(b);
  }
  document.body.appendChild(d);
 };
 let signIn=document.createElement('button');signIn.id='manual-login';signIn.style='position:fixed;z-index:10;left:10px;top:710px;width:130px;height:45px';signIn.textContent='Log in';signIn.onclick=()=>openNag();document.body.appendChild(signIn);
 """;
 await cdp.Call("Runtime.evaluate",new{expression=guestFixture});
 async Task DismissNag(string variant,int count){
  await cdp.Call("Runtime.evaluate",new{expression=$"openNag('{variant}')"});
  sw.Restart();while(await Eval("window.dismissals")!=count.ToString()){if(sw.Elapsed.TotalSeconds>5)throw new Exception("guest native dismissal "+variant);await Task.Delay(40);}assertions++;
  Check(await Eval("document.getElementById('nag')===null")=="True","native close removed optional invitation "+variant);
 }
 await DismissNag("english",1);await DismissNag("russian",2);await DismissNag("e2e",3);
 await Send(new{type="click",x=60,y=731});await Task.Delay(900);
 Check(await Eval("!!document.getElementById('nag') && window.dismissals===3")=="True","intentional login stays available");
 await Task.Delay(2300);await cdp.Call("Runtime.evaluate",new{expression="document.getElementById('nag').className='login-updated'"});await Task.Delay(450);
 Check(await Eval("!!document.getElementById('nag')")=="True","manual form preserved after intent deadline");
 await Send(new{type="click",x=347,y=220});await Task.Delay(150);
 Check(await Eval("document.getElementById('nag')===null && window.dismissals===4")=="True","user can close manual form normally");
 await DismissNag("english",5);await DismissNag("skip",6);await DismissNag("russian-skip",7);
 foreach(string variant in new[]{"required","captcha"}){
  await cdp.Call("Runtime.evaluate",new{expression=$"openNag('{variant}')"});await Task.Delay(650);
  Check(await Eval("!!document.getElementById('nag') && window.dismissals===7")=="True","leave authentication barrier untouched "+variant);
 }
 await cdp.Call("Runtime.evaluate",new{expression="document.getElementById('nag').remove();document.getElementById('open-comments').onclick=()=>openNag('comments');"});
 await Send(new{type="click",x=399,y=211});await Task.Delay(900);
 Check(await Eval("!!document.getElementById('nag') && window.dismissals===7")=="True","comment action requiring login stays visible");
 await cdp.Call("Runtime.evaluate",new{expression="document.getElementById('nag').remove()"});await Task.Delay(2300);
 await Send(new{type="guest",value=false});await Task.Delay(100);
 await cdp.Call("Runtime.evaluate",new{expression="openNag()"});await Task.Delay(650);
 Check(await Eval("!!document.getElementById('nag') && window.dismissals===7")=="True","guest mode can be disabled");
 await Send(new{type="reload"});
 sw.Restart();while(await Eval("typeof window.openNag==='undefined' && document.readyState==='complete'")!="True"){if(sw.Elapsed.TotalSeconds>10)throw new Exception("guest reload navigation");await Task.Delay(50);}
 await cdp.Call("Runtime.evaluate",new{expression=guestFixture+"openNag()"});await Task.Delay(650);
 Check(await Eval("!!document.getElementById('nag') && window.dismissals===0")=="True","disabled setting survives full navigation");
 await Send(new{type="guest",value=true});await Task.Delay(650);
 Check(await Eval("document.getElementById('nag')===null && window.dismissals===1")=="True","enabling guest mode dismisses only optional nag");
 foreach(string url in new[]{"https://www.tiktok.com/login","https://www.instagram.com/reels/"}){
  await Send(new{type="navigate",url});
  sw.Restart();while(await Eval("location.href==="+JsonSerializer.Serialize(url)+" && document.readyState==='complete'")!="True"){if(sw.Elapsed.TotalSeconds>10)throw new Exception("guest excluded navigation");await Task.Delay(50);}
  await cdp.Call("Runtime.evaluate",new{expression=guestFixture+"openNag()"});await Task.Delay(650);
  Check(await Eval("!!document.getElementById('nag') && window.dismissals===0")=="True","leave login route and other sites untouched "+url);
 }
 // Returning to an ordinary site must restore free page scrolling.
 await cdp.Call("Page.navigate",new{url="about:blank"});await Task.Delay(150);
 frame=await cdp.Call("Page.getFrameTree");id=frame.GetProperty("frameTree").GetProperty("frame").GetProperty("id").GetString();
 await cdp.Call("Page.setDocumentContent",new{frameId=id,html});
 await Send(new{type="scroll",x=200,y=600,delta=550});
 sw.Restart();while(int.Parse(await Eval("Math.round(window.scrollY)"))<100){if(sw.Elapsed.TotalSeconds>5)throw new Exception("normal browser scroll after leaving feed");await Task.Delay(30);}assertions++;
 await Send(new{type="navigate",url="http://example.com"});await Until(()=>messages.Any(m=>m.Contains("HTTPS")),"HTTP rejected");
 await Send(new{type="active",value=false});await Task.Delay(300);int paused=frames;await Task.Delay(500);Check(frames==paused,"screencast stops when pocketed");
 await Send(new{type="active",value=true});await cdp.Call("Runtime.evaluate",new{expression="document.body.style.background='purple'"});await Until(()=>frames>paused,"screencast resume");
 await Send(new{type="close"});await process.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(15));Check(process.ExitCode==0,"helper closes cleanly");await reader;
 string wrapper=Path.Combine(Path.GetTempPath(),"phone-browser-test-wrapper-"+Guid.NewGuid().ToString("N"));
 await File.WriteAllTextAsync(wrapper,"#!/bin/sh\nexec "+helper+" \"$@\" --test-headless\n");if(!OperatingSystem.IsWindows())File.SetUnixFileMode(wrapper,UnixFileMode.UserRead|UnixFileMode.UserWrite|UnixFileMode.UserExecute);
 var client=new BrowserClient();string clientProfile=profile+"-client";
 client.Start(wrapper,clientProfile,guestMode:false);await Until(()=>client.Ready,"client starts",40000);
 int clientPort=int.Parse(File.ReadLines(Path.Combine(clientProfile,"DevToolsActivePort")).First());
 using(var clientTargets=JsonDocument.Parse(await http.GetStringAsync("http://127.0.0.1:"+clientPort+"/json/list")))
 {
  var clientTarget=clientTargets.RootElement.EnumerateArray().First(t=>t.GetProperty("type").GetString()=="page");
  await using var clientCdp=new Cdp();await clientCdp.Connect(clientTarget.GetProperty("webSocketDebuggerUrl").GetString());
  var configured=await clientCdp.Call("Runtime.evaluate",new{expression="window.__pocketPhoneGuestEnabled",returnByValue=true});
  Check(!configured.GetProperty("result").GetProperty("value").GetBoolean(),"Unity client forwards disabled guest mode to helper startup");
  var clientTree=await clientCdp.Call("Page.getFrameTree");
  await clientCdp.Call("Page.setDocumentContent",new{frameId=clientTree.GetProperty("frameTree").GetProperty("frame").GetProperty("id").GetString(),html});
  client.Send(new{type="click",x=100,y=170});client.Send(new{type="text",text="Тест 🦊"});
  sw.Restart();while(true){var result=await clientCdp.Call("Runtime.evaluate",new{expression="document.getElementById('t').value",returnByValue=true});if(result.GetProperty("result").GetProperty("value").GetString()=="Тест 🦊")break;if(sw.Elapsed.TotalSeconds>10)throw new Exception("client Unicode IPC");await Task.Delay(50);}assertions++;
  await Until(()=>client.Frame()!=null,"client latest-frame delivery");
 }
 client.Stop();
 client.Start(wrapper,clientProfile);await Until(()=>client.Ready,"client restart waits for old profile",40000);client.Send(new{type="close"});await Until(()=>!client.Ready,"client exit status");client.Stop();
 Console.WriteLine($"PASS: {assertions} assertions, browser selection, bounded gestures, actual Chromium IPC, fixed viewport, native feed buttons/keys/card snapping, independent comments, optional guest nags/manual login/required barriers, screenshot, Unicode typing, volume, pause/resume and restart.");
}
finally{try{if(!process.HasExited){await Send(new{type="close"});await process.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(15));}}catch{try{process.Kill(true);}catch{}}}
