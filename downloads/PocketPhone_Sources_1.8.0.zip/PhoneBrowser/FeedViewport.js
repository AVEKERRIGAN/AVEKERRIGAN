(() => {
  if (window.__pocketPhoneFeed) return;
  let anchorX = window.scrollX, anchorY = window.scrollY;
  let navigationUntil = performance.now() + 1200, lastAdvance = -1000, correcting = false;
  let syntheticArrowUntil = 0, wheelUntil = 0, wheelBefore = '';
  let currentPlayer = null, currentActions = null, layoutPending = false;
  const videoSignature=()=>[...document.querySelectorAll('video')].map(v=>v.currentSrc||v.src||v.closest('article')?.textContent||'').join('|')+'|'+location.href;
  const feed = () => {
    const host = location.hostname.toLowerCase(), path = location.pathname;
    return ((host === 'tiktok.com' || host.endsWith('.tiktok.com')) &&
      (/^\/(foryou|following)(\/|$)/.test(path) || /^\/@[^/]+\/video\//.test(path))) ||
      ((host === 'instagram.com' || host.endsWith('.instagram.com')) && /^\/reels?(\/|$)/.test(path));
  };
  const visible = e => {
    const r = e.getBoundingClientRect();
    return r.width > 1 && r.height > 1 && r.bottom > 0 && r.top < innerHeight && r.right > 0 && r.left < innerWidth;
  };
  const editable = e => e && (e.matches('input,textarea,[contenteditable="true"]') || e.closest('[contenteditable="true"]'));
  const scrollable = e => {
    const s = getComputedStyle(e);
    return e !== document.body && e !== document.documentElement &&
      /auto|scroll/.test(s.overflowY) && e.scrollHeight > e.clientHeight + 2;
  };
  const comment = e => {
    for (let p = e; p && p !== document.body; p = p.parentElement) {
      const marker = (p.getAttribute('data-e2e') || '') + ' ' + (p.getAttribute('aria-label') || '') + ' ' + p.className;
      if ((p.getAttribute('role') === 'dialog' && !p.querySelector('video')) || /comment|комментар/i.test(marker)) return true;
    }
    return false;
  };
  const label = e => e.getAttribute('aria-label') || e.getAttribute('title') || e.querySelector('svg[aria-label]')?.getAttribute('aria-label') || e.textContent.trim();
  const nextName = /next video|next reel|следующ.{0,12}(видео|ролик)|^next$|^далее$|^следующ(ее|ий)$/i;
  const previousName = /previous video|previous reel|предыдущ.{0,12}(видео|ролик)|^previous$|^назад$|^предыдущ(ее|ий)$/i;
  const nextSelector = '[data-e2e="arrow-right"],[data-e2e="arrow-down"],[data-e2e="video-switch-next"]';
  const previousSelector = '[data-e2e="arrow-left"],[data-e2e="arrow-up"],[data-e2e="video-switch-prev"]';
  function beforeClick(x,y) {
    if (!feed()) return;
    const element=document.elementFromPoint(x,y), button=element?.closest('button,[role="button"],'+nextSelector+','+previousSelector);
    if (button && !comment(button) && (button.matches(nextSelector+','+previousSelector) || nextName.test(label(button)) || previousName.test(label(button)))) {
      const now=performance.now();lastAdvance=now;navigationUntil=now+650;
    }
  }
  // Stop scroll chaining/zoom; leave the sites' own feed and comment containers intact.
  const style = document.createElement('style');style.id = 'pocket-phone-viewport';
  style.textContent = `
html.pp-feed,html.pp-feed body{color-scheme:dark!important;background:#08090d!important;color:#f4f4f5!important;margin:0!important;overscroll-behavior:none!important}
html.pp-feed{--background-color:#08090d;--text-color:#f4f4f5;--color-background:#08090d;--color-text-primary:#f4f4f5}
.pp-feed #app,.pp-feed #root,.pp-feed #main-content,.pp-feed [class*="DivBodyContainer"],.pp-feed [class*="DivMainContainer"],.pp-feed [class*="DivMainContent"],.pp-feed [class*="DivContentContainer"]{background:#08090d!important;color:#f4f4f5!important}
.pp-feed [data-e2e="recommend-list-item-container"],.pp-feed [class*="DivItemContainer"],.pp-feed [class*="DivPlayerContainer"],.pp-feed [class*="DivVideoContainer"]{background:#08090d!important}
.pp-feed .pp-sidebar{display:none!important}
.pp-feed .pp-main{margin-left:0!important;margin-right:0!important;padding:0!important;min-width:0!important;width:100%!important;max-width:100%!important;box-sizing:border-box!important}
.pp-feed .pp-main [data-e2e="recommend-list-item-container"],.pp-feed .pp-main article{margin:0 auto!important;padding:8px 0!important;width:100%!important;max-width:100%!important;min-width:0!important;box-sizing:border-box!important;scroll-snap-align:start}
.pp-feed .pp-main [class*="DivPlayerContainer"],.pp-feed .pp-main [class*="DivVideoContainer"],.pp-feed .pp-main [class*="DivVideoWrapper"]{min-width:0!important;max-width:calc(100vw - 64px)!important;width:calc(100vw - 64px)!important;max-height:calc(100vh - 96px)!important;border-radius:16px!important;overflow:hidden!important}
.pp-feed .pp-main video{object-fit:contain!important;width:100%!important;max-width:100%!important;max-height:calc(100vh - 96px)!important;background:#000!important}
.pp-feed [data-e2e="video-desc"],.pp-feed [class*="DivActionContainer"],.pp-feed [class*="DivActionItem"],.pp-feed [class*="DivDescription"],.pp-feed [class*="DivMusicText"]{color:#f4f4f5!important}
.pp-feed [data-e2e="comment-list"],.pp-feed [class*="DivCommentListContainer"]{background:#13151b!important;color:#f4f4f5!important}

.pp-feed .pp-chain{margin-left:0!important;margin-right:0!important;padding-left:0!important;padding-right:0!important;left:0!important;min-width:0!important;max-width:100vw!important;box-sizing:border-box!important}
.pp-feed .pp-player{margin-left:64px!important;margin-right:0!important;width:calc(100vw - 64px)!important;max-width:calc(100vw - 64px)!important;height:calc(100vh - 96px)!important;max-height:calc(100vh - 96px)!important;display:flex!important;align-items:center!important;justify-content:center!important;box-sizing:border-box!important;overflow:hidden!important}
.pp-feed .pp-player video{position:static!important;object-fit:contain!important;width:100%!important;height:100%!important;max-width:100%!important;max-height:100%!important;background:#000!important}
.pp-feed .pp-actions{position:fixed!important;left:6px!important;right:auto!important;top:50%!important;bottom:auto!important;transform:translateY(-50%)!important;width:48px!important;max-width:48px!important;max-height:85vh!important;display:flex!important;flex-direction:column!important;align-items:center!important;gap:10px!important;padding:0!important;margin:0!important;z-index:20!important;color:#fff!important}
.pp-feed .pp-actions button,.pp-feed .pp-actions [role="button"]{width:44px!important;height:44px!important;margin:0!important;color:#fff!important}
.pp-feed .pp-actions strong,.pp-feed .pp-actions span{color:#f4f4f5!important;font-size:11px!important}
`;
  function activeVideo(){
    const area=e=>{const r=e.getBoundingClientRect();return Math.max(0,Math.min(innerWidth,r.right)-Math.max(0,r.left))*Math.max(0,Math.min(innerHeight,r.bottom)-Math.max(0,r.top));};
    return [...document.querySelectorAll('video')].filter(visible).sort((a,b)=>area(b)-area(a))[0];
  }
  function layout() {
    const active=feed();document.documentElement?.classList.toggle('pp-feed',active);if(!active)return;
    const video=activeVideo();if(!video)return;
    const nav=document.querySelector('[data-e2e="side-nav"],[data-e2e="side-nav-container"],[class*="DivSideNavContainer"],[class*="DivCompactSideNavContainer"]');
    if(nav)nav.classList.add('pp-sidebar');
    const player=video.closest('[class*="DivPlayerContainer"],[class*="DivVideoContainer"],[class*="DivVideoWrapper"]');
    if(!nav&&!player)return;
    let region=player||video.parentElement;
    for(let e=region?.parentElement;e&&e!==document.body;e=e.parentElement){if(comment(e))break;e.classList.add('pp-chain');}
    if(currentPlayer!==region){currentPlayer?.classList.remove('pp-player');currentPlayer=region;region?.classList.add('pp-player');}
    const main=document.querySelector('main,[role="main"],#main-content,[class*="DivMainContainer"],[class*="DivMainContent"]');
    if(main?.contains(video))main.classList.add('pp-main');
    const like='[data-e2e="like-icon"],[data-e2e="browse-like"],[data-e2e="like-count"],button[aria-label*="like" i]';
    const comments='[data-e2e="comment-icon"],[data-e2e="browse-comment"],[data-e2e="comment-count"],button[aria-label*="comment" i]';
    const card=video.closest('article,[data-e2e="recommend-list-item-container"]')||main||document.body;
    for(const button of card.querySelectorAll(like)){
      for(let e=button.parentElement;e&&e!==card;e=e.parentElement){
        if(e.querySelector(like)&&e.querySelector(comments)&&!e.contains(video)){
          if(currentActions!==e){currentActions?.classList.remove('pp-actions');currentActions=e;e.classList.add('pp-actions');}break;
        }
      }
    }
  }
  function sharedVideo(){
    if(!feed()||editable(document.activeElement))return null;
    if([...document.querySelectorAll('[role="dialog"],[aria-modal="true"],input[type="password"],iframe[src*="captcha"]')].some(visible))return null;
    const video=activeVideo();if(!video)return null;const r=video.getBoundingClientRect();
    const x=Math.max(0,r.left),y=Math.max(0,r.top),width=Math.min(innerWidth,r.right)-x,height=Math.min(innerHeight,r.bottom)-y;
    return width>32&&height>32?{x,y,width,height}:null;
  }
  const install = () => { const root=document.head || document.documentElement;if (root && !style.isConnected && feed()) root.appendChild(style); };
  function scheduleLayout(){if(layoutPending)return;layoutPending=true;requestAnimationFrame(()=>{layoutPending=false;install();layout();});}
  document.addEventListener('DOMContentLoaded',scheduleLayout);install();
  new MutationObserver(scheduleLayout).observe(document,{childList:true,subtree:true});
  window.addEventListener('resize',scheduleLayout);window.addEventListener('popstate',scheduleLayout);
  window.addEventListener('scroll', () => {
    if (!feed() || !document.querySelector('video') || correcting) return;
    if (performance.now() < navigationUntil) {anchorX = window.scrollX;anchorY = window.scrollY;return;}
    if (window.scrollX === anchorX && window.scrollY === anchorY) return;
    correcting = true;window.scrollTo({left:anchorX,top:anchorY,behavior:'instant'});correcting = false;
  }, {passive:true});
  // Native video shortcuts can still run; their unhandled browser default must not move the page.
  window.addEventListener('keydown', e => {
    if (feed() && !editable(e.target) && performance.now() < syntheticArrowUntil && /^Arrow(Up|Down)$/.test(e.key)) e.preventDefault();
  });
  // Preserve wheel events for virtual feeds that have no next button. A key is only
  // attempted when that event did not change the video or a scroll container.
  function afterWheel() {
    if(videoSignature()!==wheelBefore)return false;
    const v=[...document.querySelectorAll('video')].find(visible);
    for(let e=v;e&&e!==document.body;e=e.parentElement)if(scrollable(e))return false;
    syntheticArrowUntil=performance.now()+500;return true;
  }
  window.addEventListener('wheel',e=>{
    if(performance.now()>wheelUntil||!feed()||comment(e.target))return;
    for(let p=e.target;p&&p!==document.body;p=p.parentElement)if(scrollable(p))return;
    e.preventDefault();
  },{capture:true,passive:false});
  function scroll(x,y,delta) {
    if (!feed()) return {mode:'wheel'};
    install();const target = document.elementFromPoint(x,y);
    if (!target) return {mode:'none'};
    // Comments, menus and login dialogs scroll locally, including at their end boundaries.
    const inComment = comment(target);
    for (let e = target; e && e !== document.body; e = e.parentElement) {
      if (scrollable(e) && (inComment || !e.querySelector('video'))) {
        e.style.overscrollBehavior = 'contain';e.scrollTop += delta;return {mode:'comment'};
      }
    }
    if (inComment || editable(target) || editable(document.activeElement)) return {mode:'none'};
    if (!document.querySelector('video')) return {mode:'wheel'}; // Login/captcha stays a normal page.
    const now = performance.now();if (now - lastAdvance < 480) return {mode:'none'};
    lastAdvance = now;navigationUntil = now + 650;
    const forward = delta > 0;
    const exact = forward ? nextSelector : previousSelector;
    const candidates = [...document.querySelectorAll(exact), ...document.querySelectorAll('button,[role="button"]')];
    const name = forward ? nextName : previousName;
    const button = candidates.find(e => visible(e) && !e.disabled && !comment(e) && (e.matches(exact) || name.test(label(e))));
    if (button) {const r = button.getBoundingClientRect();return {mode:'click',x:r.left+r.width/2,y:r.top+r.height/2};}
    // Feeds containing several cards snap to the next complete card, never half a wheel step.
    let cards = [...document.querySelectorAll('[data-e2e="recommend-list-item-container"],article')].filter(e => e.querySelector('video'));
    if (cards.length < 2) cards = [...document.querySelectorAll('video')];
    cards=cards.filter(e=>{const r=e.getBoundingClientRect();return r.width>innerWidth*.35&&r.height>innerHeight*.25;});
    if (cards.length > 1) {
      let current = 0, distance = Infinity;
      cards.forEach((e,i) => {const r=e.getBoundingClientRect(),d=Math.abs(r.top+r.height/2-innerHeight/2);if(d<distance){distance=d;current=i;}});
      const next = cards[current+(forward?1:-1)];
      if (next) {next.scrollIntoView({block:'center',inline:'nearest',behavior:'smooth'});return {mode:'card'};}
    }
    const v=[...document.querySelectorAll('video')].find(visible);
    if(v){const r=v.getBoundingClientRect();x=Math.max(1,Math.min(innerWidth-1,r.left+r.width/2));y=Math.max(1,Math.min(innerHeight-1,r.top+r.height/2));}
    wheelBefore=videoSignature();wheelUntil=now+500;
    return {mode:'wheelKey',x,y,delta:forward?innerHeight:-innerHeight,key:forward?'ArrowDown':'ArrowUp'};
  }
  window.__pocketPhoneFeed = {scroll,beforeClick,afterWheel,sharedVideo};
})();
