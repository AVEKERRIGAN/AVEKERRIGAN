using Mirror;
using UnityEngine;

namespace FreshBoombox;

public struct BoxRequestV31 : NetworkMessage { public byte action; public uint id; public string text; public Vector3 origin,direction; }
public struct BoxStateV31 : NetworkMessage
{
    public uint id, owner, epoch; public Vector3 position; public Quaternion rotation;
    public Vector3 velocity; public bool playing, loading, removed; public string title,status;
}
public struct BoxNoticeV31 : NetworkMessage {public uint id;public string text;}
public struct BoxAudioV31 : NetworkMessage { public uint id, epoch, sequence; public byte[] pcm; }

public static class Wire
{
    public static void Install()
    {
        Writer<BoxRequestV31>.write = (w, m) => { w.WriteByte(m.action); w.WriteUInt(m.id); w.WriteString(m.text); w.WriteVector3(m.origin); w.WriteVector3(m.direction); };
        Reader<BoxRequestV31>.read = r => new BoxRequestV31 { action = r.ReadByte(), id = r.ReadUInt(), text = r.ReadString(), origin=r.ReadVector3(), direction=r.ReadVector3() };
        Writer<BoxStateV31>.write = (w, m) => { w.WriteUInt(m.id); w.WriteUInt(m.owner); w.WriteUInt(m.epoch); w.WriteVector3(m.position); w.WriteQuaternion(m.rotation); w.WriteVector3(m.velocity); w.WriteBool(m.loading); w.WriteString(m.status); w.WriteBool(m.playing); w.WriteBool(m.removed); w.WriteString(m.title); };
        Reader<BoxStateV31>.read = r => new BoxStateV31 { id = r.ReadUInt(), owner = r.ReadUInt(), epoch = r.ReadUInt(), position = r.ReadVector3(), rotation = r.ReadQuaternion(), velocity=r.ReadVector3(), loading=r.ReadBool(), status=r.ReadString(), playing = r.ReadBool(), removed = r.ReadBool(), title = r.ReadString() };
        Writer<BoxNoticeV31>.write=(w,m)=>{w.WriteUInt(m.id);w.WriteString(m.text);};
        Reader<BoxNoticeV31>.read=r=>new BoxNoticeV31{id=r.ReadUInt(),text=r.ReadString()};
        Writer<BoxAudioV31>.write = (w, m) => { w.WriteUInt(m.id); w.WriteUInt(m.epoch); w.WriteUInt(m.sequence); w.WriteBytesAndSize(m.pcm); };
        Reader<BoxAudioV31>.read = r => new BoxAudioV31 { id = r.ReadUInt(), epoch = r.ReadUInt(), sequence = r.ReadUInt(), pcm = r.ReadBytesAndSize() };
    }
}
