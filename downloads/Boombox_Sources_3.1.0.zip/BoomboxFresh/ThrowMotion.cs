using System;
namespace FreshBoombox;
public readonly struct Direction
{
    public readonly float X,Y,Z;
    public Direction(float x,float y,float z){X=x;Y=y;Z=z;}
}
public static class ThrowMotion
{
    public static bool Finite(float value)=>!float.IsNaN(value)&&!float.IsInfinity(value);
    public static bool Near(float x,float y,float z,float px,float py,float pz,float range=4)
    {if(!Finite(x)||!Finite(y)||!Finite(z))return false;float dx=x-px,dy=y-py,dz=z-pz;return dx*dx+dy*dy+dz*dz<=range*range;}
    public static Direction Normalize(float x,float y,float z)
    {
        if(!Finite(x)||!Finite(y)||!Finite(z))return new Direction(0,0,1);
        double length=Math.Sqrt((double)x*x+(double)y*y+(double)z*z);
        return length<.0001?new Direction(0,0,1):new Direction((float)(x/length),(float)(y/length),(float)(z/length));
    }
    public static Direction Velocity(float x,float y,float z,float speed,float vx,float vy,float vz)
    {
        var aim=Normalize(x,y,z);speed=Finite(speed)?Math.Max(4,Math.Min(12,speed)):7.5f;
        float Carry(float v)=>Finite(v)?Math.Max(-3,Math.Min(3,v*.35f)):0;
        return new Direction(aim.X*speed+Carry(vx),aim.Y*speed+1.2f+Carry(vy),aim.Z*speed+Carry(vz));
    }
    public static float Smooth(float delta)=>1-(float)Math.Exp(-24*Math.Max(0,delta));
}
