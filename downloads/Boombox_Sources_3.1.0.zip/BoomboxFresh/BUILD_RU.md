# Сборка Boombox 3.1.0

Нужен .NET 8 SDK и ваши managed DLL игры / BepInEx 5.
DLL игры и двоичные помощники не входят в архив исходников.

Из корня:

    dotnet build BoomboxFresh/BoomboxFresh.csproj -c Release -p:Managed="ПУТЬ_К_Managed" -p:Core="ПУТЬ_К_BepInEx/core"

Скопировать Boombox.dll в BepInEx/plugins/Boombox. В подпапке tools нужны
Windows x64 yt-dlp.exe, ffmpeg.exe, deno.exe (сведения и лицензии в tools).

В Linux для проверки процессов нужен /usr/bin/python3 и /usr/bin/ffmpeg:

    dotnet run --project BoomboxChecks/BoomboxChecks.csproj -c Release -p:Managed="ПУТЬ_К_Managed"

Тесты создают временные помощники с заданными сценариями, чтобы проверить
аргументы, UTF-8, ошибки, отсутствие ответа и отмену. Один сценарий запускает
настоящий ffmpeg и декодирует тестовый сигнал. Подключение к живому YouTube
и физика Unity этими тестами не проверяются.

В Windows проверить: Insert / E / Q, бросок вперёд и вверх, пол / стену,
музыку в полёте, успешный трек, недоступное видео, остановку и переключение
во время загрузки, поиск на клиенте и слышимость у второго игрока.
