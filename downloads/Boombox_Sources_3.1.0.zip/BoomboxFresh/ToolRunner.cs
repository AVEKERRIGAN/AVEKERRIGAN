using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
namespace FreshBoombox;
public sealed class ToolRunner : IDisposable
{
    public readonly Process Process;
    readonly StringBuilder _errors=new();
    public ToolRunner(string path,string[] arguments,CancellationToken token)
    {
        if(!File.Exists(path))throw new FileNotFoundException("Не найден помощник "+Path.GetFileName(path)+". Распакуйте его в Boombox/tools.");
        var info=new ProcessStartInfo{FileName=path,Arguments=Arguments(arguments),UseShellExecute=false,CreateNoWindow=true,RedirectStandardOutput=true,RedirectStandardError=true,StandardOutputEncoding=Encoding.UTF8,StandardErrorEncoding=Encoding.UTF8};
        Process=new Process{StartInfo=info};Process.ErrorDataReceived+=(_,e)=>{if(e.Data==null)return;lock(_errors){_errors.AppendLine(e.Data);if(_errors.Length>4096)_errors.Remove(0,_errors.Length-4096);}};
        Process.Start();Process.BeginErrorReadLine();_cancel=token.Register(Kill);
    }
    CancellationTokenRegistration _cancel;
    public static string Quote(string value)
    {
        var b=new StringBuilder("\"");int slash=0;
        foreach(char c in value??""){if(c=='\\'){slash++;continue;}b.Append('\\',c=='"'?slash*2+1:slash);slash=0;b.Append(c);}
        b.Append('\\',slash*2);return b.Append('"').ToString();
    }
    public static string Arguments(string[] arguments)=>string.Join(" ",Array.ConvertAll(arguments,Quote));
    public static string SafeError(string text)
    {
        text=Regex.Replace(text??"",@"https?://[^\s\""']+","[адрес]",RegexOptions.IgnoreCase);
        text=Regex.Replace(text,@"(?i)(cookie|authorization|token|signature)\s*[:=]\s*\S+","$1=[скрыто]");
        text=text.Replace('\r',' ').Replace('\n',' ').Trim();return text.Length>240?text.Substring(text.Length-240):text;
    }
    public string Error {get{lock(_errors)return SafeError(_errors.ToString());}}
    public string Capture(CancellationToken token,int limit=8*1024*1024)
    {
        var b=new StringBuilder();var buffer=new char[4096];int n;
        while((n=Process.StandardOutput.Read(buffer,0,buffer.Length))>0){token.ThrowIfCancellationRequested();if(b.Length+n>limit)throw new IOException("Помощник вернул слишком большой ответ.");b.Append(buffer,0,n);}
        Process.WaitForExit();token.ThrowIfCancellationRequested();
        if(Process.ExitCode!=0)throw new IOException(string.IsNullOrEmpty(Error)?"Помощник завершился с кодом "+Process.ExitCode:Error);
        return b.ToString();
    }
    public void Kill(){try{if(!Process.HasExited)Process.Kill();}catch{ }}
    public void Dispose(){_cancel.Dispose();Kill();Process.Dispose();}
}
