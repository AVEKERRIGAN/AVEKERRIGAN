using Blackjack3Hand;using Newtonsoft.Json;using System.Globalization;
int checks=0;void Check(bool result,string name){checks++;if(!result)throw new Exception(name);}
Check(!SeatViewPolicy.Occupied(null),"missing hand is free");Check(!SeatViewPolicy.Occupied(new SeatSt()),"unclaimed hand is free");Check(SeatViewPolicy.Occupied(new SeatSt{owner=12,who=""}),"empty name never frees an occupied seat");Check(SeatViewPolicy.Occupied(new SeatSt{occupied=true,owner=0}),"reservation remains occupied before id arrives");Check(!SeatViewPolicy.Mine(new SeatSt{owner=12},0),"unspawned local player cannot claim ownership");
var state=new StateMsg{selectedBet="18",ph=0,act=-1,s=new[]{new SeatSt{owner=12,occupied=true,who="",bet="36",b0="18",b1="18",nh=2},new SeatSt{owner=13,occupied=true,who="Second Player",bet="25",b0="25",nh=1},new SeatSt{owner=12,occupied=true,who="First Player",bet="18",b0="18",nh=1}}};
var wire=StateCodec.Encode(state);var decoded=StateCodec.Decode(wire);
Check(decoded.selectedBet=="18"&&decoded.s[0].nh==2&&decoded.s[0].b1=="18","selected bet and split stakes survive state packet");Check(SeatViewPolicy.Mine(decoded.s[0],12)&&!SeatViewPolicy.Mine(decoded.s[0],13),"each client sees its own claimed hand");
double Sum(uint id)=>decoded.s.Where(s=>SeatViewPolicy.Mine(s,id)).Sum(s=>double.Parse(s.bet,CultureInfo.InvariantCulture));Check(Sum(12)==54&&Sum(13)==25,"personal total excludes the other player's bets");
decoded.s[1].bet="50";decoded.s[1].b0="50";Check(Sum(13)==50&&Sum(12)==54,"double updates only the acting player's total");decoded.s[0]=new SeatSt();Check(!SeatViewPolicy.Occupied(decoded.s[0])&&Sum(12)==18,"release updates occupancy and personal amount");
foreach (string bad in new[]{"{}", "{\"s\":[]}", "{\"s\":[null,null,null]}", "{\"s\":[{},{}]}"}) { bool rejected=false;try{StateCodec.Decode(bad);}catch(ArgumentException){rejected=true;}Check(rejected,"missing seat data cannot be displayed as free"); }
state.c=new[]{new CardPos{n=31,a=1,i=0,c=2},new CardPos{n=32,a=1,i=1,c=2}};state.cs="31,1,0,2|32,1,1,2";state.ph=2;state.dt="8+?";
var active=StateCodec.Decode(StateCodec.Encode(state));Check(active.ph==2 && active.s.All(SeatViewPolicy.Occupied) && active.s[0].bet=="36" && active.c.Length==2 && active.cs==state.cs,"production codec preserves playing hands alongside card targets");
foreach(var value in new[]{BigNumber.FromDouble(195000),BigNumber.FromDouble(.2),BigNumber.FromDouble(18.75),BigNumber.FromDouble(390000),new BigNumber(1.23456789012345,100000)}) {
 var encoded=StakeCodec.Encode(value);var actual=StakeCodec.Decode(encoded);Check(Math.Abs(actual.Mantissa-value.Mantissa)<1e-12&&actual.Exponent==value.Exponent,"real game's monetary value survives serialization without abbreviation");
}
var real=BigNumber.FromDouble(195000);Check(BigNumber.Parse(real.ToString()).IsZero,"reproduce the actual 195K parsing bug from supplied log");
state.s[0].bet=StakeCodec.Encode(real);var roundtrip=StateCodec.Decode(StateCodec.Encode(state));Check(StakeCodec.Decode(roundtrip.s[0].bet).ToDouble()==195000,"production seat packet preserves the logged stake");
var banks=new[]{new[]{false},new[]{false},new[]{false}};
foreach(int seat in new[]{1,2,0}){int hand=HandActionPolicy.FirstOpen(true,true,banks[seat]);Check(hand==0,"bank 2, 3 and 1 may act in arbitrary order");banks[seat][hand]=true;Check(HandActionPolicy.FirstOpen(true,true,banks[seat])==-1,"finished hand cannot act or pay twice");}
Check(HandActionPolicy.FirstOpen(true,false,new[]{false})==-1&&HandActionPolicy.FirstOpen(false,true,new[]{false})==-1,"other owners and dealing phase cannot act");
Check(HandActionPolicy.FirstOpen(true,true,new[]{true,false})==1,"split progresses to the unfinished subhand");
Console.WriteLine($"PASS: {checks} checks; empty names, owner ids, split/double stakes, individual co-op totals and state roundtrip. Native Unity gameplay not executed.");
