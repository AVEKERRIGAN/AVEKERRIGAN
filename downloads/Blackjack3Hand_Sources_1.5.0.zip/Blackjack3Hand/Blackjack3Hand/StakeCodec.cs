using System.Globalization;
namespace Blackjack3Hand;
public static class StakeCodec
{
    // BigNumber.ToString() is a DISPLAY abbreviation (195K), not a wire value.
    // The game's comma form retains even exponents outside double's range.
    public static string Encode(BigNumber value)=>value.Mantissa.ToString("R",CultureInfo.InvariantCulture)+","+value.Exponent.ToString(CultureInfo.InvariantCulture);
    public static BigNumber Decode(string value)=>BigNumber.Parse(value);
}
