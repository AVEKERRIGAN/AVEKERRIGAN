using System;
namespace Blackjack3Hand;
public static class HandActionPolicy
{
    public static int FirstOpen(bool playing,bool owns,bool[] finished)=>playing&&owns&&finished!=null?Array.FindIndex(finished,done=>!done):-1;
}
