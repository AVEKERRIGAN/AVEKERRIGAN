using System;
using Mirror;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Blackjack3Hand;

public partial class BJ3Game
{
    readonly TextMeshProUGUI[] _tableInfo = new TextMeshProUGUI[4];
    readonly Image[] _tablePlate = new Image[4];
    TextMeshProUGUI _betMonitor;
    RectTransform _monitorRoot;
    TMP_FontAsset _displayFont;Font _systemFont;bool _fontTried, _ownsDisplayFont;
    readonly TextMeshProUGUI[] _buttonInfo=new TextMeshProUGUI[3];
    readonly Image[] _buttonPlate=new Image[3];static Sprite _plaque;
    readonly System.Collections.Generic.List<Material> _surfaceMaterials = new();

    static string Plain(string text) => (text ?? "").Replace("<", "").Replace(">", "");
    static string FormatStake(string value)
    {
        if (string.IsNullOrEmpty(value)) return "$0";
        try { var stake=BigNumber.Parse(value);if(stake.IsZero && value.IndexOfAny(new[]{'K','M','B','T','Q'})>=0)return "$"+Plain(value).TrimStart('$');double number=stake.ToDouble();return number>=0&&number<1e9?"$"+number.ToString("0.00",System.Globalization.CultureInfo.InvariantCulture):MoneyFormatter.FormatWithDollar(stake); }
        catch { return "$" + Plain(value); }
    }

    void HideFloatingText()
    {
        foreach (var label in labels) if (label != null) label.gameObject.SetActive(false);
        foreach (var label in _tot) if (label != null) label.gameObject.SetActive(false);
        foreach (var label in _betLbl) if (label != null) label.gameObject.SetActive(false);

    }

    TextMeshProUGUI Surface(string name, Transform parent, out RectTransform root, out Image plate)
    {
        if(!_fontTried){_fontTried=true;try{_systemFont=Font.CreateDynamicFontFromOSFont(new[]{"Arial","Liberation Sans","DejaVu Sans"},96);if(_systemFont!=null){_displayFont=TMP_FontAsset.CreateFontAsset(_systemFont);_ownsDisplayFont=_displayFont!=null;}}catch{}}
        if(_plaque==null){var tex=new Texture2D(128,64,TextureFormat.RGBA32,false);var pixels=new Color[128*64];for(int y=0;y<64;y++)for(int x=0;x<128;x++){float cx=Mathf.Clamp(x,10,117),cy=Mathf.Clamp(y,10,53),d=Vector2.Distance(new Vector2(x,y),new Vector2(cx,cy));pixels[y*128+x]=d>10?Color.clear:x<3||x>124||y<3||y>60?new Color(1,.82f,.38f):Color.white;}tex.SetPixels(pixels);tex.Apply();_plaque=Sprite.Create(tex,new Rect(0,0,128,64),new Vector2(.5f,.5f),100,0,SpriteMeshType.FullRect,new Vector4(14,14,14,14));}
        var go = new GameObject(name, typeof(RectTransform), typeof(Canvas), typeof(Image), typeof(RectMask2D));
        root = (RectTransform)go.transform; root.SetParent(parent, false);
        go.GetComponent<Canvas>().renderMode = RenderMode.WorldSpace;
        plate = go.GetComponent<Image>();plate.sprite=_plaque;plate.type=Image.Type.Sliced; plate.color = new Color(.025f, .055f, .04f, .96f); plate.raycastTarget = false;
        var child = new GameObject("Text", typeof(RectTransform), typeof(CanvasRenderer)); child.transform.SetParent(root, false);
        var text = child.AddComponent<TextMeshProUGUI>();
        if (_displayFont == null)
        {
            foreach (var candidate in GetComponentsInChildren<TMP_Text>(true))
                if (candidate != text && candidate.font != null) { _displayFont = candidate.font; break; }
            if (_displayFont == null) _displayFont = TMP_Settings.defaultFontAsset;
        }
        if (_displayFont != null)
        {
            text.font = _displayFont;
            var material = new Material(_displayFont.material);
            if (material.HasProperty("_ZTestMode")) material.SetFloat("_ZTestMode", (float)UnityEngine.Rendering.CompareFunction.LessEqual);
            text.fontSharedMaterial = material; _surfaceMaterials.Add(material);
        }
        var rt = text.rectTransform; rt.anchorMin = new Vector2(.06f, .07f); rt.anchorMax = new Vector2(.94f, .93f); rt.offsetMin = rt.offsetMax = Vector2.zero;
        text.color = Color.white; text.alignment = TextAlignmentOptions.Center; text.enableAutoSizing = true;
        text.fontSizeMin = 2; text.fontSizeMax = 58;text.fontStyle=FontStyles.Bold; text.textWrappingMode = TextWrappingModes.NoWrap; text.overflowMode = TextOverflowModes.Truncate;
        text.raycastTarget = false;
        go.layer = parent.gameObject.layer; child.layer = go.layer;
        return text;
    }

    static void WorldScale(Transform root, float scale)
    {
        var parent = root.parent != null ? root.parent.lossyScale : Vector3.one;
        root.localScale = new Vector3(scale / Mathf.Max(.001f, Mathf.Abs(parent.x)), scale / Mathf.Max(.001f, Mathf.Abs(parent.y)), scale / Mathf.Max(.001f, Mathf.Abs(parent.z)));
    }

    void DrawTableLabels()
    {
        if (_st == null || areas.Count < 7) return;
        for (int index = 0; index < 4; index++)
        {
            int area = index == 0 ? 0 : 1 + (index - 1) * 2;
            if (areas[area] == null) continue;
            SeatFrame(area, out var center, out var right, out var toDealer, out var width);
            Vector3 up = transform.up.normalized;
            toDealer = Vector3.ProjectOnPlane(toDealer, up).normalized;
            if (toDealer.sqrMagnitude < .1f) toDealer = transform.forward;
            float w = Mathf.Clamp(width * .83f, .26f, 1.0f), h = w * .39f;
            if (_tableInfo[index] == null)
                _tableInfo[index] = Surface("BJ3_TableInfo" + index, transform, out _, out _tablePlate[index]);
            var root = (RectTransform)_tableInfo[index].transform.parent;
            root.sizeDelta = new Vector2(w * 1000, h * 1000); WorldScale(root, .001f);
            // Facing up and flush with the felt, never billboarded to the camera.
            root.rotation = Quaternion.LookRotation(-up, toDealer);
            root.position = center - toDealer * Mathf.Max(_cardL * .68f, h * .9f) + up * .012f;
            if (index == 0)
            {
                _tableInfo[index].text = "ДИЛЕР  " + Plain(_st.dt) + "\n" + Plain(_st.msg);
                continue;
            }
            var state = _st.s != null && index - 1 < _st.s.Length ? _st.s[index - 1] : null;
            bool occupied = SeatViewPolicy.Occupied(state);
            bool active = _st.act >= 0 && _st.act / 2 == index - 1 && _st.ph == 2;
            _tablePlate[index].color = occupied ? active ? new Color(.19f, .13f, .025f, .98f) : new Color(.14f, .035f, .035f, .97f) : new Color(.025f, .08f, .055f, .94f);
            _tableInfo[index].text = occupied
                ? "<color=#FFD75A>РУКА " + index + " · ЗАНЯТА</color>\n" + Plain(state.who) + " · " + FormatStake(state.bet) + "\n" +
                    "ОЧКИ " + Plain(_handTot[area] ?? state.t0) + (state.nh > 1 ? " / " + Plain(_handTot[area + 1] ?? state.t1) : "")
                : "РУКА " + index + " · СВОБОДНА\nПоставь ставку";
        }
    }

    void DrawBetMonitor()
    {
        if (_kp == null || !BJ3Plugin.OwnKeypadScreen.Value) return;
        var display = KpTarget(_kp); if (display == null) return;
        if (_betMonitor == null) _betMonitor = Surface("BJ3_BetMonitor", _kp.transform, out _monitorRoot, out _);
        foreach (var child in _monitorRoot.GetComponentsInChildren<Transform>(true)) child.gameObject.layer = display.gameObject.layer;
        var corners = new Vector3[4]; display.rectTransform.GetWorldCorners(corners);
        Vector3 horizontal = corners[3] - corners[0], vertical = corners[1] - corners[0];
        if (horizontal.sqrMagnitude < .00001f || vertical.sqrMagnitude < .00001f) return;
        Vector3 normal = Vector3.Cross(horizontal, vertical).normalized;
        if (BJ3Plugin.KeypadScreenFlip.Value) normal = -normal;
        _monitorRoot.rotation = Quaternion.LookRotation(normal, vertical.normalized);
        _monitorRoot.position = (corners[0] + corners[2]) * .5f - normal * .003f;
        _monitorRoot.sizeDelta = new Vector2(horizontal.magnitude * 1000, vertical.magnitude * 1000);
        WorldScale(_monitorRoot, .001f); display.enabled = false;
        string input=KpInput(_kp);string selected=_st!=null&&!string.IsNullOrEmpty(_st.selectedBet)?_st.selectedBet:StakeCodec.Encode(currentBet);
        string amount=!string.IsNullOrWhiteSpace(input)?input:selected;
        string text="<color=#FFE097>СТАВКА</color>\n<size=150%>"+FormatStake(amount)+"</size>";
        uint local=NetworkClient.localPlayer!=null?NetworkClient.localPlayer.netId:0;BigNumber mine=BigNumber.Zero;
        for(int seat=0;seat<3;seat++)
        {
            var state=_st!=null&&_st.s!=null&&seat<_st.s.Length?_st.s[seat]:null;bool occupied=SeatViewPolicy.Occupied(state);bool own=SeatViewPolicy.Mine(state,local);
            text+="\n"+(seat+1)+" · "+(occupied?(own?"<color=#83FFB2>МОЯ</color>":"ЗАНЯТА")+" · "+FormatStake(state.bet):"СВОБОДНА · $0");
            if(own)try{mine+=BigNumber.Parse(state.bet);}catch{}
        }
        text+="\n<color=#FFE097>МОИ СТАВКИ: "+MoneyFormatter.FormatWithDollar(mine)+"</color>";
        string error=KpErr(_kp);if(!string.IsNullOrEmpty(error))text+="\n<color=#FF7777>"+Plain(error)+"</color>";
        _betMonitor.text = text;
    }

    void DrawButtonLabels()
    {
        if(_st==null)return;
        for(int seat=0;seat<3;seat++)
        {
            if(seat*5+4>=seatButtons.Count)continue;Vector3 center=Vector3.zero;int count=0;
            for(int b=0;b<5;b++)if(seatButtons[seat*5+b]!=null){center+=seatButtons[seat*5+b].transform.position;count++;}
            if(count==0)continue;center/=count;SeatFrame(1+seat*2,out var area,out var right,out var toDealer,out var width);Vector3 up=transform.up.normalized;toDealer=Vector3.ProjectOnPlane(toDealer,up).normalized;
            if(toDealer.sqrMagnitude<.1f)toDealer=transform.forward;float w=Mathf.Clamp(width*.92f,.38f,.82f),h=.15f;
            if(_buttonInfo[seat]==null)_buttonInfo[seat]=Surface("BJ3_ButtonInfo"+seat,transform,out _,out _buttonPlate[seat]);
            var root=(RectTransform)_buttonInfo[seat].transform.parent;root.sizeDelta=new Vector2(w*1000,h*1000);WorldScale(root,.001f);root.rotation=Quaternion.LookRotation(-up,toDealer);root.position=center-toDealer*.13f+up*.022f;
            var state=_st.s!=null&&seat<_st.s.Length?_st.s[seat]:null;bool taken=SeatViewPolicy.Occupied(state);uint local=NetworkClient.localPlayer!=null?NetworkClient.localPlayer.netId:0;bool mine=SeatViewPolicy.Mine(state,local);
            _buttonPlate[seat].color=taken?(mine?new Color(.03f,.17f,.10f,.99f):new Color(.20f,.05f,.06f,.99f)):new Color(.025f,.055f,.09f,.99f);
            _buttonInfo[seat].text="<size=68%>РУКА "+(seat+1)+" · "+(taken?(mine?"МОЯ":"ЗАНЯТА"):"СВОБОДНА")+"</size>\n<color=#FFE097>"+(taken?FormatStake(state.bet):"$0")+"</color>";
            if(taken)_buttonInfo[seat].text+=" <size=55%>"+Plain(state.who)+"</size>";
        }
    }
    static void FitButtonText(TMP_Text text, Transform button)
    {
        Bounds bounds = default; bool any = false;
        foreach (var mf in button.GetComponentsInChildren<MeshFilter>(true))
        {
            if (mf.sharedMesh == null || mf.GetComponent<TMP_Text>() != null) continue;
            var b = mf.sharedMesh.bounds;
            for (int k = 0; k < 8; k++)
            {
                var point = text.transform.InverseTransformPoint(mf.transform.TransformPoint(b.center + Vector3.Scale(b.extents, new Vector3((k & 1) == 0 ? -1 : 1, (k & 2) == 0 ? -1 : 1, (k & 4) == 0 ? -1 : 1))));
                if (!any) { bounds = new Bounds(point, Vector3.zero); any = true; } else bounds.Encapsulate(point);
            }
        }
        if (any && bounds.size.x > .001f && bounds.size.y > .001f)
        {
            text.rectTransform.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, bounds.size.x * .78f);
            text.rectTransform.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, bounds.size.y * .7f);
        }
        text.enableAutoSizing = true; text.fontSizeMin = .01f; text.textWrappingMode = TextWrappingModes.NoWrap;
        text.overflowMode = TextOverflowModes.Truncate; text.alignment = TextAlignmentOptions.Center;
    }

    static void MarkOccupied(Component button, bool occupied)
    {
        var block = new MaterialPropertyBlock();
        foreach (var renderer in button.GetComponentsInChildren<MeshRenderer>(true))
        {
            if (renderer.GetComponent<TMP_Text>() != null) continue;
            renderer.GetPropertyBlock(block);
            Color color = occupied ? new Color(1f, .35f, .15f) : new Color(.3f, .8f, .35f);
            block.SetColor("_Color", color); block.SetColor("_BaseColor", color); renderer.SetPropertyBlock(block);
        }
    }

    void ReleaseSurfaceMaterials() {if(_systemFont!=null){if(_ownsDisplayFont&&_displayFont!=null)Destroy(_displayFont);Destroy(_systemFont);_systemFont=null;} foreach (var material in _surfaceMaterials) if (material != null) Destroy(material); _surfaceMaterials.Clear(); }
}
