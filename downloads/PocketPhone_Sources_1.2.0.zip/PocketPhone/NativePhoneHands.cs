using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;
namespace PocketPhone;
public sealed class NativePhoneHands
{
    sealed class Bone { public Transform Transform; public Vector3 Position,Scale,ViewPosition;public Quaternion Rotation,ViewRotation; public float Side; }
    readonly List<Bone> _bones=new();
    Transform _view; Animator _anim; ItemHandController _controller; PlayerHandButtonAnimation _buttons;
    float _width,_clutch; bool _holding; bool _hasWidth,_hasClutch,_hasHolding;
    float _tap=10;
    public bool Ready=>_bones.Count>0;
    public void Attach(GameObject player,Camera view)
    {
        Release();_view=view.transform;
        _buttons=player.GetComponentInChildren<PlayerHandButtonAnimation>(true);
        if(_buttons==null)_buttons=player.GetComponent<PlayerHandButtonAnimation>();
        var field=typeof(PlayerHandButtonAnimation).GetField("handBones",BindingFlags.Instance|BindingFlags.NonPublic);
        var bones=_buttons!=null?field?.GetValue(_buttons) as Transform[]:null;
        if(bones==null)return;
        try{_buttons.LocalResetHands();}catch{ }
        for(int i=0;i<bones.Length;i++)
        {
            var t=bones[i];if(t==null)continue;
            _bones.Add(new Bone{Side=i==0?1:-1,Transform=t,Position=t.localPosition,Rotation=t.localRotation,Scale=t.localScale,ViewPosition=view.transform.InverseTransformPoint(t.position),ViewRotation=Quaternion.Inverse(view.transform.rotation)*t.rotation});
        }
        _controller=player.GetComponentInChildren<ItemHandController>(true);
        if(_controller==null && _bones.Count>0)_controller=_bones[0].Transform.GetComponentInParent<ItemHandController>();
        if(_controller==null)_controller=view.GetComponentInChildren<ItemHandController>(true);
        _anim=_controller!=null?_controller.GetComponent<Animator>():null;
        if(_anim!=null)foreach(var p in _anim.parameters)
        {
            if(p.name=="handsWidth"&&p.type==AnimatorControllerParameterType.Float){_hasWidth=true;_width=_anim.GetFloat(p.name);}
            if(p.name=="handsClutching"&&p.type==AnimatorControllerParameterType.Float){_hasClutch=true;_clutch=_anim.GetFloat(p.name);}
            if(p.name=="isHoldingItem"&&p.type==AnimatorControllerParameterType.Bool){_hasHolding=true;_holding=_anim.GetBool(p.name);}
        }
    }
    public void Tap()=>_tap=0;
    public void Apply(Transform phone,float delta,float reveal,float handScale,float grip)
    {
        if(_view==null)return;
        _tap+=delta;float pulse=PhoneLayout.Pulse(_tap), blend=PhoneLayout.Smooth(reveal);
        if(_anim!=null)
        {
            if(_hasHolding)_anim.SetBool("isHoldingItem",true);
            if(_hasWidth)_anim.SetFloat("handsWidth",Mathf.Lerp(_width,.055f,blend));
            if(_hasClutch)_anim.SetFloat("handsClutching",Mathf.Lerp(_clutch,.72f+pulse*.08f,blend));
        }
        for(int i=0;i<_bones.Count;i++)
        {
            var bone=_bones[i];var t=bone.Transform;if(t==null)continue;
            float side=bone.Side;bool right=side>0;
            Vector3 hold=new Vector3(side*grip-(right?pulse*.012f:0),-.061f-(right?0:.008f),.022f-(right?pulse*.006f:0));
            t.position=Vector3.Lerp(_view.TransformPoint(bone.ViewPosition),phone.TransformPoint(hold),blend);
            t.rotation=Quaternion.Slerp(_view.rotation*bone.ViewRotation,phone.rotation*bone.ViewRotation*Quaternion.Euler(right?pulse*7:0,side*-38,side*12),blend);
            // Scale the original mitten hands; no replacement hand meshes.
            t.localScale=bone.Scale*Mathf.Lerp(1,Mathf.Clamp(handScale,.2f,1.2f)*phone.lossyScale.x/3f,blend);
        }
    }
    public void Release()
    {
        if(_buttons!=null)try{_buttons.LocalResetHands();}catch{ }
        foreach(var bone in _bones)if(bone.Transform!=null){bone.Transform.localPosition=bone.Position;bone.Transform.localRotation=bone.Rotation;bone.Transform.localScale=bone.Scale;}
        if(_anim!=null){if(_hasWidth)_anim.SetFloat("handsWidth",_width);if(_hasClutch)_anim.SetFloat("handsClutching",_clutch);if(_hasHolding)_anim.SetBool("isHoldingItem",_holding);}
        if(_controller!=null)_controller.RefreshCurrentItem();
        _bones.Clear();_anim=null;_controller=null;_buttons=null;_hasWidth=_hasClutch=_hasHolding=false;_tap=10;
    }
}
