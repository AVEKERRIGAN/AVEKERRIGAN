using System;
using System.Collections.Generic;
namespace PocketPhone;

// Engine-independent data: Unity and the offline preview use the same meshes.
public sealed class PhoneDesign
{
    public const float Height=.212f,DisplayWidth=.092f,DisplayZ=-.0081f;
    public readonly List<PhoneFinish> Finishes=new();
    public readonly List<PhonePart> Parts=new();
    public static PhoneDesign Build()
    {
        var d=new PhoneDesign();
        d.Finishes.AddRange(new[]{
            new PhoneFinish("Graphite titanium",.125f,.130f,.140f,.80f,.46f),
            new PhoneFinish("Matte black",.027f,.028f,.031f,.12f,.28f),
            new PhoneFinish("Rear glass",.041f,.043f,.047f,.18f,.39f),
            new PhoneFinish("Black glass",.009f,.012f,.018f,.10f,.88f),
            new PhoneFinish("Camera rim",.085f,.090f,.104f,.88f,.72f),
            new PhoneFinish("Optical coating",.023f,.035f,.078f,.28f,.94f),
            new PhoneFinish("Optical violet",.071f,.047f,.107f,.36f,.91f),
            new PhoneFinish("Flash diffuser",.76f,.77f,.74f,.05f,.42f),
            new PhoneFinish("Flash center",.94f,.93f,.86f,.05f,.50f),
            new PhoneFinish("Antenna",.22f,.23f,.24f,.10f,.28f),
            new PhoneFinish("Rear emblem",.092f,.095f,.10f,.65f,.59f)
        });
        d.Round("Beveled titanium chassis",.106f,Height,.015f,.014f,.0012f,"Graphite titanium",0);
        d.Round("Matte rear enclosure",.103f,.209f,.0012f,.013f,.00045f,"Matte black",.00745f);
        d.Round("Lower rear glass panel",.097f,.147f,.0007f,.013f,.00025f,"Rear glass",.00818f,-.0285f);
        d.Round("Polished front bezel",.101f,.204f,.0007f,.013f,.00025f,"Black glass",-.00725f);
        d.Round("Edge to edge display glass",.098f,.196f,.00055f,.011f,.00016f,"Black glass",-.00762f);
        // Horizontal shelf and triangular lenses follow the supplied reference.
        d.Round("Wide rear camera shelf",.099f,.060f,.0021f,.011f,.00065f,"Matte black",.00855f,.0715f);
        d.Round("Camera shelf polished inset",.095f,.055f,.00045f,.0095f,.00015f,"Rear glass",.0097f,.0715f);
        d.Camera("Main camera",.027f,.085f);
        d.Camera("Ultra wide camera",.027f,.057f);
        d.Camera("Telephoto camera",-.001f,.071f);
        d.Disc("Flash metal bezel",.0048f,.0010f,.00023f,"Camera rim",.0103f,.086f,-.032f);
        d.Disc("Flash diffuser",.0039f,.0006f,.00015f,"Flash diffuser",.0110f,.086f,-.032f);
        d.Disc("Flash LED",.0023f,.00025f,.00008f,"Flash center",.0114f,.086f,-.032f);
        d.Disc("LiDAR rim",.0050f,.00065f,.00018f,"Camera rim",.0101f,.059f,-.032f);
        d.Disc("LiDAR black sensor",.00445f,.00055f,.00016f,"Black glass",.0106f,.059f,-.032f);
        d.Disc("Rear microphone",.0007f,.00035f,.00010f,"Black glass",.01015f,.072f,-.022f);
        d.Round("Dynamic Island",.0162f,.0049f,.0008f,.0024f,.00018f,"Black glass",-.00865f,.0891f);
        d.Disc("Front camera",.00115f,.0004f,.00012f,"Optical coating",-.00917f,.0891f,.0046f);
        d.Round("Earpiece",.017f,.00065f,.00025f,.00030f,.00008f,"Black glass",-.00799f,.0985f);
        d.SideButton("Action button",-.054f,.064f,.008f);
        d.SideButton("Volume up",-.054f,.036f,.016f);
        d.SideButton("Volume down",-.054f,.011f,.016f);
        d.SideButton("Power button",.054f,.031f,.025f);
        d.SideButton("Camera control",.054f,-.052f,.015f);
        foreach(float y in new[]{-.084f,.078f})foreach(float x in new[]{-.05305f,.05305f})
            d.Round("Side antenna band",.00035f,.00125f,.0108f,.00014f,.00005f,"Antenna",0,y,x);
        d.Round("Top antenna band",.00125f,.00035f,.0108f,.00014f,.00005f,"Antenna",0,.10605f,.021f);
        d.Round("Bottom antenna band",.00125f,.00035f,.0108f,.00014f,.00005f,"Antenna",0,-.10605f,-.021f);
        // Details face outwards from the bottom edge.
        var port=d.Round("USB C recess",.012f,.0037f,.00035f,.0017f,.0001f,"Black glass",0,-.10605f);port.Rx=90;
        var tongue=d.Round("USB C tongue",.008f,.0008f,.00038f,.0003f,.00008f,"Camera rim",0,-.10624f);tongue.Rx=90;
        for(int side=-1;side<=1;side+=2)for(int i=0;i<5;i++)
        {var hole=d.Disc("Speaker perforation",.0009f,.0003f,.00008f,"Black glass",0,-.1061f,side*(.014f+i*.0041f));hole.Rx=90;}
        d.Emblem();return d;
    }
    void Camera(string name,float x,float y)
    {
        Disc(name+" outer rim",.0123f,.0028f,.00065f,"Camera rim",.0111f,y,x);
        Disc(name+" black retaining ring",.0107f,.0011f,.00027f,"Black glass",.0125f,y,x);
        Disc(name+" front glass",.0090f,.00065f,.0002f,"Optical coating",.01325f,y,x);
        Disc(name+" optical barrel",.0067f,.00036f,.00012f,"Black glass",.01369f,y,x);
        Disc(name+" violet coating",.0037f,.00025f,.00008f,"Optical violet",.01397f,y,x);
        Disc(name+" aperture",.0025f,.00021f,.00006f,"Black glass",.01417f,y,x);
        Disc(name+" optical reflection",.00072f,.00015f,.00004f,"Optical coating",.01434f,y+.0012f,x-.0009f);
    }
    void SideButton(string name,float x,float y,float length)
    {var button=Round(name,.0036f,length,.0008f,.0015f,.00025f,"Graphite titanium",0,y,x);button.Ry=90;}
    PhonePart Round(string name,float w,float h,float depth,float radius,float bevel,string finish,float z,float y=0,float x=0)
    {
        const int segments=12;var shape=new List<PhonePoint>();
        for(int corner=0;corner<4;corner++)for(int i=0;i<segments;i++)
        {
            double a=(corner+i/(double)(segments-1))*Math.PI/2;float nx=(float)Math.Cos(a),ny=(float)Math.Sin(a);
            shape.Add(new PhonePoint((corner==0||corner==3?1:-1)*(w*.5f-radius)+radius*nx,(corner<2?1:-1)*(h*.5f-radius)+radius*ny,nx,ny));
        }
        return Add(name,PhoneMesh.Extrude(shape,depth,bevel),finish,x,y,z);
    }
    PhonePart Disc(string name,float radius,float depth,float bevel,string finish,float z,float y,float x)
    {
        const int segments=48;var shape=new List<PhonePoint>();
        for(int i=0;i<segments;i++)
        {double a=i*2*Math.PI/segments;float nx=(float)Math.Cos(a),ny=(float)Math.Sin(a);shape.Add(new PhonePoint(radius*nx,radius*ny,nx,ny));}
        return Add(name,PhoneMesh.Extrude(shape,depth,bevel),finish,x,y,z);
    }
    PhonePart Add(string name,PhoneMesh mesh,string finish,float x,float y,float z)
    {var part=new PhonePart{Name=name,Mesh=mesh,Finish=finish,X=x,Y=y,Z=z};Parts.Add(part);return part;}
    void Emblem()
    {
        var body=new[]{new PhoneVertex(0,.32f,0),new PhoneVertex(.15f,.40f,0),new PhoneVertex(.30f,.39f,0),new PhoneVertex(.43f,.30f,0),
            new PhoneVertex(.31f,.25f,0),new PhoneVertex(.24f,.17f,0),new PhoneVertex(.23f,.09f,0),new PhoneVertex(.28f,.01f,0),new PhoneVertex(.39f,-.03f,0),
            new PhoneVertex(.31f,-.24f,0),new PhoneVertex(.17f,-.42f,0),new PhoneVertex(.05f,-.43f,0),new PhoneVertex(0,-.39f,0),
            new PhoneVertex(-.10f,-.44f,0),new PhoneVertex(-.22f,-.41f,0),new PhoneVertex(-.37f,-.21f,0),new PhoneVertex(-.44f,.02f,0),
            new PhoneVertex(-.44f,.18f,0),new PhoneVertex(-.38f,.32f,0),new PhoneVertex(-.27f,.40f,0),new PhoneVertex(-.12f,.40f,0)};
        var leaf=new[]{new PhoneVertex(.025f,.415f,0),new PhoneVertex(.052f,.55f,0),new PhoneVertex(.19f,.68f,0),new PhoneVertex(.22f,.67f,0),new PhoneVertex(.20f,.52f,0),new PhoneVertex(.08f,.415f,0)};
        Add("Rear apple emblem",PhoneMesh.Silhouette(body,.025f),"Rear emblem",0,-.025f,.00855f);
        Add("Emblem leaf",PhoneMesh.Silhouette(leaf,.025f),"Rear emblem",0,-.025f,.00855f);
    }
}
public sealed class PhoneFinish
{
    public string Name;public float R,G,B,Metallic,Smoothness;
    public PhoneFinish(string name,float r,float g,float b,float metallic,float smoothness){Name=name;R=r;G=g;B=b;Metallic=metallic;Smoothness=smoothness;}
}
public sealed class PhonePart
{public string Name,Finish;public float X,Y,Z,Rx,Ry,Rz;public PhoneMesh Mesh;}
public readonly struct PhoneVertex
{public readonly float X,Y,Z;public PhoneVertex(float x,float y,float z){X=x;Y=y;Z=z;}}
public readonly struct PhonePoint
{public readonly float X,Y,Nx,Ny;public PhonePoint(float x,float y,float nx,float ny){X=x;Y=y;Nx=nx;Ny=ny;}}
public sealed class PhoneMesh
{
    public readonly List<PhoneVertex> Vertices=new(),Normals=new();public readonly List<int> Triangles=new();
    public static PhoneMesh Extrude(List<PhonePoint> shape,float depth,float bevel)
    {
        var m=new PhoneMesh();int count=shape.Count;bevel=Math.Min(bevel,depth*.49f);
        // Separate cap vertices keep flat faces flat; three bevel steps round the rim.
        var inset=new List<float>();var z=new List<float>();var nr=new List<float>();var nz=new List<float>();const int steps=3;
        for(int i=0;i<=steps;i++)
        {double a=(Math.PI/2)*(steps-i)/steps;float c=(float)Math.Cos(a),s=(float)Math.Sin(a);inset.Add(bevel*(1-c));z.Add(-depth*.5f+bevel*(1-s));nr.Add(c);nz.Add(-s);}
        for(int i=0;i<=steps;i++)
        {double a=(Math.PI/2)*i/steps;float c=(float)Math.Cos(a),s=(float)Math.Sin(a);inset.Add(bevel*(1-c));z.Add(depth*.5f-bevel*(1-s));nr.Add(c);nz.Add(s);}
        for(int ring=0;ring<z.Count;ring++)foreach(var p in shape)
        {m.Vertices.Add(new PhoneVertex(p.X-inset[ring]*p.Nx,p.Y-inset[ring]*p.Ny,z[ring]));m.Normals.Add(new PhoneVertex(p.Nx*nr[ring],p.Ny*nr[ring],nz[ring]));}
        for(int ring=0;ring<z.Count-1;ring++)for(int i=0;i<count;i++)
        {int a=ring*count+i,b=ring*count+(i+1)%count,c=b+count,e=a+count;m.Triangles.AddRange(new[]{a,b,c,a,c,e});}
        for(int face=0;face<2;face++)
        {
            int start=m.Vertices.Count,source=face==0?0:(z.Count-1)*count;
            for(int i=0;i<count;i++){m.Vertices.Add(m.Vertices[source+i]);m.Normals.Add(new PhoneVertex(0,0,face==0?-1:1));}
            int center=m.Vertices.Count;m.Vertices.Add(new PhoneVertex(0,0,face==0?-depth*.5f:depth*.5f));m.Normals.Add(new PhoneVertex(0,0,face==0?-1:1));
            for(int i=0;i<count;i++){int a=start+i,b=start+(i+1)%count;m.Triangles.AddRange(face==0?new[]{center,b,a}:new[]{center,a,b});}
        }
        return m;
    }
    public static PhoneMesh Silhouette(PhoneVertex[] anchors,float scale)
    {
        var m=new PhoneMesh();const int steps=5;
        for(int i=0;i<anchors.Length;i++)for(int k=0;k<steps;k++)
        {
            var a=anchors[(i+anchors.Length-1)%anchors.Length];var b=anchors[i];var c=anchors[(i+1)%anchors.Length];var d=anchors[(i+2)%anchors.Length];float t=k/(float)steps,t2=t*t,t3=t2*t;
            float Cat(float av,float bv,float cv,float dv)=>.5f*((2*bv)+(-av+cv)*t+(2*av-5*bv+4*cv-dv)*t2+(-av+3*bv-3*cv+dv)*t3)*scale;
            m.Vertices.Add(new PhoneVertex(-Cat(a.X,b.X,c.X,d.X),Cat(a.Y,b.Y,c.Y,d.Y),0));m.Normals.Add(new PhoneVertex(0,0,1));
        }
        double area=0;for(int i=0;i<m.Vertices.Count;i++){var a=m.Vertices[i];var b=m.Vertices[(i+1)%m.Vertices.Count];area+=a.X*b.Y-b.X*a.Y;}
        var remaining=new List<int>();for(int i=0;i<m.Vertices.Count;i++)remaining.Add(i);if(area<0)remaining.Reverse();
        while(remaining.Count>2)
        {
            bool clipped=false;
            for(int i=0;i<remaining.Count;i++)
            {
                int a=remaining[(i+remaining.Count-1)%remaining.Count],b=remaining[i],c=remaining[(i+1)%remaining.Count];if(Cross(m.Vertices[a],m.Vertices[b],m.Vertices[c])<=0)continue;
                bool contains=false;foreach(int p in remaining)if(p!=a&&p!=b&&p!=c&&Cross(m.Vertices[a],m.Vertices[b],m.Vertices[p])>=0&&Cross(m.Vertices[b],m.Vertices[c],m.Vertices[p])>=0&&Cross(m.Vertices[c],m.Vertices[a],m.Vertices[p])>=0){contains=true;break;}
                if(contains)continue;m.Triangles.AddRange(new[]{a,b,c});remaining.RemoveAt(i);clipped=true;break;
            }
            if(!clipped)throw new InvalidOperationException("Rear emblem contour cannot be triangulated");
        }
        return m;
    }
    static double Cross(PhoneVertex a,PhoneVertex b,PhoneVertex c)=>(double)(b.X-a.X)*(c.Y-a.Y)-(double)(b.Y-a.Y)*(c.X-a.X);
}
