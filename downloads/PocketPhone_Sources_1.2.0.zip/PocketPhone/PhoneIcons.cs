using System;
using System.Collections.Generic;
using UnityEngine;
namespace PocketPhone;
public sealed class PhoneIcons : IDisposable
{
    readonly Dictionary<string,Sprite> _sprites=new();readonly List<Texture2D> _textures=new();
    public Sprite Get(string name)
    {
        if(_sprites.TryGetValue(name,out var sprite))return sprite;
        const int n=96;var pixels=new Color32[n*n];
        void Plot(float x,float y,float radius,Color color)
        {
            int minX=Mathf.Max(0,(int)(x-radius-1)),maxX=Mathf.Min(n-1,(int)(x+radius+1));
            int minY=Mathf.Max(0,(int)(y-radius-1)),maxY=Mathf.Min(n-1,(int)(y+radius+1));
            for(int yy=minY;yy<=maxY;yy++)for(int xx=minX;xx<=maxX;xx++)
            {
                float alpha=Mathf.Clamp01(radius+.5f-Vector2.Distance(new Vector2(xx+.5f,yy+.5f),new Vector2(x,y)));
                if(alpha<=0)continue;int i=(n-1-yy)*n+xx;Color old=pixels[i];float a=color.a*alpha;
                pixels[i]=Color.Lerp(old,new Color(color.r,color.g,color.b,1),a);pixels[i].a=(byte)Mathf.Clamp(Mathf.RoundToInt((old.a+a*(1-old.a))*255),0,255);
            }
        }
        void Line(float x1,float y1,float x2,float y2,Color c,float width=5)
        {int steps=Mathf.CeilToInt(Vector2.Distance(new Vector2(x1,y1),new Vector2(x2,y2))*2);for(int k=0;k<=steps;k++){float q=steps==0?0:(float)k/steps;Plot(Mathf.Lerp(x1,x2,q),Mathf.Lerp(y1,y2,q),width*.5f,c);}}
        void Arc(float x,float y,float r,float start,float end,Color c,float width=5)
        {for(float a=start;a<end;a+=2){float p=a*Mathf.Deg2Rad,q=Mathf.Min(a+2,end)*Mathf.Deg2Rad;Line(x+r*Mathf.Cos(p),y+r*Mathf.Sin(p),x+r*Mathf.Cos(q),y+r*Mathf.Sin(q),c,width);}}
        void Box(float x,float y,float w,float h,float r,Color c)
        {Line(x+r,y,x+w-r,y,c);Line(x+r,y+h,x+w-r,y+h,c);Line(x,y+r,x,y+h-r,c);Line(x+w,y+r,x+w,y+h-r,c);Arc(x+r,y+r,r,180,270,c);Arc(x+w-r,y+r,r,270,360,c);Arc(x+w-r,y+h-r,r,0,90,c);Arc(x+r,y+h-r,r,90,180,c);}
        var white=Color.white;
        switch(name)
        {
            case "tiktok":
                void Note(float ox,float oy,Color c){Line(53+ox,19+oy,53+ox,62+oy,c,9);Arc(40+ox,64+oy,13,0,360,c,9);Arc(74+ox,19+oy,21,90,180,c,9);}
                Note(-3,1,new Color(.07f,.95f,.94f));Note(3,-1,new Color(1,.15f,.37f));Note(0,0,white);break;
            case "instagram":Box(16,16,64,64,19,new Color(1,.35f,.70f));Arc(48,48,16,0,360,new Color(1,.66f,.27f));Plot(68,28,4,white);break;
            case "back":Line(60,22,34,48,white);Line(34,48,60,74,white);break;
            case "close":Line(29,29,67,67,white);Line(67,29,29,67,white);break;
            case "refresh":Arc(48,48,27,40,326,white);Line(71,20,71,38,white);Line(71,38,54,36,white);break;
            case "keyboard":Box(12,23,72,50,8,white);for(int yy=0;yy<2;yy++)for(int xx=0;xx<5;xx++)Plot(23+xx*12,34+yy*13,2.5f,white);Line(31,62,66,62,white);break;
            case "sound":case "mute":Line(17,39,30,39,white);Line(30,39,47,25,white);Line(47,25,47,71,white);Line(47,71,30,57,white);Line(30,57,17,57,white);Line(17,57,17,39,white);if(name=="sound"){Arc(45,48,20,-45,45,white);Arc(45,48,32,-42,42,white);}else{Line(62,36,80,60,white);Line(80,36,62,60,white);}break;
            case "settings":for(int i=0;i<3;i++){float yy=25+i*23,xx=i%2==0?34:65;Line(18,yy,78,yy,white);Plot(xx,yy,8,white);Plot(xx,yy,4,new Color(.07f,.1f,.15f));}break;
            case "spin":Line(56,16,29,51,white);Line(29,51,49,51,white);Line(49,51,40,80,white);Line(40,80,70,41,white);Line(70,41,50,41,white);Line(50,41,56,16,white);break;
            case "globe":Arc(48,48,31,0,360,white);Line(17,48,79,48,white);Arc(48,48,16,0,360,white,4);Line(48,17,48,79,white,4);break;
            case "go":Line(22,48,74,48,white);Line(56,30,74,48,white);Line(74,48,56,66,white);break;
        }
        var texture=new Texture2D(n,n,TextureFormat.RGBA32,false);texture.SetPixels32(pixels);texture.Apply();texture.filterMode=FilterMode.Bilinear;_textures.Add(texture);
        sprite=Sprite.Create(texture,new Rect(0,0,n,n),new Vector2(.5f,.5f),96);_sprites[name]=sprite;return sprite;
    }
    public void Dispose(){foreach(var s in _sprites.Values)UnityEngine.Object.Destroy(s);foreach(var t in _textures)UnityEngine.Object.Destroy(t);_sprites.Clear();_textures.Clear();}
}
