using System;
namespace PocketPhone;
public readonly struct PhoneRect
{
    public readonly float X,Y,W,H;
    public PhoneRect(float x,float y,float w,float h){X=x;Y=y;W=w;H=h;}
    public bool Contains(float x,float y)=>x>=X&&y>=Y&&x<X+W&&y<Y+H;
}
public static class PhoneLayout
{
    public const float Width=480,Height=960;
    public static readonly PhoneRect Web=new(12,88,456,456f*PhoneProtocol.Height/PhoneProtocol.Width);
    public static readonly PhoneRect Back=new(12,909,58,42), Keyboard=new(78,909,120,42), Sound=new(206,909,58,42), Settings=new(272,909,58,42), Spin=new(338,909,130,42);
    public static readonly PhoneRect TikTok=new(12,32,222,46),Instagram=new(242,32,226,46),Close=new(436,4,32,24);
    public static bool WebPoint(float x,float y,out int px,out int py)=>PhoneProtocol.Point(x,y,Web.X,Web.Y,Web.W,Web.H,out px,out py);
    public static float Smooth(float t){t=Math.Max(0,Math.Min(1,t));return t*t*t*(t*(t*6-15)+10);}
    public static float Follow(float delta,float seconds)=>1-(float)Math.Exp(-Math.Max(0,delta)/Math.Max(.01f,seconds));
    public static float Pulse(float elapsed,float duration=.28f)=>elapsed<=0||elapsed>=duration?0:(float)Math.Pow(Math.Sin(Math.PI*elapsed/duration),2);
    public static float Scale(float fieldOfView,float depth,float fraction,float modelHeight)=>2*depth*(float)Math.Tan(fieldOfView*Math.PI/360)*fraction/modelHeight;
}
