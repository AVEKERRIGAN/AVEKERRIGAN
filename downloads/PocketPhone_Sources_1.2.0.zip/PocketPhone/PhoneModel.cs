using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
namespace PocketPhone;
public sealed class PhoneModel : MonoBehaviour
{
    readonly List<Material> _materials = new(); readonly List<Mesh> _meshes = new();
    public const float Height=PhoneDesign.Height,DisplayWidth=PhoneDesign.DisplayWidth;
    public void Build()
    {
        var design=PhoneDesign.Build();var palette=new Dictionary<string,Material>();
        foreach(var finish in design.Finishes)
        {
            var mat=Mat(new Color(finish.R,finish.G,finish.B));
            if(mat.HasProperty("_Metallic"))mat.SetFloat("_Metallic",finish.Metallic);
            if(mat.HasProperty("_Smoothness"))mat.SetFloat("_Smoothness",finish.Smoothness);
            if(mat.HasProperty("_Glossiness"))mat.SetFloat("_Glossiness",finish.Smoothness);
            palette.Add(finish.Name,mat);
        }
        // Batch by finish: all 62 details render in 11 draws instead of 62.
        foreach(var finish in design.Finishes)
        {
            var vertices=new List<Vector3>();var normals=new List<Vector3>();var triangles=new List<int>();
            foreach(var part in design.Parts)
            {
                if(part.Finish!=finish.Name)continue;
                int offset=vertices.Count;var rotation=Quaternion.Euler(part.Rx,part.Ry,part.Rz);
                var position=new Vector3(part.X,part.Y,part.Z);
                for(int i=0;i<part.Mesh.Vertices.Count;i++)
                {
                    var v=part.Mesh.Vertices[i];var n=part.Mesh.Normals[i];
                    vertices.Add(rotation*new Vector3(v.X,v.Y,v.Z)+position);
                    normals.Add(rotation*new Vector3(n.X,n.Y,n.Z));
                }
                foreach(int index in part.Mesh.Triangles)triangles.Add(offset+index);
            }
            if(vertices.Count==0)continue;
            var mesh=new Mesh{name=finish.Name};mesh.SetVertices(vertices);mesh.SetNormals(normals);
            mesh.SetTriangles(triangles,0);mesh.RecalculateBounds();_meshes.Add(mesh);
            var go=new GameObject(finish.Name);go.transform.SetParent(transform,false);
            go.AddComponent<MeshFilter>().sharedMesh=mesh;
            var renderer=go.AddComponent<MeshRenderer>();renderer.sharedMaterial=palette[finish.Name];
            renderer.shadowCastingMode=ShadowCastingMode.Off;renderer.receiveShadows=false;
        }
    }
    Material Mat(Color color,bool unlit=false)
    {
        var shader = unlit ? Shader.Find("Universal Render Pipeline/Unlit") ?? Shader.Find("Unlit/Texture") : Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard");
        var mat=new Material(shader); mat.color=color;
        if(mat.HasProperty("_BaseColor")) mat.SetColor("_BaseColor",color);
        if(mat.HasProperty("_Smoothness")) mat.SetFloat("_Smoothness",.7f);
        _materials.Add(mat); return mat;
    }
    void OnDestroy() { foreach(var m in _materials) Destroy(m); foreach(var m in _meshes) Destroy(m); }
}
