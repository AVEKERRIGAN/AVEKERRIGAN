"""Render the exact exported mesh data; no Unity/game screenshot is implied."""
import bpy, json, math, sys
from pathlib import Path
from mathutils import Vector
args=sys.argv[sys.argv.index('--')+1:]
data=json.loads(Path(args[0]).read_text())
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
materials={}
for f in data['Finishes']:
    mat=bpy.data.materials.new(f['Name']);mat.use_nodes=True
    node=mat.node_tree.nodes.get('Principled BSDF')
    # Unity material colors are sRGB input; Blender nodes expect linear RGB.
    def linear(c): return c/12.92 if c<=.04045 else ((c+.055)/1.055)**2.4
    node.inputs['Base Color'].default_value=(linear(f['R']),linear(f['G']),linear(f['B']),1)
    node.inputs['Metallic'].default_value=f['Metallic'];node.inputs['Roughness'].default_value=1-f['Smoothness']
    materials[f['Name']]=mat
for side in ['back','front']:
    root=bpy.data.objects.new(side,None);bpy.context.collection.objects.link(root)
    root.location=(-.068 if side=='back' else .068,0,0)
    root.rotation_euler=(0,math.pi-.11 if side=='back' else .12,0)
    for p in data['Parts']:
        vertices=[(v['X'],v['Y'],-v['Z']) for v in p['Mesh']['Vertices']]
        t=p['Mesh']['Triangles'];faces=[(t[i],t[i+2],t[i+1]) for i in range(0,len(t),3)]
        mesh=bpy.data.meshes.new(p['Name']);mesh.from_pydata(vertices,[],faces);mesh.update()
        mesh.normals_split_custom_set_from_vertices([(v['X'],v['Y'],-v['Z']) for v in p['Mesh']['Normals']])
        for face in mesh.polygons:face.use_smooth=True
        obj=bpy.data.objects.new(p['Name'],mesh);bpy.context.collection.objects.link(obj)
        obj.data.materials.append(materials[p['Finish']]);obj.parent=root
        obj.location=(p['X'],p['Y'],-p['Z'])
        obj.rotation_euler=(-math.radians(p['Rx']),-math.radians(p['Ry']),math.radians(p['Rz']))
# Studio backdrop behind the phones.
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.045))
back=bpy.context.object;mat=bpy.data.materials.new('Backdrop');mat.diffuse_color=(.19,.20,.22,1);back.data.materials.append(mat)
def area(name,location,energy,size,target):
    light=bpy.data.lights.new(name,'AREA');light.energy=energy;light.shape='DISK';light.size=size
    obj=bpy.data.objects.new(name,light);bpy.context.collection.objects.link(obj);obj.location=location
    obj.rotation_euler=(Vector(target)-obj.location).to_track_quat('-Z','Y').to_euler()
area('Large left softbox',(-.37,.24,.20),10,.25,(0,0,0))
area('Right strip',(.30,.07,.10),5,.14,(0,0,0))
area('Top softbox',(.01,.28,.12),5,.13,(0,0,0))
cam_data=bpy.data.cameras.new('Camera');cam=bpy.data.objects.new('Camera',cam_data);bpy.context.collection.objects.link(cam)
cam.location=(0,.012,.75);cam.rotation_euler=(-math.atan2(.012,.75),0,0)
cam_data.type='ORTHO';cam_data.ortho_scale=.300;bpy.context.scene.camera=cam
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=96;scene.cycles.use_denoising=False
scene.render.resolution_x=1200;scene.render.resolution_y=1150;scene.render.resolution_percentage=100
scene.world.color=(.15,.15,.15);scene.view_settings.view_transform='AgX';scene.view_settings.exposure=-.65
scene.render.image_settings.file_format='PNG';scene.render.filepath=args[1]
bpy.ops.wm.save_as_mainfile(filepath=args[1].replace('.png','.blend'))
bpy.ops.render.render(write_still=True)
