using System.Numerics;
using System.Text.Json;
using PocketPhone;

var model=PhoneDesign.Build();int checks=0,triangles=0;
void Check(bool ok,string message){checks++;if(!ok)throw new Exception(message);}
Vector3 V(PhoneVertex v)=>new(v.X,v.Y,v.Z);
foreach(var part in model.Parts)
{
    var mesh=part.Mesh;
    Check(mesh.Vertices.Count==mesh.Normals.Count,part.Name+": missing normals");
    Check(mesh.Triangles.Count%3==0,part.Name+": incomplete faces");
    Check(model.Finishes.Any(f=>f.Name==part.Finish),part.Name+": missing material");
    foreach(var n in mesh.Normals)
        Check(float.IsFinite(n.X)&&float.IsFinite(n.Y)&&float.IsFinite(n.Z)&&Math.Abs(V(n).Length()-1)<1e-5,part.Name+": invalid normal");
    var edges=new Dictionary<(Vector3,Vector3),int>();
    for(int i=0;i<mesh.Triangles.Count;i+=3)
    {
        int ia=mesh.Triangles[i],ib=mesh.Triangles[i+1],ic=mesh.Triangles[i+2];
        Check(ia>=0&&ib>=0&&ic>=0&&ia<mesh.Vertices.Count&&ib<mesh.Vertices.Count&&ic<mesh.Vertices.Count,part.Name+": invalid index");
        var a=V(mesh.Vertices[ia]);var b=V(mesh.Vertices[ib]);var c=V(mesh.Vertices[ic]);
        var cross=Vector3.Cross(b-a,c-a);
        Check(float.IsFinite(cross.Length())&&cross.Length()>1e-14,part.Name+": collapsed face");
        Check(Vector3.Dot(cross,V(mesh.Normals[ia])+V(mesh.Normals[ib])+V(mesh.Normals[ic]))>0,part.Name+": reversed face");
        foreach(var (start,end) in new[]{(a,b),(b,c),(c,a)})
        {edges.TryGetValue((start,end),out int count);edges[(start,end)]=count+1;}
        triangles++;
    }
    if(!part.Name.Contains("emblem",StringComparison.OrdinalIgnoreCase)&&part.Name!="Emblem leaf")
        Check(edges.All(e=>e.Value==1&&edges.TryGetValue((e.Key.Item2,e.Key.Item1),out int opposite)&&opposite==1),part.Name+": open or nonmanifold solid");
}
var cameras=model.Parts.Where(p=>p.Name.EndsWith("outer rim")).ToArray();
Check(cameras.Length==3,"three cameras");
foreach(var camera in cameras)
{
    // Lens rims must stay inside the shelf, separated from one another.
    float radius=camera.Mesh.Vertices.Max(v=>v.X);
    Check(Math.Abs(camera.X)+radius<.099f/2&&Math.Abs(camera.Y-.0715f)+radius<.060f/2,"camera outside shelf");
    foreach(var other in cameras.Where(c=>c!=camera))
        Check(Math.Sqrt(Math.Pow(other.X-camera.X,2)+Math.Pow(other.Y-camera.Y,2))>2*radius,"overlapping camera rims");
}
Check(PhoneDesign.Height==.212f&&PhoneDesign.DisplayWidth==.092f&&PhoneDesign.DisplayZ==-.0081f,"existing grip and UI dimensions");
var island=model.Parts.Single(p=>p.Name=="Dynamic Island");
Check(island.Y+island.Mesh.Vertices.Min(v=>v.Y)>.092f/480*(480-32),"island must clear app buttons");
Check(model.Parts.Sum(p=>p.Mesh.Vertices.Count)<40000&&triangles<60000,"mesh budget");
if(args.Length>0)File.WriteAllText(args[0],JsonSerializer.Serialize(model,new JsonSerializerOptions{IncludeFields=true}));
Console.WriteLine($"PASS: {checks} geometry assertions; {model.Parts.Count} parts, {model.Parts.Sum(p=>p.Mesh.Vertices.Count)} vertices, {triangles} triangles. Mesh exported from the same generator used by Unity.");
