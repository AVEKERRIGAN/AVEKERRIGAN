using System;
namespace GoldRushExpress
{
    /// Shared timing: the host waits exactly as long as the clients animate (Screen.cs uses the same numbers).
    public static class GrTiming
    {
        public static float Out(bool t) => t ? 0.12f : 0.28f;
        public static float Stagger(bool t) => t ? 0.05f : 0.12f;
        public static float Fall(bool t) => t ? 0.5f : 1.0f;
        public static float Lines(bool t) => t ? 0.6f : 1.3f;
        public static float Reveal(bool t) => t ? 0.45f : 1.0f;      // locos flip to their coin / special
        public static float RespinSpin(bool t) => t ? 0.55f : 1.05f;  // one respin of the 2-loco feature
        public static float RespinPay(bool t) => t ? 0.5f : 1.1f;
        public static float Scatter(bool t) => t ? 0.5f : 1.1f;
        public static float Zoom(bool t) => t ? 0.8f : 2.0f;
        public static float Intro(bool t) => t ? 2.0f : 4.2f;        // train crosses the screen + MONEY WAGON plaque
        public static float BSpin(bool t) => t ? 0.65f : 1.2f;       // empty wagon cells spin, new symbols land
        public static float LandEach(bool t) => t ? 0.12f : 0.3f;    // extra landing show per new SPECIAL symbol
        public static float ActBase(bool t) => t ? 0.4f : 0.85f;     // banker / marshal / tycoon / spirit action
        public static float Shot(bool t) => t ? 0.1f : 0.22f;        // per outlaw shot
        public static float Unlock(bool t) => t ? 0.5f : 1.2f;
        public static float Full(bool t) => t ? 1.0f : 2.4f;
        public static float Settle(bool t) => t ? 0.2f : 0.45f;
        public static float AntEach(bool t) => t ? 0.35f : 0.85f;
        static bool IsLoco(int x) => x == TrainEngine.SCAT || x == TrainEngine.GOLD;
        /// anticipation once 2 locos are visible (one more triggers MONEY WAGON)
        public static bool AntCol(int[] g, int c) { if (g == null) return false; int n = 0; for (int k = 0; k < c * TrainEngine.Rows && k < g.Length; k++) if (IsLoco(g[k])) n++; return n >= 2; }
        public static float AntBefore(int[] g, int c, bool t) { float e = 0; for (int k = 0; k <= c; k++) if (AntCol(g, k)) e += AntEach(t); return e; }
        public static float SpinIn(int[] g, bool t) => Fall(t) + Stagger(t) * (TrainEngine.Cols - 1) + AntBefore(g, TrainEngine.Cols - 1, t);
        public static float Spin(GrMsg m)
        {
            bool t = m.tb == 1; var s = m.s; if (s == null) return 1f;
            float d = Out(t) + SpinIn(s.g, t) + 0.1f;
            if (s.lines != null && s.lines.Length > 0) d += Lines(t);
            if (s.rs != null && s.rs.Length > 0)
            {
                d += Reveal(t);
                if (s.lw <= 0) foreach (var r in s.rs) { d += RespinSpin(t); if (r.lw > 0 && r.lines != null && r.lines.Length > 0) d += Lines(t); }
                d += RespinPay(t);
            }
            if (s.sc >= 3) d += Scatter(t) + Zoom(t);
            if (m.w > 0) d += Settle(t);
            return d;
        }
        public static float ActDur(TrainEngine.Ev e, bool t) => (e.k == TrainEngine.OUTLAW || e.k == TrainEngine.IOUTLAW) ? ActBase(t) * .5f + Shot(t) * Math.Min(e.tg != null ? e.tg.Length : 0, 12) : ActBase(t);
        public static int Specials(TrainEngine.BStep b) { int n = 0; if (b?.nw != null) foreach (var i in b.nw) if (i >= 0 && i < b.bt.Length && b.bt[i] >= TrainEngine.BANKER) n++; return Math.Min(n, 8); }
        public static float BStep(GrMsg m)
        {
            bool t = m.tb == 1; var b = m.b; if (b == null) return 1f;
            float d = m.bi == 0 ? Reveal(t) : BSpin(t) + Stagger(t) * (TrainEngine.BCols - 1);
            d += Specials(b) * LandEach(t);
            if (b.ev != null) foreach (var e in b.ev) d += ActDur(e, t);
            d += Math.Max(0, b.cols - b.cols0) * Unlock(t);
            if (b.full == 1) d += Full(t);
            d += Settle(t);
            return d;
        }
        // Every nested phase can finish on the next rendered frame. Allow for
        // 25 FPS clients so the host never cuts off the last landing/action.
        public static float FrameSlack(GrMsg m)
        {
            int phases=1;
            if(m.t=="bstep" && m.b!=null)
            {
                var b=m.b;phases+=Specials(b)+Math.Max(0,b.cols-b.cols0)+1+(b.full==1?1:0);
                if(b.ev!=null)foreach(var e in b.ev)
                    phases+=(e.k==TrainEngine.OUTLAW||e.k==TrainEngine.IOUTLAW)?1+Math.Min(e.tg?.Length??0,12):1;
            }
            else if(m.t=="spin" && m.s!=null)
            {
                var s=m.s;phases+=2+(s.lines?.Length>0?1:0)+(m.w>0?1:0)+(s.sc>=3?2:0);
                if(s.rs?.Length>0){phases+=2;if(s.lw<=0)foreach(var r in s.rs)phases+=1+(r.lines?.Length>0&&r.lw>0?1:0);}
            }
            return .15f+phases*.04f;
        }
    }}
