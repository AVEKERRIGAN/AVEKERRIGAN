using System;
using System.Globalization;
namespace GoldRushExpress
{
    // Fractions of a cell / side sign, shared by the renderer and offline checks.
    public static class TrainPresentation
    {
        public readonly struct Box
        {
            public readonly float X, Y, Width, Height;
            public Box(float x,float y,float width,float height){X=x;Y=y;Width=width;Height=height;}
        }
        public static readonly Box CoinValue=new Box(0,0,.54f,.23f);
        public static readonly Box CardValue=new Box(0,-.23f,.62f,.21f);
        public static readonly Box TotalTitle=new Box(0,.33f,.84f,.17f);
        public static readonly Box TotalMultiplier=new Box(0,.005f,.84f,.27f);
        public static readonly Box TotalMoney=new Box(0,-.31f,.84f,.15f);
        public static string Multiplier(float value)
        {
            if(float.IsNaN(value)||float.IsInfinity(value))value=0;
            value=Math.Max(0,value);
            return value.ToString("0.##",CultureInfo.InvariantCulture)+"x";
        }
        public static string CellValue(float value)
        {
            if(value>=10000)return "x"+(value/1000).ToString("0.#",CultureInfo.InvariantCulture)+"K";
            return "x"+Math.Max(0,value).ToString("0.##",CultureInfo.InvariantCulture);
        }
        public static float Total(float baseWin,float boardWin,float extra=0)
            =>Math.Min((float)TrainEngine.MaxWinX,Math.Max(0,baseWin+boardWin+extra));
    }
}
