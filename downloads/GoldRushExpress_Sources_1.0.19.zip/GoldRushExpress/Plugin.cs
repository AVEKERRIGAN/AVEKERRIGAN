using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using BepInEx;
using BepInEx.Configuration;
using HarmonyLib;
using Mirror;
using MoreMountains.Tools;
using UnityEngine;

namespace GoldRushExpress
{
    [BepInPlugin(GUID, "Gold Rush Express Slot", Version)]
    [BepInDependency("com.moregames.base", BepInDependency.DependencyFlags.SoftDependency)]
    public class TrainPlugin : BaseUnityPlugin
    {
        public const string GUID = "com.malenki.goldrushexpress", Version = "1.0.19";
        /// Bump when networked layout or animation timing changes (mismatched clients then cannot spawn the machine instead of desyncing).
        public const string NetLayout = "gr-net-1.2";
        public const string PrefabName = "GoldRushExpress_Machine";
        public static TrainPlugin Instance;
        public static BepInEx.Logging.ManualLogSource Log;
        public static GameObject Prefab;
        public static uint AssetId;
        public static ConfigEntry<bool> ReplaceAllSlots, Verbose, RestyleCabinet;
        public static ConfigEntry<float> CabinetScale, ScreenMargin, Particles;
        public static ConfigEntry<KeyCode> SpawnKey, ForceBonusKey, TurboKey;
        public static ConfigEntry<int> AutoSpins;
        public static ConfigEntry<bool> AutoStopOnBonus, ScreenFlipX, ScreenFlipY;
        public static ConfigEntry<bool> EnableForceBonusKey, AlwaysBonusNextSpin;
        public static ConfigEntry<int> ForceBonusEveryNSpins;

        static GameObject _holder;
        float _nextCheck;
        static readonly HashSet<string> _loggedFloors = new HashSet<string>();
        static float _nextBuildAttempt;
        static bool _legacyBroken;
        static int _lastTemplateCount = -1;

        public static void V(string s) { if (Verbose == null || Verbose.Value) Log.LogInfo("[GR] " + s); }

        void Awake()
        {
            Instance = this; Log = Logger;
            CabinetScale = Config.Bind("GR_Cabinet", "GR_CabinetScale", 1.35f, "Overall cabinet size multiplier (1 = vanilla). Host-side; clients get it via spawn.");
            ReplaceAllSlots = Config.Bind("GR_Spawn", "GR_ReplaceVanillaSlots", false,
                "Host: every spot that would spawn the vanilla slot machine spawns Gold Rush Express instead (otherwise it is added to the floor pool next to the vanilla slot).");
            // ScrollLock is free in this game and in our other mods (F1 = game, F12 = Thunder of Olympus, Pause = Reel King Lake).
            SpawnKey = Config.Bind("GR_Debug", "GR_SpawnKey", KeyCode.ScrollLock,
                "Host only: spawn a Gold Rush Express machine 3 m in front of you. None = disabled. (Shift+ScrollLock = force MONEY WAGON, see GR_EnableForceBonusKey; alternative free key: NumLock)");
            TurboKey = Config.Bind("GR_Controls", "GR_TurboKey_v102", KeyCode.None,
                "Host hotkey to toggle TURBO on all Gold Rush Express machines. Default None (use the cabinet TURBO button). Set a KeyCode if you want a hotkey.");
            ForceBonusKey = Config.Bind("GR_Debug", "GR_ForceBonusKey", KeyCode.None,
                "Host only (needs GR_EnableForceBonusKey): extra single key that forces 3 bonus locos (MONEY WAGON) on the NEXT spin. Default None (use Shift+<spawn key>).");
            EnableForceBonusKey = Config.Bind("GR_Debug", "GR_EnableForceBonusKey_rel", false, "DEBUG (host): allow Shift+<spawn key> (Shift+ScrollLock by default; and GR_ForceBonusKey) to force the bonus on the next spin.");
            AlwaysBonusNextSpin = Config.Bind("GR_Debug", "GR_AlwaysBonus", false, "DEBUG host: EVERY spin triggers the bonus.");
            ForceBonusEveryNSpins = Config.Bind("GR_Debug", "GR_ForceBonusEveryNSpins", 0, "DEBUG host: force the bonus every N spins per machine (0 = off).");
            ScreenMargin = Config.Bind("GR_Visual", "GR_ScreenSafeMargin", 0.03f, "Inset of the slot screen on each side (0..0.2) so the bezel never cuts symbols.");
            RestyleCabinet = Config.Bind("GR_Visual", "GR_RestyleCabinet", true, "Recolor the cabinet in Gold Rush Express colors (rusty iron / gold), logo topper and side light strips (client side).");
            Particles = Config.Bind("GR_Visual", "GR_ParticleAmount", 1f, "Explosion particle amount multiplier (0 = off, 1 = normal, 2 = lots).");
            AutoSpins = Config.Bind("GR_Controls", "GR_AutoSpins", 10, "Spins started by the on-screen AUTO button (1..100). Press AUTO again to stop.");
            AutoStopOnBonus = Config.Bind("GR_Controls", "GR_AutoStopOnBonus", true, "Stop auto-spin when the bonus triggers.");
            ScreenFlipX = Config.Bind("GR_Visual", "GR_ScreenButtonsFlipX", false, "If clicks on the on-screen buttons land mirrored left/right, set true (same on all players). Restart required.");
            ScreenFlipY = Config.Bind("GR_Visual", "GR_ScreenButtonsFlipY", false, "Same for top/bottom.");
            Verbose = Config.Bind("GR_Debug", "GR_VerboseLogging", true, "Write detailed [GR] lines to LogOutput.log.");
            using (var md5 = MD5.Create())
                AssetId = BitConverter.ToUInt32(md5.ComputeHash(Encoding.UTF8.GetBytes(PrefabName + "|" + NetLayout)), 0);
            if (AssetId == 0) AssetId = 0x5A4F4C31;
            TrainGame.RegisterRpcs();
            V("RPC UserRpcShowSpin registered");
            var h = new Harmony(GUID);
            h.PatchAll(typeof(TrainPlugin).Assembly);
            foreach (var m in h.GetPatchedMethods()) V("Harmony patched: " + m.DeclaringType?.Name + "." + m.Name);
            try
            {
                var runner = new GameObject("GoldRushExpressRunner");
                runner.hideFlags = HideFlags.HideAndDontSave;
                UnityEngine.Object.DontDestroyOnLoad(runner);
                runner.AddComponent<TrainRunner>();
            }
            catch (Exception e) { Logger.LogError("Runner creation failed: " + e); }
            Logger.LogInfo($"Gold Rush Express {Version} loaded, assetId={AssetId}, spawnKey={SpawnKey.Value}, replaceVanillaSlots={ReplaceAllSlots.Value}");
        }

        void Update() => Tick();

        static int _lastTickFrame = -1;
        static bool _tickLogged;
        /// Called from our own runner object, the plugin object and every machine; runs once per frame.
        public void Tick()
        {
            if (Time.frameCount == _lastTickFrame) return;
            _lastTickFrame = Time.frameCount;
            if (!_tickLogged) { _tickLogged = true; V("Tick running (input + spawn handler checks active)"); }
            try { TickInner(); } catch (Exception e) { if (Time.frameCount % 600 == 0) Log.LogError("[GR] Tick error: " + e); }
        }

        void TickInner()
        {
            CheckHotkey();
            if (KeyPressed(TurboKey.Value) && NetworkServer.active)
                foreach (var g in FindObjectsByType<TrainGame>(FindObjectsSortMode.None)) g.ToggleTurbo(null);
            // Shift+spawn key (Shift avoids Ctrl combos used elsewhere)
            bool combo = SpawnKey.Value != KeyCode.None && ShiftHeld() && KeyPressedRaw(SpawnKey.Value);
            if (combo) Log.LogInfo($"[GR] Key combo Shift+{SpawnKey.Value} detected");
            if (EnableForceBonusKey.Value && (combo || KeyPressed(ForceBonusKey.Value))) ToggleForceBonus("key");
            else if (combo) Log.LogInfo("[GR] Shift combo ignored: GR_EnableForceBonusKey = false");
            if (Time.unscaledTime < _nextCheck) return;
            _nextCheck = Time.unscaledTime + 1f;
            try
            {
                var dict = (Dictionary<uint, SpawnHandlerDelegate>)AccessTools.Field(typeof(NetworkClient), "spawnHandlers").GetValue(null);
                if (!dict.ContainsKey(AssetId))
                {
                    NetworkClient.RegisterSpawnHandler(AssetId, ClientSpawn, ClientUnspawn);
                    V("Client spawn handler registered");
                }
            }
            catch (Exception e) { Logger.LogError("Spawn handler registration failed: " + e); _nextCheck += 30f; }
            // try to build the prefab early (once a casino is loaded) so problems show up in the log
            if (Prefab == null && NetworkClient.active && Time.unscaledTime > _nextBuildAttempt)
            {
                _nextBuildAttempt = Time.unscaledTime + 10f;
                EnsurePrefab(null, quiet: true);
            }
        }

        public static void ToggleForceBonus(string source)
        {
            if (!NetworkServer.active) { Log.LogWarning($"[GR] Force bonus ({source}) works only for the HOST."); return; }
            TrainGame.ForceBonusNext = !TrainGame.ForceBonusNext;
            Log.LogInfo($"[GR] Force bonus on next spin: {(TrainGame.ForceBonusNext ? "ON" : "OFF")} (via {source})");
        }

        static bool ShiftHeld() => KeyHeld(KeyCode.LeftShift) || KeyHeld(KeyCode.RightShift);
        static bool KeyHeld(KeyCode k)
        {
            try { var kb = UnityEngine.InputSystem.Keyboard.current; if (kb != null && Enum.TryParse<UnityEngine.InputSystem.Key>(k.ToString(), out var key) && kb[key].isPressed) return true; } catch { }
            if (_legacyBroken) return false;
            try { return Input.GetKey(k); } catch { _legacyBroken = true; return false; }
        }

        static bool KeyPressed(KeyCode k)
        {
            bool r = KeyPressedRaw(k);
            if (r) Log.LogInfo($"[GR] Key {k} pressed (host={NetworkServer.active})");
            return r;
        }

        static bool KeyPressedRaw(KeyCode k)
        {
            if (k == KeyCode.None) return false;
            try
            {
                var kb = UnityEngine.InputSystem.Keyboard.current;
                if (kb != null && Enum.TryParse<UnityEngine.InputSystem.Key>(k.ToString(), out var key) && kb[key].wasPressedThisFrame) return true;
            }
            catch { }
            if (_legacyBroken) return false;
            try { return Input.GetKeyDown(k); } catch { _legacyBroken = true; return false; }
        }

        void CheckHotkey()
        {
            if (SpawnKey.Value == KeyCode.None || !KeyPressedRaw(SpawnKey.Value)) return;
            if (ShiftHeld()) return; // Shift+spawn key is the debug bonus combo, not a spawn
            Log.LogInfo($"[GR] Key {SpawnKey.Value} pressed (host={NetworkServer.active})");
            V($"Spawn key {SpawnKey.Value} pressed (server active={NetworkServer.active})");
            if (!NetworkServer.active) { Log.LogWarning("[GR] Spawn key works only for the HOST."); return; }
            if (!EnsurePrefab(null)) { Log.LogError("[GR] Cannot spawn: prefab could not be built (see messages above)."); return; }
            var lp = NetworkClient.localPlayer;
            Transform t = lp != null ? lp.transform : (Camera.main != null ? Camera.main.transform : null);
            if (t == null) { Log.LogError("[GR] Cannot spawn: no local player found."); return; }
            var fwd = Vector3.ProjectOnPlane(t.forward, Vector3.up); if (fwd.sqrMagnitude < 0.01f) fwd = Vector3.forward; fwd.Normalize();
            var pos = t.position + fwd * 3f;
            if (Physics.Raycast(pos + Vector3.up * 2f, Vector3.down, out var hit, 10f)) pos = hit.point;
            var rot = Quaternion.LookRotation(-fwd, Vector3.up);
            try
            {
                var go = Instantiate(Prefab, pos, rot);
                go.name = PrefabName;
                go.transform.localScale = Prefab.transform.localScale;
                NetworkServer.Spawn(go);
                Log.LogInfo($"[GR] Hotkey spawned Gold Rush Express at {pos}. If it faces the wrong way, walk around it :)");
            }
            catch (Exception e) { Log.LogError("[GR] Hotkey spawn failed: " + e); }
        }

        static GameObject ClientSpawn(SpawnMessage msg)
        {
            V($"Client spawn request netId={msg.netId} pos={msg.position}");
            if (!EnsurePrefab(null)) { Log.LogError("[GR] Cannot spawn Gold Rush Express on client: no template machine found."); return null; }
            var go = UnityEngine.Object.Instantiate(Prefab, msg.position, msg.rotation);
            go.transform.localScale = msg.scale;
            go.name = PrefabName;
            V("Client spawned Gold Rush Express instance");
            return go;
        }
        static void ClientUnspawn(GameObject go) { V("Client unspawn Gold Rush Express"); UnityEngine.Object.Destroy(go); }

        static GameObject FindTemplate(out string how)
        {
            how = null;
            var all = Resources.FindObjectsOfTypeAll<GameBase>().Where(g => g != null).ToList();
            var assets = all.Where(g => !g.gameObject.scene.IsValid()).ToList();
            if (all.Count != _lastTemplateCount) V($"Template search: {all.Count} GameBase objects loaded, {assets.Count} are prefabs: " +
              string.Join(", ", assets.Select(g => g.GetType().Name + "@" + g.transform.root.name).Distinct().Take(30)));
            _lastTemplateCount = all.Count;
            GameBase pick = assets.FirstOrDefault(g => g is Slots && g.transform.root.GetComponent<NetworkIdentity>() != null);
            if (pick != null) { how = "vanilla Slots prefab"; return pick.transform.root.gameObject; }
            pick = assets.FirstOrDefault(g => g.GetType() != typeof(TrainGame) && g.transform.root.GetComponent<NetworkIdentity>() != null
                                               && g.transform.root.GetComponentsInChildren<NetworkBehaviour>(true).Length <= 3);
            if (pick != null) { how = "fallback prefab " + pick.GetType().Name; return pick.transform.root.gameObject; }
            return null;
        }

        /// Build our prefab by cloning a vanilla machine and swapping its game script.
        public static bool EnsurePrefab(GameObject template, bool quiet = false)
        {
            if (Prefab != null) return true;
            string how = "loot table template";
            if (template == null) template = FindTemplate(out how);
            if (template == null)
            {
                if (!quiet) Log.LogError("[GR] No template machine prefab loaded yet (enter the casino first).");
                return false;
            }
            V($"Building prefab from '{template.name}' ({how})");
            try
            {
                if (_holder == null)
                {
                    _holder = new GameObject("GoldRushExpress_PrefabHolder");
                    _holder.SetActive(false);
                    UnityEngine.Object.DontDestroyOnLoad(_holder);
                }
                var clone = UnityEngine.Object.Instantiate(template, _holder.transform);
                clone.name = PrefabName;
                var old = clone.GetComponentsInChildren<GameBase>(true).FirstOrDefault(g => !(g is TrainGame));
                if (old == null) { Log.LogError("[GR] Template has no GameBase"); UnityEngine.Object.Destroy(clone); return false; }
                V($"Template game script: {old.GetType().FullName} on '{old.gameObject.name}'");
                var game = old.gameObject.AddComponent<TrainGame>();
                int copied = 0;
                foreach (var f in typeof(GameBase).GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.DeclaredOnly))
                    try { f.SetValue(game, f.GetValue(old)); copied++; } catch { }
                V($"Copied {copied} GameBase fields (keypadSpawnPoint={(game.keypadSpawnPoint != null ? game.keypadSpawnPoint.name : "NULL")})");
                if (old is Slots s) game.CopyFromSlots(s); else game.SetDefaults();
                V($"Anchor images={game.symbolLocations?.Count ?? 0}, reels={game.reels?.Count ?? 0}, payoutText={(game.payoutText != null)}");
                foreach (var trig in clone.GetComponentsInChildren<InteractableEventTrigger>(true))
                {
                    var ev = trig.serverOnInteractEvent; if (ev == null) continue;
                    for (int i = 0; i < ev.GetPersistentEventCount(); i++)
                        if (ev.GetPersistentTarget(i) == old)
                        {
                            V($"Button '{trig.name}' -> {ev.GetPersistentMethodName(i)} rewired");
                            ev.SetPersistentListenerState(i, UnityEngine.Events.UnityEventCallState.Off);
                            if (ev.GetPersistentMethodName(i) == "TryStartGame") game.playButtons.Add(trig);
                        }
                }
                try { CreateTurboButton(game); } catch (Exception e) { Log.LogError("[GR] Turbo button creation failed: " + e); }
                try { TrainGame.CreateScreenButtons(game, clone); } catch (Exception e) { Log.LogError("[GR] Screen buttons creation failed: " + e); }
                if (game.playButtons.Count == 0) Log.LogWarning("[GR] No play button found on template - machine will not start!");
                UnityEngine.Object.DestroyImmediate(old);
                var id = clone.GetComponent<NetworkIdentity>();
                AccessTools.Property(typeof(NetworkIdentity), "assetId").SetValue(id, AssetId);
                Prefab = clone;
                Log.LogInfo($"[GR] Prefab READY from '{template.name}' ({how}), play buttons={game.playButtons.Count}, assetId={id.assetId}");
                return true;
            }
            catch (Exception e) { Log.LogError("[GR] Building prefab failed: " + e); return false; }
        }

        static void CreateTurboButton(TrainGame game)
        {
            var play = game.playButtons.FirstOrDefault(); if (play == null) return;
            var pt = play.transform;
            var col = play.GetComponentInChildren<Collider>(true);
            var parent = pt.parent;
            float width = 0.4f;
            if (col is BoxCollider bc) width = bc.size.x * Mathf.Abs(bc.transform.lossyScale.x) / Mathf.Max(1e-4f, Mathf.Abs(parent != null ? parent.lossyScale.x : 1f));
            Vector3 right = pt.localRotation * Vector3.right; float colW = width; width = GwyfShared.ButtonFit.Measure(pt, right, width); V($"Play button width: collider {colW:0.###}, visible {width:0.###}");
            Vector3 basePos = pt.localPosition, baseScale = pt.localScale;
            // layout (fractions of the original SPIN button width), always identical on every client:
            // [BUY .18][- .12][SPIN .30][+ .12][TURBO .18]  (+ small gaps)
            GameObject Make(string name, float center, float frac, string label)
            {
                var go = UnityEngine.Object.Instantiate(play.gameObject, parent); go.name = name;
                go.transform.localScale = new Vector3(baseScale.x * frac * .9f, baseScale.y, baseScale.z); // 10 % gap between buttons
                go.transform.localPosition = basePos + right * width * center;
                foreach (var t in go.GetComponentsInChildren<TMPro.TMP_Text>(true))
                {
                    foreach (var c in t.GetComponents<MonoBehaviour>()) if (c != null && c.GetType().Name.IndexOf("Locali", StringComparison.OrdinalIgnoreCase) >= 0) UnityEngine.Object.DestroyImmediate(c);
                    
                    t.text = label; GwyfShared.ButtonFit.FitLabel(t, parent, width * frac * .78f, frac * .9f); // layout fix: labels clamped to their own button
                }
                return go;
            }
            var buy = Make("GR_BuyButton", -0.40f, 0.18f, "BUY\n<size=55%>10 FS 100x</size>");
            var minus = Make("GR_BetMinus", -0.23f, 0.12f, "BET\n-");
            var plus = Make("GR_BetPlus", 0.23f, 0.12f, "BET\n+");
            var turbo = Make("GR_TurboButton", 0.40f, 0.18f, "TURBO\n<size=70%>OFF</size>");
            pt.localScale = new Vector3(baseScale.x * 0.30f, baseScale.y, baseScale.z);
            pt.localPosition = basePos;
            foreach (var t in pt.GetComponentsInChildren<TMPro.TMP_Text>(true)) GwyfShared.ButtonFit.FitLabel(t, parent, width * 0.30f * .8f, 0.30f);
            game.turboButton = turbo.GetComponent<InteractableEventTrigger>();
            game.buyButton = buy.GetComponent<InteractableEventTrigger>();
            game.betMinusButton = minus.GetComponent<InteractableEventTrigger>();
            game.betPlusButton = plus.GetComponent<InteractableEventTrigger>();
            V($"Buttons BUY/BET-/BET+/TURBO created next to '{play.name}' (width {width:0.###})");
        }

        static bool IsVanillaSlots(GameObject g) => g != null && g.GetComponentInChildren<Slots>(true) != null;

        [HarmonyPatch(typeof(StampManager), "GetLootTableForFloor")]
        static class LootPatch
        {
            static void Postfix(CasinoFloor floor, MMLootTableGameObjectSO __result)
            {
                try
                {
                    string fname = floor != null ? floor.name + "#" + floor.floorIndex : "null";
                    var objs = __result?.LootTable?.ObjectsToLoot;
                    if (objs == null) { if (_loggedFloors.Add(fname + "-empty")) V($"Loot table for floor {fname}: none"); return; }
                    if (_loggedFloors.Add(fname))
                        V($"Loot table for floor {fname} ({objs.Count}): " + string.Join(", ", objs.Where(x => x?.Loot != null).Select(x => x.Loot.name)));
                    var slotEntry = objs.FirstOrDefault(x => IsVanillaSlots(x?.Loot));
                    var template = slotEntry?.Loot;
                    if (!EnsurePrefab(template, quiet: true)) return;
                    if (objs.Any(x => x != null && x.Loot == Prefab)) return;
                    objs.Add(new MMLootGameObject { Loot = Prefab, Weight = slotEntry?.Weight ?? 1f, ChancePercentage = 0f });
                    V($"Injected Gold Rush Express into floor {fname}");
                }
                catch (Exception e) { Log.LogError("[GR] Loot injection failed: " + e); }
            }
        }

        [HarmonyPatch(typeof(StampManager), "GetCappedLootForFloor")]
        static class CappedLootPatch
        {
            static void Postfix(CasinoFloor floor, Vector3 stampPosition, ref GameObject __result)
            {
                try
                {
                    V($"Stamp at {stampPosition} floor {(floor != null ? floor.name : "null")} -> {(__result != null ? __result.name : "null")}");
                    if (ReplaceAllSlots.Value && IsVanillaSlots(__result) && EnsurePrefab(__result))
                    {
                        __result = Prefab;
                        V("  replaced vanilla slot with Gold Rush Express");
                    }
                }
                catch (Exception e) { Log.LogError("[GR] CappedLoot patch failed: " + e); }
            }
        }

        [HarmonyPatch(typeof(NetworkServer), "Spawn", new Type[] { typeof(GameObject), typeof(NetworkConnectionToClient) })]
        static class SpawnLogPatch
        {
            static void Postfix(GameObject obj)
            {
                if (obj != null && obj.GetComponentInChildren<TrainGame>(true) != null)
                    Log.LogInfo($"[GR] Server spawned Gold Rush Express at {obj.transform.position}");
            }
        }
    }

    /// Independent per-frame driver (some games destroy/disable the BepInEx manager object, which stops plugin Update()).
    public class TrainRunner : MonoBehaviour
    {
        void Update() { if (TrainPlugin.Instance != null) TrainPlugin.Instance.Tick(); }
    }
}
