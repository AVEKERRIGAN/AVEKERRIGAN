using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace GoldRushExpress
{
    /// Client-side screen: base 5x4 reels (lines, 2-loco respin feature, trigger) and the MONEY WAGON board (5x4 -> 7x4).
    public partial class TrainGame
    {
        const int C = TrainEngine.Cols, R = TrainEngine.Rows, N = TrainEngine.Cells, BC = TrainEngine.BCols, BN = TrainEngine.BCells;
        RectTransform _ui, _screenWindow, _grid, _bgrid, _fx, _bfx, _bannerRt, _top;
        Image[] _cell = new Image[N]; Image[] _cellGlow = new Image[N]; TextMeshProUGUI[] _cellVal = new TextMeshProUGUI[N];
        Image[] _bcell = new Image[BN]; Image[] _bglow = new Image[BN]; TextMeshProUGUI[] _bval = new TextMeshProUGUI[BN]; Image[] _block = new Image[BC];
        Vector2[] _home = new Vector2[N]; Vector2[] _bhome = new Vector2[BN];
        int[] _g = new int[N]; int[] _bt = new int[BN]; float[] _bv = new float[BN]; int _cols = C;
        float _cs, _gw, _gh, _bcs, _bgw, _bgh;
        TMP_FontAsset _font;
        Coroutine _anim;
        TextMeshProUGUI _winLabel, _bar, _buyText, _bannerText, _bannerSub, _barBet, _barWin, _lSignVal, _rSignVal, _rSignMoney, _rSignTitle;
        Image _bannerDim, _bannerIcon, _bgImg, _lSign, _rSign, _buyPanel;
        GameObject _baseGroup;
        string _betLabel = "-"; double _betNum; float _lastWinX; bool _clientTurbo, _bonusMode;
        float _bonusBaseX;
        readonly List<GameObject> _fxObjs = new List<GameObject>();
        float _bannerUntil; int _particleBudget;
        const int MaxFxObjects = 260;
        static readonly Color Gold = new Color(1f, .85f, .25f), Copper = new Color(1f, .6f, .25f), Tracer = new Color(1f, .92f, .6f);
        static readonly Color[] LineColor = {
            new Color(1f,.9f,.2f), new Color(.3f,1f,.4f), new Color(1f,.35f,.35f), new Color(.35f,.7f,1f), new Color(1f,.5f,1f), new Color(1f,.6f,.2f),
            new Color(.4f,1f,1f), new Color(.8f,1f,.3f), new Color(1f,.75f,.75f), new Color(.7f,.5f,1f), new Color(1f,1f,1f), new Color(.3f,.9f,.7f) };
        // action colours per bonus type (coin, gold, banker, marshal, tycoon, outlaw, spirit, iron banker, iron marshal, iron outlaw)
        static readonly Color[] ActColor = { Gold, Gold, new Color(.4f,.6f,1f), new Color(1f,.6f,.2f), new Color(1f,.75f,.3f), new Color(1f,.9f,.6f), new Color(1f,.3f,.35f), new Color(.7f,.8f,1f), new Color(.85f,.9f,1f), new Color(.9f,.95f,1f) };

        void ShowBanner(float seconds) { if (_bannerDim == null) return; _bannerUntil = Time.time + seconds; _bannerDim.gameObject.SetActive(true); _bannerRt.SetAsLastSibling(); }
        void HideBanner() { _bannerUntil = 0; if (_bannerDim != null) _bannerDim.gameObject.SetActive(false); }
        void DriveBanner() { if (_bannerDim != null && _bannerDim.gameObject.activeSelf && Time.time > _bannerUntil) { TrainPlugin.V("Banner hidden by per-frame check"); HideBanner(); } }

        IEnumerator Safe(IEnumerator inner)
        {
            var stack = new Stack<IEnumerator>(); stack.Push(inner);
            while (stack.Count > 0)
            {
                object cur;
                var current = stack.Peek();
                try
                {
                    if (!current.MoveNext()) { stack.Pop(); (current as IDisposable)?.Dispose(); continue; }
                    cur = current.Current;
                }
                catch (Exception e) { TrainPlugin.Log.LogError("[GR] Animation error: " + e); break; }
                if (cur is IEnumerator nested) { stack.Push(nested); continue; }
                yield return cur;
            }
            while (stack.Count > 0) (stack.Pop() as IDisposable)?.Dispose();
            _anim = null;
            for (int i = 0; i < N; i++) if (_cell[i] != null) { _cell[i].rectTransform.localScale = Vector3.one; _cell[i].rectTransform.localRotation = Quaternion.identity; }
            for (int i = 0; i < BN; i++) if (_bcell[i] != null) { _bcell[i].rectTransform.localScale = Vector3.one; _bcell[i].rectTransform.anchoredPosition = _bhome[i]; }
        }

        void ClientAbort()
        {
            if (_anim != null) { try { StopCoroutine(_anim); } catch { } _anim = null; }
            HideBanner(); ClearFx(); ResetTransientVisuals();
            for (int i = 0; i < N; i++) if (_cell[i] != null) { _cell[i].enabled = _cell[i].sprite != null; _cell[i].rectTransform.anchoredPosition = _home[i]; _cell[i].rectTransform.localScale = Vector3.one; _cell[i].rectTransform.localRotation = Quaternion.identity; }
        }

        // ---------- building ----------
        // A three-image window into a virtual strip. Final art enters from above
        // and slows to its exact center; no vertical stretch or sprite replacement.
        class CellReel
        {
            public readonly RectTransform root;
            readonly Image target;
            readonly Image[] images = new Image[3];
            readonly TMP_Text[] labels = new TMP_Text[3];
            readonly float size;
            readonly Vector2 home;
            Sprite initial, final;
            Sprite[] fillers;
            int last; float duration;
            string finalText; float valueFontMax; Color finalColor, textColor;
            Vector2 valuePosition, valueSize; Vector4 valueMargin;
            bool running;
            public CellReel(RectTransform parent, Vector2 pos, float size, TrainGame game, Image target)
            {
                this.target = target; this.size = size; home = pos;
                var go = new GameObject("CellReel", typeof(RectTransform), typeof(RectMask2D));
                root = (RectTransform)go.transform; root.SetParent(parent, false); go.layer = parent.gameObject.layer;
                Place(root, pos, Vector2.one * size);
                for (int k = 0; k < 3; k++)
                {
                    var image = Img("Strip" + k, root); image.preserveAspect = true;
                    Place(image.rectTransform, Vector2.zero, Vector2.one * size); images[k] = image;
                    var text = game.Txt("Value" + k, image.transform, Gold); labels[k] = text; text.text = "";
                }
                go.SetActive(false);
            }
            public void Begin(Sprite from, Sprite result, TMP_Text value, Sprite[] filler, float seconds)
            {
                initial = from; final = result; fillers = filler; duration = seconds;
                last = CellReelMotion.Travel(seconds); finalColor = target.color;
                target.sprite = result;
                finalText = value != null ? value.text : "";
                if (value != null)
                {
                    valuePosition = value.rectTransform.anchoredPosition; valueSize = value.rectTransform.sizeDelta;
                    textColor = value.color; valueMargin = value.margin; valueFontMax=value.fontSizeMax;
                }
                running = true; target.gameObject.SetActive(false); root.gameObject.SetActive(true); Draw(0);
            }
            public void Draw(float elapsed)
            {
                float position = CellReelMotion.Position(elapsed, duration, last);
                for (int k = 0; k < 3; k++)
                {
                    var slot=CellReelMotion.Slot(position,k);int index=slot.Index;
                    var image = images[k]; var text = labels[k];
                    image.sprite = index == last ? final : index == 0 ? initial : fillers[Math.Abs(index) % fillers.Length];
                    image.color = index == last ? finalColor : new Color(1, 1, 1, .8f);
                    image.rectTransform.anchoredPosition = new Vector2(0, slot.Offset * size);
                    image.rectTransform.localScale = Vector3.one;
                    text.text = index == last ? finalText : "";
                    if (index == last && !string.IsNullOrEmpty(finalText))
                    { Place(text.rectTransform, valuePosition, valueSize); text.color = textColor; text.margin = valueMargin; text.fontSizeMax=valueFontMax; }
                }
            }
            public void Show(bool on)
            {
                if (!on && running)
                {
                    running = false; target.gameObject.SetActive(true);
                    target.rectTransform.anchoredPosition = home; target.rectTransform.localScale = Vector3.one;
                }
                if (root.gameObject.activeSelf != on) root.gameObject.SetActive(on);
            }
            public void Finish() { if (running) Draw(duration); Show(false); }
        }
        readonly CellReel[] _creel = new CellReel[N], _breel = new CellReel[BN];

        static Image Img(string name, Transform parent, Sprite sp = null)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Image)); go.transform.SetParent(parent, false); go.layer = parent.gameObject.layer;
            var im = go.GetComponent<Image>(); im.sprite = sp; im.raycastTarget = false; im.preserveAspect = sp != null; return im;
        }
        TextMeshProUGUI Txt(string name, Transform parent, Color c, float maxSize = 300)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer)); go.transform.SetParent(parent, false); go.layer = parent.gameObject.layer;
            var t = go.AddComponent<TextMeshProUGUI>(); var canvasRenderer = t.canvasRenderer; if (_font != null) { t.font = _font; if (_font.material != null) t.fontSharedMaterial = _font.material; }
            // Bonus/menu groups are initially inactive, so Awake has not cached this yet.
            var renderer = t.canvasRenderer;
            t.alignment = TextAlignmentOptions.Center; t.enableAutoSizing = true; t.fontSizeMin = 1; t.fontSizeMax = maxSize;
            t.color = c; t.raycastTarget = false; t.enableWordWrapping = false;
            t.overflowMode = TextOverflowModes.Truncate;
            // TMP 4 may have a font but no instantiated face material yet.
            // Its outline setters dereference that material and can abort the whole UI.
            if (t.font != null && t.font.material != null)
            {
                t.fontSharedMaterial = t.font.material;
                if (t.fontMaterial != null)
                { t.outlineWidth = .22f; t.outlineColor = new Color32(40, 0, 50, 255); }
            }
            return t;
        }
        static RectTransform Place(RectTransform rt, Vector2 center, Vector2 size) { rt.anchorMin = rt.anchorMax = new Vector2(.5f, .5f); rt.pivot = new Vector2(.5f, .5f); rt.sizeDelta = size; rt.anchoredPosition = center; return rt; }
        static void Stretch(RectTransform rt) { rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one; rt.offsetMin = rt.offsetMax = Vector2.zero; }

        // layout fractions (x from left, y from BOTTOM) measured on the approved train2 backgrounds (1600x1100)
        const float GridCX = .5f, GridCY = .519f, GridWF = .5375f, GridHF = .6255f;      // base 5x4, 172 px cells
        const float BGridCX = .5f, BGridCY = .541f, BGridWF = .65625f, BGridHF = .5455f;  // wagon 7x4, 150 px cells
        Vector2 _bgridCenter; Image _frameGlow; Image[] _dim;
        Vector2 P(float fx, float fy) => new Vector2((fx - .5f) * _uiSize.x, (fy - .5f) * _uiSize.y);

        void BuildPanel(RectTransform croot, Vector2 min, Vector2 max)
        {
            try { BuildPanelCore(croot, min, max); }
            catch
            {
                // A failed build must never be mistaken for a ready screen by EnsureUi.
                if (_screenWindow != null) Destroy(_screenWindow.gameObject);
                else if (_ui != null) Destroy(_ui.gameObject);
                _ui = null; _screenWindow = null; _menu = null;
                throw;
            }
        }

        void BuildPanelCore(RectTransform croot, Vector2 min, Vector2 max)
        {
            _font = payoutText != null ? payoutText.font : TMP_Settings.defaultFontAsset;
            if (_font == null) { var any = GetComponentsInChildren<TMP_Text>(true).FirstOrDefault(x => x.font != null); _font = any != null ? any.font : Resources.FindObjectsOfTypeAll<TMP_FontAsset>().FirstOrDefault(); }
            if (_font == null || _font.material == null)
                throw new InvalidOperationException("[GR] TMP font/material is not ready; UI creation will retry.");
            float margin = TrainPlugin.ScreenMargin != null ? Mathf.Clamp(TrainPlugin.ScreenMargin.Value, 0f, .2f) : .03f;
            Vector2 size = (max - min) * (1f - 2f * margin);
            var window = new GameObject("GoldRushExpressScreenWindow", typeof(RectTransform), typeof(RectMask2D));
            window.layer = croot.gameObject.layer; _screenWindow = (RectTransform)window.transform;
            _screenWindow.SetParent(croot, false); Place(_screenWindow,(min + max) / 2f - croot.rect.center,size);
            _screenWindow.SetAsLastSibling();
            var bg = Img("GoldRushExpressUI", _screenWindow, Spr("bg")); bg.preserveAspect = false; _bgImg = bg;
            if (bg.sprite == null) bg.color = new Color(.45f, .2f, .15f);
            _ui = bg.rectTransform; _ui.anchorMin = _ui.anchorMax = new Vector2(.5f, .5f);
            _ui.sizeDelta = size; _ui.anchoredPosition = Vector2.zero;
            _ui.SetAsLastSibling();
            // The train and its particle arcs belong to the screen. Clip them at
            // the screen edge instead of letting them pass behind the cabinet.
            _ui.gameObject.AddComponent<RectMask2D>();
            float W = size.x, H = size.y; _uiSize = size;

            // ---- base grid 5x4 ----
            _cs = Mathf.Min(W * GridWF / C, H * GridHF / R); _gw = _cs * C; _gh = _cs * R;
            _gridCenter = P(GridCX, GridCY);
            var gridGo = new GameObject("Grid", typeof(RectTransform), typeof(RectMask2D));
            _grid = (RectTransform)gridGo.transform; _grid.SetParent(_ui, false); Place(_grid, _gridCenter, new Vector2(_gw, _gh));
            for (int i = 0; i < N; i++)
            {
                int c = i / R, r = i % R;
                _home[i] = new Vector2(-_gw / 2 + _cs * (c + .5f), _gh / 2 - _cs * (r + .5f));
                var gl = Img("Glow" + i, _grid, Spr("glow")); Place(gl.rectTransform, _home[i], Vector2.one * _cs * 1.25f); gl.gameObject.SetActive(false); _cellGlow[i] = gl;
            }
            for (int i = 0; i < N; i++)
            {
                var im = Img("Cell" + i, _grid); im.preserveAspect = true; Place(im.rectTransform, _home[i], Vector2.one * _cs * .9f); _cell[i] = im;
                var v = Txt("Val" + i, im.transform, Gold); Place(v.rectTransform, new Vector2(0, -_cs * .02f), new Vector2(_cs * .62f, _cs * .3f)); v.text = ""; _cellVal[i] = v;
                _creel[i] = new CellReel(_grid, _home[i], _cs * .9f, this, im);
            }
            _dim = new Image[C];
            for (int c = 0; c < C; c++) { _dim[c] = Img("Dim" + c, _grid, Spr("px")); _dim[c].preserveAspect = false; _dim[c].raycastTarget = false; Place(_dim[c].rectTransform, new Vector2(-_gw / 2 + _cs * (c + .5f), 0), new Vector2(_cs, _gh)); _dim[c].color = new Color(0, 0, 0, 0); }
            _frameGlow = Img("FrameGlow", _ui, Spr("glow")); _frameGlow.preserveAspect = false; Place(_frameGlow.rectTransform, _gridCenter, new Vector2(_gw * 1.12f, _gh * 1.12f)); _frameGlow.color = new Color(1f, .7f, .3f, 0); _frameGlow.raycastTarget = false; _frameGlow.transform.SetSiblingIndex(_grid.GetSiblingIndex());
            var fxGo = new GameObject("Fx", typeof(RectTransform)); _fx = (RectTransform)fxGo.transform; _fx.SetParent(_ui, false); Place(_fx, _gridCenter, new Vector2(_gw, _gh));

            // ---- wagon board 7x4 ----
            _bcs = Mathf.Min(W * BGridWF / BC, H * BGridHF / R); _bgw = _bcs * BC; _bgh = _bcs * R;
            _bgridCenter = P(BGridCX, BGridCY);
            var bgo = new GameObject("BonusGrid", typeof(RectTransform)); _bgrid = (RectTransform)bgo.transform; _bgrid.SetParent(_ui, false); Place(_bgrid, _bgridCenter, new Vector2(_bgw, _bgh));
            for (int i = 0; i < BN; i++)
            {
                int c = i / R, r = i % R;
                _bhome[i] = new Vector2(-_bgw / 2 + _bcs * (c + .5f), _bgh / 2 - _bcs * (r + .5f));
                var gl = Img("BGlow" + i, _bgrid, Spr("glow")); Place(gl.rectTransform, _bhome[i], Vector2.one * _bcs * 1.3f); gl.gameObject.SetActive(false); _bglow[i] = gl;
            }
            for (int i = 0; i < BN; i++)
            {
                var im = Img("BCell" + i, _bgrid, Spr("sym_empty")); im.preserveAspect = true; Place(im.rectTransform, _bhome[i], Vector2.one * _bcs * .94f); _bcell[i] = im;
                _breel[i] = new CellReel(_bgrid, _bhome[i], _bcs * .94f, this, im);
                var v = Txt("BVal" + i, im.transform, Gold); Place(v.rectTransform, new Vector2(0, -_bcs * .1f), new Vector2(_bcs * .7f, _bcs * .32f)); v.text = ""; _bval[i] = v;
            }
            for (int c = 0; c < BC; c++) { var lk = Img("Lock" + c, _bgrid, Spr("locked")); lk.preserveAspect = false; Place(lk.rectTransform, new Vector2(-_bgw / 2 + _bcs * (c + .5f), 0), new Vector2(_bcs, _bgh)); lk.gameObject.SetActive(false); _block[c] = lk;
                var lt = Txt("LockT" + c, lk.transform, new Color(1f, .8f, .45f)); Place(lt.rectTransform, Vector2.zero, new Vector2(_bgh * .7f, _bcs * .42f)); lt.rectTransform.localRotation = Quaternion.Euler(0, 0, 90); lt.text = "LOCKED"; lt.characterSpacing = 18; }
            var bfxGo = new GameObject("BFx", typeof(RectTransform)); _bfx = (RectTransform)bfxGo.transform; _bfx.SetParent(_ui, false); Place(_bfx, _bgridCenter, new Vector2(_bgw, _bgh));
            _bgrid.gameObject.SetActive(false);

            _winLabel = Txt("WinLabel", _ui, Gold); Place(_winLabel.rectTransform, _gridCenter + new Vector2(0, -_gh * .5f - H * .03f), new Vector2(_gw * 1.1f, H * .05f)); _winLabel.text = "";
            _winLabel.outlineColor = new Color32(40, 15, 0, 255);

            // ---- side signs + buy panel ----
            _baseGroup = new GameObject("BaseGroup", typeof(RectTransform)); var bgr = (RectTransform)_baseGroup.transform; bgr.SetParent(_ui, false); Stretch(bgr);
            _buyPanel = Img("BuyPanel", bgr, Spr("panel_buy")); _buyPanel.preserveAspect = false; PlaceN(_buyPanel.rectTransform, BtnRect("Buy"));
            var bs = _buyPanel.rectTransform.sizeDelta;
            _buyText = Txt("BuyText", _buyPanel.transform, Color.white); Place(_buyText.rectTransform, Vector2.zero, new Vector2(bs.x * .78f, bs.y * .72f)); _buyText.outlineColor = new Color32(110, 40, 0, 255);
            var bt = Txt("BuyType", bgr, new Color(1f, .9f, .7f)); Place(bt.rectTransform, P(.0875f, .66f), new Vector2(W * .15f, H * .05f));
            bt.text = $"BONUS BUY\n<size=70%>{TrainEngine.Variants} WAGONS FROM {TrainEngine.BuyCost[0]:0.##}x</size>"; bt.outlineColor = new Color32(40, 15, 0, 255);
            _lSign = Img("LSign", _ui, Spr("sign_respins")); Place(_lSign.rectTransform, P(.084f, .668f), new Vector2(W * .15f, H * .245f));
            _lSignVal = Txt("LSignV", _lSign.transform, Gold); Place(_lSignVal.rectTransform, new Vector2(0, -H * .245f * .25f), new Vector2(W * .12f, H * .1f));
            _rSign = Img("RSign", _ui, Spr("sign_wagon")); Place(_rSign.rectTransform, P(.9125f, .723f), new Vector2(W * .15f, H * .227f));
            _rSignVal = Txt("RSignV", _rSign.transform, Gold); Place(_rSignVal.rectTransform, new Vector2(0, -H * .227f * .25f), new Vector2(W * .125f, H * .09f));
            _rSignMoney = Txt("RSignMoney", _rSign.transform, Color.white);
            Place(_rSignMoney.rectTransform, new Vector2(0, -H * .075f), new Vector2(W * .12f, H * .032f));
            _rSignMoney.text = ""; _rSignMoney.gameObject.SetActive(false);
            _rSignTitle = Txt("RSignTitle", _rSign.transform, Gold); _rSignTitle.text = "TOTAL"; _rSignTitle.gameObject.SetActive(false);
            BuildTotalFrame();
            _rSign.gameObject.AddComponent<RectMask2D>();
            _lSign.gameObject.SetActive(false); _rSignVal.text = "";

            var topGo = new GameObject("FxTop", typeof(RectTransform)); _top = (RectTransform)topGo.transform; _top.SetParent(_ui, false); Stretch(_top);

            // ---- bottom bar ----
            var bar = Img("Bar", _ui, Spr("bar")); bar.preserveAspect = false; Place(bar.rectTransform, P(.5f, .051f), new Vector2(W, H * .102f));
            TextMeshProUGUI Lbl(string name, float fx, float fy, float w, float h, Color c, string s0) { var t = Txt(name, _ui, c); Place(t.rectTransform, P(fx, fy), new Vector2(W * w, H * h)); t.text = s0; return t; }
            Lbl("BetT", .62f, .074f, .1f, .022f, Copper, "BET");
            _barBet = Lbl("BetV", .62f, .036f, .14f, .036f, Color.white, "-");
            Lbl("WinT", .43f, .074f, .1f, .022f, Copper, "WIN");
            _barWin = Lbl("WinV", .43f, .036f, .17f, .04f, new Color(1f, .92f, .55f), "-");
            _bar = Lbl("TurboFlag", .25f, .051f, .14f, .03f, new Color(1f, .88f, .4f), "");
            BuildHud();
            Lbl("TurboCap", BtnRect("Turbo").cx, .008f, .05f, .014f, new Color(.85f, .85f, .85f), "TURBO");

            // banner overlay
            _bannerDim = Img("Banner", _ui); _bannerDim.color = new Color(.08f, .03f, .02f, .8f); _bannerRt = _bannerDim.rectTransform; Stretch(_bannerRt);
            _bannerIcon = Img("BannerIcon", _bannerRt, Spr("plaque_wagon")); Place(_bannerIcon.rectTransform, new Vector2(0, H * .16f), new Vector2(W * .6f, W * .6f * .26f));
            _bannerText = Txt("BannerText", _bannerRt, Gold); Place(_bannerText.rectTransform, new Vector2(0, -H * .08f), new Vector2(W * .8f, H * .2f));
            _bannerSub = Txt("BannerSub", _bannerRt, Color.white); Place(_bannerSub.rectTransform, new Vector2(0, -H * .26f), new Vector2(W * .8f, H * .06f));
            _bannerDim.gameObject.SetActive(false);
            UpdateButtonsVisual(false); RefreshBar();
            GwyfShared.TextFit.Pad(_ui);
            TrainPlugin.V($"UI built {W:0}x{H:0}, cell {_cs:0.#} / wagon cell {_bcs:0.#}");
        }

        void SetMode(bool bonus)
        {
            _bonusMode = bonus;
            if (_bgImg != null) _bgImg.sprite = Spr(bonus ? "bg_bonus" : "bg") ?? _bgImg.sprite;
            if (_grid != null) _grid.gameObject.SetActive(!bonus);
            if (_bgrid != null) _bgrid.gameObject.SetActive(bonus);
            if (_baseGroup != null) _baseGroup.SetActive(!bonus);
            if (_lSign != null) _lSign.gameObject.SetActive(bonus);
            if (_rSign != null)
            {
                _rSign.sprite = bonus ? null : Spr("sign_wagon");
                _rSign.preserveAspect = !bonus; _rSign.color = bonus ? new Color(.065f, .035f, .025f, .98f) : Color.white;
                var rt = _rSign.rectTransform; rt.anchoredPosition = bonus ? P(.916f, .668f) : P(.9125f, .723f);
                rt.sizeDelta = bonus ? new Vector2(_uiSize.x * .15f, _uiSize.y * .19f) : new Vector2(_uiSize.x * .15f, _uiSize.y * .227f);
                if (bonus)
                {
                    SetSignRow(_rSignTitle, TrainPresentation.TotalTitle, rt.sizeDelta);
                    SetSignRow(_rSignVal, TrainPresentation.TotalMultiplier, rt.sizeDelta);
                    SetSignRow(_rSignMoney, TrainPresentation.TotalMoney, rt.sizeDelta);
                }
                else { Place(_rSignVal.rectTransform,new Vector2(0,-_uiSize.y*.227f*.25f),new Vector2(_uiSize.x*.125f,_uiSize.y*.09f));_rSignVal.fontSizeMax=_uiSize.y*.07f; }
                if (_totalFrame != null) _totalFrame.SetActive(bonus);
                _rSignTitle.gameObject.SetActive(bonus);
                _rSignMoney.gameObject.SetActive(bonus);
                if (!bonus) { _rSignVal.text = ""; _rSignMoney.text = ""; }
            }
        }
        GameObject _totalFrame;
        void BuildTotalFrame()
        {
            _totalFrame=new GameObject("TotalFrame",typeof(RectTransform));var root=(RectTransform)_totalFrame.transform;
            root.SetParent(_rSign.transform,false);root.gameObject.layer=_rSign.gameObject.layer;Stretch(root);root.SetAsFirstSibling();
            void Bar(string name,Vector2 min,Vector2 max)
            {var im=Img(name,root,Spr("px"));im.color=new Color(.68f,.39f,.15f);im.preserveAspect=false;im.rectTransform.anchorMin=min;im.rectTransform.anchorMax=max;im.rectTransform.offsetMin=im.rectTransform.offsetMax=Vector2.zero;}
            Bar("Left",new Vector2(0,0),new Vector2(.015f,1));Bar("Right",new Vector2(.985f,0),new Vector2(1,1));
            Bar("Top",new Vector2(0,.985f),Vector2.one);Bar("Bottom",Vector2.zero,new Vector2(1,.015f));
            Bar("Divider",new Vector2(.08f,.27f),new Vector2(.92f,.28f));_totalFrame.SetActive(false);
        }
        static void SetSignRow(TMP_Text text,TrainPresentation.Box box,Vector2 signSize)
        {
            Place(text.rectTransform,new Vector2(box.X*signSize.x,box.Y*signSize.y),new Vector2(box.Width*signSize.x,box.Height*signSize.y));
            text.rectTransform.localScale=Vector3.one;text.enableAutoSizing=true;text.fontSizeMax=box.Height*signSize.y*.8f;
            text.margin=new Vector4(signSize.x*.02f,0,signSize.x*.02f,0);
        }
        void ShowRespinSign(bool on, int mult)
        {
            if (_rSign == null) return;
            _rSign.sprite = Spr(on ? "sign_respin" : "sign_wagon"); _rSignVal.text = on ? "x" + mult : "";
        }
        static string FX(float v) => TrainPresentation.CellValue(v);
        string Money(double x) { if (_betNum <= 0) return x.ToString("0.##") + "x"; try { return MoneyFormatter.FormatWithDollar(BigNumber.FromDouble(x * _betNum)); } catch { return "$" + (x * _betNum).ToString("0.00"); } }
        void RefreshBar()
        {
            if (_barBet != null) _barBet.text = _betLabel;
            if (_barWin != null) _barWin.text = _lastWinX > 0 ? Money(_lastWinX) : "-";
            if (_bar != null) _bar.text = _clientTurbo ? "TURBO" : "";
            if (_buyText != null) _buyText.text = "BUY\nFEATURE\n<size=60%><color=#fff0aa>" + (_betNum > 0 ? "FROM " + Money(TrainEngine.BuyCost[0]) : "FROM " + TrainEngine.BuyCost[0].ToString("0.##") + "x") + "</color></size>";
        }
        void UpdateButtonsVisual(bool tb)
        {
            _clientTurbo = tb; HudTurbo(tb);
            GwyfShared.ToggleTint.Physical(turboButton, tb); GwyfShared.ToggleTint.Ui(_hudTurbo, tb);
            void Label(InteractableEventTrigger b, string s) { if (b == null) return; foreach (var t in b.GetComponentsInChildren<TMP_Text>(true)) t.text = s; }
            Label(turboButton, "TURBO\n<size=70%>" + (tb ? "ON" : "OFF") + "</size>");
            Label(buyButton, _menuSel < 0 ? "BUY\n<size=55%>BONUS MENU</size>" : "BUY\n<size=55%>NEXT \u25B6</size>");
            RefreshBar();
        }

        // ---------- cells ----------
        void SetCell(int i, int sym)
        {
            _g[i] = sym; var im = _cell[i]; im.sprite = SymSprite(sym); im.color = Color.white; im.enabled = im.sprite != null;
            var rt = im.rectTransform; rt.localScale = Vector3.one; rt.localRotation = Quaternion.identity; rt.anchoredPosition = _home[i];
            if (_cellVal[i] != null) _cellVal[i].text = "";
            if (_anim != null && (sym == TrainEngine.SCAT || sym == TrainEngine.GOLD))
                StartCoroutine(GwyfShared.BonusArrival.Pulse(im, _cellGlow[i], new Color(1f, .74f, .2f)));
        }
        void SetBCell(int i, int t, float v)
        {
            _bt[i] = t; _bv[i] = v; var im = _bcell[i]; im.sprite = BonusSprite(t, v); im.color = t < 0 ? new Color(1, 1, 1, .55f) : Color.white;
            var rt = im.rectTransform; rt.localScale = Vector3.one; rt.anchoredPosition = _bhome[i]; rt.localRotation = Quaternion.identity;
            SetBVal(i, v);
        }
        void SetBVal(int i, float v)
        {
            _bv[i] = v; var tx = _bval[i]; if (tx == null) return;
            if (_bt[i] < 0) { tx.text = ""; return; }
            tx.text = FX(v); bool card = _bt[i] >= TrainEngine.BANKER;
            var box=card?TrainPresentation.CardValue:TrainPresentation.CoinValue;
            Place(tx.rectTransform,new Vector2(box.X*_bcs,box.Y*_bcs),new Vector2(box.Width*_bcs,box.Height*_bcs));
            tx.fontSizeMax=box.Height*_bcs*.85f;
            tx.margin = new Vector4(_bcs * .02f, 0, _bcs * .02f, 0);
            tx.overflowMode = TextOverflowModes.Truncate;
            tx.color = card ? new Color(1f, .93f, .6f) : v < 20 ? new Color(1f, .9f, .45f) : v < 100 ? new Color(.7f, 1f, .97f) : new Color(.8f, .9f, 1f);
        }
        void SetLocks(int cols) { _cols = cols; for (int c = 0; c < BC; c++) if (_block[c] != null) { _block[c].gameObject.SetActive(c >= cols); _block[c].color = Color.white; } }
        float BoardTotal() { float s = 0; for (int i = 0; i < BN; i++) if (_bt[i] >= 0) s += _bv[i]; return s; }
        void ShowBonusTotal(float multiplier)
        {
            multiplier = Mathf.Clamp(multiplier, 0, (float)TrainEngine.MaxWinX);
            if (_rSignVal != null) _rSignVal.text = TrainPresentation.Multiplier(multiplier);
            if (_rSignMoney != null) _rSignMoney.text = Money(multiplier);
        }
        void SetIdle()
        {
            var r = new System.Random(GetInstanceID());
            for (int i = 0; i < N; i++) SetCell(i, r.Next(TrainEngine.NLINE));
            for (int i = 0; i < BN; i++) { _bt[i] = -1; _bv[i] = 0; }
        }
        void UpdateIdle()
        {
            if (_ui == null || _anim != null || _bonusMode) return;
            for (int i = 0; i < N; i++) if (_cell[i] != null) _cell[i].rectTransform.anchoredPosition = _home[i];
        }
        void ClearFx()
        {
            foreach (var g in _fxObjs) if (g != null) Destroy(g); _fxObjs.Clear();
            if (_cellGlow[0] != null) foreach (var g in _cellGlow) g.gameObject.SetActive(false);
            if (_bglow[0] != null) foreach (var g in _bglow) g.gameObject.SetActive(false);
            if (_winLabel != null) _winLabel.text = "";
        }

        static Vector3 Squash(float k) { float a = Mathf.Sin(k * Mathf.PI) * (1 - k) * .35f; return new Vector3(1 + a, 1 - a, 1); }

        IEnumerator DropOut(float dur)
        {
            float t0 = Time.time;
            while (Time.time - t0 < dur)
            {
                float p = (Time.time - t0) / dur;
                for (int i = 0; i < N; i++) { int c = i / R; float q = Mathf.Clamp01(p * 1.3f - c * .05f); _cell[i].rectTransform.anchoredPosition = _home[i] - new Vector2(0, q * q * _gh * 1.2f); }
                yield return null;
            }
            for (int i = 0; i < N; i++) _cell[i].enabled = false;
        }

        GameObject FxImg(string spr, Vector2 pos, float size, Color col, Transform parent = null)
        {
            _fxObjs.RemoveAll(g => g == null);
            if (_fxObjs.Count >= MaxFxObjects) { var old = _fxObjs[0]; _fxObjs.RemoveAt(0); if (old != null) Destroy(old); }
            var im = Img("fx", parent ?? _fx, Spr(spr)); im.color = col; Place(im.rectTransform, pos, Vector2.one * size); _fxObjs.Add(im.gameObject); return im.gameObject;
        }
        /// thin straight segment a->b in fx space (fishing line / pay line)
        Image Segment(Vector2 a, Vector2 b, float width, Color col, Transform parent = null)
        {
            var im = Img("seg", parent ?? _fx, Spr("px")); im.preserveAspect = false; im.color = col; _fxObjs.Add(im.gameObject);
            var rt = im.rectTransform; rt.anchorMin = rt.anchorMax = new Vector2(.5f, .5f); rt.pivot = new Vector2(0f, .5f);
            Vector2 d = b - a; rt.anchoredPosition = a; rt.sizeDelta = new Vector2(d.magnitude, width); rt.localRotation = Quaternion.Euler(0, 0, Mathf.Atan2(d.y, d.x) * Mathf.Rad2Deg);
            return im;
        }

        IEnumerator Flipbook(Image im, string prefix, int from, int to, float dur)
        {
            float t0 = Time.time; int n = to - from + 1;
            while (Time.time - t0 < dur) { if (im == null) yield break; int f = from + Mathf.Min(n - 1, (int)((Time.time - t0) / dur * n)); im.sprite = Spr(prefix + f); yield return null; }
            if (im != null) Destroy(im.gameObject);
        }

        IEnumerator Particles(Vector2 pos, Color col, int count, float dur, float dist)
        {
            float amt = TrainPlugin.Particles != null ? Mathf.Max(0, TrainPlugin.Particles.Value) : 1f;
            count = Mathf.Min(Mathf.RoundToInt(count * amt * .5f), _particleBudget); if (count <= 0) yield break; _particleBudget -= count;
            var parts = new List<(RectTransform rt, Image im, Vector2 v, float s)>();
            var rnd = new System.Random(pos.GetHashCode());
            for (int k = 0; k < count; k++)
            {
                float a = (float)(rnd.NextDouble() * Math.PI * 2), sp = dist * (.4f + (float)rnd.NextDouble() * .8f);
                bool star = rnd.NextDouble() < .25;
                var go = FxImg(star ? "sparkle" : "dot", pos, _cs * (star ? .22f : .13f) * (.6f + (float)rnd.NextDouble() * .8f), Color.Lerp(col, Color.white, (float)rnd.NextDouble() * .5f));
                parts.Add(((RectTransform)go.transform, go.GetComponent<Image>(), new Vector2(Mathf.Cos(a), Mathf.Sin(a)) * sp, (float)rnd.NextDouble() * 360));
            }
            float t0 = Time.time;
            while (Time.time - t0 < dur)
            {
                float p = (Time.time - t0) / dur, e = 1 - (1 - p) * (1 - p) * (1 - p), fa = Mathf.Min(1f, p * 10f) * (1 - p * p);
                foreach (var q in parts) { if (q.rt == null || q.im == null) continue; q.rt.anchoredPosition = pos + q.v * e + new Vector2(0, -p * p * _cs * .2f); q.rt.localRotation = Quaternion.Euler(0, 0, q.s + e * 90); q.rt.localScale = Vector3.one * (1f - .4f * p); var c = q.im.color; c.a = fa; q.im.color = c; }
                yield return null;
            }
            foreach (var q in parts) if (q.rt != null) Destroy(q.rt.gameObject);
        }

        IEnumerator Pop(Transform tr, float amt = .3f)
        {
            float t0 = Time.time;
            while (Time.time - t0 < .3f) { float p = (Time.time - t0) / .3f; if (tr == null) yield break; tr.localScale = Vector3.one * (1 + amt * Mathf.Sin(p * Mathf.PI)); yield return null; }
            if (tr != null) tr.localScale = Vector3.one;
        }
        static string Hex(Color c) => ColorUtility.ToHtmlStringRGB(c);
        IEnumerator WaitT(float d) { float t0 = Time.time; while (Time.time - t0 < d) yield return null; }

        // ================= the show =================
        // ---- bonus buy menu (client view; host owns the selection) ----
        GameObject _menu; Image[] _menuRow; TextMeshProUGUI[] _menuName, _menuDesc, _menuPrice; TextMeshProUGUI _menuHint; int _menuSel = -1;
        void BuildBuyMenu()
        {
            int n = TrainEngine.Variants; var W = _uiSize.x; var H = _uiSize.y;
            var bg = Img("BuyMenu", _ui, Spr("px")); bg.preserveAspect = false; bg.color = new Color(.06f, .03f, .02f, .93f); Place(bg.rectTransform, _gridCenter, new Vector2(_gw * 1.08f, _gh * 1.12f)); _menu = bg.gameObject;
            var sz = bg.rectTransform.sizeDelta;
            var title = Txt("MTitle", bg.transform, new Color(1f, .82f, .35f)); Place(title.rectTransform, new Vector2(0, sz.y * .41f), new Vector2(sz.x * .8f, sz.y * .12f)); title.text = "BONUS BUY";
            _menuRow = new Image[n]; _menuName = new TextMeshProUGUI[n]; _menuDesc = new TextMeshProUGUI[n]; _menuPrice = new TextMeshProUGUI[n];
            float rh = sz.y * .68f / n;
            for (int v = 0; v < n; v++)
            {
                float y = sz.y * .3f - rh * (v + .5f);
                var row = Img("MRow" + v, bg.transform, Spr("px")); row.preserveAspect = false; Place(row.rectTransform, new Vector2(0, y), new Vector2(sz.x * .94f, rh * .9f)); _menuRow[v] = row;
                var nm = Txt("MName" + v, row.transform, Color.white); nm.alignment = TextAlignmentOptions.Left; Place(nm.rectTransform, new Vector2(-sz.x * .2f, rh * .17f), new Vector2(sz.x * .5f, rh * .42f)); nm.text = TrainEngine.BuyNames[v]; _menuName[v] = nm;
                var ds = Txt("MDesc" + v, row.transform, new Color(.85f, .8f, .7f)); ds.alignment = TextAlignmentOptions.Left; Place(ds.rectTransform, new Vector2(-sz.x * .12f, -rh * .2f), new Vector2(sz.x * .66f, rh * .32f)); ds.text = TrainEngine.BuyDesc[v]; _menuDesc[v] = ds;
                var pr = Txt("MPrice" + v, row.transform, new Color(1f, .85f, .3f)); pr.alignment = TextAlignmentOptions.Right; Place(pr.rectTransform, new Vector2(sz.x * .3f, 0), new Vector2(sz.x * .3f, rh * .6f)); _menuPrice[v] = pr;
            }
            _menuHint = Txt("MHint", bg.transform, new Color(.9f, .9f, .9f)); Place(_menuHint.rectTransform, new Vector2(0, -sz.y * .43f), new Vector2(sz.x * .9f, sz.y * .08f));
            _menuHint.text = "<color=#ffcf5a>BUY</color> = next option     <color=#7dff7d>SPIN</color> = buy highlighted";
            GwyfShared.TextFit.Pad(bg.transform);
        }
        void ShowBuyMenu(int sel)
        {
            _menuSel = sel;
            if (sel < 0) { if (_menu != null) _menu.SetActive(false); UpdateButtonsVisual(_clientTurbo); return; }
            if (_bonusMode || _ui == null) return;
            if (_menu == null) BuildBuyMenu();
            _menu.SetActive(true); _menu.transform.SetAsLastSibling();
            for (int v = 0; v < TrainEngine.Variants; v++)
            {
                bool on = v == sel; double c = TrainEngine.BuyCost[v];
                _menuRow[v].color = on ? new Color(.85f, .55f, .1f, .95f) : new Color(.25f, .16f, .1f, .85f);
                _menuName[v].text = (on ? "\u25B6 " : "") + TrainEngine.BuyNames[v];
                _menuPrice[v].text = (_betNum > 0 ? Money(c) : "") + $"\n<size=60%>{c:0.##}x BET</size>";
                _menuName[v].color = on ? Color.white : new Color(.9f, .85f, .75f);
            }
            UpdateButtonsVisual(_clientTurbo);
        }

        IEnumerator Show(GrMsg m)
        {
            bool t = m.tb == 1;
            _clientTurbo = t; if (m.bn > 0) _betNum = m.bn;
            if (m.t == "intro") { yield return IntroRoutine(m, t); _anim = null; yield break; }
            if (m.t == "bstep") { if (m.b != null && m.b.bt != null && m.b.bt.Length == BN) yield return BonusStep(m, t); _anim = null; yield break; }
            if (m.t == "end" && m.tot <= 0 && m.bi <= 0) { _lastWinX = 0; RefreshBar(); _anim = null; yield break; }
            if (m.t == "end") { yield return EndRoutine(m); _anim = null; yield break; }
            var s = m.s;
            if (m.t != "spin" || s == null || s.g == null || s.g.Length != N) { _anim = null; yield break; }
            HideBanner(); SetMode(false); ShowRespinSign(false, 1);
            _lastWinX = 0; RefreshBar();
            if (m.by == 1) _winLabel.text = "<color=#ffe680>FEATURE BOUGHT: " + TrainEngine.BuyNames[Mathf.Clamp(m.buyVariant, 0, TrainEngine.Variants - 1)] + "</color>";
            Sfx(spinReelSFX, 0);
            // v-next: no drop-out before the reel spin - the strip starts seamlessly from the symbols on screen
            yield return SpinIn(s, t);
            yield return WaitT(GrTiming.Out(t)); // keeps host timing parity (the old drop-out duration)
            Sfx(spinDoneSFX, 0);
            yield return WaitT(.1f);
            double acc = 0;
            if (s.lines != null && s.lines.Length > 0) { yield return ShowLines(s.lines, t); foreach (var l in s.lines) acc += l.w; _lastWinX = (float)acc; RefreshBar(); }

            // 2-loco respin feature: locos reveal values, reels respin until a line win, +1x per losing respin
            if (s.rs != null && s.rs.Length > 0)
            {
                var locos = Enumerable.Range(0, N).Where(i => _g[i] == TrainEngine.SCAT || _g[i] == TrainEngine.GOLD).ToList();
                yield return RevealLocos(locos, s, t);
                ShowRespinSign(true, 1); StartCoroutine(Pop(_rSign.transform, .15f));
                int mult = 1;
                if (s.lw <= 0)
                    foreach (var r in s.rs)
                    {
                        mult = r.mult; _rSignVal.text = "x" + mult; StartCoroutine(Pop(_rSignVal.transform));
                        yield return RespinOnce(r.g, locos, GrTiming.RespinSpin(t));
                        if (r.lw > 0 && r.lines != null && r.lines.Length > 0) { yield return ShowLines(r.lines, t); acc += r.lw; }
                    }
                var last = s.rs[s.rs.Length - 1]; mult = last.mult;
                float dd = GrTiming.RespinPay(t), t0 = Time.time; _particleBudget = 60;
                _winLabel.text = $"<color=#ffd56a>LOCOS {FX(s.rsum)}</color>  x{mult}  =  {Money(s.rsum * mult)}";
                foreach (var i in locos) { _cellGlow[i].gameObject.SetActive(true); _cellGlow[i].color = new Color(1f, .8f, .35f, .8f); StartCoroutine(Particles(_home[i], Gold, 12, dd * .8f, _cs)); }
                Sfx(multiplierSFX, Mathf.Min(1000f, s.rsum * mult * 10f));
                while (Time.time - t0 < dd) { float p = (Time.time - t0) / dd; foreach (var i in locos) _cell[i].rectTransform.localScale = Vector3.one * (1.1f + .08f * Mathf.Sin(p * 20)); yield return null; }
                foreach (var i in locos) { _cell[i].rectTransform.localScale = Vector3.one; _cellGlow[i].gameObject.SetActive(false); }
                _lastWinX = m.w; RefreshBar();
            }
            // MONEY WAGON trigger: zoom on the last loco, locos pulse
            if (s.sc >= 3)
            {
                var scs = Enumerable.Range(0, N).Where(i => _g[i] == TrainEngine.SCAT || _g[i] == TrainEngine.GOLD).ToList();
                foreach (var i in scs) { _cellGlow[i].gameObject.SetActive(true); _cellGlow[i].color = new Color(1f, .75f, .3f, .85f); }
                if (scs.Count > 0) yield return ZoomScatter(scs, t, m);
                _winLabel.text = $"<color=#ffcf5a>{s.sc} BONUS LOCOS - MONEY WAGON!</color>";
                float sd = GrTiming.Scatter(t);
                yield return TriggerFlourish(scs, sd);
                foreach (var i in scs) { _cell[i].rectTransform.localScale = Vector3.one; _cellGlow[i].gameObject.SetActive(false); }
                _winLabel.text = "";
            }
            if (m.w > 0)
            {
                _lastWinX = m.tot; RefreshBar();
                _winLabel.text = "<size=120%>" + Money(m.w) + "</size>";
                yield return WaitT(GrTiming.Settle(t));
            }
            _anim = null;
        }

        /// all winning lines at once, label cycles through them. Duration == GrTiming.Lines
        IEnumerator ShowLines(TrainEngine.Lw[] lines, bool t)
        {
            float d = GrTiming.Lines(t), t0 = Time.time; double acc = 0;
            var cells = new HashSet<int>(); var segs = new List<Image>();
            foreach (var lw in lines)
            {
                if (lw.l < 0 || lw.l >= TrainEngine.Lines.Length) continue;
                var path = TrainEngine.Lines[lw.l]; var col = LineColor[lw.l % LineColor.Length];
                for (int c = 0; c < C - 1; c++) segs.Add(Segment(_home[TrainEngine.Idx(c, path[c])], _home[TrainEngine.Idx(c + 1, path[c + 1])], _cs * .05f, new Color(col.r, col.g, col.b, 0)));
                for (int c = 0; c < lw.n && c < C; c++) cells.Add(TrainEngine.Idx(c, path[c]));
                acc += lw.w;
            }
            foreach (var i in cells) { _cellGlow[i].gameObject.SetActive(true); _cellGlow[i].color = new Color(1f, .8f, .4f, 0); _cell[i].transform.SetAsLastSibling(); }
            Sfx(multiplierSFX, Mathf.Min(1000f, (float)acc * 10f));
            int shown = -1;
            while (Time.time - t0 < d)
            {
                float p = (Time.time - t0) / d;
                int li = Mathf.Min(lines.Length - 1, (int)(p * lines.Length));
                if (li != shown && li >= 0)
                {
                    shown = li; var lw = lines[li];
                    _winLabel.text = $"<color=#{Hex(LineColor[lw.l % LineColor.Length])}>LINE {lw.l + 1}</color>  {lw.n}x {new[] { "SPADE", "HEART", "CLUB", "DIAMOND", "OUTLAW", "SNIPER", "COLLECTOR" }[Mathf.Clamp(lw.s, 0, 6)]} = {Money(lw.w)}" + (lines.Length > 1 ? $"   <size=70%>({Money(acc)} total)</size>" : "");
                }
                foreach (var g in segs) if (g != null) { var c = g.color; c.a = Mathf.Clamp01(p * 6f) * (.75f + .25f * Mathf.Sin(p * 20)); g.color = c; }
                foreach (var i in cells) { _cell[i].rectTransform.localScale = Vector3.one * (1 + .12f * Mathf.Abs(Mathf.Sin(p * Mathf.PI * 3))); var c = _cellGlow[i].color; c.a = .5f + .3f * Mathf.Sin(p * 14); _cellGlow[i].color = c; }
                yield return null;
            }
            foreach (var g in segs) if (g != null) Destroy(g.gameObject);
            foreach (var i in cells) { _cell[i].rectTransform.localScale = Vector3.one; _cellGlow[i].gameObject.SetActive(false); }
            _winLabel.text = "";
        }

        /// base respin feature: locos flip and show their value. Duration == GrTiming.Reveal
        IEnumerator RevealLocos(List<int> locos, TrainEngine.Spin s, bool t)
        {
            float d = GrTiming.Reveal(t), t0 = Time.time; bool swapped = false; _particleBudget = 40;
            // RESPIN trigger flourish: steam burst from each loco + bell, label
            _winLabel.text = "<color=#e8f4ff>STEAM UP! RESPIN FEATURE</color>"; Sfx(spinDoneSFX, 0);
            foreach (var i in locos) for (int k = 0; k < 5; k++) { var sm = FxImg("smoke", _home[i] + new Vector2((k - 2) * _cs * .12f, _cs * .2f), _cs * .5f, new Color(1, 1, 1, .85f)); StartCoroutine(Drift(sm, d * (.6f + .1f * k))); }
            while (Time.time - t0 < d)
            {
                float p = (Time.time - t0) / d;
                float sx = p < .5f ? 1 - p * 2 : (p - .5f) * 2;
                if (!swapped && p >= .5f)
                {
                    swapped = true;
                    foreach (var i in locos) { _cell[i].sprite = Spr("coin_gold"); _cellVal[i].text = FX(s.iv != null && i < s.iv.Length ? s.iv[i] : 0); StartCoroutine(Particles(_home[i], Gold, 10, d * .5f, _cs * .8f)); }
                    Sfx(multiplierSFX, 20f);
                }
                foreach (var i in locos) _cell[i].rectTransform.localScale = new Vector3(Mathf.Max(.02f, sx), 1, 1) * (1 + .1f * Mathf.Sin(p * Mathf.PI));
                yield return null;
            }
            foreach (var i in locos) _cell[i].rectTransform.localScale = Vector3.one;
        }

        /// one respin: every non-loco cell blurs and lands the new symbol. Duration == dur
        IEnumerator RespinOnce(int[] grid, List<int> locos, float duration)
        {
            var moving = Enumerable.Range(0, N).Where(i => !locos.Contains(i)).ToArray();
            var finished = new bool[N]; var fillers = Enumerable.Range(0, TrainEngine.NLINE).Select(SymSprite).ToArray();
            foreach (int i in moving)
            {
                _cellVal[i].text = ""; _cell[i].color = Color.white;
                float end = duration * (.55f + .1f * (i / R));
                _creel[i].Begin(_cell[i].sprite, SymSprite(grid[i]), null, fillers, end);
            }
            float start = Time.time;
            try
            {
                while (true)
                {
                    float elapsed = Time.time - start;
                    foreach (int i in moving)
                    {
                        if (finished[i]) continue;
                        _creel[i].Draw(elapsed);
                        if (elapsed >= duration * (.55f + .1f * (i / R)))
                        { finished[i] = true; _creel[i].Finish(); SetCell(i, grid[i]); }
                    }
                    if (elapsed >= duration) break;
                    yield return null;
                }
            }
            finally { foreach (int i in moving) { _creel[i].Finish(); SetCell(i, grid[i]); } }
        }

        // ================= MONEY WAGON =================
        IEnumerator IntroRoutine(GrMsg m, bool t)
        {
            float d = GrTiming.Intro(t) - .1f, t0 = Time.time;
            ClearFx(); HideBanner();
            // the express crosses the screen (loco + smoke), then the board switches to the wagon and the plaque drops in
            var loco = Img("Train", _top, Spr("sym_loco_scatter")); loco.preserveAspect = true; _fxObjs.Add(loco.gameObject);
            float lh = _uiSize.y * .42f; Place(loco.rectTransform, new Vector2(_uiSize.x * .75f, -_uiSize.y * .05f), new Vector2(lh, lh));
            var wagons = new List<Image>();
            for (int k = 0; k < 3; k++) { var w = Img("Wagon" + k, _top, Spr(k == 1 ? "coin_gold" : "sym_empty")); w.preserveAspect = true; _fxObjs.Add(w.gameObject); Place(w.rectTransform, Vector2.zero, Vector2.one * lh * .7f); wagons.Add(w); }
            bool switched = false; _particleBudget = 0; float nextSmoke = 0;
            var streak = Img("Streak", _top, Spr("glow")); streak.raycastTarget = false; _fxObjs.Add(streak.gameObject); Place(streak.rectTransform, Vector2.zero, Vector2.one);
            Sfx(finaltextSFX, 1f);
            while (Time.time - t0 < d)
            {
                float el = Time.time - t0, p = el / d;
                float tq = Mathf.Clamp01(p / .55f); float tx = Mathf.Lerp(_uiSize.x * .8f, -_uiSize.x * 1.4f, tq * tq * (3 - 2 * tq) * .7f + tq * .3f);
                if (streak != null) { float sq = Mathf.Clamp01(1f - Mathf.Abs(p - .3f) / .16f); streak.rectTransform.anchoredPosition = new Vector2(tx + lh * 1.6f, -_uiSize.y * .05f); streak.rectTransform.sizeDelta = new Vector2(_uiSize.x * (.4f + 1.4f * sq), lh * (.08f + .5f * sq * sq)); streak.color = new Color(1f, .9f, .6f, .9f * Mathf.Sin(Mathf.Clamp01(p / .55f) * Mathf.PI)); streak.transform.SetAsLastSibling(); }
                if (loco != null) { loco.rectTransform.anchoredPosition = new Vector2(tx, -_uiSize.y * .05f + Mathf.Sin(el * 30f) * _uiSize.y * .004f); }
                for (int k = 0; k < wagons.Count; k++) if (wagons[k] != null) wagons[k].rectTransform.anchoredPosition = new Vector2(tx + lh * .85f * (k + 1), -_uiSize.y * .08f + Mathf.Sin(el * 30f + k) * _uiSize.y * .004f);
                if (p < .55f && el > nextSmoke) { nextSmoke = el + .14f; var sm = FxImg("smoke", new Vector2(tx - lh * .05f, lh * .35f) + new Vector2(0, -_uiSize.y * .05f), lh * .35f, new Color(1, 1, 1, .8f), _top); StartCoroutine(Drift(sm, .9f)); }
                { float w = Mathf.Clamp01(1f - Mathf.Abs(p - .3f) / .13f); w = w * w * (3 - 2 * w); if (_flash != null) { _flash.gameObject.SetActive(w > .01f); _flash.transform.SetAsLastSibling(); loco.transform.SetAsLastSibling(); foreach (var wg in wagons) if (wg != null) wg.transform.SetAsLastSibling(); _flash.color = new Color(1f, .93f, .78f, .6f * w); } }
                if (!switched && p >= .3f)
                {
                    switched = true; SetMode(true);
                    for (int i = 0; i < BN; i++) SetBCell(i, -1, 0);
                    SetLocks(C); _lSignVal.text = TrainEngine.StartRespins.ToString(); ShowBonusTotal(m.tot);
                    _bannerIcon.sprite = Spr("plaque_wagon"); _bannerText.text = m.by == 1 ? "<size=60%>FEATURE BOUGHT</size>\n<size=35%>" + TrainEngine.BuyNames[Mathf.Clamp(m.buyVariant, 0, TrainEngine.Variants - 1)] + "</size>" : "<size=60%>ALL ABOARD!</size>";
                    _bannerSub.text = "3 respins \u2022 every new symbol resets to 3 \u2022 fill a reel: +1 reel up to 7x4 \u2022 full wagon +500x";
                    ShowBanner(d * .7f + .3f); _bannerDim.color = new Color(.08f, .03f, .02f, .55f);
                }
                if (switched && m.by == 1) { float q = Mathf.Clamp01((p - .3f) / .08f); _bannerIcon.rectTransform.localScale = Vector3.one * Mathf.Lerp(3f, 1f, q * q); float sh = p > .38f && p < .5f ? (1 - (p - .38f) / .12f) : 0; _ui.anchoredPosition = _uiBasePos + new Vector2(0, Mathf.Sin(el * 70f) * _uiSize.y * .012f * sh); if (q >= 1 && sh > .95f) Sfx(spinDoneSFX, 0); }
                else if (switched) { float q = Mathf.Clamp01((p - .3f) / .15f); _bannerIcon.rectTransform.localScale = Vector3.one * Mathf.Max(.05f, Mathf.Sin(q * Mathf.PI * .5f) * (1 + .05f * Mathf.Sin(el * 8f))); }
                yield return null;
            }
            foreach (var w in wagons) if (w != null) Destroy(w.gameObject);
            if (loco != null) Destroy(loco.gameObject); if (streak != null) Destroy(streak.gameObject);
            HideBanner(); if (_flash != null) _flash.gameObject.SetActive(false); _ui.anchoredPosition = _uiBasePos; _bannerDim.color = new Color(.08f, .03f, .02f, .8f); _bannerIcon.rectTransform.localScale = Vector3.one;
        }
        /// calm hold after the flip: soft glow breathing + one diagonal light sheen across the board, duration == sd
        IEnumerator TriggerFlourish(List<int> scs, float sd)
        {
            bool gold = scs.Any(i => _g[i] == TrainEngine.GOLD); float t0 = Time.time;
            _winLabel.text = gold ? "<color=#ffe680>GOLDEN LOCO - GOLDEN EXPRESS!</color>" : scs.Count >= 4 ? $"<color=#ffcf5a>{scs.Count} LOCOS - FULL STEAM!</color>" : "<color=#ffcf5a>3 BONUS LOCOS - ALL ABOARD!</color>";
            Sfx(finaltextSFX, gold ? 10f : 1f);
            var sheen = Img("Sheen", _fx, Spr("px")); sheen.raycastTarget = false; _fxObjs.Add(sheen.gameObject);
            Place(sheen.rectTransform, Vector2.zero, new Vector2(_cs * .5f, _gh * 1.5f)); sheen.rectTransform.localRotation = Quaternion.Euler(0, 0, -20f);
            var lr = _winLabel.rectTransform;
            while (Time.time - t0 < sd)
            {
                float el = Time.time - t0, p = el / sd, e = p * p * (3 - 2 * p);
                if (sheen != null) { sheen.rectTransform.anchoredPosition = new Vector2(Mathf.Lerp(-_gw * .7f, _gw * .7f, e), 0); sheen.color = new Color(1f, .92f, .7f, .16f * Mathf.Sin(p * Mathf.PI)); }
                foreach (var i in scs) { if (_cellGlow[i] != null) _cellGlow[i].color = new Color(1f, .8f, .4f, .35f + .2f * Mathf.Sin(el * 5f)); _cell[i].rectTransform.localScale = Vector3.one * (1f + .025f * Mathf.Sin(el * 5f)); }
                float lq = Mathf.Clamp01(el / .35f); lr.localScale = Vector3.one * Mathf.LerpUnclamped(.85f, 1f, GwyfShared.ReelFx.EaseOutBack(lq, 1.5f));
                yield return null;
            }
            lr.localScale = Vector3.one; if (sheen != null) Destroy(sheen.gameObject);
            _ui.anchoredPosition = _uiBasePos;
        }

        IEnumerator Drift(GameObject g, float dur)
        {
            float t0 = Time.time; var rt = g != null ? (RectTransform)g.transform : null; var im = g != null ? g.GetComponent<Image>() : null; Vector2 p0 = rt != null ? rt.anchoredPosition : Vector2.zero;
            while (Time.time - t0 < dur) { if (rt == null) yield break; float p = (Time.time - t0) / dur; rt.anchoredPosition = p0 + new Vector2(_uiSize.x * .05f * p, _uiSize.y * .12f * p); rt.localScale = Vector3.one * (1 + p * 1.5f); im.color = new Color(1, 1, 1, .8f * (1 - p)); yield return null; }
            if (g != null) Destroy(g);
        }

        IEnumerator BonusStep(GrMsg m, bool t)
        {
            var b = m.b;
            _bonusBaseX=m.bw;
            HideBanner(); ClearFx();
            if (!_bonusMode) { SetMode(true); for (int i = 0; i < BN; i++) SetBCell(i, -1, 0); }   // late joiner: rebuild from the step
            SetLocks(b.cols0);
            var nwSet = new HashSet<int>(b.nw ?? new int[0]);
            // board as it was BEFORE this step's landings
            for (int i = 0; i < BN; i++) if (!nwSet.Contains(i)) SetBCell(i, b.bt[i], b.bv[i]); else SetBCell(i, -1, 0);
            ShowBonusTotal(m.bw + BoardTotal());
            if (m.bi == 0)
            {
                // trigger locos turn into their coins / specials
                float d = GrTiming.Reveal(t), t0 = Time.time; bool sw = false; _particleBudget = 60;
                foreach (var i in nwSet) { _bcell[i].sprite = Spr(b.bt[i] >= TrainEngine.IBANKER ? "sym_loco_gold" : "sym_loco_scatter"); _bcell[i].color = Color.white; }
                while (Time.time - t0 < d)
                {
                    float p = (Time.time - t0) / d, sx = p < .5f ? 1 - p * 2 : (p - .5f) * 2;
                    if (!sw && p >= .5f) { sw = true; foreach (var i in nwSet) { SetBCell(i, b.bt[i], b.bv[i]); StartCoroutine(Particles(_bhome[i], Gold, 10, d * .5f, _bcs * .8f)); } Sfx(multiplierSFX, 20f); }
                    foreach (var i in nwSet) _bcell[i].rectTransform.localScale = new Vector3(Mathf.Max(.02f, sx), 1, 1);
                    yield return null;
                }
                foreach (var i in nwSet) _bcell[i].rectTransform.localScale = Vector3.one;
            }
            else yield return WagonSpin(b, nwSet, t);
            _lSignVal.text = b.left.ToString();
            if (nwSet.Count > 0 && m.bi > 0) { _lSignVal.text = TrainEngine.StartRespins.ToString(); StartCoroutine(Pop(_lSignVal.transform, .4f)); }
            ShowBonusTotal(m.bw + BoardTotal());
            // every new SPECIAL gets its own landing show (left->right)
            foreach (var i in nwSet.OrderBy(x => x).Where(x => b.bt[x] >= TrainEngine.BANKER).Take(8)) yield return LandShow(i, GrTiming.LandEach(t));
            // actions in the engine's order
            if (b.ev != null) foreach (var e in b.ev) { yield return ActRoutine(e, t); ShowBonusTotal(m.bw + BoardTotal()); }
            // reel unlocks
            for (int c = b.cols0; c < b.cols && c < BC; c++) yield return UnlockRoutine(c, GrTiming.Unlock(t));
            SetLocks(b.cols);
            if (b.full == 1)
            {
                float d = GrTiming.Full(t), t0 = Time.time; _particleBudget = 80;
                _bannerIcon.sprite = Spr("plaque_wagon"); _bannerText.text = "FULL WAGON!"; _bannerSub.text = $"+{TrainEngine.FullBoardBonus:0}x BET"; ShowBanner(d + .2f); _bannerDim.color = new Color(.08f, .03f, .02f, .5f);
                StartCoroutine(Particles(Vector2.zero, Gold, 60, d * .8f, _bgw * .6f));
                while (Time.time - t0 < d) { float p = (Time.time - t0) / d; _bannerText.transform.localScale = Vector3.one * (p < .15f ? Mathf.SmoothStep(0, 1.15f, p / .15f) : 1 + .05f * Mathf.Sin(p * 20)); yield return null; }
                HideBanner(); _bannerText.transform.localScale = Vector3.one; _bannerDim.color = new Color(.08f, .03f, .02f, .8f);
            }
            _lSignVal.text = b.left.ToString();
            ShowBonusTotal(m.tot);
            _lastWinX = m.tot; RefreshBar();
            yield return WaitT(GrTiming.Settle(t));
        }

        /// empty unlocked cells spin (blurred placeholders), columns stop left to right, new symbols drop in with a flash.
        /// Duration == BSpin + Stagger * (BCols - 1)
        IEnumerator WagonSpin(TrainEngine.BStep b, HashSet<int> nw, bool t)
        {
            float spin = GrTiming.BSpin(t), stagger = GrTiming.Stagger(t), total = spin + stagger * (BC - 1);
            var cells = Enumerable.Range(0, BN).Where(i => i / R < b.cols0 && _bt[i] < 0).ToArray();
            var complete = new bool[BN]; var sound = new bool[BC];
            var fillers = new[] { Spr("coin_gold"), Spr("sym_empty"), Spr("coin_teal"), Spr("sp_banker") };
            _particleBudget = 80; Sfx(spinReelSFX, 0);
            foreach (int i in cells)
            {
                Sprite from = _bcell[i].sprite;
                SetBCell(i, b.bt[i], b.bv[i]);
                _breel[i].Begin(from, _bcell[i].sprite, _bval[i], fillers, spin + stagger * (i / R));
                _bt[i]=-1;_bv[i]=0; // Values count only after the arriving symbol has stopped.
            }
            float started = Time.time;
            try
            {
                while (true)
                {
                    float elapsed = Time.time - started;
                    foreach (int i in cells)
                    {
                        if (complete[i]) continue;
                        int column = i / R; float end = spin + stagger * column;
                        _breel[i].Draw(elapsed);
                        if (elapsed >= end)
                        {
                            complete[i] = true; _breel[i].Finish();
                            SetBCell(i,b.bt[i],b.bv[i]);ShowBonusTotal(TrainPresentation.Total(_bonusBaseX,BoardTotal()));
                            if (nw.Contains(i))
                            {
                                StartCoroutine(LandFlash(i, t ? .12f : .24f));
                                if (!sound[column]) { sound[column] = true; Sfx(spinDoneSFX, 0); }
                            }
                        }
                    }
                    if (elapsed >= total) break;
                    yield return null;
                }
            }
            finally { foreach (int i in cells) { _breel[i].Finish(); SetBCell(i, b.bt[i], b.bv[i]); } }
        }
        IEnumerator LandFlash(int i, float dur)
        {
            var pop = FxImg("pop_0", _bhome[i], _bcs * 1.6f, Color.white, _bfx); StartCoroutine(Flipbook(pop.GetComponent<Image>(), "pop_", 0, 7, dur * 1.4f));
            StartCoroutine(Particles(_bhome[i], _bt[i] >= 0 ? ActColor[_bt[i]] : Gold, 8, dur * 1.5f, _bcs * .7f));
            float t0 = Time.time; var gl = _bglow[i]; gl.gameObject.SetActive(true);
            while (Time.time - t0 < dur * 2f) { float p = (Time.time - t0) / (dur * 2f); var c = _bt[i] >= 0 ? ActColor[_bt[i]] : Gold; gl.color = new Color(c.r, c.g, c.b, .9f * (1 - p)); yield return null; }
            gl.gameObject.SetActive(false);
        }
        /// extra show when a special lands: swell, name tag, glow ring. Duration == dur
        IEnumerator LandShow(int i, float dur)
        {
            var tag = Txt("tag", _ui, ActColor[_bt[i]]); Place(tag.rectTransform, P(.5f, .845f), new Vector2(_uiSize.x * .6f, _uiSize.y * .04f)); tag.text = TrainEngine.BNames[_bt[i]]; _fxObjs.Add(tag.gameObject);
            var gl = _bglow[i]; gl.gameObject.SetActive(true); float t0 = Time.time; Sfx(multiplierSFX, 15f);
            if (_bt[i] == TrainEngine.SPIRIT) { _particleBudget = 30; StartCoroutine(Particles(_bhome[i], new Color(1f, .4f, .5f), 14, dur * 2f, _bcs)); }
            while (Time.time - t0 < dur) { float p = (Time.time - t0) / dur; _bcell[i].rectTransform.localScale = Vector3.one * (1 + .25f * Mathf.Sin(p * Mathf.PI)); var c = ActColor[_bt[i]]; gl.color = new Color(c.r, c.g, c.b, .8f); tag.rectTransform.localScale = Vector3.one * Mathf.Min(1, p * 3); yield return null; }
            _bcell[i].rectTransform.localScale = Vector3.one; gl.gameObject.SetActive(false); if (tag != null) Destroy(tag.gameObject);
        }

        Vector2 Arc(Vector2 a, Vector2 b, float t, float h) => Vector2.Lerp(a, b, t) + new Vector2(0, h * 4 * t * (1 - t));

        /// one special action. Duration == GrTiming.ActDur
        IEnumerator ActRoutine(TrainEngine.Ev e, bool t)
        {
            float d = GrTiming.ActDur(e, t); int s = e.s; var tg = e.tg ?? new int[0];
            if (s < 0 || s >= BN) { yield return WaitT(d); yield break; }
            var col = ActColor[Mathf.Clamp(e.k, 0, 9)]; float t0 = Time.time; _particleBudget = 70;
            var gl = _bglow[s]; gl.gameObject.SetActive(true); gl.color = new Color(col.r, col.g, col.b, .9f);
            if (e.by >= 0 && e.by < BN) { var sg = Segment(_bhome[e.by], _bhome[s], _bcs * .06f, new Color(1f, .35f, .45f, .8f), _bfx); Destroy(sg.gameObject, d * .5f); }
            var label = Txt("act", _ui, col); Place(label.rectTransform, P(.5f, .845f), new Vector2(_uiSize.x * .65f, _uiSize.y * .04f)); _fxObjs.Add(label.gameObject);
            label.text = (e.by >= 0 ? "SPIRIT: " : "") + TrainEngine.BNames[Mathf.Clamp(e.k, 0, 9)] + (e.k == TrainEngine.BANKER || e.k == TrainEngine.IBANKER ? " PAYS" : e.k == TrainEngine.MARSHAL || e.k == TrainEngine.IMARSHAL ? " COLLECTS" : e.k == TrainEngine.TYCOON ? " COLLECTS + PAYS" : e.k == TrainEngine.SPIRIT ? (tg.Length > 0 ? " AWAKENS " + tg.Length : " (NOTHING TO AWAKEN)") : " SHOOTS");
            Sfx(multiplierSFX, 25f);
            switch (e.k)
            {
                case TrainEngine.BANKER: case TrainEngine.IBANKER:
                    {   // beams out of the banker, every target pops with +value
                        var segs = tg.Select(x => Segment(_bhome[s], _bhome[s], _bcs * .05f, new Color(col.r, col.g, col.b, .9f), _bfx)).ToList(); bool applied = false;
                        while (Time.time - t0 < d)
                        {
                            float p = (Time.time - t0) / d, q = Mathf.Clamp01(p / .5f);
                            for (int k = 0; k < tg.Length; k++) { var sg = segs[k]; if (sg == null) continue; Vector2 tip = Vector2.Lerp(_bhome[s], _bhome[tg[k]], q), dv = tip - _bhome[s]; sg.rectTransform.sizeDelta = new Vector2(dv.magnitude, sg.rectTransform.sizeDelta.y); sg.rectTransform.localRotation = Quaternion.Euler(0, 0, Mathf.Atan2(dv.y, dv.x) * Mathf.Rad2Deg); sg.color = new Color(col.r, col.g, col.b, .9f * (1 - Mathf.Clamp01((p - .6f) / .4f))); }
                            if (!applied && p >= .5f) { applied = true; ApplyAfter(e); foreach (var x in tg) { StartCoroutine(Pop(_bcell[x].transform, .25f)); StartCoroutine(Particles(_bhome[x], col, 4, d * .4f, _bcs * .5f)); } }
                            _bcell[s].rectTransform.localScale = Vector3.one * (1 + .15f * Mathf.Sin(p * Mathf.PI));
                            yield return null;
                        }
                        foreach (var sg in segs) if (sg != null) Destroy(sg.gameObject);
                        break;
                    }
                case TrainEngine.MARSHAL: case TrainEngine.IMARSHAL: case TrainEngine.TYCOON:
                    {   // coins fly to the collector on arcs; the tycoon then pays the new value back out
                        bool tyc = e.k == TrainEngine.TYCOON; float collectEnd = tyc ? .5f : .85f;
                        var flyers = tg.Select(x => FxImg("coin_gold", _bhome[x], _bcs * .35f, Color.white, _bfx)).ToList(); bool applied = false; List<Image> segs = null;
                        while (Time.time - t0 < d)
                        {
                            float p = (Time.time - t0) / d, q = Mathf.Clamp01(p / collectEnd);
                            for (int k = 0; k < flyers.Count; k++) if (flyers[k] != null) { float qq = Mathf.Clamp01(q * 1.2f - k * .02f); ((RectTransform)flyers[k].transform).anchoredPosition = Arc(_bhome[tg[k]], _bhome[s], qq, _bcs * .8f); flyers[k].SetActive(qq < 1); }
                            if (!applied && p >= collectEnd) { applied = true; ApplyAfter(e); StartCoroutine(Pop(_bcell[s].transform, .35f)); StartCoroutine(Particles(_bhome[s], col, 12, d * .3f, _bcs * .8f)); if (tyc) segs = tg.Select(x => Segment(_bhome[s], _bhome[x], _bcs * .05f, new Color(col.r, col.g, col.b, .9f), _bfx)).ToList(); }
                            if (segs != null) foreach (var sg in segs) if (sg != null) sg.color = new Color(col.r, col.g, col.b, .9f * (1 - Mathf.Clamp01((p - collectEnd) / (1 - collectEnd))));
                            _bcell[s].rectTransform.localScale = Vector3.one * (1 + .12f * Mathf.Sin(p * Mathf.PI * 2));
                            yield return null;
                        }
                        foreach (var f in flyers) if (f != null) Destroy(f);
                        if (segs != null) foreach (var sg in segs) if (sg != null) Destroy(sg.gameObject);
                        break;
                    }
                case TrainEngine.OUTLAW: case TrainEngine.IOUTLAW:
                    {   // muzzle flash, tracer into the target, target value doubles per hit
                        float pre = GrTiming.ActBase(t) * .5f, shot = GrTiming.Shot(t); int shots = Mathf.Min(tg.Length, 12);
                        var baseSpr = _bcell[s].sprite;
                        yield return WaitT(pre);
                        for (int k = 0; k < shots; k++)
                        {
                            int x = tg[k]; float s0 = Time.time;
                            if (e.k == TrainEngine.OUTLAW) _bcell[s].sprite = Spr("sp_outlaw_fire") ?? baseSpr;
                            var tr = Segment(_bhome[s] + new Vector2(_bcs * .4f, 0), _bhome[x], _bcs * .04f, Tracer, _bfx);
                            var fl = FxImg("glow", _bhome[s] + new Vector2(_bcs * .45f, 0), _bcs * .7f, new Color(1f, .8f, .3f, 1f), _bfx);
                            SetBVal(x, _bv[x] * 2f); StartCoroutine(Pop(_bcell[x].transform, .3f)); StartCoroutine(Particles(_bhome[x], Tracer, 5, shot * 2f, _bcs * .5f)); Sfx(multiplierSFX, 40f);
                            ShowBonusTotal(TrainPresentation.Total(_bonusBaseX,BoardTotal()));
                            var hit = Txt("x2", _bfx, new Color(1f, .3f, .3f)); Place(hit.rectTransform, _bhome[x] + new Vector2(_bcs * .3f, _bcs * .35f), new Vector2(_bcs * .6f, _bcs * .3f)); hit.text = "x2"; _fxObjs.Add(hit.gameObject); Destroy(hit.gameObject, shot * 3f);
                            while (Time.time - s0 < shot) { float p = (Time.time - s0) / shot; if (tr != null) tr.color = new Color(Tracer.r, Tracer.g, Tracer.b, 1 - p); if (fl != null) fl.GetComponent<Image>().color = new Color(1f, .8f, .3f, 1 - p); yield return null; }
                            if (tr != null) Destroy(tr.gameObject); if (fl != null) Destroy(fl);
                            _bcell[s].sprite = baseSpr;
                        }
                        ApplyAfter(e);
                        break;
                    }
                case TrainEngine.SPIRIT:
                    {   // ghost glow, the chosen specials light up red one after another
                        while (Time.time - t0 < d)
                        {
                            float p = (Time.time - t0) / d;
                            gl.rectTransform.localScale = Vector3.one * (1.2f + .4f * Mathf.Sin(p * Mathf.PI));
                            int lit = Mathf.Min(tg.Length, (int)(p * 1.3f * tg.Length));
                            for (int k = 0; k < tg.Length; k++) { var g2 = _bglow[tg[k]]; g2.gameObject.SetActive(k < lit); g2.color = new Color(1f, .3f, .4f, .8f); }
                            _bcell[s].color = new Color(1, 1, 1, .75f + .25f * Mathf.Sin(p * 30f));
                            yield return null;
                        }
                        foreach (var x in tg) _bglow[x].gameObject.SetActive(false);
                        _bcell[s].color = Color.white; gl.rectTransform.localScale = Vector3.one;
                        break;
                    }
                default: yield return WaitT(d); break;
            }
            gl.gameObject.SetActive(false); if (label != null) Destroy(label.gameObject);
            ApplyAfter(e);
        }
        void ApplyAfter(TrainEngine.Ev e) { if (e.after == null || e.after.Length != BN) return; for (int i = 0; i < BN; i++) if (_bt[i] >= 0) SetBVal(i, e.after[i]); ShowBonusTotal(TrainPresentation.Total(_bonusBaseX,BoardTotal())); }

        IEnumerator UnlockRoutine(int c, float dur)
        {
            var lk = _block[c]; float t0 = Time.time; _particleBudget = 40;
            _winLabel.text = "<color=#ffcf5a>NEW REEL UNLOCKED!</color>"; Sfx(finaltextSFX, 5f);
            StartCoroutine(Particles(new Vector2(-_bgw / 2 + _bcs * (c + .5f), 0), Gold, 24, dur, _bcs * 1.2f));
            while (Time.time - t0 < dur)
            {
                float p = (Time.time - t0) / dur;
                if (lk != null) { lk.color = new Color(1, 1, 1, 1 - p); lk.rectTransform.anchoredPosition = new Vector2(-_bgw / 2 + _bcs * (c + .5f), _bgh * p * .3f); }
                yield return null;
            }
            if (lk != null) { lk.gameObject.SetActive(false); lk.rectTransform.anchoredPosition = new Vector2(-_bgw / 2 + _bcs * (c + .5f), 0); lk.color = Color.white; }
            _winLabel.text = "";
        }

        IEnumerator EndRoutine(GrMsg m)
        {
            _lastWinX = m.tot; RefreshBar();
            bool bonus = m.bi > 0;
            if (!bonus && m.tot < 10) { SetMode(false); yield break; }
            Sfx(finaltextSFX, m.tot);
            _bannerIcon.sprite = Spr("logo"); _bannerIcon.rectTransform.localScale = Vector3.one;
            string title = m.tot >= 500 ? "LEGENDARY WIN" : m.tot >= 100 ? "MEGA WIN" : m.tot >= 50 ? "SUPER WIN" : m.tot >= 20 ? "BIG WIN" : "TOTAL WIN";
            _bannerSub.text = (m.cap == 1 ? $"MAX WIN {TrainEngine.MaxWinX:0}x  \u2022  " : "") + $"{m.tot:0.##}x bet";
            float d = m.tb == 1 ? 1.5f : 3f, t0 = Time.time;
            ShowBanner(d + (m.tb == 1 ? 1f : 2.5f) + .2f); _particleBudget = 40;
            StartCoroutine(Particles(Vector2.zero, Gold, 40, d * .8f, _gw * .7f));
            while (Time.time - t0 < d)
            {
                float p = Mathf.Clamp01((Time.time - t0) / (d * .7f));
                _bannerText.text = $"<size=55%>{title}</size>\n" + Money(m.tot * (1 - Mathf.Pow(1 - p, 3)));
                _bannerText.transform.localScale = Vector3.one * (1 + .06f * Mathf.Sin(Time.time * 9)); yield return null;
            }
            _bannerText.text = $"<size=55%>{title}</size>\n" + Money(m.tot); _bannerText.transform.localScale = Vector3.one;
            yield return WaitT(m.tb == 1 ? 1f : 2.5f);
            HideBanner(); SetMode(false);
        }
    }
}
