using System;

namespace GoldRushExpress
{

// Integral of smoothstep velocity: starts/stops with zero velocity and
// acceleration, and arrives at an integer cell without a frame-time phase jump.
public static class CellReelMotion
{
    public readonly struct StripSlot
    {
        public readonly int Index;
        public readonly float Offset;
        public StripSlot(int index,float offset){Index=index;Offset=offset;}
    }
    public static StripSlot Slot(float position,int image)
    {int index=(int)Math.Floor(position)+image-1;return new StripSlot(index,index-position);}
    public static int Travel(float duration) => Math.Max(2, (int)Math.Round(duration * 6));
    public static float Position(float elapsed, float duration, int travel)
    {
        if (elapsed <= 0) return 0;
        if (elapsed >= duration) return travel;
        float ramp = duration * .18f, brake = duration * .36f;
        float speed = travel / (duration - (ramp + brake) * .5f);
        if (elapsed < ramp)
        {
            float q = elapsed / ramp;
            return speed * ramp * (q * q * q - .5f * q * q * q * q);
        }
        if (elapsed < duration - brake) return speed * (elapsed - ramp * .5f);
        float p = (elapsed - duration + brake) / brake;
        return speed * (duration - brake - ramp * .5f + brake * (p - p * p * p + .5f * p * p * p * p));
    }
}

}
