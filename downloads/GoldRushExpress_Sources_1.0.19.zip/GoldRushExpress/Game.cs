using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using FMODUnity;
using Mirror;
using Mirror.RemoteCalls;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace GoldRushExpress
{
    public partial class TrainGame : GameBase
    {
        const string RpcSig = "System.Void GoldRushExpress.TrainGame::UserRpcShowSpin(System.String)";
        public bool turbo;
        public InteractableEventTrigger turboButton, buyButton, betMinusButton, betPlusButton;
        int _spinCount;
        BigNumber _charged = BigNumber.Zero; bool _roundActive; float _deadline;
        readonly List<RenderTexture> _ownRts = new List<RenderTexture>();
        public static bool ForceBonusNext;

        public TextMeshPro payoutText;
        public List<Image> symbolLocations = new List<Image>();
        public List<SlotReel> reels = new List<SlotReel>();
        public EventReference spinReelSFX, spinDoneSFX, multiplierSFX, finaltextSFX;
        public List<InteractableEventTrigger> playButtons = new List<InteractableEventTrigger>();

        static bool _rpcRegistered;
        public static void RegisterRpcs()
        {
            if (_rpcRegistered) return; _rpcRegistered = true;
            GwyfShared.RpcGuard.Register(typeof(TrainGame), RpcSig, (obj, reader, conn) =>
            {
                if (!NetworkClient.active) return;
                ((TrainGame)obj).UserRpcShowSpin(reader.ReadString());
            });
        }
        public override bool Weaved() => true;

        public void CopyFromSlots(Slots s)
        {
            T Get<T>(string n) => (T)HarmonyLib.AccessTools.Field(typeof(Slots), n).GetValue(s);
            try { payoutText = Get<TextMeshPro>("payoutText"); } catch { }
            try { symbolLocations = Get<List<Image>>("symbolLocations"); } catch { }
            try { reels = Get<List<SlotReel>>("reels"); } catch { }
            try { spinReelSFX = Get<EventReference>("spinReelSFX"); spinDoneSFX = Get<EventReference>("spinDoneSFX");
                  multiplierSFX = Get<EventReference>("multiplierSFX"); finaltextSFX = Get<EventReference>("finaltextSFX"); } catch { }
            gameName = "Gold Rush Express";
        }
        public void SetDefaults() { gameName = "Gold Rush Express"; }

        protected override void OnAwake()
        {
            base.OnAwake();
            // own screen render texture per machine (vanilla slots share one asset)
            try { var pb = playButtons != null && playButtons.Count > 0 && playButtons[0] != null ? playButtons[0].transform : null; var r = GwyfShared.CabinetScaler.Apply(transform, TrainPlugin.CabinetScale.Value, pb, "GR"); if (r != null) TrainPlugin.Log.LogInfo("[GR] " + r); } catch (Exception e) { TrainPlugin.Log.LogError("[GR] cabinet scale: " + e.Message); }
            // ScreenIso removed: the slot screen is a direct world-space canvas (no camera/RT); the camera it found was the keypad camera.
        }

        // ---------------- art ----------------
        static readonly Dictionary<string, Sprite> _sprites = new Dictionary<string, Sprite>();
        public static Texture2D LoadPng(string key)
        {
            using (var st = typeof(TrainGame).Assembly.GetManifestResourceStream("GoldRushExpress.art." + key + ".png"))
            {
                if (st == null) { TrainPlugin.Log.LogError("[GR] Missing embedded art: " + key); return null; }
                var ms = new System.IO.MemoryStream(); st.CopyTo(ms);
                var tex = new Texture2D(2, 2, TextureFormat.RGBA32, true);
                ImageConversion.LoadImage(tex, ms.ToArray());
                tex.name = "GR_" + key; GwyfShared.ReelFx.ConfigureTexture(tex);
                return tex;
            }
        }
        public static Sprite Spr(string key)
        {
            if (_sprites.TryGetValue(key, out var sp)) return sp;
            try { sp = FreshSpriteKey(key); if (sp != null) { _sprites[key] = sp; return sp; } var tex = LoadPng(key); sp = tex != null ? Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), new Vector2(.5f, .5f), 100f) : null; }
            catch (Exception e) { TrainPlugin.Log.LogError("[GR] Sprite load failed " + key + ": " + e.Message); sp = null; }
            _sprites[key] = sp; return sp;
        }
        public static Sprite BlurSprite(int sym)
        {
            if (sym == TrainEngine.SCAT) return Spr("blur_loco_scatter");
            if (sym == TrainEngine.GOLD) return Spr("blur_loco_gold");
            return Spr("blur_" + TrainEngine.ArtKeys[Mathf.Clamp(sym, 0, TrainEngine.NLINE - 1)]);
        }
        static readonly Dictionary<Sprite, Sprite> _blurOf = new Dictionary<Sprite, Sprite>();
        public static Sprite BlurOf(Sprite s)
        {
            if (s == null) return null; if (_blurOf.TryGetValue(s, out var b)) return b;
            string n = s.texture != null ? s.texture.name : ""; int k = n.IndexOf("sym_"); b = null;
            if (k >= 0) { string key = "blur_" + n.Substring(k + 4); if (typeof(TrainGame).Assembly.GetManifestResourceInfo("GoldRushExpress.art." + key + ".png") != null) b = Spr(key); }
            _blurOf[s] = b; return b;
        }
        public static Sprite SymSprite(int sym)
        {
            if (sym == TrainEngine.SCAT) return Spr("sym_loco_scatter");
            if (sym == TrainEngine.GOLD) return Spr("sym_loco_gold");
            return Spr("sym_" + TrainEngine.ArtKeys[Mathf.Clamp(sym, 0, TrainEngine.NLINE - 1)]);
        }
        static readonly string[] SpKeys = { null, null, "sp_banker", "sp_marshal", "sp_tycoon", "sp_outlaw", "sp_spirit", "sp_iron_banker", "sp_iron_marshal", "sp_iron_outlaw" };
        public static Sprite BonusSprite(int t, float v)
        {
            if (t < 0) return Spr("sym_empty");
            if (t <= TrainEngine.GCOIN) return Spr(v < 20 ? "coin_gold" : v < 100 ? "coin_teal" : "coin_blue");
            return Spr(SpKeys[Mathf.Clamp(t, 2, 9)]);
        }

        // ---------------- server ----------------
        static void Hook(InteractableEventTrigger b, UnityEngine.Events.UnityAction<PlayerInteract> a)
        {
            if (b == null) return;
            if (b.serverOnInteractEvent == null) b.serverOnInteractEvent = new UnityEngine.Events.UnityEvent<PlayerInteract>();
            b.serverOnInteractEvent.AddListener(a);
        }
        public override void OnStartServer()
        {
            base.OnStartServer();
            foreach (var b in playButtons) Hook(b, TryStartGame);
            Hook(buyButton, TryBuyBonus); Hook(turboButton, ToggleTurbo);
            Hook(betMinusButton, p => StepBet(-1)); Hook(betPlusButton, p => StepBet(+1));
            HookScreenButtons();
            TrainPlugin.V($"OnStartServer: {playButtons.Count} play button(s), buy={(buyButton != null)} bet+-={(betPlusButton != null)} keypad={(keypad != null)}");
        }

        [Server]
        public override void TryStartGame(PlayerInteract pi)
        {
            if (!NetworkServer.active || pi == null) return;
            if (_buySel >= 0 && !isPlaying) { int v = _buySel; SetBuyMenu(-1); BuyVariant(pi, v); return; }
            if (!CanGameStart() || isPlaying) return;
            if (pi.TryGetComponent<PlayerProfile>(out var prof)) interactingPlayer = prof;
            if (interactingPlayer == null) return;
            if (!isGoldenChipApplied)
            {
                BigNumber cost = currentBet;
                if (currentBet < MinBet || currentBet > MaxBet || !Extensions.NetworkSingleton<MoneyManager>.Instance.TryChangeBalance(-cost, interactingPlayer, ChangeType.Bet))
                { try { keypad.ServerInvalidBetAmountFb(); } catch { } return; }
                _charged = cost;
            }
            else { isGoldenBet = true; _charged = BigNumber.Zero; }
            isPlaying = true; canBet = false;
            StartGame();
        }

        [Server]
        protected override void StartGame()
        {
            if (!NetworkServer.active) return;
            TrainPlugin.V("StartGame by " + (interactingPlayer != null ? interactingPlayer.name : "?"));
            StartCoroutine(RoundRoutine(false, 0));
        }

        int _roundGen; // bumped by refund/watchdog: a late-resuming round coroutine must never pay after a refund
        IEnumerator RoundRoutine(bool buy, int variant)
        {
            TrainEngine.Round round = null; int gen = ++_roundGen;
            _roundActive = true; _deadline = Time.time + 30f;
            _spinCount++;
            int everyN = TrainPlugin.ForceBonusEveryNSpins?.Value ?? 0;
            bool force = !buy && (ForceBonusNext || (TrainPlugin.AlwaysBonusNextSpin?.Value ?? false) || (everyN > 0 && _spinCount % everyN == 0));
            if (!buy) ForceBonusNext = false;
            try { round = buy ? TrainEngine.PlayBuyVariant(GetSeededRandom(7171), variant) : TrainEngine.Play(GetSeededRandom(7070), force); }
            catch (Exception e) { TrainPlugin.Log.LogError(e); }
            bool byAuto = _autoRound; _autoRound = false;
            if (round == null) { Refund("engine error"); SafeReset(); ContinueAuto(false, byAuto); yield break; }
            TrainPlugin.V($"Round: bet={currentBet} buy={buy} base={round.baseSpin.win:0.##}x lines={round.baseSpin.lines.Length} locos={round.baseSpin.sc} respins={(round.baseSpin.rs?.Length ?? 0)} bonusSteps={round.bonus.Count} total={round.total:0.##}x");
            string betS = FormatBet(currentBet); double bnum = currentBet.ToDouble();
            bool tb = turbo;
            double running = Math.Min(round.baseSpin.win, TrainEngine.MaxWinX), baseW = running;
            var bm = new GrMsg { t = "spin", s = round.baseSpin, w = (float)running, tot = (float)running, tb = tb ? 1 : 0, by = buy ? 1 : 0, buyVariant = variant, bet = betS, bn = bnum };
            if (round.bonus.Count > 0 && round.bonus[0].bt != null) { bm.lt = round.bonus[0].bt; bm.lv = round.bonus[0].bv; }
            Broadcast(bm);
            yield return Wait(GrTiming.Spin(bm) + GrTiming.FrameSlack(bm));
            if (gen != _roundGen) yield break;
            if (round.bonus.Count > 0)
            {
                Broadcast(new GrMsg { t = "intro", tot = (float)running, tb = tb ? 1 : 0, by = buy ? 1 : 0, buyVariant = variant, bet = betS, bn = bnum });
                yield return Wait(GrTiming.Intro(tb) + 0.1f);
                if (gen != _roundGen) yield break;
                for (int k = 0; k < round.bonus.Count; k++)
                {
                    tb = turbo;
                    var st = round.bonus[k];
                    double now = Math.Min(baseW + st.tot, TrainEngine.MaxWinX);
                    var m = new GrMsg { t = "bstep", b = st, bi = k, tot = (float)now, bw = (float)baseW, w = (float)(now - running), tb = tb ? 1 : 0, by = buy ? 1 : 0, bet = betS, bn = bnum, cap = now >= TrainEngine.MaxWinX ? 1 : 0 };
                    running = now;
                    Broadcast(m);
                    yield return Wait(GrTiming.BStep(m) + GrTiming.FrameSlack(m));
                    if (gen != _roundGen) yield break;
                }
            }
            try
            {
                if (interactingPlayer != null)
                {
                    if (buy) { double c = TrainEngine.BuyCost[variant]; Payout(round.total / c * EstimatedValue, ChangeType.GameResult, null, currentBet * c); }
                    else Payout(round.total * EstimatedValue);
                    TrainPlugin.V($"Payout: {round.total:0.##}x * floor {EstimatedValue:0.##}");
                }
                else TrainPlugin.Log.LogWarning("[GR] Player left before payout.");
            }
            catch (Exception e) { TrainPlugin.Log.LogError("[GR] Payout failed: " + e); }
            _roundActive = false; _charged = BigNumber.Zero;
            Broadcast(new GrMsg { t = "end", tot = (float)round.total, bi = round.bonus.Count, cap = round.capped ? 1 : 0, tb = tb ? 1 : 0, by = buy ? 1 : 0, bet = betS, bn = bnum });
            SafeReset();
            ContinueAuto(round.bonus.Count > 0, byAuto);
        }

        /// host waits exactly as long as the clients animate; the watchdog fires only 30 s after the expected end
        IEnumerator Wait(float s) { _deadline = Time.time + s + 30f; yield return new WaitForSeconds(s); }

        static string FormatBet(BigNumber b) { try { return MoneyFormatter.FormatWithDollar(b); } catch { return "$" + b; } }

        // ---- bonus buy menu: BUY opens the menu / cycles variants (last step closes it), SPIN buys the highlighted one ----
        int _buySel = -1; float _buyMenuT;
        [Server]
        void SetBuyMenu(int sel)
        {
            _buySel = sel; _buyMenuT = Time.time;
            Broadcast(new GrMsg { t = "buymenu", bi = sel, tb = turbo ? 1 : 0, bet = FormatBet(currentBet), bn = currentBet.ToDouble() });
        }
        void BuyMenuTimeout() { if (NetworkServer.active && _buySel >= 0 && (isPlaying || Time.time - _buyMenuT > 15f)) SetBuyMenu(-1); }

        [Server]
        public void TryBuyBonus(PlayerInteract pi)
        {
            if (!NetworkServer.active || pi == null) return;
            if (!CanGameStart() || isPlaying || _autoLeft > 0) return;
            int next = _buySel + 1; if (next >= TrainEngine.Variants) next = -1;
            SetBuyMenu(next);
            TrainPlugin.V(next < 0 ? "Buy menu closed" : $"Buy menu: {TrainEngine.BuyNames[next]} ({TrainEngine.BuyCost[next]}x)");
        }

        [Server]
        public void BuyVariant(PlayerInteract pi, int v)
        {
            if (!NetworkServer.active || pi == null) return;
            if (v < 0 || v >= TrainEngine.Variants || !CanGameStart() || isPlaying) return;
            if (pi.TryGetComponent<PlayerProfile>(out var prof)) interactingPlayer = prof;
            if (interactingPlayer == null) return;
            BigNumber cost = currentBet * TrainEngine.BuyCost[v];
            if (isGoldenChipApplied || currentBet < MinBet || currentBet > MaxBet || !Extensions.NetworkSingleton<MoneyManager>.Instance.TryChangeBalance(-cost, interactingPlayer, ChangeType.Bet))
            { TrainPlugin.Log.LogInfo($"[GR] Bonus buy refused: bet {currentBet}, cost {cost}"); try { keypad.ServerInvalidBetAmountFb(); } catch { } return; }
            _charged = cost;
            TrainPlugin.Log.LogInfo($"[GR] Bonus '{TrainEngine.BuyNames[v]}' bought by {interactingPlayer.name} for {cost} ({TrainEngine.BuyCost[v]}x)");
            isPlaying = true; canBet = false;
            StartCoroutine(RoundRoutine(true, v));
        }

        [Server]
        public void ToggleTurbo(PlayerInteract pi = null)
        {
            if (!NetworkServer.active) return;
            turbo = !turbo; TrainPlugin.V("Turbo " + (turbo ? "ON" : "OFF"));
            Broadcast(new GrMsg { t = "turbo", tb = turbo ? 1 : 0 });
        }

        static readonly double[] Ladder = { 1, 1.5, 2, 2.5, 3, 4, 5, 6, 8 };
        [Server]
        void StepBet(int dir)
        {
            if (!NetworkServer.active || isPlaying || !canBet || keypad == null || isGoldenChipApplied) return;
            try
            {
                double m = MinBet.ToDouble(), mx = MaxBet.ToDouble(), cur = currentBet.ToDouble();
                if (double.IsInfinity(mx) || mx > 1e15) mx = 1e15;
                var list = new List<double> { m };
                for (double dec = Math.Pow(10, Math.Floor(Math.Log10(Math.Max(1e-9, m)))); dec <= mx; dec *= 10)
                    foreach (var l in Ladder) { double v = l * dec; if (v > m * 1.0001 && v < mx * 0.9999) list.Add(v); }
                list.Add(mx);
                list = list.Select(v => Math.Max(1, Math.Round(v, MidpointRounding.AwayFromZero))).Where(v => v >= Math.Ceiling(m - 1e-9) && v <= mx + 1e-9).Distinct().OrderBy(v => v).ToList();
                if (list.Count == 0) return;
                double pick = cur;
                if (dir > 0) { pick = list.Last(); foreach (var v in list) if (v > cur * 1.0001) { pick = v; break; } }
                else { pick = list[0]; foreach (var v in list) if (v < cur * 0.9999) pick = v; }
                                if (Math.Abs(pick - cur) < 1e-9) return;
                var nb = BigNumber.FromDouble(pick);
                var apply = HarmonyLib.AccessTools.Method(typeof(Keypad), "ApplyInput");
                if (apply != null) apply.Invoke(keypad, new object[] { nb.ToKeypadString(), true });
                else { TrainPlugin.V("Keypad.ApplyInput not found - fallback"); keypad.Network_currentInput = nb.ToKeypadString(); ServerSetBet(nb); }
                TrainPlugin.V($"Bet {(dir > 0 ? "+" : "-")} -> {nb}");
                Broadcast(new GrMsg { t = "bet", bet = FormatBet(nb), bn = pick, tb = turbo ? 1 : 0 });
            }
            catch (Exception e) { TrainPlugin.Log.LogError("[GR] Bet step failed: " + e); }
        }

        void Refund(string why)
        {
            try
            {
                if (_charged > BigNumber.Zero && interactingPlayer != null)
                { Extensions.NetworkSingleton<MoneyManager>.Instance.TryChangeBalance(_charged, interactingPlayer, ChangeType.Bet); TrainPlugin.Log.LogWarning($"[GR] Refunded {_charged} ({why})"); }
            }
            catch (Exception e) { TrainPlugin.Log.LogError("[GR] Refund failed: " + e); }
            _charged = BigNumber.Zero; _roundActive = false; _roundGen++;
        }

        // floor change / day end / despawn while a round runs: coroutines die with the object, so refund what was really charged
        protected override void OnDisable()
        {
            try
            {
                if (NetworkServer.active && isPlaying) { Refund("machine disabled mid-round"); SafeReset(); }
                _roundActive = false;
            }
            catch (Exception e) { TrainPlugin.Log.LogError("[GR] OnDisable: " + e); }
            try { ClientAbort(); } catch { }
        }

        void OnDestroy()
        {
            StopAllCoroutines();
            try { foreach (var r in GetComponentsInChildren<Renderer>(true)) foreach (var m in r.sharedMaterials) if (m != null && m.name.EndsWith("(Instance)")) Destroy(m); } catch { }
            foreach (var rt in _ownRts) if (rt != null) { rt.Release(); Destroy(rt); }
            _ownRts.Clear();
        }

        void ServerWatchdog()
        {
            if (!NetworkServer.active || !_roundActive) return;
            if (Time.time > _deadline)
            {
                TrainPlugin.Log.LogError("[GR] Round stalled (coroutine died?) - refunding and unlocking machine");
                Refund("watchdog"); SafeReset(); _autoLeft = 0; _autoPi = null; Broadcast(new GrMsg { t = "auto", fsi = 0, tb = turbo ? 1 : 0 });
                Broadcast(new GrMsg { t = "end", tb = turbo ? 1 : 0 });
            }
        }

        void SafeReset() { _roundActive = false; try { ResetGame(); } catch (Exception e) { TrainPlugin.Log.LogError(e); isPlaying = false; canBet = true; } }

        void Broadcast(GrMsg msg)
        {
            if (!NetworkServer.active) return;
            try
            {
                var writer = NetworkWriterPool.Get();
                writer.WriteString(GwyfShared.MiniJson.ToJson(msg));
                SendRPCInternal(RpcSig, RpcSig.GetStableHashCode(), writer, 0, true);
                NetworkWriterPool.Return(writer);
            }
            catch (Exception e) { TrainPlugin.Log.LogError("[GR] Broadcast failed: " + e.Message); }
        }

        // ---------------- client ----------------
        public void UserRpcShowSpin(string json)
        {
            if (!NetworkClient.active) return;
            GrMsg msg;
            try { msg = GwyfShared.MiniJson.FromJson<GrMsg>(json); } catch (Exception e) { TrainPlugin.Log.LogError("[GR] Bad RPC json: " + e.Message); return; }
            if (msg.t != "bstep" || msg.bi <= 1) TrainPlugin.V($"RPC {msg.t} step={msg.bi} win={msg.w:0.##} tot={msg.tot:0.##} ({json.Length} bytes)");
            EnsureUi();
            if (_ui == null) return;
            if (!string.IsNullOrEmpty(msg.bet)) _betLabel = msg.bet;
            if (msg.bn > 0) _betNum = msg.bn;
            if (msg.t == "auto") { UpdateAutoVisual(msg.fsi); UpdateButtonsVisual(msg.tb == 1); RefreshBar(); return; }
            if (msg.t == "buymenu") { ShowBuyMenu(msg.bi); RefreshBar(); return; }
            if (msg.t == "turbo" || msg.t == "bet") { UpdateButtonsVisual(msg.tb == 1); RefreshBar(); return; }
            if (_anim != null) StopCoroutine(_anim);
            ClearFx(); HideBanner(); ResetTransientVisuals();
            _anim = StartCoroutine(Safe(Show(msg)));
        }

        void Update() { if (TrainPlugin.Instance != null) TrainPlugin.Instance.Tick(); UpdateIdle(); UpdateCabinetFx(); DriveBanner(); ServerWatchdog(); BuyMenuTimeout(); UpdateHudSpin(); ServerStateSync(); }

        void Start()
        {
            if (NetworkClient.active) { try { EnsureUi(); SetIdle(); } catch (Exception e) { TrainPlugin.Log.LogError("[GR] UI build failed: " + e); } }
            try
            {
                foreach (var tmp in GetComponentsInChildren<TextMeshPro>(true))
                    if (tmp != payoutText && tmp.text != null && tmp.text.IndexOf("slot", StringComparison.OrdinalIgnoreCase) >= 0) tmp.text = "GOLD RUSH EXPRESS";
            }
            catch { }
            try { if (TrainPlugin.RestyleCabinet == null || TrainPlugin.RestyleCabinet.Value) BuildCabinet(); GwyfShared.CabinetSkin.Build(transform, playButtons.FirstOrDefault(b => b != null)?.transform, "train"); } catch (Exception e) { TrainPlugin.Log.LogError("[GR] Cabinet restyle failed: " + e); }
        }

        void EnsureUi()
        {
            if (_ui != null) return;
            var imgs = (symbolLocations ?? new List<Image>()).Where(i => i != null).ToList();
            if (imgs.Count == 0 && reels != null) imgs = reels.Where(r => r != null).SelectMany(r => r.symbols ?? new Image[0]).Where(i => i != null).ToList();
            if (imgs.Count == 0 || imgs[0].canvas == null)
            {
                TrainPlugin.V("No vanilla screen found: building floating screen above the machine");
                var cgo = new GameObject("GoldRushExpressScreen", typeof(RectTransform), typeof(Canvas));
                cgo.GetComponent<Canvas>().renderMode = RenderMode.WorldSpace;
                var cr = (RectTransform)cgo.transform; cr.SetParent(transform, false);
                cr.sizeDelta = new Vector2(640, 400); cr.localScale = Vector3.one * 0.004f;
                cr.localPosition = new Vector3(0, 2.3f, 0); cr.localRotation = Quaternion.Euler(0, 180, 0);
                BuildPanel(cr, new Vector2(-320, -200), new Vector2(320, 200));
                return;
            }
            var canvas = imgs[0].canvas;
            var croot = (RectTransform)canvas.transform;
            var rect = croot.rect;
            TrainPlugin.V($"Screen canvas '{canvas.name}' mode={canvas.renderMode} rect={rect} layer={canvas.gameObject.layer}");
            if (rect.width < 10 || rect.height < 10) rect = new Rect(-500, -400, 1000, 800);
            foreach (var r in reels) if (r != null) foreach (var g in r.GetComponentsInChildren<Graphic>(true)) g.enabled = false;
            foreach (var im in imgs) im.enabled = false;
            var fmin = rect.min; var fmax = rect.max;
            try { TrainPlugin.Log.LogInfo("[GR] Screen " + GwyfShared.ScreenFit.Fit(transform, croot, ref fmin, ref fmax)); } catch (Exception e) { TrainPlugin.Log.LogWarning("[GR] screen fit: " + e.Message); }
            BuildPanel(croot, fmin, fmax);
            SetLayer(_ui.gameObject, canvas.gameObject.layer);
        }

        static void SetLayer(GameObject go, int layer) { go.layer = layer; foreach (Transform c in go.transform) SetLayer(c.gameObject, layer); }

        void Sfx(EventReference ev, float value, string param = "Multiplier")
        {
            try
            {
                if (ev.IsNull) return;
                SFXManager.SFXOneShotWithParameters(ev, new[] { new SFXParams(param, Mathf.Clamp(value, 0f, param == "Multiplier" ? 1000f : 100000f)) }, transform.position);
            }
            catch { }
        }
    }

}
