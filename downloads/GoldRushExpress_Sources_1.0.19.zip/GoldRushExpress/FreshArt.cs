using UnityEngine;
namespace GoldRushExpress
{
    public partial class TrainGame
    {
        static Texture2D _freshSheet, _freshDigits, _freshLogos, _freshPoses, _freshOrbs, _freshToro;
        static Sprite FreshSpriteKey(string key)
        {
            if (key.StartsWith("blur_")) key = "sym_" + key.Substring(5);
            if (key == "logo" || key == "topper")
            {
                if (_freshLogos == null) _freshLogos = LoadPng("fresh_logos");
                return GwyfShared.FreshAtlas.Logo(_freshLogos, 4);
            }
            if (_freshSheet == null) _freshSheet = LoadPng("fresh_atlas");

            int index;
            switch (key)
            {
                case "sym_J": index = 0; break;
                case "sym_Q": index = 1; break;
                case "sym_K": index = 2; break;
                case "sym_A": index = 3; break;
                case "sym_hat": index = 4; break;
                case "sym_moneybag": index = 5; break;
                case "sym_revolver": index = 6; break;
                case "sym_loco_scatter": index = 7; break;
                case "sym_loco_gold": index = 8; break;
                case "coin_gold": index = 9; break;
                case "coin_teal": index = 10; break;
                case "coin_blue": index = 10; break;
                case "sp_banker": index = 11; break;
                case "sp_marshal": index = 12; break;
                case "sp_tycoon": index = 13; break;
                case "sp_outlaw": index = 14; break;
                case "sp_spirit": index = 15; break;
                case "sp_iron_banker": index = 16; break;
                case "sp_iron_marshal": index = 17; break;
                case "sp_iron_outlaw": index = 18; break;
                case "sp_outlaw_fire": index = 19; break;
                case "sign_wagon": index = 23; break;
                case "plaque_wagon": index = 23; break;
                default: return null;
            }
            return GwyfShared.FreshAtlas.Sprite(_freshSheet, 5, 5, index);
        }
    }
}
