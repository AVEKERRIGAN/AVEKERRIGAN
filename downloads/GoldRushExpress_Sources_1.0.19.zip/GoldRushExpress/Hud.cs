using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using Mirror;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace GoldRushExpress
{
    /// on-screen HUD (raycast/E clickable), reel-style spin-in with anticipation, scatter zoom + flash,
    /// AUTO, late-join state sync, transient visual reset.
    public partial class TrainGame
    {
        Vector2 _uiSize, _uiBasePos, _gridCenter;
        Image _hudTurbo, _hudAuto, _hudSpin, _colGlow, _flash;
        TextMeshProUGUI _hudAutoText;

        /// Rects in panel space: x from left, y from BOTTOM (0..1). Shared by the drawn HUD and the world colliders.
        public struct BtnDef { public string id, sprite, tip; public float cx, cy, w, h; public BtnDef(string i, string s, string t, float x, float y, float ww, float hh) { id = i; sprite = s; tip = t; cx = x; cy = y; w = ww; h = hh; } }
        public static readonly BtnDef[] Buttons = {
            // layout measured on the approved train2 mockup: left BUY FEATURE pill, bottom bar - / + / TURBO / big SPIN / AUTO
            new BtnDef("Buy",   null,         "Buy MONEY WAGON (100x bet)", .0875f, .765f, .14f, .13f),
            new BtnDef("Minus", "btn_minus",  "Bet -",                     .526f, .051f, .042f, .061f),
            new BtnDef("Plus",  "btn_plus",   "Bet +",                     .714f, .051f, .042f, .061f),
            new BtnDef("Turbo", "btn_turbo",  "Turbo",                     .794f, .051f, .05f,  .072f),
            new BtnDef("Spin",  "btn_spin",   "Spin",                      .881f, .111f, .105f, .152f),
            new BtnDef("Auto",  "btn_auto",   "Auto spin",                 .966f, .051f, .05f,  .072f),
        };
        static BtnDef BtnRect(string id) => Buttons.First(b => b.id == id);
        void PlaceN(RectTransform rt, BtnDef b) { rt.anchorMin = rt.anchorMax = new Vector2(b.cx, b.cy); rt.pivot = new Vector2(.5f, .5f); rt.sizeDelta = new Vector2(_uiSize.x * b.w, _uiSize.y * b.h); rt.anchoredPosition = Vector2.zero; }

        void BuildHud()
        {
            _uiBasePos = _ui.anchoredPosition;
            foreach (var b in Buttons)
            {
                if (b.sprite == null) continue;
                var im = Img("Hud" + b.id, _ui, Spr(b.sprite)); im.preserveAspect = true; PlaceN(im.rectTransform, b);
                if (im.sprite == null) im.color = new Color(.8f, .3f, .7f, .8f);
                if (b.id == "Turbo") _hudTurbo = im; else if (b.id == "Auto") _hudAuto = im; else if (b.id == "Spin") _hudSpin = im;
            }
            _hudAutoText = Txt("HudAutoN", _ui, Color.white); var a = BtnRect("Auto");
            _hudAutoText.rectTransform.anchorMin = new Vector2(a.cx - .03f, .0f); _hudAutoText.rectTransform.anchorMax = new Vector2(a.cx + .03f, .016f); _hudAutoText.rectTransform.offsetMin = _hudAutoText.rectTransform.offsetMax = Vector2.zero; _hudAutoText.text = "";
            _colGlow = Img("ColGlow", _grid, Spr("glow")); _colGlow.preserveAspect = false; _colGlow.gameObject.SetActive(false); _colGlow.transform.SetAsFirstSibling();
            _flash = Img("Flash", _ui); _flash.color = new Color(1, 1, 1, 0); Stretch(_flash.rectTransform); _flash.gameObject.SetActive(false);
        }

        void HudTurbo(bool on) { if (_hudTurbo != null) _hudTurbo.sprite = Spr(on ? "btn_turbo_on" : "btn_turbo") ?? _hudTurbo.sprite; }
        void UpdateAutoVisual(int left)
        {
            GwyfShared.ToggleTint.Ui(_hudAuto, left > 0);
            if (_hudAuto != null) _hudAuto.sprite = Spr(left > 0 ? "btn_auto_on" : "btn_auto") ?? _hudAuto.sprite;
            if (_hudAutoText != null) _hudAutoText.text = left > 0 ? left.ToString() : "";
        }
        void UpdateHudSpin() { if (_hudSpin == null) return; if (_anim != null && _spinning) _hudSpin.transform.Rotate(0, 0, -540f * Time.deltaTime); else _hudSpin.transform.localRotation = Quaternion.identity; }
        bool _spinning;

        /// Clears zoom/flash/anticipation left over when an animation is interrupted by a newer RPC or a scene change.
        void ResetTransientVisuals()
        {
            _spinning = false;
            if (_ui == null) return;
            foreach (var r in _creel) r?.Show(false);
            foreach (var r in _breel) r?.Show(false);
            for (int i = 0; i < N; i++) if (_cell[i] != null && _cell[i].sprite != null) _cell[i].enabled = true;
            if (_uiSize != Vector2.zero) { _ui.localScale = Vector3.one; _ui.anchoredPosition = _uiBasePos; } GwyfShared.CamZoom.Clear(this);
            if (_flash != null) _flash.gameObject.SetActive(false);
            if (_colGlow != null) _colGlow.gameObject.SetActive(false);
            if (_hudSpin != null) _hudSpin.transform.localRotation = Quaternion.identity;
            for (int i = 0; i < N; i++) if (_cell[i] != null) { var rt = _cell[i].rectTransform; rt.localScale = Vector3.one; rt.localRotation = Quaternion.identity; rt.anchoredPosition = _home[i]; _cell[i].color = Color.white; }
        }

        /// Reel-style spin: every column scrolls random symbols, then the real ones land column by column.
        /// Once 2 scatters are visible the next columns spin longer with a glow (anticipation). Duration == GrTiming.SpinIn.
        IEnumerator SpinIn(TrainEngine.Spin result, bool turbo)
        {
            _spinning = true;
            var endAt = new float[C]; var stopped = new bool[C];
            var filler = Enumerable.Range(0, TrainEngine.NLINE).Select(SymSprite).ToArray();
            for (int column = 0; column < C; column++)
            {
                endAt[column] = GrTiming.Fall(turbo) + GrTiming.Stagger(turbo) * column + GrTiming.AntBefore(result.g, column, turbo);
                for (int row = 0; row < R; row++)
                {
                    int index = column * R + row;
                    _cellVal[index].text = ""; _cell[index].color = Color.white;
                    _creel[index].Begin(_cell[index].sprite, SymSprite(result.g[index]), null, filler, endAt[column]);
                }
            }
            float start = Time.time, end = endAt[C - 1];
            try
            {
                while (true)
                {
                    float elapsed = Time.time - start;
                    for (int column = 0; column < C; column++)
                    {
                        if (stopped[column]) continue;
                        for (int row = 0; row < R; row++) _creel[column * R + row].Draw(elapsed);
                        if (elapsed >= endAt[column])
                        {
                            stopped[column] = true;
                            for (int row = 0; row < R; row++)
                            {
                                int index = column * R + row; _creel[index].Finish(); SetCell(index, result.g[index]);
                                if (result.g[index] == TrainEngine.SCAT || result.g[index] == TrainEngine.GOLD)
                                { StartCoroutine(LandGlow(index, turbo ? .16f : .35f)); StartCoroutine(LocoClank(index, turbo ? .10f : .20f, result.g[index] == TrainEngine.GOLD)); }
                            }
                            Sfx(spinDoneSFX, 0);
                        }
                    }
                    if (_frameGlow != null)
                    {
                        float fade = Mathf.Min(Mathf.Clamp01(elapsed / .25f), Mathf.Clamp01((end - elapsed) / .2f));
                        _frameGlow.color = new Color(1f, .72f, .32f, fade * .18f);
                    }
                    if (elapsed >= end) break;
                    yield return null;
                }
            }
            finally
            {
                for (int index = 0; index < N; index++) { _creel[index].Finish(); SetCell(index, result.g[index]); }
                if (_frameGlow != null) _frameGlow.color = new Color(1, 1, 1, 0);
                if (_colGlow != null) _colGlow.gameObject.SetActive(false);
                if (_dim != null) foreach (var dim in _dim) if (dim != null) dim.color = Color.clear;
                _spinning = false;
            }
        }

        /// clean metallic clank: damped spring scale, one glint sweep, one soft steam puff (no dust / sparks / shake)
        IEnumerator LocoClank(int i, float delay, bool gold)
        {
            yield return WaitT(delay); var rt = _cell[i].rectTransform; Sfx(spinDoneSFX, 0);
            var sm = FxImg("smoke", _home[i] + new Vector2(_cs * .18f, _cs * .38f), _cs * .45f, new Color(1, 1, 1, .55f)); StartCoroutine(SoftPuff(sm, .9f));
            var gl = Img("Glint", _fx, Spr("px")); gl.raycastTarget = false; _fxObjs.Add(gl.gameObject);
            Place(gl.rectTransform, _home[i], new Vector2(_cs * .14f, _cs * 1.25f)); gl.rectTransform.localRotation = Quaternion.Euler(0, 0, -22f);
            float d = .55f, t0 = Time.time;
            while (Time.time - t0 < d)
            {
                float el = Time.time - t0, p = el / d;
                float k = Mathf.Exp(-7f * el) * Mathf.Sin(el * 26f) * .09f;               // damped spring
                rt.localScale = new Vector3(1 + k, 1 - k * .6f, 1);
                float gp = Mathf.Clamp01(el / .38f), ge = gp * gp * (3 - 2 * gp);
                if (gl != null) { gl.rectTransform.anchoredPosition = _home[i] + new Vector2(Mathf.Lerp(-.55f, .55f, ge) * _cs, 0); gl.color = gold ? new Color(1f, .93f, .6f, .55f * Mathf.Sin(gp * Mathf.PI)) : new Color(1, 1, 1, .45f * Mathf.Sin(gp * Mathf.PI)); }
                yield return null;
            }
            rt.localScale = Vector3.one; if (gl != null) Destroy(gl.gameObject);
        }

        IEnumerator SoftPuff(GameObject g, float dur)
        {
            float t0 = Time.time; var rt = g != null ? (RectTransform)g.transform : null; var im = g != null ? g.GetComponent<Image>() : null; Vector2 p0 = rt != null ? rt.anchoredPosition : Vector2.zero; float a0 = im != null ? im.color.a : 0;
            while (Time.time - t0 < dur) { if (rt == null) yield break; float p = (Time.time - t0) / dur, e = 1 - (1 - p) * (1 - p) * (1 - p); rt.anchoredPosition = p0 + new Vector2(_cs * .12f * e, _cs * .45f * e); rt.localScale = Vector3.one * (.6f + .9f * e); im.color = new Color(1, 1, 1, a0 * Mathf.Sin(Mathf.Min(1f, p * 1.6f + .0001f) * Mathf.PI * .5f) * (1 - p)); yield return null; }
            if (g != null) Destroy(g);
        }

        /// scatter landing: short glow pulse (purely visual, runs in parallel, does not change timing)
        IEnumerator LandGlow(int cell, float dur)
        {
            dur = Mathf.Max(.15f, dur); float t0 = Time.time;
            while (Time.time - t0 < dur)
            {
                float p = (Time.time - t0) / dur; var gl = _cellGlow[cell];
                if (gl != null) { gl.gameObject.SetActive(true); gl.color = new Color(1f, .8f, .4f, .85f * (1 - p)); }
                yield return null;
            }
            if (_cellGlow[cell] != null) _cellGlow[cell].gameObject.SetActive(false);
        }

        /// Bonus trigger (v1.0.5): subtle camera dolly toward the locos while each loco flips (3D card turn) to its gold coin / special face.
        /// Total == GrTiming.Zoom. No flash, no shockwave, no particles.
        IEnumerator ZoomScatter(List<int> scs, bool t, GrMsg m)
        {
            Vector2 c = Vector2.zero; foreach (var i in scs) c += _gridCenter + _home[i]; c /= scs.Count; c = Vector2.Lerp(_gridCenter, c, .6f);
            float T = GrTiming.Zoom(t), tIn = T * .55f, tOut = T * .22f; const float Z = 1.07f;
            _winLabel.text = "";
            var faces = new Sprite[scs.Count]; var vals = new TMPro.TextMeshProUGUI[scs.Count];
            for (int k = 0; k < scs.Count; k++)
            {
                int i = scs[k], ty = m?.lt != null && i < m.lt.Length ? m.lt[i] : TrainEngine.COIN; float v = m?.lv != null && i < m.lv.Length ? m.lv[i] : 0;
                faces[k] = BonusSprite(ty, v);
                if (ty <= TrainEngine.GCOIN && v > 0) { var tx = Txt("FlipVal", _fx, Color.white); _fxObjs.Add(tx.gameObject); Place(tx.rectTransform, _home[i] + new Vector2(0, -_cs * .02f), new Vector2(_cs * .9f, _cs * .32f)); tx.text = FX(v); tx.color = new Color(1, 1, 1, 0); vals[k] = tx; }
            }
            float flipD = Mathf.Min(.42f, T * .26f), stag = Mathf.Min(.14f, (T * .55f - flipD) / Mathf.Max(1, scs.Count - 1));
            var flipped = new bool[scs.Count]; float t0 = Time.time;
            while (true)
            {
                float el = Time.time - t0; if (el >= T) break;
                float s;
                if (el < tIn) { float q = el / tIn; s = Mathf.Lerp(1f, Z, q * q * q * (q * (q * 6 - 15) + 10)); }
                else if (el < T - tOut) s = Z + .004f * Mathf.Sin((el - tIn) * 3f);
                else { float q = (el - (T - tOut)) / tOut; s = Mathf.Lerp(Z, 1f, q * q * (3 - 2 * q)); }
                _ui.localScale = Vector3.one; _ui.anchoredPosition = _uiBasePos; GwyfShared.CamZoom.Set(this, _ui.TransformPoint(c), s); // camera dolly; screen stays put
                for (int k = 0; k < scs.Count; k++)
                {
                    int i = scs[k]; float fe = el - T * .12f - k * stag, q = Mathf.Clamp01(fe / flipD), sx;
                    if (q < .5f) { float a = q * 2; sx = Mathf.Cos(a * a * Mathf.PI * .5f); }
                    else
                    {
                        if (!flipped[k]) { flipped[k] = true; _cell[i].sprite = faces[k]; Sfx(multiplierSFX, 5f + k * 5f); }
                        float a = (q - .5f) * 2; sx = GwyfShared.ReelFx.EaseOutBack(a, 1.4f);
                    }
                    float settle = fe > flipD ? Mathf.Exp(-6f * (fe - flipD)) * Mathf.Sin((fe - flipD) * 20f) * .05f : 0;
                    _cell[i].rectTransform.localScale = new Vector3(Mathf.Max(.02f, sx) * (1 + settle), 1 + settle * .5f, 1);
                    if (vals[k] != null) { var vc = vals[k].color; vc.a = Mathf.Clamp01((q - .5f) * 2f); vals[k].color = vc; vals[k].rectTransform.localScale = new Vector3(Mathf.Max(.02f, sx), 1, 1); }
                    if (_cellGlow[i] != null) _cellGlow[i].color = new Color(1f, .8f, .4f, .25f + .5f * Mathf.Sin(Mathf.Clamp01(fe / (flipD * 2f)) * Mathf.PI));
                }
                yield return null;
            }
            _ui.localScale = Vector3.one; _ui.anchoredPosition = _uiBasePos; GwyfShared.CamZoom.Clear(this);
            foreach (var i in scs) _cell[i].rectTransform.localScale = Vector3.one;
        }

        // ---------------- server: screen buttons, AUTO, late-join sync ----------------
        int _autoLeft; PlayerInteract _autoPi; bool _autoRound;

        void HookScreenButtons()
        {
            foreach (var trig in GetComponentsInChildren<InteractableEventTrigger>(true))
            {
                if (!trig.name.StartsWith("GRScr_")) continue;
                switch (trig.name.Substring(6))
                {
                    case "Spin": Hook(trig, TryStartGame); break;
                    case "Buy": Hook(trig, TryBuyBonus); break;
                    case "Turbo": Hook(trig, ToggleTurbo); break;
                    case "Plus": Hook(trig, p => StepBet(+1)); break;
                    case "Minus": Hook(trig, p => StepBet(-1)); break;
                    case "Auto": Hook(trig, ToggleAuto); break;
                }
            }
        }

        [Server]
        public void ToggleAuto(PlayerInteract pi)
        {
            if (!NetworkServer.active) return;
            if (_autoLeft > 0) { _autoLeft = 0; _autoPi = null; Broadcast(new GrMsg { t = "auto", fsi = 0, tb = turbo ? 1 : 0 }); TrainPlugin.V("Auto OFF"); return; }
            if (pi == null) return;
            _autoLeft = Mathf.Clamp(TrainPlugin.AutoSpins?.Value ?? 10, 1, 100); _autoPi = pi;
            Broadcast(new GrMsg { t = "auto", fsi = _autoLeft, tb = turbo ? 1 : 0 });
            TrainPlugin.V($"Auto ON: {_autoLeft} spins");
            if (!isPlaying) StartCoroutine(AutoNext(0.05f));
        }

        void ContinueAuto(bool bonusHit, bool byAuto)
        {
            if (_autoLeft <= 0) return;
            if (byAuto) { _autoLeft--; if (bonusHit && (TrainPlugin.AutoStopOnBonus?.Value ?? true)) _autoLeft = 0; }
            if (_autoPi == null) _autoLeft = 0;
            Broadcast(new GrMsg { t = "auto", fsi = _autoLeft, tb = turbo ? 1 : 0 });
            if (_autoLeft > 0) StartCoroutine(AutoNext(turbo ? .3f : .8f));
        }

        IEnumerator AutoNext(float delay)
        {
            yield return new WaitForSeconds(delay);
            if (_autoLeft <= 0 || _autoPi == null || isPlaying) yield break;
            _autoRound = true;
            try { TryStartGame(_autoPi); } catch (Exception e) { TrainPlugin.Log.LogError(e); }
            if (!isPlaying) { _autoRound = false; _autoLeft = 0; Broadcast(new GrMsg { t = "auto", fsi = 0, tb = turbo ? 1 : 0 }); TrainPlugin.V("Auto stopped (spin refused: money/bet)"); }
        }

        int _lastConnCount = -1; float _nextSync;
        void ServerStateSync()
        {
            if (!NetworkServer.active || Time.unscaledTime < _nextSync) return;
            _nextSync = Time.unscaledTime + 2f;
            int n = NetworkServer.connections.Count; if (n == _lastConnCount) return;
            _lastConnCount = n;
            string bet = null; double bn = 0; try { if (!currentBet.IsZero) { bet = FormatBet(currentBet); bn = currentBet.ToDouble(); } } catch { }
            Broadcast(new GrMsg { t = "bet", bet = bet, bn = bn, tb = turbo ? 1 : 0 });
            Broadcast(new GrMsg { t = "auto", fsi = _autoLeft, tb = turbo ? 1 : 0 });
        }

        // ---------------- prefab: invisible raycast colliders over the screen ----------------
        public static void CreateScreenButtons(TrainGame game, GameObject clone)
        {
            var play = game.playButtons.FirstOrDefault(); if (play == null) { TrainPlugin.Log.LogWarning("[GR] Screen buttons: no play button template"); return; }
            RenderTexture rtex = GwyfShared.ScreenIso.FindRT(clone);
            Renderer scr = null;
            foreach (var r in clone.GetComponentsInChildren<Renderer>(true))
            {
                if (rtex == null || scr != null) break;
                foreach (var m in r.sharedMaterials) if (m != null) foreach (var p in m.GetTexturePropertyNames()) if (m.GetTexture(p) == rtex) scr = r;
            }
            var mf = scr != null ? scr.GetComponent<MeshFilter>() : null;
            if (scr == null || mf == null || mf.sharedMesh == null) TrainPlugin.Log.LogWarning($"[GR] Screen buttons: screen mesh not found (rt={(rtex != null)}, renderer={(scr != null)}) - use the cabinet buttons");
            Bounds b = mf != null && mf.sharedMesh != null ? mf.sharedMesh.bounds : new Bounds(Vector3.zero, Vector3.one);
            Vector3 ext = b.size; int nAx = ext.x <= ext.y && ext.x <= ext.z ? 0 : ext.y <= ext.z ? 1 : 2;
            int[] rest = new[] { 0, 1, 2 }.Where(a => a != nAx).ToArray();
            int uAx = ext[rest[0]] >= ext[rest[1]] ? rest[0] : rest[1], vAx = uAx == rest[0] ? rest[1] : rest[0];
            float uSign = 1f, vSign = 1f;
            try
            {
                var mesh = mf != null ? mf.sharedMesh : null;
                if (mesh != null && mesh.isReadable)
                {
                    var vs = mesh.vertices; var uv = mesh.uv;
                    if (uv != null && uv.Length == vs.Length && vs.Length >= 3)
                    {
                        int iu0 = 0, iu1 = 0, iv0 = 0, iv1 = 0;
                        for (int i = 1; i < uv.Length; i++) { if (uv[i].x < uv[iu0].x) iu0 = i; if (uv[i].x > uv[iu1].x) iu1 = i; if (uv[i].y < uv[iv0].y) iv0 = i; if (uv[i].y > uv[iv1].y) iv1 = i; }
                        Vector3 du = vs[iu1] - vs[iu0];
                        uAx = Mathf.Abs(du[rest[0]]) >= Mathf.Abs(du[rest[1]]) ? rest[0] : rest[1]; vAx = uAx == rest[0] ? rest[1] : rest[0];
                        uSign = Mathf.Sign(du[uAx]); vSign = Mathf.Sign((vs[iv1] - vs[iv0])[vAx]);
                        if (uSign == 0) uSign = 1; if (vSign == 0) vSign = 1;
                        TrainPlugin.V($"Screen UV orientation from mesh: u=axis{uAx}{(uSign > 0 ? "+" : "-")} v=axis{vAx}{(vSign > 0 ? "+" : "-")}");
                    }
                }
            }
            catch (Exception e) { TrainPlugin.V("Screen UV read failed: " + e.Message); }
            if (TrainPlugin.ScreenFlipX != null && TrainPlugin.ScreenFlipX.Value) uSign = -uSign;
            if (TrainPlugin.ScreenFlipY != null && TrainPlugin.ScreenFlipY.Value) vSign = -vSign;
            float margin = TrainPlugin.ScreenMargin != null ? Mathf.Clamp(TrainPlugin.ScreenMargin.Value, 0f, .2f) : .03f;
            Transform parent = scr != null ? scr.transform : game.transform;
            float nScale = Mathf.Max(1e-4f, Mathf.Abs(parent.lossyScale[nAx]));
            int made = 0;
            foreach (var d in Buttons)
            {
                var go = UnityEngine.Object.Instantiate(play.gameObject, parent); go.name = "GRScr_" + d.id;
                for (int i = go.transform.childCount - 1; i >= 0; i--) UnityEngine.Object.DestroyImmediate(go.transform.GetChild(i).gameObject);
                foreach (var c in go.GetComponents<Collider>()) UnityEngine.Object.DestroyImmediate(c);
                foreach (var c in go.GetComponents<Renderer>()) UnityEngine.Object.DestroyImmediate(c);
                foreach (var c in go.GetComponents<MeshFilter>()) UnityEngine.Object.DestroyImmediate(c);
                go.transform.localRotation = Quaternion.identity; go.transform.localScale = Vector3.one;
                float u = .5f + (d.cx - .5f) * (1f - 2f * margin), v = .5f + (d.cy - .5f) * (1f - 2f * margin);
                Vector3 pos = b.center, size = Vector3.zero;
                pos[uAx] += uSign * (u - .5f) * ext[uAx]; pos[vAx] += vSign * (v - .5f) * ext[vAx];
                size[uAx] = d.w * (1f - 2f * margin) * ext[uAx]; size[vAx] = d.h * (1f - 2f * margin) * ext[vAx]; size[nAx] = .05f / nScale;
                go.transform.localPosition = pos;
                var bc = go.AddComponent<BoxCollider>(); bc.size = size;
                var trig = go.GetComponent<InteractableEventTrigger>();
                if (trig != null)
                {
                    foreach (var ev in new UnityEngine.Events.UnityEventBase[] { trig.onInteractEvent, trig.serverOnInteractEvent, trig.rpcOnInteractEvent, trig.onHoverEvent, trig.onHoverExitEvent, trig.onHoldEvent, trig.onHoldExitEvent })
                        if (ev != null) for (int i = 0; i < ev.GetPersistentEventCount(); i++) ev.SetPersistentListenerState(i, UnityEngine.Events.UnityEventCallState.Off);
                    try { AccessTools.Field(typeof(InteractableBase), "tooltipMessage").SetValue(trig, "[E] " + d.tip); } catch { }
                    try { AccessTools.Field(typeof(InteractableBase), "interactableName").SetValue(trig, "Gold Rush Express: " + d.tip); } catch { }
                }
                made++;
            }
            TrainPlugin.V($"Screen buttons: {made} colliders on '{(scr != null ? scr.name : "machine root")}' (normal axis {nAx}, mesh size {ext})");
        }
    }
}
