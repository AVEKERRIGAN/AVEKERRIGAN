using System;
namespace GoldRushExpress
{
    [Serializable]
    public class GrMsg
    {
        public string t;           // spin | intro | bstep | end | turbo | bet | auto
        public TrainEngine.Spin s; // base spin incl. 2-loco respin feature
        public TrainEngine.BStep b;// MONEY WAGON step
        public int[] lt; public float[] lv; // spin: trigger reveal preview (types/values of the locos' coins, from bonus step 0)
        public int bi;             // bonus step index (0 = trigger reveal + pre-spin actions) / auto: spins left (fsi)
        public int fsi;            // auto: spins left
        public int buyVariant;     // selected bonus name for purchase confirmation
        public float w;            // shown win of this message (x bet, trimmed by the cap)
        public float tot;          // running round total (x bet)
        public float bw;           // base part of the round (lines + respin feature), for the bonus total sign
        public int tb, by, cap;    // turbo, bought, cap reached
        public string bet; public double bn;
    }

}
