from pathlib import Path
import zipfile,hashlib,json,shutil
root=Path('/workspace/mod-work');out=Path('/workspace/outputs');repo=Path('/workspace/AVEKERRIGAN')
checks=(root/'train-1.0.19-checks.log').read_text()
assert 'PASS: 620989 assertions;' in checks and 'Unity rendering and live co-op not executed.' in checks
build=(root/'train-1.0.19-build.log').read_text();assert 'Build succeeded.' in build and '0 Error(s)' in build
assert (root/'GoldRushExpress/TrainEngine.cs').read_bytes()==Path('/workspace/mod-work-backups/v3-before-followups/GoldRushExpress/TrainEngine.cs').read_bytes()
plugin=root/'GoldRushExpress/bin/Release/netstandard2.1/GoldRushExpress.dll';assert plugin.read_bytes()[:2]==b'MZ'
with zipfile.ZipFile(repo/'downloads/GoldRushExpress_1.0.18.zip') as previous:
 assert hashlib.sha256(previous.read('BepInEx/plugins/GoldRushExpress/GoldRushExpress.dll')).digest()!=hashlib.sha256(plugin.read_bytes()).digest()
manifest={'BepInEx/plugins/GoldRushExpress/GoldRushExpress.dll':{'version':'1.0.19','networkLayout':'gr-net-1.2','sha256':hashlib.sha256(plugin.read_bytes()).hexdigest()}}
names=['GoldRushExpress_1.0.19.zip','GoldRushExpress_Sources_1.0.19.zip']
with zipfile.ZipFile(out/names[0],'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 z.write(plugin,next(iter(manifest)))
 z.write(root/'GoldRushExpress/README_RU.md','README_RU.md')
 z.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2))
with zipfile.ZipFile(out/names[1],'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for folder in ['GoldRushExpress','TrainChecks']:
  for file in sorted((root/folder).rglob('*')):
   if file.is_file() and not {'bin','obj'}&set(file.relative_to(root/folder).parts) and file.suffix in {'.cs','.csproj','.md','.png'}:
    z.write(file,str(file.relative_to(root)))
 for file in ['global.json','train-1.0.19-build.log','train-1.0.19-checks.log','package_train_1_0_19.py']:
  z.write(root/file,file)
 z.write(out/'train-1.0.19-presentation.json','validation/presentation.json')
for name in names:
 p=out/name
 with zipfile.ZipFile(p) as z:
  assert z.testzip() is None
  assert not any('..' in Path(n).parts or n.startswith('/') for n in z.namelist())
 shutil.copy2(p,repo/'downloads'/name)
 print(name,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
shutil.copy2(root/'GoldRushExpress/README_RU.md',repo/'README_MoneyTrain_RU.md')
p=repo/'README.md';s=p.read_text();header='''## Money Train / Gold Rush Express 1.0.19 — плавные барабаны и читаемый TOTAL

- [Установка / обновление — ZIP](downloads/GoldRushExpress_1.0.19.zip)
- [Изменения, управление и кооп](README_MoneyTrain_RU.md)
- [Исходники, графика и результаты проверок](downloads/GoldRushExpress_Sources_1.0.19.zip)

Символы плавно въезжают в ячейки и останавливаются в центре; цифры двигаются
вместе с ними. Справа раздельные строки TOTAL / общий икс / деньги, итог обновляется
после приземления и действий персонажей. Эффекты ограничены экраном.
Время хоста учитывает окончания анимаций на низком FPS.

У всех участников должна стоять 1.0.19; после замены DLL создайте новое лобби.
Если устанавливаете общий архив автоматов v3, распакуйте **это обновление после него**.
620 989 офлайн-проверок, 6 000 раундов, 45 247 бонусных шагов; DLL собрана без ошибок.
Unity-отрисовка в Windows и живой кооп здесь не запускались.

'''
a=s.index('## Бумбокс');s=s[:a]+header+s[a:]
s=s.replace('- [GoldRushExpress 1.0.18](downloads/GoldRushExpress_1.0.18.zip)','- [GoldRushExpress 1.0.19](downloads/GoldRushExpress_1.0.19.zip)');p.write_text(s)
p=repo/'SHA256SUMS.txt';lines=p.read_text().splitlines()
lines=[line for line in lines if not any(line.endswith('downloads/'+name) for name in names)]
for name in names:lines.append(hashlib.sha256((out/name).read_bytes()).hexdigest()+'  downloads/'+name)
p.write_text('\n'.join(lines)+'\n')
