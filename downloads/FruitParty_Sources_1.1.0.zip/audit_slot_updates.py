from pathlib import Path
import sys,struct,json,hashlib,re
from PIL import Image
sys.path.insert(0,'/workspace/setup-tools');import dnfile
r=Path('/workspace/mod-work');out=Path('/workspace/outputs');checks=0;report={}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for folder in ['SlotShowtime','Hoarder','FruitParty','GoldRushExpress']:
 p=r/folder/f'bin/Release/netstandard2.1/{folder}.dll';pe=dnfile.dnPE(str(p));rs={str(x.Name):x for x in pe.net.mdtables.ManifestResource.rows};base=pe.net.struct.ResourcesRva
 files=list((r/folder/'art').glob('*.png'))
 for f in files:
  name=folder+'.art.'+f.name
  if folder=='GoldRushExpress':name=folder+'.'+f.stem+'.png' if name not in rs else name
  if name not in rs:
   possible=[k for k in rs if k.endswith('.'+f.name)];assert len(possible)==1,(folder,name,list(rs)[:4]);name=possible[0]
  row=rs[name];n=struct.unpack('<I',pe.get_data(base+row.Offset,4))[0];assert pe.get_data(base+row.Offset+4,n)==f.read_bytes();Image.open(f).verify();checks+=1
 report[folder]={'binary_sha256':sha(p),'resource_pngs':len(files),'source_sha256':{p.name:sha(p) for p in (r/folder).glob('*.cs')}}
# Validate the actual APIs the Harmony addon patches, from all eight compiled mods.
plugins=['PuppyPalacePlugin','SugarGalaxyPlugin','TrainPlugin','ThunderPlugin','FishPlugin','ToroLeapPlugin','HoarderPlugin','FruitPartyPlugin']
for folder,plugin in zip(['PuppyPalace','SugarGalaxy','GoldRushExpress','ThunderOlympus','ReelKingLake','ToroLeap','Hoarder','FruitParty'],plugins):
 pe=dnfile.dnPE(str(r/folder/f'bin/Release/netstandard2.1/{folder}.dll'));types={str(x.TypeName):x for x in pe.net.mdtables.TypeDef.rows};assert plugin in types
 game=next(t for n,t in types.items() if n.endswith('Game'));methods={str(i.row.Name):i.row for i in game.MethodList};assert {'UserRpcShowSpin','Start','AutoNext'}<=methods.keys(),folder
 assert methods['UserRpcShowSpin'].Signature.value==bytes([0x20,1,1,0x0e]),folder
 assert 'EnsurePrefab' in [str(i.row.Name) for i in types[plugin].MethodList],folder
 assert 'CabinetScale' in [str(i.row.Name) for i in types[plugin].FieldList],folder;checks+=5
# Match all wagon tile centres to the original illustrated grid at arbitrary glass aspect ratios.
train=(r/'GoldRushExpress/Screen.cs').read_text()
assert 'typeof(RectMask2D)' in train and 'BonusTile' in train and 'rt.anchoredPosition = Vector2.zero' in train
for aspect in [4/3,1.6,16/9,2]:
 W=1280.;H=W/aspect;cw=W*.65625/7;ch=H*.5455/4;size=min(cw,ch)
 for c in range(7):
  for row in range(4):
   x=W*(.5-.65625/2)+(c+.5)*cw;y=H*(1-.541-.5455/2)+(row+.5)*ch
   px=x/W*1280;py=y/H*880
   assert abs(px-(280+c*120))<.01 and abs(py-(224+row*120))<.1
   assert size*.78*1.25<=cw and size*.78*1.25<=ch;checks+=2
# Celebration payload regions fit inside all supported glass proportions.
for aspect in [4/3,1.6,16/9,2]:
 for x,y,w,h in [(.07,.108,.56,.086),(.07,0,.54,.115),(.07,-.10,.56,.058)]:
  assert abs(x)+w/2<=.46 and abs(y)+h/2<=.325;checks+=1
policy=(r/'SlotShowtime/Plugin.cs').read_text();assert 'WaitAuto' in policy and 'DelayAuto' in policy and 'GameBase),"TryStartGame"' in policy
assert 'GwyfShared.CamZoom.Set' in (r/'SlotShowtime/WinView.cs').read_text();checks+=2
summary={'pass':True,'checks':checks,'mods':report,'eight_actual_game_patch_APIs_verified':True,'train_grid_aspects':[4/3,1.6,16/9,2],'live_unity_or_coop_verified':False}
(out/'SlotUpdates_Assembly_Checks.json').write_text(json.dumps(summary,indent=2));print('PASS:',checks,'embedded resource, actual API and layout checks')
