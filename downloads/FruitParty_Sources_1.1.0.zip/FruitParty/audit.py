from pathlib import Path
import re,json,hashlib,struct,sys
sys.path.insert(0,'/workspace/setup-tools')
import dnfile
from PIL import Image
root=Path(__file__).parent;binary=root/'bin/Release/netstandard2.1/FruitParty.dll';pe=dnfile.dnPE(str(binary));rva=pe.net.struct.ResourcesRva
resources={str(r.Name):r for r in pe.net.mdtables.ManifestResource.rows};checks=0
for p in (root/'art').glob('*.png'):
 row=resources['FruitParty.art.'+p.name];offset=rva+row.Offset;n=struct.unpack('<I',pe.get_data(offset,4))[0];assert pe.get_data(offset+4,n)==p.read_bytes()
 with Image.open(p) as im:im.verify()
 checks+=1
for key in ['strawberry','orange','apple','grapes','plum','star','heart','scatter']:
 with Image.open(root/'art'/f'{key}.png') as im:assert im.mode=='RGBA' and im.size==(512,512) and im.getextrema()[3][0]==0;checks+=1
screen=(root/'Screen.cs').read_text();buttonDefs=[]
for m in re.finditer(r'new BtnDef\("([^"]+)","([^"]+)",([^\)]+)\)',screen):
 x,y,w,h=[float(v.strip().rstrip('f')) for v in m[3].split(',')];assert 0<=x-w/2<x+w/2<=1 and 0<=y-h/2<y+h/2<=1
 buttonDefs.append({'id':m[1],'x':x,'y':y,'w':w,'h':h});checks+=1
assert len(buttonDefs)==12
# All UI text boxes and common-aspect reel envelopes remain inside the glass.
for m in re.finditer(r'Label\("[^"]+","[^"]*",(\.\d+f),(\.\d+f),(\.\d+f),(\.\d+f)',screen):
 x,y,w,h=[float(m[i][:-1]) for i in range(1,5)];assert 0<=x-w/2<x+w/2<=1 and 0<=y-h/2<y+h/2<=1;checks+=1
for aspect in [4/3,1.6,16/9,2]:
 step=min(aspect*.64/7,.7/7);xmin=.49-3.5*step/aspect;xmax=.49+3.5*step/aspect;ymin=.525-3.5*step;ymax=.525+3.5*step
 assert xmin>=.17-1e-7 and xmax<=.81+1e-7 and ymin>.16 and ymax<.934-.115/2
 for col in range(7):
  for row in range(7):
   x=.49+(col-3)*step/aspect;y=.525+(3-row)*step
   assert xmin<=x-step*.45/aspect<x+step*.45/aspect<=xmax and ymin<=y-step*.45<y+step*.45<=ymax;checks+=1
 assert .76-.028/2>.71+.055/2 and .71-.055/2>.657+.032/2;checks+=1
assert 'Layer(go,root.gameObject.layer)' in screen and screen.count('typeof(RectMask2D)')>=3
assert 'val.enableAutoSizing=false;val.fontSize=step*.30f' in screen and 'im.preserveAspect=true' in screen
assert 'GwyfShared.ScreenFit.Fit' in screen and 'GwyfShared.ScreenFit.Fit' in (root/'ScreenButtons.cs').read_text()
assert 'KeyCode.F9' in (root/'Plugin.cs').read_text() and 'new WaitForSecondsRealtime(duration)' in (root/'Game.cs').read_text();checks+=5
# New RPC does not collide with the previous custom slots or managed game strings.
def stable(s):
 h=23
 for c in s:h=(h*31+ord(c))&0xffffffff
 return h&65535
sig='System.Void FruitParty.FruitPartyGame::UserRpcShowSpin(System.String)';rpc=stable(sig);others=set()
for p in root.parent.glob('*/Game.cs'):
 others.update(re.findall(r'"(System.Void [^"\n]+)"',p.read_text()))
blob=Path('/workspace/library-files/gamble-with-your-friends/managed/Assembly-CSharp.dll').read_bytes().decode('utf-16le',errors='ignore')
others.update(re.findall(r'System\.Void [\w.]+::\w+\([^\x00]{0,500}\)',blob));others.discard(sig)
assert all(stable(s)!=rpc for s in others);checks+=len(others)
report={'pass':True,'checks':checks,'embedded_pngs':len(resources),'screen_controls':len(buttonDefs),'rpc_hash':rpc,'rpc_signatures_checked':len(others),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in root.glob('*.cs')},'no_live_unity_or_coop':True,'tested_aspects':[4/3,1.6,16/9,2],'multiplier_font_fixed':True,'all_art_embedded':True}
Path('/workspace/outputs/FruitParty_Assembly_Checks_1.1.0.json').write_text(json.dumps(report,indent=2));print('PASS',checks,'assembly/resource/layout checks; RPC',rpc)
