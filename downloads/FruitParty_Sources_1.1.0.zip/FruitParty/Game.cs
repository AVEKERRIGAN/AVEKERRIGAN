using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using FMODUnity;
using Mirror;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
namespace FruitParty
{
    public partial class FruitPartyGame:GameBase
    {
        const string RpcSig="System.Void FruitParty.FruitPartyGame::UserRpcShowSpin(System.String)";
        public bool turbo;public int speedMode;public InteractableEventTrigger turboButton,buyButton,betMinusButton,betPlusButton;
        public TextMeshPro payoutText;public List<Image> symbolLocations=new List<Image>();public List<SlotReel> reels=new List<SlotReel>();
        public EventReference spinReelSFX,spinDoneSFX,multiplierSFX,finaltextSFX;
        public List<InteractableEventTrigger> playButtons=new List<InteractableEventTrigger>();
        public static bool ForceBonusNext;static bool registered;
        int sequence,generation,spinCount,buySelection=-1,autoLeft;float deadline,menuTime,nextSnapshot;bool roundActive,autoScheduled;
        BigNumber charged=BigNumber.Zero;PlayerInteract autoPlayer,menuPlayer;FruitPartyMsg lastPhase;
        public static void RegisterRpcs()
        {
            if(registered)return;registered=true;
            GwyfShared.RpcGuard.Register(typeof(FruitPartyGame),RpcSig,(o,r,c)=>{if(NetworkClient.active)((FruitPartyGame)o).UserRpcShowSpin(r.ReadString());});
        }
        public override bool Weaved()=>true;
        public void SetDefaults(){gameName="Fruit Party";}
        public void CopyFromSlots(Slots s)
        {
            T Get<T>(string n)=>(T)HarmonyLib.AccessTools.Field(typeof(Slots),n).GetValue(s);
            payoutText=Get<TextMeshPro>("payoutText");symbolLocations=Get<List<Image>>("symbolLocations");reels=Get<List<SlotReel>>("reels");
            spinReelSFX=Get<EventReference>("spinReelSFX");spinDoneSFX=Get<EventReference>("spinDoneSFX");multiplierSFX=Get<EventReference>("multiplierSFX");finaltextSFX=Get<EventReference>("finaltextSFX");SetDefaults();
        }
        protected override void OnAwake(){base.OnAwake();if(FruitPartyPlugin.CabinetScale!=null)GwyfShared.CabinetScaler.Apply(transform,FruitPartyPlugin.CabinetScale.Value,null,"FP");}
        static void Hook(InteractableEventTrigger b,UnityEngine.Events.UnityAction<PlayerInteract> a)
        {if(b==null)return;if(b.serverOnInteractEvent==null)b.serverOnInteractEvent=new UnityEngine.Events.UnityEvent<PlayerInteract>();b.serverOnInteractEvent.AddListener(a);}
        public override void OnStartServer()
        {
            base.OnStartServer();foreach(var b in playButtons)Hook(b,TryStartGame);Hook(buyButton,TryBuyBonus);Hook(turboButton,ToggleTurbo);
            Hook(betMinusButton,p=>StepBet(-1));Hook(betPlusButton,p=>StepBet(1));
            foreach(var t in GetComponentsInChildren<InteractableEventTrigger>(true))
            {
                if(!t.name.StartsWith("FPScr_"))continue;string id=t.name.Substring(6);
                switch(id)
                {
                    case "Spin":Hook(t,TryStartGame);break;case "Buy":Hook(t,TryBuyBonus);break;case "Turbo":Hook(t,ToggleTurbo);break;
                    case "Plus":Hook(t,p=>StepBet(1));break;case "Minus":Hook(t,p=>StepBet(-1));break;case "Auto":Hook(t,ToggleAuto);break;
                    case "Info":Hook(t,p=>{if(!isPlaying)SetMenu(p,buySelection<=-2&&buySelection>=-4?(buySelection==-4?-5:buySelection-1):-5);});break;
                    case "Rules":Hook(t,p=>{if(!isPlaying)SetMenu(p,-2);});break;
                    case "MenuSpeed":Hook(t,ToggleTurbo);break;
                    case "MenuAuto":Hook(t,p=>{SetMenu(p,-1);ToggleAuto(p);});break;
                    case "Close":Hook(t,p=>{if(menuPlayer==null||p==menuPlayer)SetMenu(p,-1);});break;
                    default:if(id.StartsWith("Buy")&&int.TryParse(id.Substring(3),out int v)){int copy=v;Hook(t,p=>BuyVariant(p,copy));}break;
                }
            }
        }
        protected override void OnBetSet(){base.OnBetSet();if(NetworkServer.active){if(buySelection>=0)SetMenu(menuPlayer,-1);Control();}}
        public override void TryStartGame(PlayerInteract p)
        {
            if(!NetworkServer.active||p==null||isPlaying||!CanGameStart())return;
            if(buySelection>=0){if(p==menuPlayer)BuyVariant(p,buySelection);return;}
            if(!p.TryGetComponent<PlayerProfile>(out var profile))return;interactingPlayer=profile;
            if(!isGoldenChipApplied)
            {
                if(currentBet<MinBet||currentBet>MaxBet||!Extensions.NetworkSingleton<MoneyManager>.Instance.TryChangeBalance(-currentBet,profile,ChangeType.Bet)){Invalid();return;}
                charged=currentBet;
            }
            else{isGoldenBet=true;charged=BigNumber.Zero;}
            SetMenu(p,-1);isPlaying=true;canBet=false;StartGame();
        }
        protected override void StartGame(){if(NetworkServer.active)StartCoroutine(RoundRoutine(-1));}
        public void TryBuyBonus(PlayerInteract p)
        {
            if(!NetworkServer.active||p==null||isPlaying||autoLeft>0||!CanGameStart())return;
            if(buySelection>=0&&menuPlayer!=p&&Time.time-menuTime<20f)return;
            int next=buySelection>=0?buySelection+1:0;SetMenu(p,next>=FruitPartyEngine.Variants?-1:next);
        }
        void SetMenu(PlayerInteract p,int selection)
        {buySelection=selection;menuPlayer=selection!=-1?p:null;menuTime=Time.time;Control();}
        public void BuyVariant(PlayerInteract p,int variant)
        {
            if(!NetworkServer.active||p==null||isPlaying||!CanGameStart()||variant<0||variant>=FruitPartyEngine.Variants)return;
            if(buySelection<0||p!=menuPlayer)return;
            if(!p.TryGetComponent<PlayerProfile>(out var profile))return;
            BigNumber cost=currentBet*FruitPartyEngine.BuyCost[variant];
            if(isGoldenChipApplied||currentBet<MinBet||currentBet>MaxBet||!Extensions.NetworkSingleton<MoneyManager>.Instance.TryChangeBalance(-cost,profile,ChangeType.Bet)){Invalid();return;}
            interactingPlayer=profile;charged=cost;SetMenu(p,-1);isPlaying=true;canBet=false;StartCoroutine(RoundRoutine(variant));
        }
        void Invalid(){try{keypad.ServerInvalidBetAmountFb();}catch{}}
        IEnumerator RoundRoutine(int variant)
        {
            int gen=++generation;roundActive=true;deadline=Time.unscaledTime+30;spinCount++;
            bool force=variant<0&&(ForceBonusNext||FruitPartyPlugin.AlwaysBonusNextSpin.Value||(FruitPartyPlugin.ForceBonusEveryNSpins.Value>0&&spinCount%FruitPartyPlugin.ForceBonusEveryNSpins.Value==0));ForceBonusNext=false;
            FruitPartyEngine.Round round=null;
            try{round=variant>=0?FruitPartyEngine.PlayBuyVariant(GetSeededRandom(9191),variant):FruitPartyEngine.Play(GetSeededRandom(9090),force);}
            catch(Exception e){FruitPartyPlugin.Log.LogError("[FP] Engine: "+e);}
            if(round==null){Refund("engine");Unlock();yield break;}
            for(int k=0;k<round.spins.Count;k++)
            {
                var s=round.spins[k];int mode=speedMode;
                if(k==1)
                {
                    var entry=new FruitPartyMsg{t="intro",s=round.spins[0],speed=mode,buyVariant=variant,round=gen,total=round.spins[0].total,duration=FruitPartyTiming.Intro(mode)};
                    Phase(entry);if(gen!=generation)yield break;yield return Wait(entry.duration+.15f);if(gen!=generation)yield break;
                }
                mode=speedMode;
                var m=new FruitPartyMsg{t="spin",s=s,speed=mode,round=gen,bi=k,buyVariant=variant,total=s.total,duration=FruitPartyTiming.Duration(s,mode)};
                Phase(m);if(gen!=generation)yield break;yield return Wait(m.duration+.18f);if(gen!=generation)yield break;
            }
            bool paid=false;
            try
            {
                if(interactingPlayer!=null){if(variant>=0)Payout(round.total/FruitPartyEngine.BuyCost[variant]*EstimatedValue,ChangeType.GameResult,null,currentBet*FruitPartyEngine.BuyCost[variant]);else Payout(round.total*EstimatedValue);paid=true;}
                else FruitPartyPlugin.Log.LogWarning("[FP] Player left before payout");
            }
            catch(Exception e){FruitPartyPlugin.Log.LogError("[FP] Payout: "+e);}
            if(!paid)Refund("payout unavailable");else{charged=BigNumber.Zero;roundActive=false;}
            Phase(new FruitPartyMsg{t="end",round=gen,s=round.spins.Last(),speed=speedMode,total=round.total,buyVariant=variant,duration=1.35f});
            Unlock();
            if(autoLeft>0){autoLeft--;if(round.spins.Count>1&&FruitPartyPlugin.AutoStopOnBonus.Value)autoLeft=0;Control();ScheduleAuto();}
        }
        IEnumerator Wait(float duration){deadline=Time.unscaledTime+duration+30;yield return new WaitForSecondsRealtime(duration);}
        void Unlock(){roundActive=false;try{ResetGame();}catch(Exception e){FruitPartyPlugin.Log.LogError("[FP] Reset: "+e.Message);isPlaying=false;canBet=true;}}
        void Refund(string why)
        {
            generation++;roundActive=false;autoLeft=0;
            try{if(charged>BigNumber.Zero)Extensions.NetworkSingleton<MoneyManager>.Instance.TryChangeBalance(charged,interactingPlayer,ChangeType.Bet);}
            catch(Exception e){FruitPartyPlugin.Log.LogError("[FP] Refund: "+e.Message);}
            charged=BigNumber.Zero;FruitPartyPlugin.Log.LogWarning("[FP] Round aborted: "+why);
        }
        void Phase(FruitPartyMsg m)
        {m.seq=++sequence;m.tb=m.speed==2?1:0;m.sent=NetworkTime.time;lastPhase=m;Broadcast(m);}
        void Control(){Broadcast(new FruitPartyMsg{t="control",seq=sequence});}
        void Broadcast(FruitPartyMsg m)
        {
            if(!NetworkServer.active)return;
            m.bet=FormatBet(currentBet);m.bn=currentBet.ToDouble();m.settingTurbo=turbo?1:0;m.settingSpeed=speedMode;m.menu=buySelection;m.auto=autoLeft;m.busy=isPlaying?1:0;
            var writer=NetworkWriterPool.Get();
            try{writer.WriteString(GwyfShared.MiniJson.ToJson(m));SendRPCInternal(RpcSig,RpcSig.GetStableHashCode(),writer,0,true);}
            catch(Exception e){FruitPartyPlugin.Log.LogError("[FP] RPC: "+e.Message);if(roundActive){Refund("RPC transport failed");Unlock();}}
            finally{NetworkWriterPool.Return(writer);}
        }
        public void ToggleTurbo(PlayerInteract p=null){if(!NetworkServer.active)return;speedMode=(speedMode+1)%3;turbo=speedMode==2;Control();}
        public void ToggleAuto(PlayerInteract p)
        {
            if(!NetworkServer.active||p==null)return;
            if(autoLeft>0){autoLeft=0;autoPlayer=null;Control();return;}
            if(buySelection>=0||!CanGameStart())return;
            autoPlayer=p;autoLeft=Mathf.Clamp(FruitPartyPlugin.AutoSpins.Value,1,100);Control();ScheduleAuto();
        }
        void ScheduleAuto(){if(autoScheduled||isPlaying||autoLeft<=0||autoPlayer==null)return;autoScheduled=true;StartCoroutine(AutoNext());}
        IEnumerator AutoNext()
        {yield return new WaitForSecondsRealtime(turbo?.25f:.6f);autoScheduled=false;if(autoLeft>0&&autoPlayer!=null&&!isPlaying){TryStartGame(autoPlayer);if(!isPlaying){autoLeft=0;Control();}}}
        static string FormatBet(BigNumber b){try{return MoneyFormatter.FormatWithDollar(b);}catch{return "$"+b;}}
        void StepBet(int dir)
        {
            if(!NetworkServer.active||isPlaying||!canBet||keypad==null||isGoldenChipApplied)return;
            try
            {
                double mn=MinBet.ToDouble(),mx=Math.Min(1e15,MaxBet.ToDouble()),cur=currentBet.ToDouble();var options=new List<double>{mn};
                if(mn<=0||double.IsNaN(mn)||double.IsNaN(mx))return;
                for(double decade=Math.Pow(10,Math.Floor(Math.Log10(mn)));decade<=mx;decade*=10)
                    foreach(double v in new[]{1d,1.5,2,2.5,3,4,5,6,8})if(decade*v>=mn&&decade*v<=mx)options.Add(decade*v);
                options.Sort();double next=dir>0?options.FirstOrDefault(v=>v>cur*1.00001):options.LastOrDefault(v=>v<cur*.99999);if(next<=0)return;
                var b=BigNumber.FromDouble(next);HarmonyLib.AccessTools.Method(typeof(Keypad),"ApplyInput").Invoke(keypad,new object[]{b.ToKeypadString(),true});Control();
            }
            catch(Exception e){FruitPartyPlugin.Log.LogError("[FP] Bet: "+e.Message);}
        }
        protected override void OnDisable()
        {if(NetworkServer.active&&roundActive){Refund("machine disabled");Unlock();}autoScheduled=false;autoLeft=0;autoPlayer=null;ClientAbort();}
        void OnDestroy(){ClearEffects();StopAllCoroutines();if(dynamicFont!=null)Destroy(dynamicFont);if(systemFont!=null)Destroy(systemFont);foreach(var m in ownedMaterials)if(m!=null)Destroy(m);ownedMaterials.Clear();}
        void Start()
        {
            try{EnsureUi();SetIdle();if(FruitPartyPlugin.RestyleCabinet.Value)BuildCabinet();}catch(Exception e){FruitPartyPlugin.Log.LogError("[FP] Start: "+e);}
        }
        void Update()
        {
            if(FruitPartyPlugin.Instance!=null)FruitPartyPlugin.Instance.Tick();
            if(NetworkServer.active)
            {
                if(roundActive&&Time.unscaledTime>deadline){Refund("watchdog");Unlock();Phase(new FruitPartyMsg{t="end",duration=0});}
                if(buySelection!=-1&&Time.time-menuTime>25f)SetMenu(null,-1);
                if(Time.unscaledTime>=nextSnapshot)
                {nextSnapshot=Time.unscaledTime+2;if(lastPhase!=null){var copy=GwyfShared.MiniJson.FromJson<FruitPartyMsg>(GwyfShared.MiniJson.ToJson(lastPhase));copy.snapshot=true;Broadcast(copy);}else Control();}
            }
            if(NetworkClient.active&&_ui==null&&Time.unscaledTime>=nextUiTry){nextUiTry=Time.unscaledTime+2;try{EnsureUi();SetIdle();}catch(Exception e){FruitPartyPlugin.Log.LogWarning("[FP] UI retry: "+e.Message);}}
        }
        float nextUiTry;
        void Sfx(EventReference ev,float value=0){try{if(!ev.IsNull)SFXManager.SFXOneShotWithParameters(ev,new[]{new SFXParams("Multiplier",Mathf.Clamp(value,0,1000))},transform.position);}catch{}}
    }
}
