using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Mirror;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
namespace FruitParty
{
    public partial class FruitPartyGame
    {
        RectTransform _ui,window,grid,menuRoot,popRoot,fxRoot;TMP_FontAsset font;Font systemFont;TMP_FontAsset dynamicFont;Image dim,ring,popIcon;Image[] sparks=new Image[28];Vector2 size;float step;
        readonly List<Material> ownedMaterials=new List<Material>();
        Image[] cells=new Image[49],glows=new Image[49];TMP_Text[] values=new TMP_Text[49];Vector2[] home=new Vector2[49];
        Image[][] strips=new Image[7][];TMP_Text[][] stripValues=new TMP_Text[7][];
        TMP_Text totalX,totalMoney,betLabel,winLabel,spinCountLabel,statusLabel,blockLabel,bonusLabel,menuTitle,popup,popupSub,buyCostText;
        Coroutine animation;int lastAnimated=-1,lastMenu=int.MinValue;double shownTotal,betNumber,lastMenuBet=-1;string shownBet="—";int[] previous=FruitPartyEngine.InitialGrid();
        static readonly Color Gold=new Color(1,.89f,.24f),Pink=new Color(1,.22f,.68f),Lime=new Color(.64f,1,.24f);
        static readonly Dictionary<string,Sprite> sprites=new Dictionary<string,Sprite>();
        public struct BtnDef {public string id,tip;public float cx,cy,w,h;public BtnDef(string id,string tip,float x,float y,float w,float h){this.id=id;this.tip=tip;cx=x;cy=y;this.w=w;this.h=h;}}
        public static readonly BtnDef[] Buttons={
            new BtnDef("Buy","Buy 10 free spins for 100x bet",.10f,.70f,.15f,.18f),new BtnDef("Info","Menu / next rules page",.042f,.085f,.055f,.075f),
            new BtnDef("Spin","Spin / confirm bonus purchase",.844f,.108f,.12f,.155f),new BtnDef("Minus","Bet -",.495f,.085f,.055f,.075f),new BtnDef("Plus","Bet +",.674f,.085f,.055f,.075f),
            new BtnDef("Turbo","Normal / quick / turbo",.746f,.085f,.055f,.075f),new BtnDef("Auto","Automatic play / stop",.948f,.085f,.055f,.075f),
            new BtnDef("Buy0","Confirm 10 free spins for 100x bet",.50f,.335f,.46f,.09f),new BtnDef("Close","Close menu",.88f,.85f,.060f,.065f),
            new BtnDef("Rules","Payouts and rules",.50f,.64f,.50f,.09f),new BtnDef("MenuSpeed","Normal / quick / turbo",.50f,.50f,.50f,.09f),new BtnDef("MenuAuto","Automatic play",.50f,.36f,.50f,.09f)};
        static Sprite Spr(string key)
        {
            if(sprites.TryGetValue(key,out var sprite))return sprite;
            using(var stream=typeof(FruitPartyGame).Assembly.GetManifestResourceStream("FruitParty.art."+key+".png"))
            {
                if(stream==null)throw new InvalidOperationException("Missing art "+key);
                using(var mem=new System.IO.MemoryStream())
                {stream.CopyTo(mem);var tex=new Texture2D(2,2,TextureFormat.RGBA32,true);if(!ImageConversion.LoadImage(tex,mem.ToArray()))throw new InvalidOperationException("Invalid PNG "+key);
                    tex.name="FP_"+key;GwyfShared.ReelFx.ConfigureTexture(tex);sprite=Sprite.Create(tex,new Rect(0,0,tex.width,tex.height),new Vector2(.5f,.5f),100,0,SpriteMeshType.FullRect,(key=="panel"||key=="ribbon")?new Vector4(100,90,100,90):Vector4.zero);sprite.name=key;sprites[key]=sprite;return sprite;}
            }
        }
        public static Texture2D LoadPng(string key)=>Spr(key).texture;
        static Sprite Symbol(int sym)=>Spr(FruitPartyEngine.ArtKeys[Mathf.Clamp(sym,0,7)]);
        static Image Img(string n,Transform parent,Sprite sprite=null)
        {var go=new GameObject(n,typeof(RectTransform),typeof(Image));go.layer=parent.gameObject.layer;go.transform.SetParent(parent,false);var im=go.GetComponent<Image>();im.sprite=sprite;im.preserveAspect=sprite!=null;if(sprite!=null&&(sprite.name=="panel"||sprite.name=="ribbon")){im.type=Image.Type.Sliced;im.preserveAspect=false;}im.raycastTarget=false;return im;}
        static void Place(RectTransform r,Vector2 position,Vector2 dimensions)
        {r.anchorMin=r.anchorMax=r.pivot=new Vector2(.5f,.5f);r.sizeDelta=dimensions;r.anchoredPosition=position;}
        void N(RectTransform r,float x,float y,float w,float h)=>Place(r,new Vector2((x-.5f)*size.x,(y-.5f)*size.y),new Vector2(w*size.x,h*size.y));
        TMP_Text Text(string n,Transform parent,Color color,float pixels)
        {
            var go=new GameObject(n,typeof(RectTransform),typeof(CanvasRenderer));go.layer=parent.gameObject.layer;go.transform.SetParent(parent,false);var t=go.AddComponent<TextMeshProUGUI>();
            t.font=font;t.fontSharedMaterial=font.material;t.color=color;t.alignment=TextAlignmentOptions.Center;t.enableAutoSizing=true;t.fontSizeMax=pixels;t.fontSizeMin=1;
            t.textWrappingMode=TextWrappingModes.NoWrap;t.overflowMode=TextOverflowModes.Truncate;t.raycastTarget=false;t.fontStyle=FontStyles.Bold;return t;
        }
        TMP_Text Label(string n,string text,float x,float y,float w,float h,Color color,float fontFraction)
        {var t=Text(n,_ui,color,size.y*fontFraction);N(t.rectTransform,x,y,w,h);t.text=text;return t;}
        static void Layer(GameObject go,int layer){go.layer=layer;foreach(Transform child in go.transform)Layer(child.gameObject,layer);}
        void EnsureUi()
        {
            if(_ui!=null)return;var anchors=(symbolLocations??new List<Image>()).Where(i=>i!=null).ToList();
            if(anchors.Count==0&&reels!=null)anchors=reels.Where(r=>r!=null).SelectMany(r=>r.symbols??new Image[0]).Where(i=>i!=null).ToList();
            if(anchors.Count==0||anchors[0].canvas==null)throw new InvalidOperationException("Slot canvas anchors not ready");
            var root=(RectTransform)anchors[0].canvas.transform;font=payoutText!=null?payoutText.font:TMP_Settings.defaultFontAsset;
            if(font==null)font=Resources.FindObjectsOfTypeAll<TMP_FontAsset>().FirstOrDefault(f=>f!=null&&f.material!=null);
            if(font==null||font.material==null)throw new InvalidOperationException("TMP font not ready");
            try{systemFont=Font.CreateDynamicFontFromOSFont(new[]{"Arial","Liberation Sans","DejaVu Sans"},96);if(systemFont!=null){dynamicFont=TMP_FontAsset.CreateFontAsset(systemFont);if(dynamicFont!=null)font=dynamicFont;}}catch(Exception e){FruitPartyPlugin.Log.LogWarning("[FP] Font fallback: "+e.Message);}
            var min=root.rect.min;var max=root.rect.max;GwyfShared.ScreenFit.Fit(transform,root,ref min,ref max);
            size=(max-min)*(1-2*Mathf.Clamp(FruitPartyPlugin.ScreenMargin.Value,0,.2f));if(size.x<1||size.y<1)throw new InvalidOperationException("Invalid screen bounds");
            var go=new GameObject("FruitPartyWindow",typeof(RectTransform),typeof(RectMask2D));window=(RectTransform)go.transform;go.layer=root.gameObject.layer;window.SetParent(root,false);Place(window,(min+max)*.5f-root.rect.center,size);
            try
            {
                var bg=Img("FruitPartyUI",window,Spr("bg"));bg.preserveAspect=false;_ui=bg.rectTransform;Place(_ui,Vector2.zero,size);_ui.gameObject.AddComponent<RectMask2D>();BuildPanel();Layer(go,root.gameObject.layer);
                foreach(var r in reels??new List<SlotReel>())if(r!=null)foreach(var g in r.GetComponentsInChildren<Graphic>(true))g.enabled=false;
                foreach(var im in anchors)im.enabled=false;if(payoutText!=null){payoutText.text="";var old=payoutText.GetComponent<MeshRenderer>();if(old!=null)old.enabled=false;}window.SetAsLastSibling();
            }
            catch{Destroy(go);window=null;_ui=null;throw;}
        }
        void BuildPanel()
        {
            var logo=Img("Logo",_ui,Spr("logo"));N(logo.rectTransform,.49f,.934f,.32f,.115f);
            step=Mathf.Min(size.x*.64f/7,size.y*.70f/7);
            var gr=new GameObject("Reels",typeof(RectTransform),typeof(RectMask2D));grid=(RectTransform)gr.transform;grid.SetParent(_ui,false);N(grid,.49f,.525f,step*7/size.x,step*7/size.y);
            var background=Img("Tiles",grid,Spr("grid"));background.preserveAspect=false;Place(background.rectTransform,Vector2.zero,Vector2.one*step*7);
            for(int c=0;c<7;c++)
            {
                var column=new GameObject("Column"+c,typeof(RectTransform),typeof(RectMask2D));var rt=(RectTransform)column.transform;rt.SetParent(grid,false);Place(rt,new Vector2((c-3)*step,0),new Vector2(step,step*7));
                strips[c]=new Image[9];stripValues[c]=new TMP_Text[9];for(int j=0;j<9;j++)MakeSymbol("Strip"+j,rt,out strips[c][j],out stripValues[c][j]);
            }
            for(int i=0;i<49;i++)
            {
                home[i]=new Vector2((i/7-3)*step,(3-i%7)*step);glows[i]=Img("WinGlow"+i,grid,Spr("px"));glows[i].preserveAspect=false;Place(glows[i].rectTransform,home[i],Vector2.one*step*.95f);glows[i].color=Color.clear;
                MakeSymbol("Fruit"+i,grid,out cells[i],out values[i]);Place(cells[i].rectTransform,home[i],Vector2.one*step*.90f);
            }
            var toolbar=Img("Toolbar",_ui,Spr("toolbar"));toolbar.preserveAspect=false;N(toolbar.rectTransform,.5f,.082f,.98f,.155f);
            var buy=Img("BuyFeature",_ui,Spr("panel"));N(buy.rectTransform,.10f,.70f,.15f,.18f);
            Label("BuyTitle","BUY FREE\nSPINS",.10f,.729f,.13f,.062f,Gold,.024f).textWrappingMode=TextWrappingModes.Normal;
            Label("BuyCost","100x BET",.10f,.665f,.13f,.029f,Color.white,.023f);
            foreach(var pos in new[]{new Vector2(.10f,.47f),new Vector2(.91f,.68f),new Vector2(.91f,.48f),new Vector2(.91f,.32f)})
            {var plate=Img("SidePlaque",_ui,Spr("panel"));N(plate.rectTransform,pos.x,pos.y,.155f,pos.y==.68f?.23f:.15f);plate.transform.SetSiblingIndex(2);}
            Label("MaxTitle","MAX WIN",.10f,.52f,.13f,.028f,Color.white,.023f);Label("MaxX","5000x",.10f,.475f,.13f,.046f,Gold,.040f);
            Label("ClusterTitle","CLUSTERS",.10f,.37f,.13f,.027f,Color.white,.020f);Label("ClusterCount","5+ CONNECTED",.10f,.332f,.14f,.025f,Color.white,.018f);
            Label("TotalTitle","TOTAL WIN",.91f,.76f,.13f,.028f,Gold,.023f);totalX=Label("TotalX","0x",.91f,.71f,.14f,.055f,Color.white,.041f);
            totalMoney=Label("TotalMoney","$0",.91f,.657f,.14f,.032f,Color.white,.025f);
            Label("FreeTitle","FREE SPINS",.91f,.565f,.14f,.025f,Color.white,.023f);spinCountLabel=Label("FreeCount","—",.91f,.52f,.14f,.055f,Gold,.050f);
            bonusLabel=Label("Mode","BASE GAME",.91f,.46f,.14f,.031f,Color.white,.020f);blockLabel=Label("BlockWin","",.91f,.355f,.14f,.10f,Gold,.023f);blockLabel.textWrappingMode=TextWrappingModes.Normal;
            Label("BetTitle","BET",.585f,.120f,.11f,.019f,Gold,.020f);betLabel=Label("Bet","—",.585f,.074f,.12f,.046f,Color.white,.030f);
            Label("WinTitle","WIN",.29f,.120f,.26f,.019f,Gold,.020f);winLabel=Label("Win","$0",.29f,.074f,.28f,.046f,Color.white,.030f);
            statusLabel=Label("Status","PLACE YOUR BETS",.49f,.167f,.62f,.021f,Color.white,.018f);
            foreach(var b in Buttons.Where(b=>new[]{"Spin","Minus","Plus","Turbo","Auto","Info"}.Contains(b.id)))
            {var im=Img("Hud"+b.id,_ui,Spr("button_"+b.id.ToLowerInvariant()));N(im.rectTransform,b.cx,b.cy,b.w,b.h);}
            fxRoot=Img("Effects",_ui).rectTransform;fxRoot.GetComponent<Image>().enabled=false;N(fxRoot,.5f,.5f,1,1);
            dim=Img("BonusDim",fxRoot,Spr("px"));dim.preserveAspect=false;N(dim.rectTransform,.5f,.5f,1,1);dim.color=Color.clear;
            ring=Img("ScatterShock",fxRoot,Spr("ring"));Place(ring.rectTransform,Vector2.zero,Vector2.one*step);ring.color=Color.clear;
            for(int i=0;i<sparks.Length;i++){sparks[i]=Img("Spark"+i,fxRoot,Spr("sparkle"));sparks[i].color=Color.clear;Place(sparks[i].rectTransform,Vector2.zero,Vector2.one*step*.16f);}
            popRoot=Img("Popup",fxRoot,Spr("bonusframe")).rectTransform;N(popRoot,.5f,.535f,.83f,.50f);
            popIcon=Img("GoldenScatter",popRoot,Symbol(7));Place(popIcon.rectTransform,new Vector2(-size.x*.25f,0),Vector2.one*size.y*.22f);
            popup=Text("PopupTitle",popRoot,Gold,size.y*.072f);Place(popup.rectTransform,new Vector2(size.x*.08f,size.y*.045f),new Vector2(size.x*.47f,size.y*.12f));popup.textWrappingMode=TextWrappingModes.Normal;
            popupSub=Text("PopupSubtitle",popRoot,Color.white,size.y*.027f);Place(popupSub.rectTransform,new Vector2(size.x*.08f,-size.y*.075f),new Vector2(size.x*.47f,size.y*.07f));popupSub.textWrappingMode=TextWrappingModes.Normal;popRoot.gameObject.SetActive(false);
            menuRoot=Img("Menu",_ui,Spr("px")).rectTransform;menuRoot.GetComponent<Image>().preserveAspect=false;menuRoot.GetComponent<Image>().color=new Color(.025f,.01f,.05f,.84f);N(menuRoot,.50f,.50f,1,1);menuRoot.gameObject.AddComponent<RectMask2D>();
            var menuPanel=Img("MenuPanel",menuRoot,Spr("panel"));Place(menuPanel.rectTransform,Vector2.zero,new Vector2(size.x*.85f,size.y*.81f));
            menuTitle=Text("MenuTitle",menuRoot,Gold,size.y*.045f);Place(menuTitle.rectTransform,new Vector2(0,size.y*.30f),new Vector2(size.x*.68f,size.y*.07f));
            var close=Img("Close",menuRoot,Spr("button_close"));Place(close.rectTransform,new Vector2(size.x*.38f,size.y*.35f),new Vector2(size.x*.060f,size.y*.065f));
            menuRoot.gameObject.SetActive(false);ShowBuyMenu(-1);
        }
        void MakeSymbol(string n,Transform parent,out Image im,out TMP_Text val)
        {
            im=Img(n,parent);im.preserveAspect=true;Place(im.rectTransform,Vector2.zero,Vector2.one*step*.90f);
            var plate=Img("MultiplierPlate",im.transform,Spr("panel"));plate.color=Color.white;Place(plate.rectTransform,new Vector2(0,-step*.13f),new Vector2(step*.62f,step*.38f));plate.gameObject.SetActive(false);
            val=Text("Multiplier",im.transform,Gold,step*.30f);val.enableAutoSizing=false;val.fontSize=step*.30f;val.outlineWidth=.14f;Place(val.rectTransform,new Vector2(0,-step*.13f),new Vector2(step*.62f,step*.38f));
        }
        void SymbolView(Image im,TMP_Text val,int symbol,int mult=1,float alpha=1,float scale=1)
        {
            im.sprite=Symbol(symbol);im.color=new Color(1,1,1,alpha);im.rectTransform.localScale=Vector3.one*scale;
            im.transform.GetChild(0).gameObject.SetActive(mult>1);im.transform.GetChild(0).GetComponent<Image>().color=new Color(1,1,1,alpha);
            val.text=mult>1?"x"+mult:"";val.color=new Color(Gold.r,Gold.g,Gold.b,alpha);
        }
        void SetIdle(){if(_ui!=null)DrawGrid(previous);}
        void DrawGrid(int[] g)
        {
            ClearEffects();foreach(var column in strips)if(column!=null)foreach(var im in column)im.gameObject.SetActive(false);
            for(int i=0;i<49;i++){cells[i].gameObject.SetActive(true);SymbolView(cells[i],values[i],g[i]);cells[i].rectTransform.anchoredPosition=home[i];glows[i].color=Color.clear;}
        }
        static string X(double v)=>v.ToString(v<100?"0.##":"0.#",CultureInfo.InvariantCulture)+"x";
        static string Money(double n)
        {if(double.IsNaN(n)||double.IsInfinity(n))return "—";double a=Math.Abs(n);return "$"+(a>=1e9?(n/1e9).ToString("0.##",CultureInfo.InvariantCulture)+"B":a>=1e6?(n/1e6).ToString("0.##",CultureInfo.InvariantCulture)+"M":a>=1e3?(n/1e3).ToString("0.##",CultureInfo.InvariantCulture)+"K":n.ToString("0.##",CultureInfo.InvariantCulture));}
        void Totals(double total){shownTotal=total;totalX.text=X(total);totalMoney.text=Money(total*betNumber);winLabel.text=Money(total*betNumber);}
        void FeatureHud(FruitPartyEngine.Spin s)
        {if(s==null)return;_ui.GetComponent<Image>().sprite=Spr(s.bonus==1?"bonusbg":"bg");spinCountLabel.text=s.bonus==1||s.awarded>0?s.left.ToString():"—";bonusLabel.text=s.bonus==1?"FRUIT FREE SPINS":"BASE GAME";}
        public void UserRpcShowSpin(string json)
        {
            if(!NetworkClient.active)return;FruitPartyMsg m;
            try{m=GwyfShared.MiniJson.FromJson<FruitPartyMsg>(json);EnsureUi();}catch(Exception e){FruitPartyPlugin.Log.LogError("[FP] Client packet: "+e);return;}
            if(!string.IsNullOrEmpty(m.bet))shownBet=m.bet;if(m.bn>0)betNumber=m.bn;betLabel.text=shownBet;ShowBuyMenu(m.menu);
            var fast=_ui.Find("HudTurbo");if(fast!=null)fast.GetComponent<Image>().color=m.settingSpeed==0?Color.white:m.settingSpeed==1?Lime:Pink;
            var auto=_ui.Find("HudAuto");if(auto!=null)auto.GetComponent<Image>().color=m.auto>0?Lime:Color.white;
            if(m.t=="control"){statusLabel.text=m.busy==1?"ROUND IN PROGRESS":m.auto>0?"AUTO · "+m.auto:"PLACE YOUR BETS";return;}
            if(m.seq<=lastAnimated)return;lastAnimated=m.seq;ClientAbort();float elapsed=FruitPartyTiming.Elapsed(NetworkTime.time,m.sent,m.duration);
            if(elapsed>=m.duration){if(m.s!=null){DrawGrid(m.s.Final);previous=(int[])m.s.Final.Clone();FeatureHud(m.s);}Totals(m.total);return;}
            animation=StartCoroutine(SafeAnimate(m,elapsed));
        }
        IEnumerator SafeAnimate(FruitPartyMsg m,float elapsed)
        {
            var iterator=Animate(m,elapsed);
            while(true)
            {
                object current;try{if(!iterator.MoveNext())break;current=iterator.Current;}catch(Exception e){FruitPartyPlugin.Log.LogError("[FP] Animation: "+e);break;}yield return current;
            }
            (iterator as IDisposable)?.Dispose();if(m.s!=null){DrawGrid(m.s.Final);previous=(int[])m.s.Final.Clone();FeatureHud(m.s);}Totals(m.total);if(m.t=="intro")_ui.GetComponent<Image>().sprite=Spr("bonusbg");animation=null;
        }
        IEnumerator Animate(FruitPartyMsg m,float elapsed)
        {
            float origin=Time.unscaledTime-elapsed;var sounds=new bool[7];int lastStep=-1;FruitPartyTimeline.Phase last=FruitPartyTimeline.Phase.Done;
            try
            {
                if(m.t=="intro")
                {
                    Sfx(multiplierSFX,10);DrawGrid(m.s.Final);_ui.GetComponent<Image>().sprite=Spr("bonusbg");
                    while(Time.unscaledTime-origin<m.duration){float p=(Time.unscaledTime-origin)/m.duration;DrawBonusBanner("10 FREE\nSPINS",m.buyVariant>=0?"BONUS BOUGHT · GOOD LUCK!":"CONGRATULATIONS · GOOD LUCK!",p);yield return null;}yield break;
                }
                if(m.t=="end")
                {if(m.s!=null)DrawGrid(m.s.Final);Totals(m.total);statusLabel.text=m.total>=5000?"MAX WIN · 5000x":"ROUND COMPLETE · "+X(m.total);yield break;}
                if(elapsed<FruitPartyTiming.ReelEnd(6,m.speed))Sfx(spinReelSFX);
                while(true)
                {
                    float t=Time.unscaledTime-origin;for(int c=0;c<7;c++)if(!sounds[c]&&t>=FruitPartyTiming.ReelEnd(c,m.speed)){sounds[c]=true;Sfx(spinDoneSFX);}
                    var frame=FruitPartyTimeline.At(m.s,t,m.speed);
                    if(frame.phase==FruitPartyTimeline.Phase.Hit&&(last!=frame.phase||lastStep!=frame.step))Sfx(multiplierSFX,m.s.steps[frame.step].clusters.Max(c=>c.multi));
                    if(frame.phase==FruitPartyTimeline.Phase.BonusFocus&&last!=frame.phase)Sfx(multiplierSFX,10);
                    DrawSpin(m.s,frame,t,m.speed,m.total-m.s.win);last=frame.phase;lastStep=frame.step;if(t>=m.duration)break;yield return null;
                }
                if(m.s.win>0)Sfx(finaltextSFX,(float)m.s.win);Totals(m.total);
            }
            finally{ClearEffects();animation=null;}
        }
        void DrawSpin(FruitPartyEngine.Spin s,FruitPartyTimeline.Frame frame,float elapsed,int speed,double from)
        {
            var state=s.steps[frame.step];blockLabel.text="";ClearEffects();
            foreach(var column in strips)foreach(var im in column)im.gameObject.SetActive(false);
            for(int i=0;i<49;i++){cells[i].gameObject.SetActive(true);cells[i].rectTransform.anchoredPosition=home[i];glows[i].color=Color.clear;}
            if(frame.phase==FruitPartyTimeline.Phase.Reels)
            {
                for(int c=0;c<7;c++)
                {
                    float end=FruitPartyTiming.ReelEnd(c,speed);bool moving=elapsed<end;int travel=Math.Max(8,(int)Math.Round(end*9));float p=CellReelMotion.Position(elapsed,end,travel);
                    for(int row=0;row<7;row++){int i=c*7+row;cells[i].gameObject.SetActive(!moving);if(!moving)SymbolView(cells[i],values[i],s.steps[0].g[i],1,1,FruitPartyPresentation.Landing(elapsed-end));}
                    if(!moving)continue;
                    for(int j=0;j<9;j++)
                    {
                        int idx=(int)Math.Floor(p)+1-j,endRow=travel-idx,startRow=-idx;
                        int sym=endRow>=0&&endRow<7?s.steps[0].g[c*7+endRow]:startRow>=0&&startRow<7?previous[c*7+startRow]:Math.Abs(idx+c*3)%7;
                        var im=strips[c][j];im.gameObject.SetActive(true);SymbolView(im,stripValues[c][j],sym);Place(im.rectTransform,new Vector2(0,(3+idx-p)*step),Vector2.one*step*.90f);
                    }
                }
            }
            else if(frame.phase==FruitPartyTimeline.Phase.Drop)
            {
                for(int i=0;i<49;i++){SymbolView(cells[i],values[i],state.after[i]);cells[i].rectTransform.anchoredPosition=new Vector2(home[i].x,(3-FruitPartyTimeline.DropRow(state,i,frame.p))*step);
                    if(FruitPartyTimeline.FromRow(state,i)<i%7){float squash=.09f*Mathf.Sin(Mathf.Clamp01((frame.p-.76f)/.24f)*Mathf.PI);cells[i].rectTransform.localScale=new Vector3(1+squash,1-squash,1);}}
            }
            else
            {
                bool hit=frame.phase==FruitPartyTimeline.Phase.Hit;float fade=hit?FruitPartyTimeline.Ease(Mathf.Clamp01((frame.p-.58f)/.42f)):0;
                var removed=new HashSet<int>(hit?state.removed:new int[0]);
                for(int i=0;i<49;i++)
                {
                    bool winning=removed.Contains(i);float alpha=winning?1-fade:1;int multi=hit&&frame.p>.10f?state.m[i]:1;
                    SymbolView(cells[i],values[i],state.g[i],multi,alpha,winning?1+.13f*Mathf.Sin(frame.p*Mathf.PI)-.22f*fade:1);
                    if(winning)glows[i].color=new Color(1,.82f,.22f,.42f*Mathf.Sin(frame.p*Mathf.PI));
                }
                if(hit){Burst(state.removed,frame.p);var best=state.clusters.OrderByDescending(c=>c.pay).First();blockLabel.text="BLOCK "+X(best.multi)+"\n"+X(state.win);}
                if(frame.phase==FruitPartyTimeline.Phase.BonusFocus)DrawBonusFocus(s.Final,frame.p);
                if(frame.phase==FruitPartyTimeline.Phase.Retrigger)DrawBonusBanner("+"+s.awarded+" FREE\nSPINS",s.scatters+" SCATTERS · "+s.left+" SPINS LEFT",frame.p);
            }
            FeatureHud(s);if(s.bonus==1&&frame.phase!=FruitPartyTimeline.Phase.Retrigger&&frame.phase!=FruitPartyTimeline.Phase.Done)spinCountLabel.text=Math.Max(0,s.left-s.awarded).ToString();
            Totals(Math.Max(0,from)+frame.win);statusLabel.text=frame.phase==FruitPartyTimeline.Phase.Reels?(s.bonus==1?"FREE SPIN · SPINNING":"SPINNING"):frame.phase==FruitPartyTimeline.Phase.Hit?"CLUSTER WIN · "+X(state.win):frame.phase==FruitPartyTimeline.Phase.Drop?"TUMBLE":s.capped?"MAX WIN · 5000x":"TUMBLE WIN · "+X(s.win);
        }
        void ShowBuyMenu(int selected)
        {
            if(menuRoot==null||selected==lastMenu&&lastMenuBet==betNumber)return;lastMenu=selected;lastMenuBet=betNumber;menuRoot.gameObject.SetActive(selected!=-1);
            foreach(var t in GetComponentsInChildren<InteractableEventTrigger>(true))
            {if(!t.name.StartsWith("FPScr_"))continue;string id=t.name.Substring(6);bool visible=id=="Buy0"?selected>=0:id=="Close"?selected!=-1:id=="Rules"||id=="MenuSpeed"||id=="MenuAuto"?selected==-5:selected==-1||id=="Info";t.gameObject.SetActive(visible);}
            for(int i=menuRoot.childCount-1;i>=0;i--){var child=menuRoot.GetChild(i);if(child.name.StartsWith("Content"))Destroy(child.gameObject);}
            if(selected==-1)return;
            menuTitle.text=selected>=0?"BUY FREE SPINS":selected==-2?"PAYOUT · x TOTAL BET":selected==-3?"CLUSTERS / TUMBLES / MULTIPLIERS":selected==-5?"FRUIT PARTY · MENU":"FREE SPINS / CONTROLS";
            if(selected>=0)
            {
                var title=Text("ContentOffer",menuRoot,Gold,size.y*.075f);title.text="10 FREE SPINS";Place(title.rectTransform,new Vector2(0,size.y*.10f),new Vector2(size.x*.66f,size.y*.09f));
                for(int i=0;i<3;i++){var peach=Img("ContentScatter"+i,menuRoot,Symbol(7));Place(peach.rectTransform,new Vector2((i-1)*size.y*.15f,-size.y*.025f),Vector2.one*size.y*.145f);}
                var detail=Text("ContentDetail",menuRoot,Color.white,size.y*.025f);detail.text="MORE x2 / x4 · MAX WIN 5000x";Place(detail.rectTransform,new Vector2(0,-size.y*.105f),new Vector2(size.x*.62f,size.y*.035f));
                var card=Img("ContentBuy",menuRoot,Spr("ribbon"));Place(card.rectTransform,new Vector2(0,-size.y*.165f),new Vector2(size.x*.46f,size.y*.09f));
                buyCostText=Text("Price",card.transform,Color.white,size.y*.037f);buyCostText.text="BUY · "+Money(betNumber*100);Place(buyCostText.rectTransform,Vector2.zero,new Vector2(size.x*.39f,size.y*.054f));
                var hint=Text("ContentHint",menuRoot,Color.white,size.y*.020f);hint.text="100x BET · [E] BUY / SPIN TO CONFIRM";Place(hint.rectTransform,new Vector2(0,-size.y*.26f),new Vector2(size.x*.65f,size.y*.035f));return;
            }
            if(selected==-5)
            {
                var titles=new[]{"PAYOUTS & RULES","NORMAL / QUICK / TURBO","AUTOMATIC PLAY"};for(int i=0;i<3;i++)
                {var card=Img("ContentOption"+i,menuRoot,Spr("ribbon"));Place(card.rectTransform,new Vector2(0,size.y*(.14f-i*.14f)),new Vector2(size.x*.50f,size.y*.09f));var label=Text("Title",card.transform,Color.white,size.y*.032f);label.text=titles[i];Place(label.rectTransform,Vector2.zero,new Vector2(size.x*.44f,size.y*.06f));}return;
            }
            if(selected==-2)
            {
                for(int sym=0;sym<7;sym++)
                {
                    float x=(sym-3)*size.x*.108f;var icon=Img("ContentIcon"+sym,menuRoot,Symbol(sym));Place(icon.rectTransform,new Vector2(x,size.y*.205f),Vector2.one*size.y*.088f);
                    var pay=Text("ContentPay"+sym,menuRoot,Color.white,size.y*.020f);pay.textWrappingMode=TextWrappingModes.Normal;Place(pay.rectTransform,new Vector2(x,-size.y*.045f),new Vector2(size.x*.10f,size.y*.37f));
                    pay.text=string.Join("\n",Enumerable.Range(5,11).Select(n=>(n==15?"15+":n.ToString())+"  "+X(FruitPartyEngine.Pays[sym][n-5])));
                }
            }
            else
            {
                var text=Text("ContentRules",menuRoot,Color.white,size.y*.028f);text.textWrappingMode=TextWrappingModes.Normal;text.alignment=TextAlignmentOptions.Left;
                Place(text.rectTransform,new Vector2(0,-size.y*.020f),new Vector2(size.x*.76f,size.y*.55f));
                text.text=selected==-3?"7 × 7 · CLUSTERS\nFive or more identical symbols connected horizontally or vertically pay. Diagonals do not connect. Separate winning blocks all pay.\n\nTUMBLE\nWinning symbols disappear. Survivors fall down; new symbols enter from above. Tumbles continue until there are no winning clusters.\n\nRANDOM MULTIPLIERS\nWinning tiles may receive x2 in the base game, x2 or x4 more often in free spins. Multiply every tile multiplier inside its block, up to x256.\n\nMAX ROUND WIN · 5000x BET":
                "3+ SCATTERS → 10 FREE SPINS\nScatter can land on every reel and does not form clusters.\n\nRETRIGGER\n3 / 4 / 5 / 6 / 7 scatters award +10 / +11 / +12 / +13 / +14 free spins.\n\nBUY FREE SPINS · 100x BET\nA round stops immediately at the 5000x cap. Payout follows all tumbles/free spins.\n\nSPIN · start / confirm purchase\nSPEED · normal / quick / turbo\nAUTO · start / stop automatic play\nINFO · next rules page\nMod uses its own reel frequencies; original RTP is not claimed.";
            }
        }
        void ClearEffects()
        {GwyfShared.CamZoom.Clear(this);if(dim!=null)dim.color=Color.clear;if(ring!=null)ring.color=Color.clear;foreach(var sp in sparks)if(sp!=null)sp.color=Color.clear;if(popRoot!=null){popRoot.gameObject.SetActive(false);popRoot.localScale=Vector3.one;}}
        void Burst(int[] positions,float progress)
        {
            if(positions.Length==0)return;float p=Mathf.Clamp01((progress-.48f)/.52f);if(p<=0)return;
            for(int k=0;k<sparks.Length;k++){int cell=positions[k%positions.Length];float a=k*2.39996f;Vector2 start=grid.anchoredPosition+home[cell];Vector2 motion=new Vector2(Mathf.Cos(a),Mathf.Sin(a))*step*.55f*FruitPartyTimeline.Ease(p);
                sparks[k].rectTransform.anchoredPosition=start+motion;sparks[k].rectTransform.localRotation=Quaternion.Euler(0,0,k*17+p*100);sparks[k].rectTransform.localScale=Vector3.one*(1-p*.6f);sparks[k].color=new Color(1,.9f,.5f,(1-p)*.9f);}
        }
        void DrawBonusFocus(int[] settled,float progress)
        {
            int last=FruitPartyPresentation.LastScatter(settled);if(last<0)return;float envelope=Mathf.Sin(progress*Mathf.PI);dim.color=new Color(.10f,.015f,.20f,.30f*envelope);
            // Fixed screen geometry: change the viewing player's camera, never enlarge the UI beyond the bezel.
            GwyfShared.CamZoom.Set(this,cells[last].transform.position,FruitPartyPresentation.Zoom(progress));
            for(int i=0;i<49;i++)if(settled[i]==FruitPartyEngine.Scatter){cells[i].rectTransform.localScale=Vector3.one*(1+.12f*envelope);glows[i].color=new Color(1,.82f,.2f,.6f*envelope);}
            Vector2 focus=grid.anchoredPosition+home[last];ring.rectTransform.anchoredPosition=focus;ring.rectTransform.localScale=Vector3.one*(1+2.3f*FruitPartyTimeline.Ease(progress));ring.color=new Color(1,.91f,.35f,envelope*(1-progress));
            for(int k=0;k<sparks.Length;k++){float a=k*2.39996f;float distance=step*(.30f+1.2f*progress);sparks[k].rectTransform.anchoredPosition=focus+new Vector2(Mathf.Cos(a),Mathf.Sin(a))*distance;sparks[k].rectTransform.localScale=Vector3.one*(.8f+.5f*envelope);sparks[k].color=new Color(1,.85f,.3f,envelope);}
            statusLabel.text="";
        }
        void DrawBonusBanner(string title,string sub,float progress)
        {
            float a=Mathf.Clamp01(Mathf.Min(progress/.12f,(1-progress)/.15f));dim.color=new Color(.07f,.01f,.16f,.76f*a);popRoot.gameObject.SetActive(true);popRoot.localScale=Vector3.one*FruitPartyPresentation.Pop(progress);popRoot.GetComponent<Image>().color=new Color(1,1,1,a);popup.text=title;popupSub.text=sub;popup.color=new Color(Gold.r,Gold.g,Gold.b,a);popupSub.color=new Color(1,1,1,a);popIcon.color=new Color(1,1,1,a);popIcon.rectTransform.localRotation=Quaternion.Euler(0,0,4*Mathf.Sin(progress*Mathf.PI*2));
            for(int k=0;k<sparks.Length;k++){float angle=k*2.39996f;float distance=size.y*(.16f+.27f*progress);sparks[k].rectTransform.anchoredPosition=new Vector2(Mathf.Cos(angle)*distance*1.45f,Mathf.Sin(angle)*distance)+new Vector2(0,size.y*.035f);sparks[k].rectTransform.localScale=Vector3.one*(.65f+.4f*Mathf.Sin(progress*Mathf.PI));sparks[k].color=new Color(1,.85f,.4f,a*.8f);}
        }
        void ClientAbort()
        {
            if(animation!=null){StopCoroutine(animation);animation=null;}ClearEffects();if(_ui==null)return;
            foreach(var column in strips)if(column!=null)foreach(var im in column)im.gameObject.SetActive(false);
            for(int i=0;i<49;i++)if(cells[i]!=null){cells[i].gameObject.SetActive(true);cells[i].rectTransform.anchoredPosition=home[i];cells[i].rectTransform.localScale=Vector3.one;glows[i].color=Color.clear;}
            if(popRoot!=null)popRoot.gameObject.SetActive(false);
        }
    }
}
