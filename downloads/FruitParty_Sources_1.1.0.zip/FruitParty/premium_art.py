from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import shutil,math,json,hashlib
r=Path(__file__).parent;a=r/'art';inputs=r/'inputs'
shutil.copy2('/workspace/generated_images/exec-47bfc386-03cd-4669-a05b-4bd9abdd43e3.png',inputs/'landscapes.png')
shutil.copy2('/workspace/generated_images/exec-3293c19c-3e85-49ec-908f-5166c151cc20.png',inputs/'premium-atlas.png')
im=Image.open(inputs/'landscapes.png').convert('RGBA');w,h=im.size
for name,box in [('bg',(0,0,w,h//2)),('bonusbg',(0,h//2,w,h))]:im.crop(box).save(a/(name+'.png'))
im=Image.open(inputs/'premium-atlas.png').convert('RGBA')
for name,box,target in [('scatter',(35,30,725,638),(512,512)),('logo',(735,135,1536,627),(960,576)),('panel',(20,665,748,945),(768,300)),('ribbon',(755,694,1536,952),(768,270))]:
 tile=im.crop(box);tile.thumbnail(target,Image.Resampling.LANCZOS);canvas=Image.new('RGBA',target);canvas.alpha_composite(tile,((target[0]-tile.width)//2,(target[1]-tile.height)//2));canvas.save(a/(name+'.png'))
font='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
# Original vector skins with opaque jewel faces and readable sculpted controls.
for name,label in [('spin',''),('minus','−'),('plus','+'),('turbo','»'),('auto','AUTO'),('info','≡'),('close','×')]:
 im=Image.new('RGBA',(256,256));d=ImageDraw.Draw(im)
 d.ellipse((8,11,247,250),fill='#321253');d.ellipse((8,5,247,244),fill='#ffe057');d.ellipse((16,13,239,234),fill='#ab631d');d.ellipse((22,18,234,226),fill='#fff2aa')
 for k in range(96):
  t=k/95;rgb=(int(254*(1-t)+153*t),int(72*(1-t)+13*t),int(190*(1-t)+142*t));d.ellipse((30+k*.20,26+k*.20,226-k*.20,222-k*.20),fill=rgb)
 d.arc((35,29,219,218),205,330,fill='#ffc7ec',width=8)
 if name=='spin':d.arc((65,60,195,187),200,500,fill='white',width=17);d.polygon([(201,146),(202,192),(158,183)],fill='white')
 else:
  f=ImageFont.truetype(font,51 if name=='auto' else 123);box=d.textbbox((0,0),label,font=f);x=(256-(box[2]-box[0]))/2-box[0];y=(256-(box[3]-box[1]))/2-box[1]-8;d.text((x+2,y+3),label,font=f,fill='#63255c',stroke_width=4,stroke_fill='#63255c');d.text((x,y),label,font=f,fill='#fff9e3')
 im.save(a/f'button_{name}.png')
# A single translucent rounded bottom bar; no alpha-faded round HUD buttons.
im=Image.new('RGBA',(1280,192));d=ImageDraw.Draw(im);d.rounded_rectangle((2,2,1278,190),radius=40,fill='#271340ee',outline='#ed9fe0',width=4);d.line((42,7,1238,7),fill='#ffed9b',width=3);im.save(a/'toolbar.png')
# Thin fruit-friendly grid. Each full illustration can occupy 90% of its tile.
im=Image.new('RGBA',(896,896));d=ImageDraw.Draw(im)
for col in range(7):
 for row in range(7):
  x=col*128;y=row*128;d.rectangle((x+2,y+2,x+126,y+126),fill='#e5fffb' if (row+col)%2==0 else '#f9fff1');d.line((x,y,x+128,y),fill='#97c3e4',width=3);d.line((x,y,x,y+128),fill='#97c3e4',width=3)
d.rounded_rectangle((3,3,893,893),radius=15,outline='#ffde61',width=7);d.rounded_rectangle((10,10,886,886),radius=10,outline='#8055ac',width=3);im.save(a/'grid.png')
# Original additive halo, ring and burst are tiny reusable particle textures.
for name in ['glow','ring','sparkle']:
 im=Image.new('RGBA',(128,128));px=im.load()
 for y in range(128):
  for x in range(128):
   u=(x-63.5)/63.5;v=(y-63.5)/63.5;radius=math.hypot(u,v)
   z=max(0,1-radius)**2 if name=='glow' else max(0,1-abs(radius-.72)/.11) if name=='ring' else max(0,1-radius)*max(0,1-min(abs(u),abs(v))*4)**4
   px[x,y]=(255,255,255,int(255*z))
 im.save(a/(name+'.png'))
im=Image.new('RGBA',(512,512),'#33194f');logo=Image.open(a/'logo.png');logo.thumbnail((480,430));im.alpha_composite(logo,((512-logo.width)//2,(512-logo.height)//2));im.save(a/'topscreen.png')
(r/'art-provenance.json').write_text(json.dumps({'symbols':'original glossy fruit art retained; golden scatter newly illustrated','landscapes':'new generated orchard and twilight fruit garden','ui':'new generated enamel logo/panels plus original procedural HUD controls/grid/particles','original_game_art_copied':False,'masters':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs.glob('*.png')}},indent=2))
print('Premium textures:',len(list(a.glob('*.png'))))
