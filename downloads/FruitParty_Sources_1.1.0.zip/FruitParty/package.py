from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,json,shutil
root=Path(__file__).parent;out=Path('/workspace/outputs');repo=Path('/workspace/AVEKERRIGAN')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
checks=json.loads((out/'FruitParty_Checks_1.1.0.json').read_text());assembly=json.loads((out/'FruitParty_Assembly_Checks_1.1.0.json').read_text());dll=root/'bin/Release/netstandard2.1/FruitParty.dll'
assert checks['pass'] and checks['rounds']==4000 and assembly['pass'] and sha(dll)==assembly['binary_sha256']
for name,expected in assembly['source_sha256'].items():assert sha(root/name)==expected
log=(root.parent/'fruitparty-build.log').read_text();assert 'Build succeeded.' in log and '0 Warning(s)' in log and '0 Error(s)' in log
shutil.copy2(root/'inputs/symbols.png',out/'FruitParty_Symbols_1.1.0.png')
install={'BepInEx/plugins/FruitParty/FruitParty.dll':dll,'README_RU.md':root/'README_RU.md','FruitParty_Symbols_1.1.0.png':out/'FruitParty_Symbols_1.1.0.png','validation/FruitParty_Checks_1.1.0.json':out/'FruitParty_Checks_1.1.0.json','validation/FruitParty_Assembly_Checks_1.1.0.json':out/'FruitParty_Assembly_Checks_1.1.0.json'}
manifest={'name':'FruitParty','version':'1.1.0','plugin_guid':'com.avekerrigan.fruitparty','game':'Gamble With Your Friends','all_players_need_same_version':True,'live_unity_verified':False,'live_coop_verified':False,'math':'Rules and paytable adapted from supplied references at BET $2. Custom symbol/multiplier probabilities; original RTP not claimed.','files':{name:{'bytes':p.stat().st_size,'sha256':sha(p)} for name,p in install.items()}}
archive=out/'FruitParty_1.1.0.zip'
with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in install.items():z.write(p,name)
 z.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2))
sources=out/'FruitParty_Sources_1.1.0.zip'
with ZipFile(sources,'w',ZIP_DEFLATED,compresslevel=9) as z:
 for folder in [root,root.parent/'FruitPartyChecks']:
  for p in folder.rglob('*'):
   if p.is_file() and not any(x in {'bin','obj','__pycache__'} for x in p.relative_to(folder).parts):z.write(p,str(p.relative_to(root.parent)))
 z.write(root.parent/'global.json','global.json')
 for p in [out/'FruitParty_Checks_1.1.0.json',out/'FruitParty_Assembly_Checks_1.1.0.json',root.parent/'fruitparty-checks.log',root.parent/'fruitparty-build.log']:z.write(p,'validation/'+p.name)
for p in [archive,sources]:
 with ZipFile(p) as z:assert z.testzip() is None
public=[archive,sources,out/'FruitParty_Symbols_1.1.0.png']
for p in public:shutil.copy2(p,repo/'downloads'/p.name)
shutil.copy2(root/'README_RU.md',repo/'README_FruitParty_RU.md')
readme=repo/'README.md';text=readme.read_text();section='''## Fruit Party 1.1.0 — отдельный слот

- [Скачать мод — ZIP](downloads/FruitParty_1.1.0.zip)
- [Новые рисунки символов](downloads/FruitParty_Symbols_1.1.0.png)
- [Исходники и графика](downloads/FruitParty_Sources_1.1.0.zip)
- [Установка, управление, правила](README_FruitParty_RU.md)

Поле 7×7, ортогональные кластеры от пяти символов, каскады,
множители x2/x4 с произведением до 256×, 10 фриспинов и покупка за 100×.
Повторный бонус 3–7 Scatter даёт +10–14 спинов. Лимит раунда 5000×.
Плавные цельные ленты и падение по реальным индексам, фиксированные цифры
множителей, отдельные итоговые иксы/деньги, правила и три скорости.
Хост создаёт автомат **F9**; всем игрокам нужна версия **1.1.0**.
Видео и отдельные превью интерфейса не создавались по просьбе пользователя.

Сборка без ошибок/предупреждений; 4000 раундов, более 3.6 млн проверок
движка/каскадов/анимационного времени, аудит встроенных ресурсов и разметки.
Живая Unity-сцена и реальный кооп не запускались. Таблица по снимкам,
частоты собственные; оригинальный RTP не заявляется.

'''
if '## Fruit Party ' in text:
 a=text.index('## Fruit Party ');b=text.index('## Hoarder ',a);text=text[:a]+text[b:]
assert '## Hoarder ' in text;text=text.replace('## Hoarder ',section+'## Hoarder ',1);readme.write_text(text)
sums=repo/'SHA256SUMS.txt';lines=sums.read_text().splitlines();names={p.name for p in public};lines=[line for line in lines if line.split('  ')[-1].split('/')[-1] not in names];lines.extend(sha(p)+'  downloads/'+p.name for p in public);sums.write_text('\n'.join(lines)+'\n')
for p in public:print(p.name,p.stat().st_size,sha(p))
print('PASS: install path, matching binary/source/checks, embedded art, archive CRC')
