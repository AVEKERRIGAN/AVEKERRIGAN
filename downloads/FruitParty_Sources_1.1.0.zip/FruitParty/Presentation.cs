using System;
namespace FruitParty
{
    // Stateless curves: late RPCs seek to the same pose without replaying effects.
    public static class FruitPartyPresentation
    {
        static float Clamp(float p)=>Math.Max(0,Math.Min(1,p));
        public static float Zoom(float progress)
        {float p=Clamp(progress);return p<.35f?1+.55f*FruitPartyTimeline.Ease(p/.35f):p<.65f?1.55f:1+.55f*(1-FruitPartyTimeline.Ease((p-.65f)/.35f));}
        public static float Landing(float seconds)
        {if(seconds<=0||seconds>=.32f)return 1;float p=seconds/.32f;return 1+.12f*(float)Math.Sin(p*Math.PI)*FruitPartyTimeline.Ease(1-p);}
        public static float Fall(float progress)
        {float p=Clamp(progress);if(p<.80f)return FruitPartyTimeline.Ease(p/.80f);float wave=(float)Math.Sin((p-.8f)/.2f*Math.PI);return 1-.025f*wave*wave;}
        public static float Pop(float progress)
        {float p=Clamp(progress);return .85f+.15f*FruitPartyTimeline.Ease(Math.Min(1,p/.20f))+.035f*(float)Math.Sin(Math.Min(1,p/.20f)*Math.PI);}
        public static int LastScatter(int[] grid)
        {for(int i=grid.Length-1;i>=0;i--)if(grid[i]==FruitPartyEngine.Scatter)return i;return -1;}
    }
}
