import bpy,math
from pathlib import Path
out=Path('/workspace/outputs');scene=bpy.context.scene;rig=bpy.data.objects['CartoonHandsRig']
scene.cycles.samples=24
import json
data=json.loads((out/'phone-1.2-model.json').read_text())
for f in data['Finishes']:
 mat=bpy.data.materials.get('Phone '+f['Name'])
 if mat:mat.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value=tuple(c/12.92 if c<=.04045 else ((c+.055)/1.055)**2.4 for c in [f['R'],f['G'],f['B']])+(1,)
bpy.ops.wm.save_as_mainfile(filepath=str(out/'CartoonHands_Prototype_0.1.blend'))
for kind in ['Fist','Point','PhoneGrip','PhoneSwipe']:
 rig.animation_data.action=bpy.data.actions['CartoonHands_'+kind];scene.frame_set(45)
 for obj in scene.objects:
  if obj.name.startswith('Phone '):obj.hide_render=kind.startswith('Phone') is False
 scene.render.filepath=str(out/('CartoonHands_'+kind+'_0.1.png'));bpy.ops.render.render(write_still=True)
# Export the same rig with the phone reference as a separately named scene node.
rig.animation_data.action=None
for pb in rig.pose.bones:pb.location=(0,0,0);pb.rotation_euler=(0,0,0)
bpy.data.objects['Phone grip reference']['prototypeRole']='phone-reference'
bpy.context.view_layer.update()
scene.frame_set(0)
bpy.ops.object.select_all(action='DESELECT');rig.select_set(True)
for obj in scene.objects:
 if obj.name.startswith('CartoonHand.') or obj.name.startswith('Phone '):obj.select_set(True)
bpy.ops.export_scene.gltf(filepath=str(out/'CartoonHands_Phone_Study_0.1.glb'),export_format='GLB',use_selection=True,export_animations=True,export_animation_mode='ACTIONS',export_skins=True,export_extras=True)
