import bpy,math,json
from mathutils import Vector
rig=bpy.data.objects['CartoonHandsRig'];rig.animation_data.action=bpy.data.actions['CartoonHands_PhoneGrip'];bpy.context.scene.frame_set(45)
con=rig.pose.bones['Thumb.03.L'].constraints[0];con.target.location=(-.034,.0165,.064);con.influence=1
results=[]
for angle in [0,math.pi/2,math.pi,-math.pi/2]:
 con.pole_angle=angle;bpy.context.view_layer.update();points=[];score=0
 for i,radius in [(1,.0088),(2,.0082),(3,.007)]:
  bone=rig.pose.bones[f'Thumb.{i:02}.L'];points.append(tuple(bone.tail))
  for j in range(11):
   p=bone.head.lerp(bone.tail,j/10);dx=max(abs(p.x)-.052,0);dy=max(abs(p.y)-.009,0);dz=max(.014-p.z,p.z-.226,0);distance=(dx*dx+dy*dy+dz*dz)**.5
   score+=max(0,radius-distance)**2
 results.append({'angle':angle,'score':score,'tails':points})
print('THUMB_PROBE',json.dumps(results))
