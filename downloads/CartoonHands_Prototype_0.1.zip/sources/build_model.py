"""Standalone five-finger cartoon hand study. No original game meshes are used."""
import bpy,math,json,sys
from mathutils import Vector,Quaternion,Euler,Matrix
from pathlib import Path
OUT=Path('/workspace/outputs');SRC=Path('/workspace/mod-work/CartoonHandsPrototype');OUT.mkdir(exist_ok=True)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
S=.8
mat=bpy.data.materials.new('Soft ivory cartoon glove');mat.use_nodes=True
bs=mat.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(.84,.805,.745,1);bs.inputs['Roughness'].default_value=.68
bs.inputs['Subsurface Weight'].default_value=.025
rig_data=bpy.data.armatures.new('CartoonHands 5-finger skeleton');rig=bpy.data.objects.new('CartoonHandsRig',rig_data);bpy.context.collection.objects.link(rig)
rig.show_in_front=True;bpy.context.view_layer.objects.active=rig;rig.select_set(True);bpy.ops.object.mode_set(mode='EDIT')
paths={};head_positions={}
for side,sign in [('R',1),('L',-1)]:
 origin=Vector((sign*.13,0,0));head_positions[side]=origin
 hand=rig_data.edit_bones.new('Hand.'+side);hand.head=origin;hand.tail=origin+Vector((0,0,.06*S))
 specifications=[('Index',-.036,.088,.063,.0105),('Middle',-.010,.094,.074,.0115),('Ring',.016,.092,.067,.0110),('Little',.041,.081,.051,.0092)]
 for name,x,z,length,radius in specifications:
  pts=[origin+Vector((x*sign,0,(z+length*t)*S)) for t in [0,.42,.76,1]]
  # Scale width and thickness as well as length.
  pts=[Vector((origin.x+(p.x-origin.x)*S,p.y,p.z)) for p in pts]
  paths[side,name]={'points':pts,'radius':radius*S}
 thumb=[(-.038,0,.047),(-.063,0,.060),(-.076,0,.077),(-.080,0,.096)]
 paths[side,'Thumb']={'points':[origin+Vector((x*sign*S,y*S,z*S)) for x,y,z in thumb],'radius':.011*S}
 for name in ['Thumb','Index','Middle','Ring','Little']:
  pts=paths[side,name]['points'];parent=hand
  for i in range(3):
   bone=rig_data.edit_bones.new(f'{name}.{i+1:02}.{side}');bone.head=pts[i];bone.tail=pts[i+1];bone.parent=parent;bone.use_connect=i>0;parent=bone
bpy.ops.object.mode_set(mode='OBJECT');rig.select_set(False)

def sphere(center,scale):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=24,ring_count=12,location=center)
 obj=bpy.context.object;obj.scale=scale;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return obj

def capsule(a,b,r1,r2):
 parts=[];d=b-a;mid=(a+b)/2
 bpy.ops.mesh.primitive_cone_add(vertices=20,radius1=r1,radius2=r2,depth=d.length,location=mid)
 ob=bpy.context.object;ob.rotation_mode='QUATERNION';ob.rotation_quaternion=Vector((0,0,1)).rotation_difference(d.normalized());bpy.ops.object.transform_apply(location=False,rotation=True,scale=True);parts.append(ob)
 parts.append(sphere(a,(r1,r1,r1)));parts.append(sphere(b,(r2,r2,r2)));return parts

def projection(point,a,b):
 ab=b-a;q=max(0,min(1,(point-a).dot(ab)/ab.length_squared));return (point-(a+ab*q)).length,q

report={'notice':'Prototype model and rig; no original game meshes/animations. Not installed in the game.', 'scaleStudy':S,'hands':[],'clips':[]}
for side,sign in [('R',1),('L',-1)]:
 origin=head_positions[side];parts=[]
 parts.append(sphere(origin+Vector((0,0,.058*S)),(.052*S,.018*S,.044*S)))
 parts.append(sphere(origin+Vector((0,0,.018*S)),(.026*S,.0135*S,.024*S)))
 for name in ['Thumb','Index','Middle','Ring','Little']:
  path=paths[side,name];pts=path['points'];r=path['radius']
  for i in range(3):parts+=capsule(pts[i],pts[i+1],r*(1-.06*i),r*(.94-.07*i))
 bpy.ops.object.select_all(action='DESELECT')
 for part in parts:part.select_set(True)
 bpy.context.view_layer.objects.active=parts[0];bpy.ops.object.join();mesh_obj=bpy.context.object;mesh_obj.name='CartoonHand.'+side
 # World-space coordinates simplify the bind-pose and weight checks below.
 bpy.ops.object.transform_apply(location=True,rotation=True,scale=True)
 mesh_obj.data.remesh_voxel_size=.00125;bpy.ops.object.voxel_remesh()
 smooth=mesh_obj.modifiers.new('Soft toy silhouette','SMOOTH');smooth.factor=.55;smooth.iterations=4;bpy.ops.object.modifier_apply(modifier=smooth.name)
 dec=mesh_obj.modifiers.new('Game mesh budget','DECIMATE');dec.ratio=.48;bpy.ops.object.modifier_apply(modifier=dec.name)
 for face in mesh_obj.data.polygons:face.use_smooth=True
 mesh_obj.data.materials.clear();mesh_obj.data.materials.append(mat)
 groups={name:mesh_obj.vertex_groups.new(name=name) for name in [f'Hand.{side}']+[f'{finger}.{i:02}.{side}' for finger in ['Thumb','Index','Middle','Ring','Little'] for i in range(1,4)]}
 counts={name:0 for name in ['Thumb','Index','Middle','Ring','Little']}
 for vertex in mesh_obj.data.vertices:
  p=vertex.co;winner=None
  for name in ['Thumb','Index','Middle','Ring','Little']:
   path=paths[side,name];pts=path['points'];distance=0;best=None;lengths=[(pts[i+1]-pts[i]).length for i in range(3)]
   for i in range(3):
    dist,q=projection(p,pts[i],pts[i+1]);progress=distance+q*lengths[i]
    if best is None or dist<best[0]:best=(dist,progress)
    distance+=lengths[i]
   score=best[0]/path['radius']
   if best[1]>.0002 and score<1.55 and (winner is None or score<winner[0]):winner=(score,name,best[1],lengths)
  weights={f'Hand.{side}':1}
  if winner:
   _,name,progress,lengths=winner;counts[name]+=1
   centers=[lengths[0]/2,lengths[0]+lengths[1]/2,lengths[0]+lengths[1]+lengths[2]/2]
   palm=max(0,1-progress/(paths[side,name]['radius']*1.65));finger={}
   if progress<=centers[0]:finger[1]=1
   elif progress>=centers[2]:finger[3]=1
   else:
    j=0 if progress<centers[1] else 1;q=(progress-centers[j])/(centers[j+1]-centers[j]);finger[j+1]=1-q;finger[j+2]=q
   weights={f'Hand.{side}':palm,**{f'{name}.{i:02}.{side}':w*(1-palm) for i,w in finger.items()}}
  assert abs(sum(weights.values())-1)<1e-6
  for name,w in weights.items():
   if w>1e-7:groups[name].add([vertex.index],w,'REPLACE')
 mod=mesh_obj.modifiers.new('Finger skin','ARMATURE');mod.object=rig;mesh_obj.parent=rig
 mesh_obj.data.calc_loop_triangles();report['hands'].append({'side':side,'vertices':len(mesh_obj.data.vertices),'triangles':len(mesh_obj.data.loop_triangles),'fingerVertices':counts})
 assert all(n>40 for n in counts.values())

# Import the exact existing phone geometry; used only as a grip reference.
phone=bpy.data.objects.new('Phone grip reference',None);bpy.context.collection.objects.link(phone);phone.location=(0,0,.12)
phone.hide_render=True
phone_materials={}
data=json.loads((OUT/'phone-1.2-model.json').read_text())
for f in data['Finishes']:
 m=bpy.data.materials.new('Phone '+f['Name']);m.use_nodes=True;n=m.node_tree.nodes.get('Principled BSDF');n.inputs['Base Color'].default_value=tuple(c/12.92 if c<=.04045 else ((c+.055)/1.055)**2.4 for c in [f['R'],f['G'],f['B']])+(1,);n.inputs['Metallic'].default_value=f['Metallic'];n.inputs['Roughness'].default_value=1-f['Smoothness'];phone_materials[f['Name']]=m
for p in data['Parts']:
 vertices=[(v['X'], -v['Z'],v['Y']) for v in p['Mesh']['Vertices']];t=p['Mesh']['Triangles']
 mesh=bpy.data.meshes.new('Phone '+p['Name']);mesh.from_pydata(vertices,[],[tuple(t[i:i+3]) for i in range(0,len(t),3)]);mesh.update()
 obj=bpy.data.objects.new('Phone '+p['Name'],mesh);bpy.context.collection.objects.link(obj);obj.parent=phone;obj.location=(p['X'],-p['Z'],p['Y'])
 # Rotation conversion C * R * C^-1, with C mapping Unity Y-up to Blender Z-up.
 from mathutils import Matrix
 C=Matrix(((1,0,0),(0,0,-1),(0,1,0)))
 # Unity Quaternion.Euler applies Z, then X, then Y. Matrices act on column vectors.
 R=Matrix.Rotation(math.radians(p['Ry']),3,'Y')@Matrix.Rotation(math.radians(p['Rx']),3,'X')@Matrix.Rotation(math.radians(p['Rz']),3,'Z')
 obj.rotation_mode='QUATERNION';obj.rotation_quaternion=(C@R@C.inverted()).to_quaternion();obj.data.materials.append(phone_materials[p['Finish']]);obj.hide_render=True
 for face in obj.data.polygons:face.use_smooth=True

for pb in rig.pose.bones:pb.rotation_mode='XYZ'
thumb_ik={};thumb_targets={};contact_errors=[]
for side in ['R','L']:
 target=bpy.data.objects.new('Thumb contact target '+side,None);bpy.context.collection.objects.link(target)
 con=rig.pose.bones['Thumb.03.'+side].constraints.new('IK');con.target=target;con.chain_count=3;con.use_tail=True;con.use_stretch=False;con.influence=0
 pole=bpy.data.objects.new('Thumb front pole '+side,None);bpy.context.collection.objects.link(pole);pole.location=(.15 if side=='R' else -.15,.20 if side=='R' else -.20,.07)
 con.pole_target=pole;con.pole_angle=math.pi if side=='R' else 0
 thumb_ik[side]=con;thumb_targets[side]=target
def smooth(t):return max(0,min(1,t))**2*(3-2*max(0,min(1,t)))
def pose(kind,t):
 for pb in rig.pose.bones:pb.location=(0,0,0);pb.rotation_euler=(0,0,0)
 weight=0;swipe=0
 if kind in ['PhoneGrip','PhoneSwipe']:
  weight=smooth(t/.6)*smooth((3-t)/.6)
  if kind=='PhoneSwipe':swipe=math.sin(math.pi*max(0,min(1,(t-1)/.8))) if 1<t<1.8 else 0
 elif kind in ['Fist','Point']:weight=smooth(t/.55)*smooth((3-t)/.55)
 for side,sign in [('R',1),('L',-1)]:
  root=rig.pose.bones['Hand.'+side]
  if kind in ['PhoneGrip','PhoneSwipe']:
   delta=Vector((sign*(.080-.13)*weight,-.040*weight,.010*weight))
   if side=='R':delta+=Vector((-swipe*.005,swipe*.005,swipe*.028))
   root.location=root.bone.matrix_local.to_quaternion().inverted()@delta;root.rotation_euler.y=-sign*1.10*weight
  elif kind=='Wave':root.rotation_euler.z=sign*math.sin(t*2*math.pi)*.22*smooth(t/.3)*smooth((3-t)/.3)
  for name in ['Thumb','Index','Middle','Ring','Little']:
   if kind=='Idle':angles=[1.5+math.sin(t*2*math.pi/3+sign)*1.5,2,0]
   elif kind in ['PhoneGrip','PhoneSwipe']:
    angles={'Thumb':[-40,-55,-15],'Index':[52,48,28],'Middle':[60,58,35],'Ring':[64,64,40],'Little':[68,70,42]}[name]
    angles=[x*weight for x in angles]
    if side=='R' and name=='Thumb':angles=[angles[0]-swipe*18,angles[1]+swipe*22,angles[2]+swipe*5]
   elif kind in ['Fist','Point']:
    angles=([20,35,15] if name=='Thumb' else [72,88,40]);angles=[x*weight for x in angles]
    if kind=='Point' and name=='Index':angles=[0,0,0]
   else:angles=[5,8,3]
   for i,angle in enumerate(angles):rig.pose.bones[f'{name}.{i+1:02}.{side}'].rotation_euler.x=math.radians(angle)
 bpy.context.view_layer.update()
 if kind in ['PhoneGrip','PhoneSwipe']:
  for side,sign in [('R',1),('L',-1)]:
   base=rig.pose.bones['Thumb.01.'+side]
   base.matrix=Matrix.Translation(Vector((0,.014*weight if side=='R' else 0,0)))@base.matrix
   bpy.context.view_layer.update()
   contact=Vector((sign*(.044-(.010*swipe if side=='R' else .010)),.0165 if side=='R' else -.026,.064+(.03*swipe if side=='R' else .004)))
   rest=paths[side,'Thumb']['points'][-1]
   thumb_targets[side].location=rest.lerp(contact,weight);thumb_ik[side].influence=weight
  bpy.context.view_layer.update()
  solved={side:[rig.pose.bones[f'Thumb.{i:02}.{side}'].matrix.copy() for i in range(1,4)] for side in ['R','L']}
  for con in thumb_ik.values():con.influence=0
  bpy.context.view_layer.update()
  for side in ['R','L']:
   for i in range(1,4):
    rig.pose.bones[f'Thumb.{i:02}.{side}'].matrix=solved[side][i-1];bpy.context.view_layer.update()
   if weight>.999:
    tip=rig.pose.bones['Thumb.03.'+side].tail
    contact_errors.append((tip-thumb_targets[side].location).length)
  # IK is baked to ordinary bone transforms; the exported clips need no solver.

scene=bpy.context.scene;scene.render.fps=30;scene.frame_start=0;scene.frame_end=90
if not rig.animation_data:rig.animation_data_create()
actions={}
for kind in ['Idle','PhoneGrip','PhoneSwipe','Fist','Point','Wave']:
 action=bpy.data.actions.new('CartoonHands_'+kind);rig.animation_data.action=action
 for frame in range(0,91,3):
  t=frame/30;pose(kind,t)
  for pb in rig.pose.bones:pb.keyframe_insert('rotation_euler',frame=frame,group=pb.name);pb.keyframe_insert('location',frame=frame,group=pb.name)
 track=rig.animation_data.nla_tracks.new();track.name=action.name;strip=track.strips.new(action.name,0,action);track.mute=True;actions[kind]=action
 report['clips'].append({'name':action.name,'duration':3,'frames':91,'animatedBones':32})
rig.animation_data.action=None;pose('Idle',0)
# No materials, sockets or animation bindings from the game's original rig are assumed.
report['bones']=len(rig.data.bones);assert report['bones']==32
report['thumbContactMaxError']=max(contact_errors,default=0)
assert report['thumbContactMaxError']<.004,report['thumbContactMaxError']
for ob in [o for o in scene.objects if o.type=='MESH' and o.name.startswith('CartoonHand.')]:
 for v in ob.data.vertices:
  assert 1<=len(v.groups)<=3 and abs(sum(g.weight for g in v.groups)-1)<1e-4
 for triangle in ob.data.loop_triangles:
  a,b,c=[ob.data.vertices[i].co for i in triangle.vertices];assert (b-a).cross(c-a).length>1e-12
report['validation']='PASS: 2 hands, 5 weighted fingers per hand, 32 bones, 6 clips; every vertex normalized to <=3 influences, finite nondegenerate triangles.'
(OUT/'CartoonHands_Prototype_0.1-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
bpy.ops.object.select_all(action='DESELECT');rig.select_set(True)
for obj in scene.objects:
 if obj.name.startswith('CartoonHand.'):obj.select_set(True)
# Export all action clips as individual glTF animations.
bpy.ops.export_scene.gltf(filepath=str(OUT/'CartoonHands_Prototype_0.1.glb'),export_format='GLB',use_selection=True,export_animations=True,export_animation_mode='ACTIONS',export_skins=True,export_extras=True)

# Studio scene: a neutral background, soft shadows, no simulated game graphics.
world=scene.world;world.color=(.09,.09,.09);world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(.055,.068,.095,1);world.node_tree.nodes['Background'].inputs[1].default_value=.5
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.025));floor=bpy.context.object;floor.name='Studio floor';fm=bpy.data.materials.new('Studio charcoal');fm.diffuse_color=(.045,.055,.075,1);floor.data.materials.append(fm)
def area(name,location,power,size):
 bpy.ops.object.light_add(type='AREA',location=location);l=bpy.context.object;l.name=name;l.data.energy=power;l.data.shape='DISK';l.data.size=size;l.rotation_euler=(Vector((0,0,.085))-l.location).to_track_quat('-Z','Y').to_euler()
area('Large soft key',(-.25,.30,.45),8,.35);area('Cool fill',(.30,.05,.30),3,.25);area('Rim',(.1,-.20,.35),5,.22)
bpy.ops.object.camera_add(location=(.22,.53,.27));cam=bpy.context.object;cam.rotation_euler=(Vector((0,0,.087))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=.405;scene.camera=cam
scene.render.engine='CYCLES';scene.cycles.samples=32;scene.cycles.use_denoising=False
scene.render.resolution_x=960;scene.render.resolution_y=720;scene.render.resolution_percentage=100
scene.view_settings.view_transform='AgX';scene.render.image_settings.file_format='PNG';scene.render.film_transparent=False
# Keep all animation tracks present, enabling the selected action explicitly for renders.
rig.animation_data.action=actions['Idle'];scene.frame_set(0)
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'CartoonHands_Prototype_0.1.blend'))
scene.render.filepath=str(OUT/'CartoonHands_Open_0.1.png');bpy.ops.render.render(write_still=True)
print(report['validation']);print(json.dumps(report['hands']))
