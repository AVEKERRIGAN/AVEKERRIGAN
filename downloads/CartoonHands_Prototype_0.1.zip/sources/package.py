from pathlib import Path
import zipfile,json,hashlib,shutil,subprocess
root=Path('/workspace/mod-work');src=root/'CartoonHandsPrototype';out=Path('/workspace/outputs');repo=Path('/workspace/AVEKERRIGAN')
assert 'PASS: 114591 assertions' in (root/'cartoon-hands-validation.log').read_text()
assert 'PASS: 32 rig bones, 6 actual glTF clips, 540 frames' in (root/'cartoon-hands-preview.log').read_text()
info=json.loads((out/'CartoonHands_Capture_0.1.json').read_text())
assert hashlib.sha256((out/'CartoonHands_Phone_Study_0.1.glb').read_bytes()).hexdigest()==info['glbSha256']
assert hashlib.sha256((out/'CartoonHands_3D_Preview_0.1.html').read_bytes()).hexdigest()==info['htmlSha256']
assert len(list(Path(info['frameDirectory']).glob('*.png')))==540
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_entries','stream=nb_frames,width,height,duration','-of','json',str(out/'CartoonHands_Animations_0.1.mp4')]))['streams'][0]
assert probe['nb_frames']=='540' and abs(float(probe['duration'])-18)<.01 and probe['width']==960 and probe['height']==720
files=['CartoonHands_Prototype_0.1.glb','CartoonHands_Phone_Study_0.1.glb','CartoonHands_Prototype_0.1.blend','CartoonHands_3D_Preview_0.1.html','CartoonHands_Animations_0.1.mp4']
files+=[f'CartoonHands_Viewer_{kind}_0.1.png' for kind in ['Open','Fist','Point','Wave','PhoneGrip','PhoneSwipe']]
manifest={name:{'bytes':(out/name).stat().st_size,'sha256':hashlib.sha256((out/name).read_bytes()).hexdigest()} for name in files}
with zipfile.ZipFile(out/'CartoonHands_Prototype_0.1.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name in files:z.write(out/name,name)
 z.write(src/'README_RU.md','README_RU.md');z.writestr('manifest.json',json.dumps(manifest,indent=2))
 for file in sorted(src.rglob('*')):
  if file.is_file() and file.suffix in {'.py','.mjs','.html','.js','.json','.txt'}:z.write(file,'sources/'+str(file.relative_to(src)))
 z.write(out/'phone-1.2-model.json','sources/inputs/phone-1.2-model.json')
 for name in ['CartoonHands_Prototype_0.1-report.json','CartoonHands_Capture_0.1.json','CartoonHands_GLB_Validation_0.1.json','CartoonHands_Reuse_0.1.json']:z.write(out/name,'validation/'+name)
 for name in ['cartoon-hands-build.log','cartoon-hands-stills.log','cartoon-hands-validation.log','cartoon-hands-preview.log']:z.write(root/name,'validation/'+name)
for name in ['CartoonHands_Prototype_0.1.zip','CartoonHands_Animations_0.1.mp4','CartoonHands_Viewer_Open_0.1.png','CartoonHands_Viewer_PhoneGrip_0.1.png']:
 file=out/name
 if name.endswith('.zip'):
  with zipfile.ZipFile(file) as z:assert z.testzip() is None
 assert file.stat().st_size<100*1024*1024
 shutil.copy2(file,repo/'downloads'/name);print(name,file.stat().st_size,hashlib.sha256(file.read_bytes()).hexdigest())
shutil.copy2(src/'README_RU.md',repo/'README_CartoonHands_RU.md')
p=repo/'README.md';s=p.read_text();intro='''## Cartoon Hands — 3D-прототип пяти пальцев, 0.1

- [Модель, анимации и интерактивный просмотр — ZIP](downloads/CartoonHands_Prototype_0.1.zip)
- [Все шесть анимаций — MP4, 18 секунд](downloads/CartoonHands_Animations_0.1.mp4)
- [Открытые руки — изображение](downloads/CartoonHands_Viewer_Open_0.1.png)
- [Хват телефона — изображение](downloads/CartoonHands_Viewer_PhoneGrip_0.1.png)
- [Что готово, просмотр и ограничения](README_CartoonHands_RU.md)

Две мультяшные руки с пятью пальцами, 32 кости. Клипы: спокойная ладонь,
кулак, указательный жест, помахивание, хват телефона и свайп большим пальцем.
HTML в архиве открывает настоящие GLB-анимации офлайн, с выбором жеста,
вращением модели и ползунком времени. Есть GLB, Blender-сцена и исходники.

Это отдельный 3D-прототип для последующего мода. Замена рук в игре,
совместимость с её анимациями и синхронизация в коопе ещё не подключены:
для следующего этапа нужны игровые модели и скелеты или данные из запущенной игры.
Видеоролик снят с отдельного просмотра модели, без запуска игры.
114 591 проверка экспортированных данных; проверены браузерные кнопки и 540 кадров.

'''
a=s.index('## Money Train');s=s[:a]+intro+s[a:];p.write_text(s)
p=repo/'SHA256SUMS.txt';lines=p.read_text().splitlines()
names=['CartoonHands_Prototype_0.1.zip','CartoonHands_Animations_0.1.mp4','CartoonHands_Viewer_Open_0.1.png','CartoonHands_Viewer_PhoneGrip_0.1.png']
lines=[l for l in lines if not any(l.endswith('downloads/'+n) for n in names)]
for n in names:lines.append(hashlib.sha256((out/n).read_bytes()).hexdigest()+'  downloads/'+n)
p.write_text('\n'.join(lines)+'\n')
