from pathlib import Path
import json,struct,math,hashlib
out=Path('/workspace/outputs');checks=0

def require(value,name):
 global checks
 checks+=1
 if not value:raise AssertionError(name)

def parse(path):
 raw=path.read_bytes();require(raw[:4]==b'glTF' and struct.unpack_from('<I',raw,4)[0]==2,'GLB 2.0 header');require(struct.unpack_from('<I',raw,8)[0]==len(raw),'GLB exact byte length')
 length=struct.unpack_from('<I',raw,12)[0];g=json.loads(raw[20:20+length]);offset=20+length;blob=raw[offset+8:]
 def acc(i):
  a=g['accessors'][i];view=g['bufferViews'][a['bufferView']];offset=view.get('byteOffset',0)+a.get('byteOffset',0)
  typ={5121:'B',5123:'H',5125:'I',5126:'f'}[a['componentType']];n={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}[a['type']];size=struct.calcsize(typ);stride=view.get('byteStride',size*n)
  return [struct.unpack_from('<'+typ*n,blob,offset+j*stride) for j in range(a['count'])]
 return g,acc
for filename,expected_meshes in [('CartoonHands_Prototype_0.1.glb',2),('CartoonHands_Phone_Study_0.1.glb',64)]:
 path=out/filename;g,acc=parse(path);require(len(g['skins'])==1 and len(g['skins'][0]['joints'])==32,'two hands have 32 finger/hand bones');require(len(g['meshes'])==expected_meshes,'mesh count')
 joints=g['skins'][0]['joints'];names=[g['nodes'][i]['name'] for i in joints]
 for side in ['R','L']:
  for finger in ['Thumb','Index','Middle','Ring','Little']:
   require(all(f'{finger}.{i:02}.{side}' in names for i in range(1,4)),'three joints per finger')
 for mesh in g['meshes']:
  for prim in mesh['primitives']:
   positions=acc(prim['attributes']['POSITION']);indices=acc(prim['indices'])
   require(all(all(math.isfinite(v) for v in p) for p in positions),'finite exported positions');require(all(0<=i[0]<len(positions) for i in indices),'valid triangle indices')
   if 'WEIGHTS_0' in prim['attributes']:
    weights=acc(prim['attributes']['WEIGHTS_0']);bones=acc(prim['attributes']['JOINTS_0']);require(len(weights)==len(positions)==len(bones),'skin attribute counts')
    for w,b in zip(weights,bones):
     require(abs(sum(w)-1)<1e-5 and all(0<=v<=1 for v in w),'normalized exported skin weights')
     require(sum(v>1e-7 for v in w)<=3 and all(0<=j<32 for j in b),'valid normalized <=3 bone influences')
 expected={'CartoonHands_'+x for x in ['Idle','Fist','Point','Wave','PhoneGrip','PhoneSwipe']}
 require({a['name'] for a in g['animations']}==expected,'six exported playable clips')
 for clip in g['animations']:
  require(len(clip['channels'])==96,'all 32 bones have rotation/translation/scale channels')
  for sampler in clip['samplers']:
   times=[t[0] for t in acc(sampler['input'])];values=acc(sampler['output']);require(abs(min(times))<1e-6 and abs(max(times)-3)<1e-6,'exact three second clip')
   require(all(a<b for a,b in zip(times,times[1:])),'ordered sample times');require(all(all(math.isfinite(x) for x in row) for row in values),'finite exported animation values')
  for channel in clip['channels']:
   if channel['target']['path']=='rotation':
    sampler=clip['samplers'][channel['sampler']]
    for q in acc(sampler['output']):require(abs(sum(x*x for x in q)-1)<1e-4,'unit animation quaternions')
report=json.loads((out/'CartoonHands_Prototype_0.1-report.json').read_text());require(report['thumbContactMaxError']<.004,'baked support/contact error below 4mm at sampled hold poses')
summary=f'PASS: {checks} assertions. Exported GLBs: mesh/index bounds, 32 joints, five fingers per hand, skin weights, six 3-second clips, finite samples and unit quaternions. No game binding or live coop tested.'
print(summary)
(out/'CartoonHands_GLB_Validation_0.1.json').write_text(json.dumps({'assertions':checks,'result':summary,'glbSha256':{name:hashlib.sha256((out/name).read_bytes()).hexdigest() for name in ['CartoonHands_Prototype_0.1.glb','CartoonHands_Phone_Study_0.1.glb']}},indent=2))
