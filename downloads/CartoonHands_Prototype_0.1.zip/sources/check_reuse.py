from pathlib import Path
import json,struct,hashlib

def glb(path):
 raw=Path(path).read_bytes();length=struct.unpack_from('<I',raw,12)[0];g=json.loads(raw[20:20+length]);offset=20+length;binary=raw[offset+8:];return g,binary

def fingerprint(path):
 g,blob=glb(path)
 def acc(index):
  a=g['accessors'][index];v=g['bufferViews'][a['bufferView']];off=v.get('byteOffset',0)+a.get('byteOffset',0)
  scalar={5120:1,5121:1,5122:2,5123:2,5125:4,5126:4}[a['componentType']];n={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}[a['type']]
  return {'count':a['count'],'type':a['type'],'component':a['componentType'],'sha':hashlib.sha256(blob[off:off+a['count']*n*scalar]).hexdigest()}
 meshes=[{'name':m.get('name'),'primitives':[{'attributes':{k:acc(v) for k,v in p['attributes'].items()},'indices':acc(p['indices']),'material':g['materials'][p['material']]} for p in m['primitives']]} for m in g['meshes']]
 nodes=[{k:v for k,v in n.items() if k not in ['extras']} for n in g['nodes']]
 skins=[{'joints':s['joints'],'bind':acc(s['inverseBindMatrices'])} for s in g['skins']]
 clips={a['name']:{'samplers':[{'input':acc(s['input']),'output':acc(s['output']),'interpolation':s.get('interpolation','LINEAR')} for s in a['samplers']],'channels':a['channels']} for a in g['animations'] if a['name'] in ['CartoonHands_Idle','CartoonHands_Fist','CartoonHands_Point','CartoonHands_Wave']}
 return {'meshes':meshes,'nodes':nodes,'skins':skins,'clips':clips}
old=fingerprint('/tmp/cartoon-hands-baseline.glb');new=fingerprint('/workspace/outputs/CartoonHands_Phone_Study_0.1.glb')
okay=old==new
report={'unchangedHandGeometryRigAndFourClips':okay,'reusedFrames':360 if okay else 0,'baselineSha256':hashlib.sha256(Path('/tmp/cartoon-hands-baseline.glb').read_bytes()).hexdigest(),'newSha256':hashlib.sha256(Path('/workspace/outputs/CartoonHands_Phone_Study_0.1.glb').read_bytes()).hexdigest()}
Path('/workspace/outputs/CartoonHands_Reuse_0.1.json').write_text(json.dumps(report,indent=2));print('Validated reusable frames:',report['reusedFrames'])
