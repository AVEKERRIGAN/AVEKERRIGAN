from pathlib import Path
import json,base64
root=Path('/workspace/mod-work/CartoonHandsPrototype');out=Path('/workspace/outputs')
modules={name:base64.b64encode((root/'vendor'/file).read_bytes()).decode() for name,file in [('three','three.module.js'),('utils','BufferGeometryUtils.js'),('loader','GLTFLoader.js')]}
s=(root/'viewer_template.html').read_text().replace('__MODULES__',json.dumps(modules)).replace('__MODEL__',base64.b64encode((out/'CartoonHands_Phone_Study_0.1.glb').read_bytes()).decode())
(out/'CartoonHands_3D_Preview_0.1.html').write_text(s)
