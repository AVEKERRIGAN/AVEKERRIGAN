using System.Diagnostics;
using FreshBoombox;
using Newtonsoft.Json.Linq;
using Mirror;
using UnityEngine;

if(!OperatingSystem.IsLinux())throw new PlatformNotSupportedException("These process integration checks require Linux and ffmpeg.");
int assertions=0;
void Check(bool test,string name){assertions++;if(!test)throw new Exception(name);}
void Drain(){for(int i=0;i<100&&YouTube.Main.TryDequeue(out var action);i++)action();}
async Task Until(Func<bool> test,string name,int timeout=5000){var timer=Stopwatch.StartNew();while(!test()){Drain();if(timer.ElapsedMilliseconds>timeout)throw new Exception("Timeout: "+name);await Task.Delay(10);}Drain();assertions++;}
string Unquote(string argument){var b=new System.Text.StringBuilder();for(int i=0;i<argument.Length;){int slash=0;while(i<argument.Length&&argument[i]=='\\'){slash++;i++;}if(i<argument.Length&&argument[i]=='"'){b.Append('\\',slash/2);if(slash%2==1)b.Append('"');i++;}else{b.Append('\\',slash);if(i<argument.Length)b.Append(argument[i++]);}}return b.ToString();}
foreach(string value in new[]{"","a b","C:\\Game Mods\\колонка\\deno.exe","trailing\\","quote\"inside","https://example.invalid/?a=1&b=2","$()`\\'x"})Check(Unquote(ToolRunner.Quote(value))==value,"Windows command line quoting");
Check(!ToolRunner.SafeError("ERROR https://media.example.invalid/?signature=secret Cookie=private").Contains("secret")&&!ToolRunner.SafeError("Cookie=private").Contains("private"),"signed URLs/cookies redacted");
var aim=ThrowMotion.Normalize(4,0,3);Check(Math.Abs(aim.X-.8f)<1e-6&&Math.Abs(aim.Z-.6f)<1e-6,"look direction normalized");
Check(ThrowMotion.Normalize(float.NaN,0,0).Z==1&&ThrowMotion.Normalize(float.PositiveInfinity,1,1).Z==1,"bad direction cannot enter physics");
Check(ThrowMotion.Near(1,2,3,1,2,3)&&!ThrowMotion.Near(float.NaN,0,0,0,0,0)&&!ThrowMotion.Near(100,0,0,0,0,0),"camera origin validated against holder");
var thrown=ThrowMotion.Velocity(0,0,1,7.5f,0,0,0);Check(thrown.Z==7.5f&&thrown.Y==1.2f,"throw has forward and upward velocity");
var clamped=ThrowMotion.Velocity(0,0,1,float.NaN,1000,float.NaN,float.PositiveInfinity);Check(clamped.X==3&&clamped.Z==7.5f&&clamped.Y==1.2f,"invalid speed and carry bounded");
float a=1-ThrowMotion.Smooth(.01f),b=1-ThrowMotion.Smooth(.02f);Check(Math.Abs(a*a-b)<1e-6,"snapshot smoothing frame-independent");
var headers=JObject.Parse("{\"User-Agent\":\"Test agent\",\"Referer\":\"https://youtube.com/\",\"Origin\":\"https://youtube.com\",\"Cookie\":\"secret\",\"Accept\":\"bad\\r\\nInjected: value\"}");
var arguments=YouTube.AudioArguments("https://example.invalid/audio",headers);
Check(arguments.Contains("-user_agent")&&arguments.Contains("Test agent"),"extractor User-Agent forwarded");
Check(arguments.Contains("Referer: https://youtube.com/\r\nOrigin: https://youtube.com\r\n")&&!arguments.Any(s=>s.Contains("secret")||s.Contains("Injected")),"headers filtered and CRLF injection blocked");
Wire.Install();
using(var writer=NetworkWriterPool.Get()){
 var m=new BoxRequestV32{action=3,id=5,text="Бросок",origin=new Vector3(1,2,3),direction=new Vector3(.8f,0,.6f)};Writer<BoxRequestV32>.write(writer,m);using var reader=NetworkReaderPool.Get(writer.ToArraySegment());var n=Reader<BoxRequestV32>.read(reader);Check(n.action==3&&n.origin.y==2&&n.direction.z==.6f&&n.text==m.text,"co-op throw carries camera origin and aim");
}
using(var writer=NetworkWriterPool.Get()){
 var m=new BoxStateV32{scale=1.25f,id=9,owner=11,epoch=3,loading=true,status="Подключаю звук…",title="Музыка",velocity=new Vector3(0,1.2f,7.5f),rotation=Quaternion.identity};Writer<BoxStateV32>.write(writer,m);using var reader=NetworkReaderPool.Get(writer.ToArraySegment());var n=Reader<BoxStateV32>.read(reader);Check(n.scale==1.25f&&n.loading&&!n.playing&&n.status==m.status&&n.velocity.z==7.5f&&n.owner==11,"co-op status and velocity serialize");
}
using(var writer=NetworkWriterPool.Get()){
 Writer<BoxNoticeV32>.write(writer,new BoxNoticeV32{id=2,text="Подойдите ближе"});using var reader=NetworkReaderPool.Get(writer.ToArraySegment());var n=Reader<BoxNoticeV32>.read(reader);Check(n.id==2&&n.text=="Подойдите ближе","rejection notice visible to requester");
}
string tools=Path.Combine(Path.GetTempPath(),"JBL tools с пробелом "+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(tools);YouTube.Tools=tools;
async Task Mode(string mode)=>await File.WriteAllTextAsync(Path.Combine(tools,"mode.txt"),mode);
string script="""
#!/usr/bin/python3
import sys,os,json,time,struct
base=os.path.dirname(__file__)
mode=open(os.path.join(base,'mode.txt')).read()
args=sys.argv[1:]
name=os.path.basename(__file__)
if name=='yt-dlp.exe':
 if '--flat-playlist' in args:
  if mode=='searchhang': time.sleep(5)
  if mode=='searcherror': print('ERROR: upstream denied https://youtube.com/?token=hidden',file=sys.stderr);sys.exit(2)
  print(json.dumps({'id':'dQw4w9WgXcQ','title':'Тестовый трек 🦊','duration':180},ensure_ascii=False))
  print(json.dumps({'id':'abcdefghijk','title':'Без длительности','duration':None},ensure_ascii=False))
 else:
  assert '--dump-single-json' in args
  assert args[args.index('--js-runtimes')+1]=='deno:'+os.path.join(base,'deno.exe')
  if mode=='linkhang':time.sleep(5)
  if mode=='linkerror':print('ERROR: HTTP 403 https://media.example.invalid/?signature=secret',file=sys.stderr);sys.exit(2)
  print(json.dumps({'url':'https://media.example.invalid/audio?signature=secret','http_headers':{'User-Agent':'JBL Test Agent/1','Referer':'https://youtube.com/'}}))
else:
 assert '-user_agent' in args and args[args.index('-user_agent')+1]=='JBL Test Agent/1'
 assert '-i' in args and args[args.index('-i')+1]=='https://media.example.invalid/audio?signature=secret'
 if mode=='firsthang':time.sleep(5)
 if mode=='audioerror':print('ERROR: decoder refused https://media.example.invalid/?token=private',file=sys.stderr);sys.exit(7)
 if mode=='real':os.execv('/usr/bin/ffmpeg',['ffmpeg','-nostdin','-hide_banner','-loglevel','error','-re','-f','lavfi','-i','sine=frequency=880:duration=0.6']+args[args.index('-i')+2:])
 for i in range(12):
  sys.stdout.buffer.write(struct.pack('<h',8192)*480);sys.stdout.buffer.flush()
  if mode=='stall':time.sleep(5)
  time.sleep(0.01)
""";
foreach(string name in new[]{"yt-dlp.exe","ffmpeg.exe"}){var p=Path.Combine(tools,name);await File.WriteAllTextAsync(p,script);File.SetUnixFileMode(p,UnixFileMode.UserRead|UnixFileMode.UserWrite|UnixFileMode.UserExecute);}
await File.WriteAllTextAsync(Path.Combine(tools,"deno.exe"),"placeholder for runtime path validation");
YouTube.SearchLimit=YouTube.LinkLimit=YouTube.FirstAudioLimit=YouTube.StallLimit=TimeSpan.FromMilliseconds(350);
try{
 await Mode("normal");Track[] tracks=null;string searchError=null;
 YouTube.Search("песня с пробелами",t=>tracks=t,e=>searchError=e);await Until(()=>tracks!=null||searchError!=null,"search results");Check(searchError==null&&tracks.Length==2&&tracks[0].title.Contains("🦊")&&tracks[1].duration==0,"Unicode search and null duration");
 foreach(string mode in new[]{"searchhang","searcherror"}){await Mode(mode);searchError=null;tracks=null;YouTube.Search("test",t=>tracks=t,e=>searchError=e);await Until(()=>searchError!=null,"search error "+mode);Check(tracks==null&&!searchError.Contains("hidden"),"bounded search reports safe error");}
 async Task<(string Message,int Packets,int Stages)> Play(string mode)
 {
  await Mode(mode);string done=null;int count=0,stages=0;
  YouTube.Play(1,1,"dQw4w9WgXcQ",p=>{Check(p.Length>0&&p.Length<=960&&(p.Length&1)==0,"valid PCM packet");Interlocked.Increment(ref count);},e=>done=e,_=>stages++);
  await Until(()=>done!=null,"play "+mode);return(done,count,stages);
 }
 var success=await Play("normal");Check(success.Message=="Трек завершён"&&success.Packets==12&&success.Stages==2,"metadata, headers and audio pipeline");
 foreach(string mode in new[]{"linkhang","firsthang","stall","linkerror","audioerror"}){var result=await Play(mode);Check(result.Message!="Трек завершён"&&!result.Message.Contains("secret")&&!result.Message.Contains("private"),"bounded failure "+mode);if(mode=="stall")Check(result.Packets==1,"stall after first audio detected");else Check(result.Packets==0,"failed stage cannot claim playing");}
 await Mode("real");YouTube.FirstAudioLimit=TimeSpan.FromSeconds(3);YouTube.StallLimit=TimeSpan.FromSeconds(2);string completed=null;var queue=new AudioQueue();int realPackets=0;
 YouTube.Play(2,1,"dQw4w9WgXcQ",p=>{queue.Push(p);Interlocked.Increment(ref realPackets);},e=>completed=e);await Until(()=>completed!=null,"real ffmpeg decoder");Check(completed=="Трек завершён"&&realPackets>=25,"real 24 kHz ffmpeg signal streamed");var samples=new float[480];queue.Read(samples);Check(samples.Any(v=>Math.Abs(v)>.01f)&&samples.All(v=>float.IsFinite(v)&&Math.Abs(v)<=1),"actual decoded PCM enters audio queue");
 await Mode("firsthang");bool stale=false;YouTube.Play(1,3,"dQw4w9WgXcQ",_=>stale=true,_=>stale=true,_=>stale=true);YouTube.Stop();await Task.Delay(500);Drain();Check(!stale,"stop suppresses stale callbacks");
 var timer=Stopwatch.StartNew();using(var cts=new CancellationTokenSource(200)){try{using var runner=new ToolRunner(Path.Combine(tools,"ffmpeg.exe"),YouTube.AudioArguments("https://media.example.invalid/audio?signature=secret",JObject.Parse("{\"User-Agent\":\"JBL Test Agent/1\"}")),cts.Token);runner.Capture(cts.Token);throw new Exception("expected timeout");}catch(OperationCanceledException){ }}Check(timer.ElapsedMilliseconds<2000,"tool process interrupted promptly");
 Console.WriteLine($"PASS: {assertions} assertions; throwing math, Mirror status/aim, real process arguments, search, stage timeouts, errors, cancellation and real ffmpeg PCM.");
}finally{YouTube.Shutdown();}
