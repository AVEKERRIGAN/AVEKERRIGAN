using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
namespace FreshBoombox;
[Serializable]public sealed class Track{public string id,title;public float duration;}
public static class YouTube
{
    public static string Tools;
    public static readonly ConcurrentQueue<Action> Main=new();
    public static TimeSpan SearchLimit=TimeSpan.FromSeconds(25),LinkLimit=TimeSpan.FromSeconds(20),FirstAudioLimit=TimeSpan.FromSeconds(10),StallLimit=TimeSpan.FromSeconds(12);
    sealed class Job
    {
        public readonly CancellationTokenSource Cancel=new();public readonly CancellationToken Token;public volatile bool Stopped;
        public Job(){Token=Cancel.Token;}
    }
    static Job _search,_playback;
    static void Cancel(Job job){if(job==null)return;job.Stopped=true;_ = Task.Run(()=>{try{job.Cancel.Cancel();}catch{ }});}
    static string Tool(string name)=>Path.Combine(Tools,name+".exe");
    static string Runtime{get{string path=Tool("deno");if(!File.Exists(path))throw new FileNotFoundException("Не найден tools/deno.exe. Хосту нужен архив Boombox_YouTube_Runtime.");return "deno:"+path;}}
    static void SearchPost(Job job,Action action)=>Main.Enqueue(()=>{if(ReferenceEquals(_search,job)&&!job.Stopped)action();});
    static void PlayPost(Job job,Action action)=>Main.Enqueue(()=>{if(ReferenceEquals(_playback,job)&&!job.Stopped)action();});
    public static void Search(string query,Action<Track[]> complete,Action<string> error)
    {
        var old=_search;var job=new Job();_search=job;Cancel(old);
        _ = Task.Run(()=>
        {
            try
            {
                using var deadline=CancellationTokenSource.CreateLinkedTokenSource(job.Token);deadline.CancelAfter(SearchLimit);
                string target=VideoId(query) is string video?"https://www.youtube.com/watch?v="+video:"ytsearch8:"+query;
                using var process=new ToolRunner(Tool("yt-dlp"),new[]{"--encoding","utf-8","--flat-playlist","--dump-json","--skip-download","--no-playlist","--socket-timeout","8","--retries","1","--extractor-retries","1",target},deadline.Token);
                string output=process.Capture(deadline.Token);var tracks=new List<Track>();
                foreach(string line in output.Split('\n'))
                {
                    if(string.IsNullOrWhiteSpace(line))continue;
                    try{var item=JObject.Parse(line);string id=(string)item["id"];if(ValidId(id))tracks.Add(new Track{id=id,title=(string)item["title"]??id,duration=(float?)item["duration"]??0});}catch{ }
                }
                SearchPost(job,()=>complete(tracks.ToArray()));
            }
            catch(OperationCanceledException){SearchPost(job,()=>error("Поиск не ответил за "+(int)SearchLimit.TotalSeconds+" секунд. Проверьте доступ к YouTube."));}
            catch(Exception e){string message=ToolRunner.SafeError(e.Message);SearchPost(job,()=>error(message));}
            finally{job.Cancel.Dispose();}
        });
    }
    public static bool ValidId(string id)
    {
        if(id==null||id.Length!=11)return false;
        foreach(char c in id)if(c!='-'&&c!='_'&&(c>127||!char.IsLetterOrDigit(c)))return false;return true;
    }
    public static string VideoId(string value)
    {
        value=value?.Trim();if(ValidId(value))return value;
        if(!Uri.TryCreate(value,UriKind.Absolute,out var uri))return null;
        string host=uri.Host.ToLowerInvariant(),id=null;
        if(host=="youtu.be")id=uri.AbsolutePath.Trim('/');
        else if(host=="youtube.com"||host=="www.youtube.com"||host=="m.youtube.com")
        {
            var parts=uri.AbsolutePath.Trim('/').Split('/');
            if(parts.Length==2&&(parts[0]=="shorts"||parts[0]=="embed"))id=parts[1];
            else foreach(string parameter in uri.Query.TrimStart('?').Split('&'))if(parameter.StartsWith("v="))id=Uri.UnescapeDataString(parameter.Substring(2));
        }
        return ValidId(id)?id:null;
    }
    public static string[] AudioArguments(string url,JObject headers)
    {
        var args=new List<string>{"-nostdin","-hide_banner","-loglevel","error","-rw_timeout","10000000","-reconnect","1","-reconnect_streamed","1","-reconnect_delay_max","2","-reconnect_on_network_error","1","-re"};
        var http=new System.Text.StringBuilder();
        if(headers!=null)foreach(var header in headers.Properties())
        {
            string name=header.Name,value=(string)header.Value;
            if(name.IndexOfAny(new[]{'\r','\n',':'})>=0||string.IsNullOrEmpty(value)||value.IndexOfAny(new[]{'\r','\n'})>=0)continue;
            if(name.Equals("User-Agent",StringComparison.OrdinalIgnoreCase)){args.Add("-user_agent");args.Add(value);}
            else if(name.Equals("Referer",StringComparison.OrdinalIgnoreCase)||name.Equals("Origin",StringComparison.OrdinalIgnoreCase)||name.Equals("Accept-Language",StringComparison.OrdinalIgnoreCase)||name.Equals("Accept",StringComparison.OrdinalIgnoreCase))http.Append(name).Append(": ").Append(value).Append("\r\n");
        }
        if(http.Length>0){args.Add("-headers");args.Add(http.ToString());}
        args.AddRange(new[]{"-probesize","32768","-analyzeduration","0","-i",url,"-vn","-sn","-dn","-f","s16le","-ac","1","-ar","24000","pipe:1"});return args.ToArray();
    }
    public static void Play(uint id,uint epoch,string video,Action<byte[]> packet,Action<string> done,Action<string> stage=null)
    {
        Stop();var job=new Job();_playback=job;
        _ = Task.Run(()=>
        {
            string phase="Получаю ссылку YouTube";ToolRunner active=null;
            try
            {
                if(!ValidId(video))throw new IOException("Неверный идентификатор YouTube.");
                if(stage!=null)PlayPost(job,()=>stage("Получаю ссылку YouTube…"));
                JObject info;
                using(var deadline=CancellationTokenSource.CreateLinkedTokenSource(job.Token))
                {
                    deadline.CancelAfter(LinkLimit);
                    using var extractor=new ToolRunner(Tool("yt-dlp"),new[]{"--encoding","utf-8","--js-runtimes",Runtime,"--no-playlist","--skip-download","--dump-single-json","--socket-timeout","8","--retries","1","--extractor-retries","1","--extractor-args","youtube:player_client=android_vr,web","--format","bestaudio[protocol=https]/bestaudio[protocol=m3u8_native]/best[protocol=https]/best","https://www.youtube.com/watch?v="+video},deadline.Token);
                    active=extractor;info=JObject.Parse(extractor.Capture(deadline.Token));active=null;
                }
                string url=(string)info["url"];
                if(!Uri.TryCreate(url,UriKind.Absolute,out var address)||address.Scheme!="https")throw new IOException("YouTube не вернул HTTPS-ссылку на звук. Выберите другой трек.");
                phase="Подключаю звук";
                if(stage!=null)PlayPost(job,()=>stage("Ссылка получена. Подключаю звук…"));
                using var watchdog=CancellationTokenSource.CreateLinkedTokenSource(job.Token);watchdog.CancelAfter(FirstAudioLimit);
                using var decoder=new ToolRunner(Tool("ffmpeg"),AudioArguments(url,info["http_headers"] as JObject),watchdog.Token);
                active=decoder;var stream=decoder.Process.StandardOutput.BaseStream;bool started=false;
                while(!job.Token.IsCancellationRequested)
                {
                    var pcm=new byte[960];int used=0;
                    while(used<pcm.Length){int n=stream.Read(pcm,used,pcm.Length-used);if(n==0)break;used+=n;}
                    watchdog.Token.ThrowIfCancellationRequested();
                    if(used==0)break;
                    if(used<pcm.Length)Array.Resize(ref pcm,used&~1);
                    if(pcm.Length==0)continue;
                    if(!started){started=true;phase="Поток звука прервался";}
                    watchdog.CancelAfter(StallLimit);packet(pcm);
                }
                decoder.Process.WaitForExit();watchdog.Token.ThrowIfCancellationRequested();
                if(!started)throw new IOException("Звук не начался: "+(string.IsNullOrEmpty(decoder.Error)?"пустой поток":decoder.Error));
                if(decoder.Process.ExitCode!=0)throw new IOException("Ошибка звука: "+decoder.Error);
                PlayPost(job,()=>done("Трек завершён"));
            }
            catch(OperationCanceledException){string message=phase=="Получаю ссылку YouTube"?"YouTube не отдал ссылку за "+(int)LinkLimit.TotalSeconds+" секунд.":phase=="Подключаю звук"?"Звук не начался за "+(int)FirstAudioLimit.TotalSeconds+" секунд.":"Поток звука не ответил за "+(int)StallLimit.TotalSeconds+" секунд.";string details=active?.Error;if(!string.IsNullOrEmpty(details))message+=" "+details;PlayPost(job,()=>done(message));}
            catch(Exception e){string message=ToolRunner.SafeError(e.Message);PlayPost(job,()=>done(message));}
            finally{job.Cancel.Dispose();}
        });
    }
    public static void Stop(){var old=_playback;_playback=null;Cancel(old);}
    public static void Shutdown(){Stop();var old=_search;_search=null;Cancel(old);}
}
