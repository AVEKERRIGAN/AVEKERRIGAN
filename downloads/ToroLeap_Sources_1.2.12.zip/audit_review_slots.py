from pathlib import Path
import sys,struct,json,hashlib
from PIL import Image
sys.path.insert(0,'/workspace/setup-tools');import dnfile
r=Path('/workspace/mod-work');out=Path('/workspace/outputs');checks=0;report={}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
versions={'SlotShowtime':'1.1.1','Hoarder':'1.3.0','FruitParty':'1.2.0','GoldRushExpress':'1.0.22','ToroLeap':'1.2.12'}
for folder,version in versions.items():
 p=r/folder/f'bin/Release/netstandard2.1/{folder}.dll';pe=dnfile.dnPE(str(p));a=pe.net.mdtables.Assembly.rows[0];assert (a.MajorVersion,a.MinorVersion,a.BuildNumber)==tuple(map(int,version.split('.'))),(folder,version)
 log=(r/f'review-{folder}-build.log').read_text();assert '0 Warning(s)' in log and '0 Error(s)' in log
 rs={str(x.Name):x for x in pe.net.mdtables.ManifestResource.rows};base=pe.net.struct.ResourcesRva;files=list((r/folder/'art').glob('*.png'))
 for f in files:
  names=[k for k in rs if k.endswith('.'+f.name)];assert len(names)==1,(folder,f.name);row=rs[names[0]];n=struct.unpack('<I',pe.get_data(base+row.Offset,4))[0];assert pe.get_data(base+row.Offset+4,n)==f.read_bytes();Image.open(f).verify();checks+=1
 report[folder]={'version':version,'binary_sha256':sha(p),'resource_pngs':len(files),'source_sha256':{p.name:sha(p) for p in (r/folder).glob('*.cs')}}
plugins=['PuppyPalacePlugin','SugarGalaxyPlugin','TrainPlugin','ThunderPlugin','FishPlugin','ToroLeapPlugin','HoarderPlugin','FruitPartyPlugin']
for folder,plugin in zip(['PuppyPalace','SugarGalaxy','GoldRushExpress','ThunderOlympus','ReelKingLake','ToroLeap','Hoarder','FruitParty'],plugins):
 pe=dnfile.dnPE(str(r/folder/f'bin/Release/netstandard2.1/{folder}.dll'));types={str(x.TypeName):x for x in pe.net.mdtables.TypeDef.rows};assert plugin in types
 game=next(t for n,t in types.items() if n.endswith('Game'));methods={str(i.row.Name):i.row for i in game.MethodList};assert {'UserRpcShowSpin','Start','AutoNext'}<=methods.keys(),folder
 assert methods['UserRpcShowSpin'].Signature.value==bytes([0x20,1,1,0x0e]),folder
 assert 'EnsurePrefab' in [str(i.row.Name) for i in types[plugin].MethodList]
 assert 'CabinetScale' in [str(i.row.Name) for i in types[plugin].FieldList];checks+=5
 zoom=types['CamZoom'];method=next(x.row for x in zoom.MethodList if str(x.row.Name)=='Set');assert [str(x.row.Name) for x in method.ParamList]==['key','worldTarget','s'];checks+=1
# Actual sprite bounds, not transparent PNG canvas size.
coins={}
for key in ['clean_coin_gold','clean_coin_teal']:
 im=Image.open(r/'GoldRushExpress/art'/f'{key}.png');bbox=im.getchannel('A').point(lambda a:255 if a>32 else 0).getbbox();assert bbox and bbox[2]-bbox[0]<im.width*.55 and bbox[3]-bbox[1]<im.height*.55;coins[key]={'canvas':im.size,'content':bbox};checks+=2
for aspect in [4/3,1.6,16/9,2]:
 W=1280.;H=W/aspect;cw=W*.65625/7;ch=H*.5455/4;size=min(cw,ch)
 for c in range(7):
  for row in range(4):
   x=W*(.5-.65625/2)+(c+.5)*cw;y=H*(1-.541-.5455/2)+(row+.5)*ch
   assert abs(x/W*1280-(280+c*120))<.01 and abs(y/H*880-(224+row*120))<.1
   assert size*.74*1.25<=cw*.95 and size*.74*1.25<=ch*.95;checks+=2
 # Overlay labels are relative to the fitted frame, not the viewport.
 for key in ['panel_2','panel_7']:
  w,h=Image.open(r/'SlotShowtime/art'/f'{key}.png').size;ratio=w/h;panelW=min(W*.94,H*.66*ratio);panelH=panelW/ratio
  assert panelW<=W*.94 and panelH<=H*.66
  for y,height in [(.16,.12),(-.01,.18),(-.18,.10)]:assert abs(y)+height/2<.26;checks+=1
summary={'pass':True,'checks':checks,'mods':report,'eight_actual_game_and_camera_patch_APIs_verified':True,'coin_sprite_bounds':coins,'train_grid_aspects':[4/3,1.6,16/9,2],'live_unity_fps_or_coop_verified':False}
(out/'ReviewSlots_Assembly_Checks.json').write_text(json.dumps(summary,indent=2));print('PASS:',checks,'exact versions, embedded art, old/new game APIs, camera signatures and sprite/mask geometry')
