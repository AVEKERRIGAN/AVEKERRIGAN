using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace ToroLeap
{
    /// v1.1.0 client screen (Minotaurus style): tunnel background, 5x3 reels, full-reel Toro wild that drops in with
    /// anticipation + zoom, jumps IN PLACE on every dead respin (+1x), big "X N" on top, LEAPS counter on the right.
    public partial class ToroLeapGame
    {
        const int C = ToroEngine.Cols, R = ToroEngine.Rows, N = ToroEngine.Cells;
        RectTransform _ui, _grid, _fx, _bannerRt;
        Vector2 _uiHome, _gridCenter, _uiSize;
        GwyfShared.ReelFx.Column[] _reel; Image _frameGlow;
        Image[] _cell = new Image[N]; Image[] _cellGlow = new Image[N];
        Vector2[] _home = new Vector2[N];
        Image _toroCol, _logo, _colGlow, _flash, _toroPart;
        float _cs, _gw, _gh;
        TMP_FontAsset _font;
        Coroutine _anim;
        TextMeshProUGUI _winLabel, _xLabel, _leapsTitle, _leapsValue, _winBar, _betText, _buyText, _selText, _bannerText, _bannerSub;
        Image _bannerDim, _bannerIcon;
        string _betLabel = "-"; double _betNum; float _lastWinX; bool _clientTurbo; int _clientSel = 1;
        readonly List<GameObject> _fxObjs = new List<GameObject>();
        float _bannerUntil; int _particleBudget;
        float _zoomS = 1f; Vector2 _zoomC, _shakeOff;
        const int MaxFxObjects = 220;

        void ShowBanner(float seconds) { if (_bannerDim == null) return; _bannerUntil = Time.time + seconds; _bannerDim.gameObject.SetActive(true); _bannerRt.SetAsLastSibling(); }
        void HideBanner() { _bannerUntil = 0; if (_bannerDim != null) _bannerDim.gameObject.SetActive(false); }
        void DriveBanner() { if (_bannerDim != null && _bannerDim.gameObject.activeSelf && Time.time > _bannerUntil) { ToroLeapPlugin.V("Banner hidden by per-frame check"); HideBanner(); } }

        IEnumerator Safe(IEnumerator inner)
        {
            while (true)
            {
                object cur;
                try { if (!inner.MoveNext()) break; cur = inner.Current; }
                catch (Exception e) { ToroLeapPlugin.Log.LogError("[TL] Animation error: " + e); break; }
                yield return cur;
            }
            _anim = null; ResetTransforms();
        }

        void ApplyUi() { if (_ui == null) return; _ui.localScale = Vector3.one; _ui.anchoredPosition = _uiHome + _shakeOff; if (_zoomS > 1.0005f) GwyfShared.CamZoom.Set(this, _ui.TransformPoint(_zoomC), _zoomS); else GwyfShared.CamZoom.Clear(this); } // camera zoom; screen stays put

        /// every transient visual back to rest (called after interrupted animations, new RPCs, disable)
        void ResetTransforms()
        {
            _zoomS = 1f; _shakeOff = Vector2.zero; ApplyUi();
            for (int i = 0; i < N; i++) if (_cell[i] != null) { _cell[i].rectTransform.localScale = Vector3.one; _cell[i].rectTransform.localRotation = Quaternion.identity; _cell[i].rectTransform.anchoredPosition = _home[i]; _cell[i].color = Color.white; }
            if (_toroCol != null) { _toroCol.rectTransform.localScale = Vector3.one; _toroCol.rectTransform.localRotation = Quaternion.identity; }
            if (_xLabel != null) _xLabel.transform.localScale = Vector3.one;
            if (_leapsValue != null) _leapsValue.transform.localScale = Vector3.one;
            if (_colGlow != null) _colGlow.gameObject.SetActive(false);
            if (_flash != null) _flash.gameObject.SetActive(false);
            if (_hudSpin != null) _hudSpin.transform.localScale = Vector3.one;
        }

        void ClientAbort()
        {
            if (_anim != null) { try { StopCoroutine(_anim); } catch { } _anim = null; }
            HideBanner(); ClearFx(); ResetTransforms();
        }
        static readonly Color Gold = new Color(1f, .85f, .35f), Fire = new Color(1f, .55f, .15f), Cream = new Color(1f, .95f, .82f), Teal = new Color(.45f, .85f, .85f);

        // ---------- building ----------
        static Image Img(string name, Transform parent, Sprite sp = null)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Image)); go.transform.SetParent(parent, false); go.layer = parent.gameObject.layer;
            var im = go.GetComponent<Image>(); im.sprite = sp; im.raycastTarget = false; im.preserveAspect = sp != null; return im;
        }
        TextMeshProUGUI Txt(string name, Transform parent, Color c, float maxSize = 300)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer)); go.transform.SetParent(parent, false); go.layer = parent.gameObject.layer;
            var t = go.AddComponent<TextMeshProUGUI>(); var canvasRenderer = t.canvasRenderer; if (_font != null) { t.font = _font; if (_font.material != null) t.fontSharedMaterial = _font.material; }
            t.alignment = TextAlignmentOptions.Center; t.enableAutoSizing = true; t.fontSizeMin = 1; t.fontSizeMax = maxSize;
            t.color = c; t.raycastTarget = false; t.outlineWidth = .22f; t.outlineColor = new Color32(30, 12, 4, 255); t.textWrappingMode = TMPro.TextWrappingModes.NoWrap;
            return t;
        }
        static RectTransform Place(RectTransform rt, Vector2 center, Vector2 size) { rt.anchorMin = rt.anchorMax = new Vector2(.5f, .5f); rt.pivot = new Vector2(.5f, .5f); rt.sizeDelta = size; rt.anchoredPosition = center; return rt; }
        static void Stretch(RectTransform rt) { rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one; rt.offsetMin = rt.offsetMax = Vector2.zero; }
        Vector2 CellPos(int i) => _gridCenter + _home[i];
        Vector2 ColPos(int c) => _gridCenter + new Vector2(_home[c * R + 1].x, 0);

        void BuildPanel(RectTransform croot, Vector2 min, Vector2 max)
        {
            _font = payoutText != null ? payoutText.font : TMP_Settings.defaultFontAsset;
            if (_font == null) { var any = GetComponentsInChildren<TMP_Text>(true).FirstOrDefault(x => x.font != null); _font = any != null ? any.font : Resources.FindObjectsOfTypeAll<TMP_FontAsset>().FirstOrDefault(); }
            var bg = Img("ToroLeapUI", croot, Spr("bg")); bg.preserveAspect = false;
            if (bg.sprite == null) bg.color = new Color(.2f, .1f, .06f);
            _ui = bg.rectTransform; _ui.anchorMin = _ui.anchorMax = new Vector2(.5f, .5f); _ui.pivot = new Vector2(.5f, .5f);
            float margin = ToroLeapPlugin.ScreenMargin != null ? Mathf.Clamp(ToroLeapPlugin.ScreenMargin.Value, 0f, .2f) : .03f;
            Vector2 size = (max - min) * (1f - 2f * margin); _ui.sizeDelta = size; _ui.anchoredPosition = (min + max) / 2f - croot.rect.center; _uiHome = _ui.anchoredPosition;
            _ui.SetAsLastSibling();
            float W = size.x, H = size.y; _uiSize = size;

            float barH = H * .1f, topH = H * .14f;
            float availH = H - barH - topH - H * .06f;
            _cs = Mathf.Min(availH / R, W * .62f / C);
            _gw = _cs * C; _gh = _cs * R;
            _gridCenter = new Vector2(0, (barH - topH) / 2f + H * .005f);

            _logo = Img("Logo", _ui, Spr("logo")); Place(_logo.rectTransform, new Vector2(0, H / 2 - topH * .55f), new Vector2(W * .34f, topH * .95f));
            _xLabel = Txt("XLabel", _ui, Gold); Place(_xLabel.rectTransform, new Vector2(0, H / 2 - topH * .55f), new Vector2(W * .3f, topH * .9f));
            _xLabel.outlineColor = new Color32(60, 25, 0, 255); _xLabel.text = "";
            var shade = Img("GridShade", _ui); shade.color = new Color(0, 0, 0, .18f); Place(shade.rectTransform, _gridCenter, new Vector2(_gw * 1.03f, _gh * 1.04f));

            var gridGo = new GameObject("Grid", typeof(RectTransform), typeof(RectMask2D));
            _grid = (RectTransform)gridGo.transform; _grid.SetParent(_ui, false); Place(_grid, _gridCenter, new Vector2(_gw, _gh * 1.02f));
            _colGlow = Img("ColGlow", _grid, Spr("glow")); _colGlow.preserveAspect = false; _colGlow.gameObject.SetActive(false);
            for (int i = 0; i < N; i++)
            {
                int c = i / R, r = i % R;
                _home[i] = new Vector2(-_gw / 2 + _cs * (c + .5f), _gh / 2 - _cs * (r + .5f));
                var gl = Img("Glow" + i, _grid, Spr("glow")); Place(gl.rectTransform, _home[i], Vector2.one * _cs * 1.25f); gl.gameObject.SetActive(false); _cellGlow[i] = gl;
            }
            for (int i = 0; i < N; i++) { var im = Img("Cell" + i, _grid); im.preserveAspect = true; Place(im.rectTransform, _home[i], Vector2.one * _cs * .9f); _cell[i] = im; }
            _reel = new GwyfShared.ReelFx.Column[C];
            for (int c = 0; c < C; c++) { var cells = new Image[R]; for (int r = 0; r < R; r++) cells[r] = _cell[c * R + r]; _reel[c] = new GwyfShared.ReelFx.Column(cells, _home[c * R], new Vector2(0, -_cs), Vector2.one * _cs * .9f, _grid, (n, par) => Img(n, par), Spr("reel_shade"), _cs, _gh); }
            _frameGlow = Img("FrameGlow", _ui, Spr("glow")); _frameGlow.preserveAspect = false; Place(_frameGlow.rectTransform, _grid.anchoredPosition, new Vector2(_gw * 1.12f, _gh * 1.12f)); _frameGlow.color = new Color(1, 1, 1, 0); _frameGlow.raycastTarget = false; _frameGlow.transform.SetSiblingIndex(_grid.GetSiblingIndex());
            // Toro full-reel figure (outside the mask: taller than the reel like the mockup, drops in from above)
            // partial Minotaur lives inside the masked grid so only the visible 1-2 cells show
            _toroPart = Img("ToroPart", _grid, Spr("toro_tall")); _toroPart.preserveAspect = true; _toroPart.raycastTarget = false; _toroPart.rectTransform.pivot = new Vector2(.5f, 0f);
            _toroPart.rectTransform.anchorMin = _toroPart.rectTransform.anchorMax = new Vector2(.5f, .5f); _toroPart.rectTransform.sizeDelta = new Vector2(_cs * 1.15f, _gh * 1.12f); _toroPart.gameObject.SetActive(false);
            _toroCol = Img("ToroReel", _ui, Spr("toro_tall")); _toroCol.preserveAspect = true; _toroCol.rectTransform.pivot = new Vector2(.5f, 0f);
            _toroCol.rectTransform.anchorMin = _toroCol.rectTransform.anchorMax = new Vector2(.5f, .5f); _toroCol.rectTransform.sizeDelta = new Vector2(_cs * 1.15f, _gh * 1.12f); _toroCol.gameObject.SetActive(false);

            // right: LEAPS counter
            var lp = Img("LeapsPanel", _ui, Spr("panel_dark")); lp.preserveAspect = false;
            lp.rectTransform.anchorMin = lp.rectTransform.anchorMax = new Vector2(.905f, .58f); lp.rectTransform.sizeDelta = new Vector2(W * .165f, H * .26f); lp.rectTransform.anchoredPosition = Vector2.zero;
            float lw = W * .165f, lh = H * .26f;
            _leapsTitle = Txt("LeapsTitle", lp.transform, Cream); Place(_leapsTitle.rectTransform, new Vector2(0, lh * .3f), new Vector2(lw * .82f, lh * .26f)); _leapsTitle.text = "LEAPS\n<size=55%>ПРЫЖКИ</size>";
            _leapsValue = Txt("LeapsValue", lp.transform, Gold); Place(_leapsValue.rectTransform, new Vector2(0, -lh * .15f), new Vector2(lw * .7f, lh * .48f)); _leapsValue.text = "0";

            var fxGo = new GameObject("Fx", typeof(RectTransform)); _fx = (RectTransform)fxGo.transform; _fx.SetParent(_ui, false); Place(_fx, Vector2.zero, new Vector2(W, H));
            _winLabel = Txt("WinLabel", _ui, Gold); Place(_winLabel.rectTransform, _gridCenter + new Vector2(0, -_gh * .32f), new Vector2(_gw * .98f, _cs * .45f)); _winLabel.text = "";

            var bar = Img("Bar", _ui, Spr("bar")); bar.preserveAspect = false; Place(bar.rectTransform, new Vector2(0, -H / 2 + barH * .5f), new Vector2(W * .985f, barH * .92f));
            _winBar = Txt("WinBar", _ui, Cream); _winBar.rectTransform.anchorMin = new Vector2(.32f, .01f); _winBar.rectTransform.anchorMax = new Vector2(.54f, .09f); _winBar.rectTransform.offsetMin = _winBar.rectTransform.offsetMax = Vector2.zero;
            BuildHud();

            _flash = Img("Flash", _ui); _flash.color = new Color(1, .9f, .7f, 0); Stretch(_flash.rectTransform); _flash.gameObject.SetActive(false);
            _bannerDim = Img("Banner", _ui); _bannerDim.color = new Color(.1f, .04f, .02f, .82f); _bannerRt = _bannerDim.rectTransform; Stretch(_bannerRt);
            _bannerIcon = Img("BannerIcon", _bannerRt, Spr("toro_head")); Place(_bannerIcon.rectTransform, new Vector2(0, H * .17f), Vector2.one * H * .3f);
            _bannerText = Txt("BannerText", _bannerRt, Gold); Place(_bannerText.rectTransform, new Vector2(0, -H * .07f), new Vector2(W * .8f, H * .2f));
            _bannerSub = Txt("BannerSub", _bannerRt, Color.white); Place(_bannerSub.rectTransform, new Vector2(0, -H * .23f), new Vector2(W * .75f, H * .1f));
            _bannerDim.gameObject.SetActive(false);
            SetFeature(false, 1, 0); UpdateButtonsVisual(false, _clientSel); RefreshBar();
            ToroLeapPlugin.V($"UI built {W:0}x{H:0}, cell {_cs:0.#}");
        }

        string Money(double x) { if (_betNum <= 0) return x.ToString("0.##") + "x"; try { return MoneyFormatter.FormatWithDollar(BigNumber.FromDouble(x * _betNum)); } catch { return "$" + (x * _betNum).ToString("0.00"); } }
        void RefreshBar()
        {
            if (_betText != null) _betText.text = "<size=60%><color=#d8b070>BET</color></size>\n" + _betLabel;
            if (_winBar != null) _winBar.text = "<size=60%><color=#d8b070>WIN</color></size>\n" + Money(_lastWinX);
        }

        /// X label on top (feature) or logo (idle) + LEAPS counter
        void SetFeature(bool on, int x, int leaps)
        {
            if (_logo != null) _logo.gameObject.SetActive(!on);
            if (_xLabel != null) _xLabel.text = on ? "X" + x : "";
            if (_leapsValue != null) _leapsValue.text = leaps.ToString();
        }

        void UpdateButtonsVisual(bool tb, int sel)
        {
            _clientTurbo = tb; _clientSel = Mathf.Clamp(sel, 1, 3); HudTurbo(tb);
            GwyfShared.ToggleTint.Physical(turboButton, tb); GwyfShared.ToggleTint.Ui(_hudTurbo, tb);
            void Label(InteractableEventTrigger b, string s) { if (b == null) return; foreach (var t in b.GetComponentsInChildren<TMP_Text>(true)) t.text = s; }
            Label(turboButton, "TURBO\n<size=70%>" + (tb ? "ON" : "OFF") + "</size>");
            Label(buySelectButton, "REEL\n<size=60%>" + (_clientSel + 1) + "</size>");
            Label(buyButton, "BONUS POP\n<size=55%>" + BuyCostLabel(_clientSel) + "x BET</size>");
            if (_buyText != null) _buyText.text = "BONUS POP\n<size=58%>Toro on reel " + (_clientSel + 1) + "</size>\n<size=70%><color=#ffe28a>" + BuyCostLabel(_clientSel) + "x BET</color></size>";
            if (_selText != null) _selText.text = "<size=70%>REEL</size>  " + string.Join(" ", new[] { 1, 2, 3 }.Select(k => k == _clientSel ? $"<color=#ffd24a>[{k + 1}]</color>" : $"<color=#a08060>{k + 1}</color>"));
        }

        // ---------- cells ----------
        void SetCell(int i, int sym)
        {
            var im = _cell[i]; im.sprite = SymSprite(sym); im.color = Color.white; im.enabled = im.sprite != null;
            var rt = im.rectTransform; rt.localScale = Vector3.one; rt.localRotation = Quaternion.identity; rt.anchoredPosition = _home[i];
            if (_anim != null && (sym == ToroEngine.WILD)) StartCoroutine(GwyfShared.BonusArrival.Pulse(im, _cellGlow[i], new Color(1f, .8f, .35f)));
        }
        void SetIdle()
        {
            var r = new System.Random(GetInstanceID());
            for (int i = 0; i < N; i++) SetCell(i, r.Next(ToroEngine.NSYM));
        }
        void UpdateIdle()
        {
            if (_ui == null || _anim != null) return;
            float t = Time.time;
            for (int i = 0; i < N; i++)
                if (_cell[i] != null && _cell[i].enabled) _cell[i].rectTransform.anchoredPosition = _home[i] + new Vector2(0, Mathf.Sin(t * 1.6f + i * .7f) * _cs * .015f);
        }
        void ClearFx()
        {
            foreach (var g in _fxObjs) if (g != null) Destroy(g); _fxObjs.Clear();
            if (_cellGlow[0] != null) foreach (var g in _cellGlow) g.gameObject.SetActive(false);
            if (_winLabel != null) _winLabel.text = "";
        }

        static Vector3 Squash(float k) { float a = Mathf.Sin(k * Mathf.PI) * (1 - k) * .35f; return new Vector3(1 + a, 1 - a, 1); }

        /// columns in `cols` drop out, get new symbols and fall in with stagger. Exact duration = SpinIn(t, cols.Count) * sp.
        IEnumerator SpinColumns(int[] g, List<int> cols, bool t, float sp,int fullToro=-1)
        {
            // premium reel spin (shared ReelFx). Exact duration unchanged: outD + st*(n-1) + fall, then .05*sp.
            float outD = TlTiming.Out(t) * sp, st = TlTiming.Stagger(t) * sp, fall = TlTiming.Fall(t) * sp;
            float landDur = fall * .7f, end = outD + st * (cols.Count - 1) + fall;
            var rnd = new System.Random(GetInstanceID() ^ Time.frameCount);
            // Decorative strip symbols are independent of the already chosen result.
            // Include Toro in the strip: an empty landing cell must not reveal a feature early.
            System.Func<int, System.Func<int>> picker = c => () => rnd.Next(ToroEngine.NSYM + (c!=fullToro&&c >= 1 && c <= 3 ? 1 : 0));
            var picks = new System.Func<int>[C]; foreach (var c in cols) picks[c] = picker(c);
            float speed = (t ? 16f : 11f) / Mathf.Max(.5f, sp);
            foreach (var c in cols) { _reel[c].BlurOf = BlurOf; _reel[c].Start(SymSprite, id => BlurSprite(id), picks[c]); }
            var landing = new bool[cols.Count]; var landed = new bool[cols.Count];
            float t0 = Time.time;
            while (true)
            {
                float tt = Time.time - t0;
                for (int ci = 0; ci < cols.Count; ci++)
                {
                    int c = cols[ci]; float ls = outD + st * ci + fall - landDur;
                    if (tt < ls) _reel[c].Spin(tt, speed, picks[c]);
                    else
                    {
                        if(c==fullToro)
                        {
                            if(!landing[ci]){landing[ci]=true;_reel[c].Finish();for(int r=0;r<R;r++)_cell[c*R+r].enabled=false;}
                            float q=Mathf.Clamp01((tt-ls)/landDur);_toroCol.gameObject.SetActive(true);
                            var home=ColPos(c)+new Vector2(0,-_gh*.5f-_cs*.02f);
                            _toroCol.rectTransform.anchoredPosition=home+new Vector2(0,_gh*1.15f*GwyfShared.ReelFx.GravityFall(q));_toroCol.rectTransform.localScale=Vector3.one;
                            if(!landed[ci]&&q>=.72f){landed[ci]=true;Sfx(spinDoneSFX,0);}continue;
                        }
                        if (!landing[ci]) { landing[ci] = true; var fin = new Sprite[R]; for (int r = 0; r < R; r++) fin[r] = SymSprite(g[c * R + r]); _reel[c].BeginLand(fin, landDur, BlurOf); }
                        float p = Mathf.Clamp01((tt - ls) / landDur); _reel[c].Land(p);
                        if (!landed[ci] && p >= .55f) { landed[ci] = true; Sfx(spinDoneSFX, 0); }
                    }
                }
                if (_frameGlow != null) { float fa = tt < end - .2f ? Mathf.Clamp01(tt / .3f) : Mathf.Clamp01((end - tt) / .2f); _frameGlow.color = new Color(1f, .55f, .25f, .25f * fa); }
                if (tt >= end) break;
                yield return null;
            }
            if (_frameGlow != null) _frameGlow.color = new Color(1, 1, 1, 0);
            foreach (var c in cols) { _reel[c].Finish(); for (int r = 0; r < R; r++) { int i = c * R + r;if(c==fullToro){_cell[i].sprite=SymSprite(g[i]);_cell[i].enabled=false;}else SetCell(i, g[i]); _cell[i].rectTransform.anchoredPosition = _home[i]; _cell[i].rectTransform.localScale = Vector3.one; } }
            yield return Wait(.05f * sp);
           
        }

        GameObject FxImg(string spr, Vector2 pos, float size, Color col)
        {
            _fxObjs.RemoveAll(g => g == null);
            if (_fxObjs.Count >= MaxFxObjects) { var old = _fxObjs[0]; _fxObjs.RemoveAt(0); if (old != null) Destroy(old); }
            var im = Img("fx", _fx, Spr(spr)); im.color = col; Place(im.rectTransform, pos, Vector2.one * size); _fxObjs.Add(im.gameObject); return im.gameObject;
        }

        float Amt => ToroLeapPlugin.Particles != null ? Mathf.Max(0, ToroLeapPlugin.Particles.Value) : 1f;

        IEnumerator Particles(Vector2 pos, Color col, int count, float dur, float dist, bool upward = false)
        {
            count = Mathf.Min(Mathf.RoundToInt(count * Amt), _particleBudget); if (count <= 0) yield break; _particleBudget -= count;
            var parts = new List<(RectTransform rt, Image im, Vector2 v, float s)>();
            var rnd = new System.Random(pos.GetHashCode() ^ Time.frameCount);
            for (int k = 0; k < count; k++)
            {
                float a = upward ? (float)(Math.PI * (.1 + .8 * rnd.NextDouble())) : (float)(rnd.NextDouble() * Math.PI * 2), sp = dist * (.4f + (float)rnd.NextDouble() * .8f);
                bool star = rnd.NextDouble() < .25;
                var go = FxImg(star ? "sparkle" : "dot", pos, _cs * (star ? .22f : .13f) * (.6f + (float)rnd.NextDouble() * .8f), Color.Lerp(col, Color.white, (float)rnd.NextDouble() * .5f));
                parts.Add(((RectTransform)go.transform, go.GetComponent<Image>(), new Vector2(Mathf.Cos(a), Mathf.Sin(a)) * sp, (float)rnd.NextDouble() * 360));
            }
            float t0 = Time.time;
            while (Time.time - t0 < dur)
            {
                float p = (Time.time - t0) / dur, e = 1 - (1 - p) * (1 - p) * (1 - p), fa = Mathf.Min(1f, p * 10f) * (1 - p * p);
                foreach (var q in parts) { if (q.rt == null || q.im == null) continue; q.rt.anchoredPosition = pos + q.v * e + new Vector2(0, -p * p * _cs * .2f); q.rt.localRotation = Quaternion.Euler(0, 0, q.s + e * 90); q.rt.localScale = Vector3.one * (1f - .4f * p); var c = q.im.color; c.a = fa; q.im.color = c; }
                yield return null;
            }
            foreach (var q in parts) if (q.rt != null) Destroy(q.rt.gameObject);
        }

        IEnumerator Dust(Vector2 pos, float width, int count, float dur)
        {
            count = Mathf.Min(Mathf.RoundToInt(count * Amt), _particleBudget); if (count <= 0) yield break; _particleBudget -= count;
            var parts = new List<(RectTransform rt, Image im, float dir, float s)>();
            for (int k = 0; k < count; k++)
            {
                float dir = (k % 2 == 0 ? 1 : -1) * (.4f + .6f * (k / (float)count));
                var go = FxImg("dust", pos + new Vector2(UnityEngine.Random.Range(-width * .3f, width * .3f), 0), _cs * UnityEngine.Random.Range(.35f, .6f), new Color(1, 1, 1, .9f));
                parts.Add(((RectTransform)go.transform, go.GetComponent<Image>(), dir, UnityEngine.Random.Range(.8f, 1.2f)));
            }
            float t0 = Time.time; var start = parts.Select(q => q.rt.anchoredPosition).ToArray();
            while (Time.time - t0 < dur)
            {
                float p = (Time.time - t0) / dur, e = 1 - (1 - p) * (1 - p);
                for (int k = 0; k < parts.Count; k++) { var q = parts[k]; if (q.rt == null) continue; q.rt.anchoredPosition = start[k] + new Vector2(q.dir * width * .9f * e, _cs * .35f * e); q.rt.localScale = Vector3.one * q.s * (1 + p); var c = q.im.color; c.a = .9f * (1 - p); q.im.color = c; }
                yield return null;
            }
            foreach (var q in parts) if (q.rt != null) Destroy(q.rt.gameObject);
        }

        IEnumerator Shake(float dur, float amp)
        {
            amp *= ToroLeapPlugin.ShakeAmount != null ? Mathf.Max(0, ToroLeapPlugin.ShakeAmount.Value) : 1f;
            float t0 = Time.time;
            while (Time.time - t0 < dur && _ui != null)
            {
                float p = (Time.time - t0) / dur, a = amp * (1 - p) * (1 - p);
                _shakeOff = new Vector2(UnityEngine.Random.Range(-a, a), UnityEngine.Random.Range(-a, a)); ApplyUi();
                yield return null;
            }
            _shakeOff = Vector2.zero; ApplyUi();
        }

        IEnumerator Wait(float d) { float t0 = Time.time; while (Time.time - t0 < d) yield return null; }

        // ---------- the show ----------
        IEnumerator Show(TlMsg m)
        {
            bool t = m.tb == 1;
            _clientTurbo = t; if (m.bn > 0) _betNum = m.bn;
            if (m.t == "end") { yield return EndRoutine(m); _anim = null; yield break; }
            if (m.t != "spin" || m.first == null || m.first.g == null || m.first.g.Length != N) { _anim = null; yield break; }
            HideBanner(); ResetTransforms();
            int lockCol = m.toro;
            _toroCol.gameObject.SetActive(false); if (_toroPart != null) _toroPart.gameObject.SetActive(false);
            SetFeature(false, 1, 0); _lastWinX = 0; RefreshBar();
            Sfx(spinReelSFX, 0);
            _particleBudget = 160;

            // 1) all reels spin with visible Toro symbols in any winning/partial cells.
            yield return SpinColumns(m.first.g, Enumerable.Range(0, C).ToList(), t, 1f,lockCol);

            // 2) expand the landed Toro symbols in place, then celebrate the feature.
            if (lockCol >= 0) { yield return Anticipate(lockCol, t); yield return LandToro(lockCol, t); }
            else if (m.ptoro >= 0) yield return LandPartial(m.ptoro, m.ps, t);

            double acc = 0;
            if (m.first.w > 0) { acc += m.first.w; yield return ShowLines(m.first, TlTiming.Lines(t), "LINE WIN " + Money(m.first.w)); _lastWinX = (float)acc; RefreshBar(); }

            // 3) MINOTAUR RE-SPINS: X starts at 1, +1 per dead respin, first win * X ends the feature
            if (m.rs != null && lockCol >= 0)
            {
                var cols = Enumerable.Range(0, C).Where(c => c != lockCol).ToList();
                SetFeature(true, 1, 0);
                for (int k = 0; k < m.rs.Length; k++)
                {
                    float sp = TlTiming.Speed(k); var st = m.rs[k];
                    ClearFx();
                    yield return SpinColumns(st.g, cols, t, sp);
                    if (st.w > 0)
                    {
                        yield return ShowLines(st, TlTiming.Lines(t) * sp, "LINE WIN " + Money(st.w));
                        yield return ApplyMultiplier(st, TlTiming.Apply(t) * sp);
                        acc += st.mw; _lastWinX = (float)Math.Min(acc, m.tot); RefreshBar();
                    }
                    else yield return JumpInPlace(lockCol, st.x + 1, k + 1, TlTiming.Jump(t) * sp);
                }
            }
            if (m.w > 0)
            {
                _lastWinX = m.tot; RefreshBar();
                _winLabel.text = "<size=120%>" + Money(m.tot) + "</size>" + (m.cap == 1 ? "  <size=70%><color=#ffd24a>MAX WIN</color></size>" : "");
                yield return Wait(TlTiming.Settle(t));
            }
            _anim = null;
        }

        Image[] _dims;
        void SetDims(int keep, float a)
        {
            if (_dims == null) { _dims = new Image[C]; for (int c = 0; c < C; c++) { _dims[c] = Img("Dim" + c, _grid); _dims[c].preserveAspect = false; _dims[c].raycastTarget = false; Place(_dims[c].rectTransform, new Vector2(-_gw / 2 + _cs * (c + .5f), 0), new Vector2(_cs, _gh * 1.02f)); } }
            for (int c = 0; c < C; c++) { _dims[c].color = new Color(0, 0, 0, c == keep ? 0f : a); _dims[c].transform.SetAsLastSibling(); }
        }

        /// anticipation: other reels darken, the empty Toro reel glows, eased push-in with a slow rumble (no random jitter)
        IEnumerator Anticipate(int col, bool t)
        {
            float d = TlTiming.Ant(t), t0 = Time.time;
            _zoomC = ColPos(col);
            _colGlow.gameObject.SetActive(true); var rt = _colGlow.rectTransform; Place(rt, _home[col * R + 1], new Vector2(_cs * 1.2f, _gh * 1.05f));
            _winLabel.text = "<color=#ffb050>THE GROUND SHAKES...</color>";
            Sfx(multiplierSFX, 5);
            while (Time.time - t0 < d)
            {
                float el = Time.time - t0, p = el / d, e = p * p * (3 - 2 * p);
                SetDims(col, .5f * Mathf.Clamp01(el / .3f));
                _colGlow.color = new Color(1f, .55f, .2f, Mathf.Clamp01(el / .2f) * (.45f + .25f * Mathf.Sin(el * 9f)));
                _zoomS = Mathf.Lerp(1f, 1.1f, e);
                _shakeOff = new Vector2(Mathf.Sin(el * 37f) + .5f * Mathf.Sin(el * 61f), Mathf.Cos(el * 43f)) * _cs * .008f * e; ApplyUi();
                yield return null;
            }
            _colGlow.gameObject.SetActive(false); _shakeOff = Vector2.zero; ApplyUi();
        }

        /// Toro drops with gravity, slams: ease-out-back zoom punch, soft flash, shockwave ring, dust, shake, eased zoom out
        IEnumerator LandToro(int col, bool t)
        {
            float d = TlTiming.Land(t);
            var rt = _toroCol.rectTransform; var home = ColPos(col) + new Vector2(0, -_gh * .5f - _cs * .02f);
            _toroCol.gameObject.SetActive(true); _toroCol.transform.SetAsLastSibling(); _fx.SetAsLastSibling(); _winLabel.transform.SetAsLastSibling();
            for (int row = 0; row < R; row++) _cell[col * R + row].enabled = false;
            float fall = d * .3f, slam = d * .2f, rest = d - fall - slam;
            float t0 = Time.time; bool hit = false; Image ring = null;
            Sfx(multiplierSFX, 50);
            while (Time.time - t0 < d)
            {
                float tt = Time.time - t0;
                if (tt < fall)
                {
                    float p = tt / fall; rt.anchoredPosition = home;
                    rt.localScale = Vector3.one;
                    _zoomS = 1.1f; SetDims(col, .5f); ApplyUi();
                }
                else if (tt < fall + slam)
                {
                    if (!hit)
                    {
                        hit = true; rt.anchoredPosition = home;
                        StartCoroutine(Dust(home + new Vector2(0, _cs * .05f), _cs * 1.6f, 12, rest + slam));
                        StartCoroutine(Particles(home + new Vector2(0, _cs * .1f), Fire, 14, slam + rest * .6f, _cs * 1.2f, true));
                        StartCoroutine(Shake(slam + rest * .4f, _cs * .08f));
                        _flash.gameObject.SetActive(true); _flash.transform.SetAsLastSibling();
                        ring = Img("Shock", _fx, Spr("glow")); ring.preserveAspect = true; ring.raycastTarget = false; _fxObjs.Add(ring.gameObject); Place(ring.rectTransform, home + new Vector2(0, _cs * .3f), Vector2.one * _cs * 1.2f);
                        Sfx(spinDoneSFX, 0); Sfx(multiplierSFX, 200);
                        _winLabel.text = "<color=#ffd24a>MINOTAUR WILD!</color>  <size=70%>re-spins until a win \u2022 +1x every miss</size>";
                    }
                    float p = (tt - fall) / slam, k = Mathf.Sin(p * Mathf.PI * 2f) * (1 - p) * .16f;
                    rt.localScale = new Vector3(1 + k, 1 - k, 1);
                    _zoomS = Mathf.LerpUnclamped(1.1f, 1.28f, GwyfShared.ReelFx.EaseOutBack(p, 1.6f)); ApplyUi();
                }
                else
                {
                    float p = (tt - fall - slam) / rest; rt.localScale = Vector3.one;
                    _zoomS = Mathf.Lerp(1.28f, 1f, p * p * (3 - 2 * p)); SetDims(col, .5f * (1 - p)); ApplyUi();
                }
                if (hit)
                {
                    float he = tt - fall, fa = Mathf.Clamp01(1f - he / (slam + rest * .35f));
                    _flash.color = new Color(1, .9f, .7f, .55f * fa * fa * Mathf.Clamp01(he / .06f)); if (fa <= 0) _flash.gameObject.SetActive(false);
                    if (ring != null) { float rq = Mathf.Clamp01(he / (slam + rest * .5f)); ring.rectTransform.localScale = Vector3.one * (1 + rq * 4f); ring.color = new Color(1f, .6f, .25f, .9f * (1 - rq) * (1 - rq)); }
                }
                yield return null;
            }
            if (ring != null) Destroy(ring.gameObject);
            SetDims(col, 0);
            rt.anchoredPosition = home; rt.localScale = Vector3.one; _winLabel.text = ""; _zoomS = 1f; ApplyUi(); _flash.gameObject.SetActive(false);
        }

        /// partial Minotaur (v1.2.0): drops in with gravity and stops shifted by `sh` cells, clipped by the grid mask.
        /// sh > 0: pushed down (head + shoulders visible at the bottom), sh < 0: hangs from the top (legs visible). Duration == PLand.
        IEnumerator LandPartial(int col, int sh, bool t)
        {
            float d = TlTiming.PLand(t), t0 = Time.time, fall = d * .38f;
            var rt = _toroPart.rectTransform; _toroPart.gameObject.SetActive(true); _toroPart.transform.SetAsLastSibling();
            var x = -_gw / 2 + _cs * (col + .5f);
            var home = new Vector2(x, -_gh * .5f - _cs * .02f - sh * _cs);   // pivot at the feet
            var from = home;
            for (int row = 0; row < R; row++) if (ToroEngine.PartialRow(row, sh)) _cell[col * R + row].enabled = false;
            int vis = ToroEngine.Rows - Mathf.Abs(sh); bool hit = false;
            _winLabel.text = "";
            while (Time.time - t0 < d)
            {
                float tt = Time.time - t0;
                if (tt < fall) { float p = tt / fall; rt.anchoredPosition = from; rt.localScale = Vector3.one * Mathf.Lerp(.9f, 1f, p * p * (3 - 2 * p)); }
                else
                {
                    if (!hit)
                    {
                        hit = true; rt.anchoredPosition = home; Sfx(spinDoneSFX, 0); Sfx(multiplierSFX, 20);
                        _winLabel.text = $"<color=#ffd24a>MINOTAUR WILD</color>  <size=70%>{vis} of 3 \u2022 lands fully for RE-SPINS</size>";
                        StartCoroutine(Shake(.25f, _cs * .03f));
                    }
                    float p = (tt - fall) / (d - fall), k = Mathf.Exp(-5f * p) * Mathf.Sin(p * Mathf.PI * 3f) * .1f;   // damped spring settle
                    rt.localScale = new Vector3(1 + k, 1 - k, 1);
                    _colGlow.gameObject.SetActive(true); Place(_colGlow.rectTransform, new Vector2(x, 0), new Vector2(_cs * 1.15f, _gh * 1.04f));
                    _colGlow.color = new Color(1f, .55f, .2f, .35f * Mathf.Sin(Mathf.Min(1, p * 1.5f) * Mathf.PI));
                }
                yield return null;
            }
            rt.anchoredPosition = home; rt.localScale = Vector3.one; _colGlow.gameObject.SetActive(false);
        }

        /// dead respin: Toro squats, jumps straight up, slams back down IN PLACE (dust + shake); X +1, LEAPS +1
        IEnumerator JumpInPlace(int col, int newX, int leaps, float d)
        {
            var rt = _toroCol.rectTransform; var home = ColPos(col) + new Vector2(0, -_gh * .5f - _cs * .02f);
            float squat = d * .22f, air = d * .4f, slam = d * .13f; bool landed = false;
            float t0 = Time.time;
            while (Time.time - t0 < d)
            {
                float tt = Time.time - t0;
                if (tt < squat) { float p = tt / squat; rt.localScale = new Vector3(1 + .12f * p, 1 - .14f * p, 1); rt.anchoredPosition = home; }
                else if (tt < squat + air)
                {
                    float p = (tt - squat) / air;
                    rt.anchoredPosition = home + new Vector2(0, _cs * .7f * Mathf.Sin(p * Mathf.PI)); rt.localScale = new Vector3(.94f, 1.08f, 1);
                    if (p > .2f && p < .25f) Sfx(spinReelSFX, 0);
                }
                else
                {
                    if (!landed)
                    {
                        landed = true; rt.anchoredPosition = home;
                        SetFeature(true, newX, leaps);
                        StartCoroutine(Dust(home + new Vector2(0, _cs * .05f), _cs * 1.4f, 8, d * .45f));
                        StartCoroutine(Shake(d * .25f, _cs * .06f));
                        StartCoroutine(Particles(new Vector2(0, _uiSize.y / 2 - _uiSize.y * .08f), Gold, 8, d * .4f, _cs * 1.2f));
                        Sfx(multiplierSFX, newX);
                        _winLabel.text = "<color=#ff9a50>NO WIN</color>  \u2022  <color=#ffe066>X" + newX + "</color>";
                    }
                    float p = Mathf.Clamp01((tt - squat - air) / (d - squat - air));
                    rt.localScale = tt < squat + air + slam ? new Vector3(1.15f, .86f, 1) : Squash(p);
                    _xLabel.transform.localScale = Vector3.one * (1 + .5f * Mathf.Sin(Mathf.Min(1, p * 1.5f) * Mathf.PI) * (1 - p * .5f));
                    _leapsValue.transform.localScale = Vector3.one * (1 + .3f * (1 - p));
                }
                yield return null;
            }
            rt.anchoredPosition = home; rt.localScale = Vector3.one; _xLabel.transform.localScale = Vector3.one; _leapsValue.transform.localScale = Vector3.one;
        }

        List<int> WinCells(ToroEngine.Step st)
        {
            var set = new HashSet<int>();
            if (st.ln != null) for (int k = 0; k < st.ln.Length; k++) { var line = ToroEngine.Lines[st.ln[k]]; for (int c = 0; c < st.lc[k] && c < C; c++) set.Add(c * R + line[c]); }
            return set.ToList();
        }

        IEnumerator ShowLines(ToroEngine.Step st, float d, string label)
        {
            var cells = WinCells(st);
            _winLabel.text = label + (st.ln != null && st.ln.Length > 1 ? $"  <size=70%>({st.ln.Length} lines)</size>" : "");
            Sfx(multiplierSFX, Mathf.Min(1000f, (float)st.w * 10f));
            foreach (var i in cells) { _cellGlow[i].gameObject.SetActive(true); _cellGlow[i].color = new Color(1f, .8f, .3f, 0); }
            float t0 = Time.time;
            while (Time.time - t0 < d)
            {
                float p = (Time.time - t0) / d;
                foreach (var i in cells)
                {
                    var c = _cellGlow[i].color; c.a = .5f + .35f * Mathf.Sin(p * 14); _cellGlow[i].color = c;
                    if (!_cell[i].enabled) continue;
                    _cell[i].rectTransform.localScale = Vector3.one * (1 + .15f * Mathf.SmoothStep(0, 1, Mathf.Min(1, p * 3f)) + Mathf.Sin(p * 18) * .04f);
                }
                yield return null;
            }
            foreach (var i in cells) { _cell[i].rectTransform.localScale = Vector3.one; _cellGlow[i].gameObject.SetActive(false); }
        }

        /// the X on top flies onto the line win and the result pops
        IEnumerator ApplyMultiplier(ToroEngine.Step st, float d)
        {
            int x = Mathf.Max(1, st.x);
            var from = new Vector2(0, _uiSize.y / 2 - _uiSize.y * .08f); var target = _gridCenter + new Vector2(0, -_gh * .32f);
            float fly = d * .45f; float t0 = Time.time;
            var tx = Txt("fly", _fx, Gold); Place(tx.rectTransform, from, new Vector2(_cs * 1.6f, _cs * .8f)); tx.text = "X" + x; _fxObjs.Add(tx.gameObject);
            Sfx(multiplierSFX, x);
            while (Time.time - t0 < fly)
            {
                float p = (Time.time - t0) / fly, e = p * p * (3 - 2 * p);
                if (tx == null) break;
                tx.rectTransform.anchoredPosition = Vector2.Lerp(from, target, e); tx.rectTransform.localScale = Vector3.one * (1.5f - .4f * p); yield return null;
            }
            if (tx != null) Destroy(tx.gameObject);
            _winLabel.text = $"{Money(st.w)} <color=#ffe066>\u00D7 X{x}</color> = <size=125%>{Money(st.mw)}</size>";
            StartCoroutine(Particles(target, Gold, 18, d * .5f, _cs * 1.6f));
            StartCoroutine(Pop(_winLabel.transform, d * .4f));
            if (x >= 10) StartCoroutine(Shake(d * .3f, _cs * .05f));
            yield return Wait(d - fly);
        }

        IEnumerator Pop(Transform tr, float d)
        {
            float t0 = Time.time;
            while (Time.time - t0 < d) { float p = (Time.time - t0) / d; if (tr == null) yield break; tr.localScale = Vector3.one * (1 + .3f * Mathf.Sin(p * Mathf.PI)); yield return null; }
            if (tr != null) tr.localScale = Vector3.one;
        }

        IEnumerator EndRoutine(TlMsg m)
        {
            _lastWinX = m.tot; RefreshBar();
            if (m.tot < 10) yield break;
            Sfx(finaltextSFX, m.tot);
            _bannerIcon.sprite = Spr("toro_head");
            string title = m.tot >= 500 ? "EPIC WIN" : m.tot >= 100 ? "MEGA WIN" : m.tot >= 50 ? "SUPER WIN" : "BIG WIN";
            _bannerSub.text = (m.x > 1 ? $"Minotaur X{m.x}  \u2022  " : "") + $"{m.tot:0.##}x bet" + (m.cap == 1 ? "  \u2022  MAX WIN" : "");
            float d = m.tb == 1 ? 1.5f : 3f, hold = m.tb == 1 ? 1f : 2.5f, t0 = Time.time;
            ShowBanner(d + hold + .2f); _particleBudget = 40;
            StartCoroutine(Particles(Vector2.zero, Gold, 40, d * .8f, _gw * .7f));
            while (Time.time - t0 < d)
            {
                float p = Mathf.Clamp01((Time.time - t0) / (d * .7f));
                _bannerText.text = $"<size=55%>{title}</size>\n" + Money(m.tot * (1 - Mathf.Pow(1 - p, 3)));
                _bannerText.transform.localScale = Vector3.one * (1 + .06f * Mathf.Sin(Time.time * 9)); yield return null;
            }
            _bannerText.text = $"<size=55%>{title}</size>\n" + Money(m.tot);
            yield return Wait(hold);
            HideBanner(); _bannerText.transform.localScale = Vector3.one;
        }
    }
}
