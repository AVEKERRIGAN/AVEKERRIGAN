using System;
using System.Collections;
using System.Linq;
using HarmonyLib;
using Mirror;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace ToroLeap
{
    /// v1.1.0: on-screen HUD (E-clickable via invisible colliders over the screen mesh), AUTO, late-join sync.
    public partial class ToroLeapGame
    {
        Image _hudTurbo, _hudAuto, _hudSpin; TextMeshProUGUI _hudTurboTxt, _hudAutoTxt;

        /// Rects in panel space: x from left, y from BOTTOM (0..1). Shared by the drawn HUD and the world colliders.
        public struct BtnDef { public string id, sprite, tip; public float cx, cy, w, h; public BtnDef(string i, string s, string t, float x, float y, float ww, float hh) { id = i; sprite = s; tip = t; cx = x; cy = y; w = ww; h = hh; } }
        public static readonly BtnDef[] Buttons = {
            new BtnDef("Buy",   "panel_dark", "Bonus Pop (buy Toro re-spins)", .1f,  .64f, .17f, .26f),
            new BtnDef("Sel",   "panel_dark", "Bonus Pop: choose reel 2/3/4",  .1f,  .43f, .17f, .1f),
            new BtnDef("Minus", "pill",       "Bet -",                          .05f, .05f, .07f, .065f),
            new BtnDef("Plus",  "pill",       "Bet +",                          .26f, .05f, .07f, .065f),
            new BtnDef("Turbo", "pill",       "Turbo",                          .62f, .05f, .09f, .065f),
            new BtnDef("Auto",  "pill",       "Auto spin",                      .72f, .05f, .09f, .065f),
            new BtnDef("Spin",  "spin_pill",  "Spin",                           .875f,.05f, .21f, .08f),
        };
        static BtnDef BtnRect(string id) => Buttons.First(b => b.id == id);
        void PlaceN(RectTransform rt, BtnDef b) { rt.anchorMin = rt.anchorMax = new Vector2(b.cx, b.cy); rt.pivot = new Vector2(.5f, .5f); rt.sizeDelta = new Vector2(_uiSize.x * b.w, _uiSize.y * b.h); rt.anchoredPosition = Vector2.zero; }

        void BuildHud()
        {
            foreach (var b in Buttons)
            {
                var im = Img("Hud" + b.id, _ui, Spr(b.sprite)); im.preserveAspect = false; PlaceN(im.rectTransform, b);
                if (im.sprite == null) im.color = new Color(.1f, .07f, .05f, .85f);
                var tx = Txt("HudTxt" + b.id, im.transform, Cream); Stretch(tx.rectTransform); tx.margin = new Vector4(8, 4, 8, 4);
                switch (b.id)
                {
                    case "Buy": _buyText = tx; break;
                    case "Sel": _selText = tx; break;
                    case "Minus": tx.text = "\u2212"; break;
                    case "Plus": tx.text = "+"; break;
                    case "Turbo": _hudTurbo = im; _hudTurboTxt = tx; tx.text = "TURBO"; break;
                    case "Auto": _hudAuto = im; _hudAutoTxt = tx; tx.text = "AUTO"; break;
                    case "Spin": _hudSpin = im; tx.text = ""; break;
                }
            }
            _betText = Txt("BetText", _ui, Cream); _betText.rectTransform.anchorMin = new Vector2(.095f, .01f); _betText.rectTransform.anchorMax = new Vector2(.215f, .09f); _betText.rectTransform.offsetMin = _betText.rectTransform.offsetMax = Vector2.zero;
        }

        void HudTurbo(bool on) { if (_hudTurbo != null) _hudTurbo.sprite = Spr(on ? "pill_on" : "pill") ?? _hudTurbo.sprite; }
        void UpdateAutoVisual(int left)
        {
            GwyfShared.ToggleTint.Ui(_hudAuto, left > 0);
            if (_hudAuto != null) _hudAuto.sprite = Spr(left > 0 ? "pill_on" : "pill") ?? _hudAuto.sprite;
            if (_hudAutoTxt != null) _hudAutoTxt.text = left > 0 ? "AUTO " + left : "AUTO";
        }
        void UpdateHudSpin() { if (_hudSpin == null) return; _hudSpin.transform.localScale = _anim != null ? Vector3.one * (1f + .03f * Mathf.Sin(Time.time * 10f)) : Vector3.one; }

        // ---------------- server: screen buttons, AUTO, late-join sync ----------------
        int _autoLeft; PlayerInteract _autoPi; bool _autoRound;

        void HookScreenButtons()
        {
            foreach (var trig in GetComponentsInChildren<InteractableEventTrigger>(true))
            {
                if (!trig.name.StartsWith("TLScr_")) continue;
                switch (trig.name.Substring(6))
                {
                    case "Spin": Hook(trig, TryStartGame); break;
                    case "Buy": Hook(trig, TryBuy); break;
                    case "Sel": Hook(trig, CycleBuy); break;
                    case "Turbo": Hook(trig, ToggleTurbo); break;
                    case "Plus": Hook(trig, p => StepBet(+1)); break;
                    case "Minus": Hook(trig, p => StepBet(-1)); break;
                    case "Auto": Hook(trig, ToggleAuto); break;
                }
            }
        }

        TlMsg State(string t, int au = -1) => new TlMsg { t = t, tb = turbo ? 1 : 0, sel = buySel, au = au < 0 ? _autoLeft : au };

        [Server]
        public void ToggleAuto(PlayerInteract pi)
        {
            if (!NetworkServer.active) return;
            if (_autoLeft > 0) { _autoLeft = 0; _autoPi = null; Broadcast(State("auto")); ToroLeapPlugin.V("Auto OFF"); return; }
            if (pi == null) return;
            _autoLeft = Mathf.Clamp(ToroLeapPlugin.AutoSpins?.Value ?? 10, 1, 100); _autoPi = pi;
            Broadcast(State("auto")); ToroLeapPlugin.V($"Auto ON: {_autoLeft} spins");
            if (!isPlaying) StartCoroutine(AutoNext(0.05f));
        }

        /// byAuto: the round just finished was started by AUTO (manual spins/buys never count)
        void ContinueAuto(bool featureHit, bool byAuto)
        {
            if (_autoLeft <= 0) return;
            if (byAuto) { _autoLeft--; if (featureHit && (ToroLeapPlugin.AutoStopOnFeature?.Value ?? true)) _autoLeft = 0; }
            if (_autoPi == null) _autoLeft = 0;
            Broadcast(State("auto"));
            if (_autoLeft > 0) StartCoroutine(AutoNext(turbo ? .3f : .8f));
        }
        void StopAuto() { if (_autoLeft <= 0 && _autoPi == null) return; _autoLeft = 0; _autoPi = null; Broadcast(State("auto")); }

        IEnumerator AutoNext(float delay)
        {
            yield return new WaitForSeconds(delay);
            if (_autoLeft <= 0 || _autoPi == null || isPlaying) yield break;
            _autoRound = true;
            try { TryStartGame(_autoPi); } catch (Exception e) { ToroLeapPlugin.Log.LogError(e); }
            if (!isPlaying) { _autoRound = false; StopAuto(); ToroLeapPlugin.V("Auto stopped (spin refused: money/bet)"); }
        }

        int _lastConnCount = -1; float _nextSync;
        void ServerStateSync()
        {
            if (!NetworkServer.active || Time.unscaledTime < _nextSync) return;
            _nextSync = Time.unscaledTime + 2f;
            int n = NetworkServer.connections.Count; if (n == _lastConnCount) return;
            _lastConnCount = n;
            var m = State("bet"); try { if (!currentBet.IsZero) { m.bet = FormatBet(currentBet); m.bn = currentBet.ToDouble(); } } catch { }
            Broadcast(m);
        }

        // ---------------- prefab: invisible raycast colliders over the screen ----------------
        public static void CreateScreenButtons(ToroLeapGame game, GameObject clone)
        {
            var play = game.playButtons.FirstOrDefault(); if (play == null) { ToroLeapPlugin.Log.LogWarning("[TL] Screen buttons: no play button template"); return; }
            RenderTexture rtex = GwyfShared.ScreenIso.FindRT(clone);
            Renderer scr = null;
            foreach (var r in clone.GetComponentsInChildren<Renderer>(true))
            {
                if (rtex == null || scr != null) break;
                foreach (var m in r.sharedMaterials) if (m != null) foreach (var p in m.GetTexturePropertyNames()) if (m.GetTexture(p) == rtex) scr = r;
            }
            var mf = scr != null ? scr.GetComponent<MeshFilter>() : null;
            if (scr == null || mf == null || mf.sharedMesh == null) ToroLeapPlugin.Log.LogWarning($"[TL] Screen buttons: screen mesh not found (rt={(rtex != null)}, renderer={(scr != null)}) - use the cabinet buttons");
            Bounds b = mf != null && mf.sharedMesh != null ? mf.sharedMesh.bounds : new Bounds(Vector3.zero, Vector3.one);
            Vector3 ext = b.size; int nAx = ext.x <= ext.y && ext.x <= ext.z ? 0 : ext.y <= ext.z ? 1 : 2;
            int[] rest = new[] { 0, 1, 2 }.Where(a => a != nAx).ToArray();
            int uAx = ext[rest[0]] >= ext[rest[1]] ? rest[0] : rest[1], vAx = uAx == rest[0] ? rest[1] : rest[0];
            float uSign = 1f, vSign = 1f;
            try
            {
                var mesh = mf != null ? mf.sharedMesh : null;
                if (mesh != null && mesh.isReadable)
                {
                    var vs = mesh.vertices; var uv = mesh.uv;
                    if (uv != null && uv.Length == vs.Length && vs.Length >= 3)
                    {
                        int iu0 = 0, iu1 = 0, iv0 = 0, iv1 = 0;
                        for (int i = 1; i < uv.Length; i++) { if (uv[i].x < uv[iu0].x) iu0 = i; if (uv[i].x > uv[iu1].x) iu1 = i; if (uv[i].y < uv[iv0].y) iv0 = i; if (uv[i].y > uv[iv1].y) iv1 = i; }
                        Vector3 du = vs[iu1] - vs[iu0];
                        uAx = Mathf.Abs(du[rest[0]]) >= Mathf.Abs(du[rest[1]]) ? rest[0] : rest[1]; vAx = uAx == rest[0] ? rest[1] : rest[0];
                        uSign = Mathf.Sign(du[uAx]); vSign = Mathf.Sign((vs[iv1] - vs[iv0])[vAx]);
                        if (uSign == 0) uSign = 1; if (vSign == 0) vSign = 1;
                        ToroLeapPlugin.V($"Screen UV orientation from mesh: u=axis{uAx}{(uSign > 0 ? "+" : "-")} v=axis{vAx}{(vSign > 0 ? "+" : "-")}");
                    }
                }
            }
            catch (Exception e) { ToroLeapPlugin.V("Screen UV read failed: " + e.Message); }
            if (ToroLeapPlugin.ScreenFlipX != null && ToroLeapPlugin.ScreenFlipX.Value) uSign = -uSign;
            if (ToroLeapPlugin.ScreenFlipY != null && ToroLeapPlugin.ScreenFlipY.Value) vSign = -vSign;
            float margin = ToroLeapPlugin.ScreenMargin != null ? Mathf.Clamp(ToroLeapPlugin.ScreenMargin.Value, 0f, .2f) : .03f;
            Transform parent = scr != null ? scr.transform : game.transform;
            float nScale = Mathf.Max(1e-4f, Mathf.Abs(parent.lossyScale[nAx]));
            int made = 0;
            foreach (var d in Buttons)
            {
                var go = UnityEngine.Object.Instantiate(play.gameObject, parent); go.name = "TLScr_" + d.id;
                for (int i = go.transform.childCount - 1; i >= 0; i--) UnityEngine.Object.DestroyImmediate(go.transform.GetChild(i).gameObject);
                foreach (var c in go.GetComponents<Collider>()) UnityEngine.Object.DestroyImmediate(c);
                foreach (var c in go.GetComponents<Renderer>()) UnityEngine.Object.DestroyImmediate(c);
                foreach (var c in go.GetComponents<MeshFilter>()) UnityEngine.Object.DestroyImmediate(c);
                go.transform.localRotation = Quaternion.identity; go.transform.localScale = Vector3.one;
                float u = .5f + (d.cx - .5f) * (1f - 2f * margin), v = .5f + (d.cy - .5f) * (1f - 2f * margin);
                Vector3 pos = b.center, size = Vector3.zero;
                pos[uAx] += uSign * (u - .5f) * ext[uAx]; pos[vAx] += vSign * (v - .5f) * ext[vAx];
                size[uAx] = d.w * (1f - 2f * margin) * ext[uAx]; size[vAx] = d.h * (1f - 2f * margin) * ext[vAx]; size[nAx] = .05f / nScale;
                go.transform.localPosition = pos;
                var bc = go.AddComponent<BoxCollider>(); bc.size = size;
                var trig = go.GetComponent<InteractableEventTrigger>();
                if (trig != null)
                {
                    foreach (var ev in new UnityEngine.Events.UnityEventBase[] { trig.onInteractEvent, trig.serverOnInteractEvent, trig.rpcOnInteractEvent, trig.onHoverEvent, trig.onHoverExitEvent, trig.onHoldEvent, trig.onHoldExitEvent })
                        if (ev != null) for (int i = 0; i < ev.GetPersistentEventCount(); i++) ev.SetPersistentListenerState(i, UnityEngine.Events.UnityEventCallState.Off);
                    try { AccessTools.Field(typeof(InteractableBase), "tooltipMessage").SetValue(trig, "[E] " + d.tip); } catch { }
                    try { AccessTools.Field(typeof(InteractableBase), "interactableName").SetValue(trig, "Toro Leap: " + d.tip); } catch { }
                }
                made++;
            }
            ToroLeapPlugin.V($"Screen buttons: {made} colliders on '{(scr != null ? scr.name : "machine root")}' (normal axis {nAx}, mesh size {ext})");
        }
    }
}
