using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using BepInEx;
using BepInEx.Configuration;
using HarmonyLib;
using Mirror;
using MoreMountains.Tools;
using UnityEngine;

namespace ToroLeap
{
    [BepInPlugin(GUID, "Toro Leap Slot", Version)]
    [BepInDependency("com.moregames.base", BepInDependency.DependencyFlags.SoftDependency)]
    public class ToroLeapPlugin : BaseUnityPlugin
    {
        public const string GUID = "com.malenki.toroleap", Version = "1.2.12";
        /// bump when the RPC/message layout or prefab buttons change: hashed into the assetId so mismatched versions never spawn/desync
        public const string NetLayout = "net-1.3";
        public const string PrefabName = "ToroLeap_Machine";
        public static ToroLeapPlugin Instance;
        public static BepInEx.Logging.ManualLogSource Log;
        public static GameObject Prefab;
        public static uint AssetId;
        public static ConfigEntry<bool> ReplaceAllSlots, Verbose, RestyleCabinet;
        public static ConfigEntry<float> CabinetScale, ScreenMargin, Particles, ShakeAmount;
        public static ConfigEntry<string> ToroReelWeights;
        public static ConfigEntry<KeyCode> ForceToroKey;
        public static ConfigEntry<KeyCode> SpawnKey, ForceBonusKey, TurboKey;
        public static ConfigEntry<bool> EnableForceBonusKey, AlwaysBonusNextSpin;
        public static ConfigEntry<int> ForceBonusEveryNSpins, AutoSpins;
        public static ConfigEntry<bool> AutoStopOnFeature, ScreenFlipX, ScreenFlipY;
        public static ConfigEntry<float> MaxWinX;

        static GameObject _holder;
        float _nextCheck;
        static readonly HashSet<string> _loggedFloors = new HashSet<string>();
        static float _nextBuildAttempt;
        static bool _legacyBroken;
        static int _lastTemplateCount = -1;

        public static void V(string s) { if (Verbose == null || Verbose.Value) Log.LogInfo("[TL] " + s); }

        void Awake()
        {
            Instance = this; Log = Logger;
            CabinetScale = Config.Bind("TL_Cabinet", "TL_CabinetScale", 1.35f, "Overall cabinet size multiplier (1 = vanilla). Host-side; clients get it via spawn.");
            ReplaceAllSlots = Config.Bind("TL_Spawn", "TL_ReplaceVanillaSlots", false,
                "Host: every spot that would spawn the vanilla slot machine spawns Toro Leap instead (otherwise it is added to the floor pool next to the vanilla slot).");
            SpawnKey = Config.Bind("TL_Debug", "TL_SpawnKey", KeyCode.Home,
                "Host only: spawn a Toro Leap machine 3 m in front of you. None = disabled.");
            TurboKey = Config.Bind("TL_Controls", "TL_TurboKey", KeyCode.None,
                "Host: toggle TURBO on all Toro Leap machines (the in-world TURBO button works for everyone). None = off (default).");
            ForceBonusKey = Config.Bind("TL_Debug", "TL_ForceBonusKey", KeyCode.End,
                "Host only (needs TL_EnableForceBonusKey): force the Minotaur on the NEXT spin (random reel 2-4). v1.1.0 has no free spins.");
            ForceToroKey = Config.Bind("TL_Debug", "TL_ForceToroKey", KeyCode.PageDown,
                "Host only (needs TL_EnableForceBonusKey): force Toro to land on the NEXT spin (cycles reel 2/3/4).");
            EnableForceBonusKey = Config.Bind("TL_Debug", "TL_EnableForceBonusKey", false, "DEBUG (host): allow End (Toro, random reel) and PageDown (Toro, cycle reel 2/3/4) debug keys.");
            AlwaysBonusNextSpin = Config.Bind("TL_Debug", "TL_AlwaysBonus", false, "DEBUG host: EVERY paid spin lands the Minotaur.");
            ForceBonusEveryNSpins = Config.Bind("TL_Debug", "TL_ForceBonusEveryNSpins", 0, "DEBUG host: force the Minotaur every N spins per machine (0 = off).");
            AutoSpins = Config.Bind("TL_Controls", "TL_AutoSpins", 10, "Spins started by the on-screen AUTO button (1..100). Press AUTO again to stop.");
            AutoStopOnFeature = Config.Bind("TL_Controls", "TL_AutoStopOnFeature", true, "Stop auto-spin when the Minotaur lands.");
            ScreenFlipX = Config.Bind("TL_Visual", "TL_ScreenButtonsFlipX", false, "If clicks on the on-screen buttons land mirrored left/right, set true (same on all players). Restart required.");
            ScreenFlipY = Config.Bind("TL_Visual", "TL_ScreenButtonsFlipY", false, "Same for top/bottom.");
            MaxWinX = Config.Bind("TL_Math", "TL_MaxWinX", 10000f, "Host: max win per round in x bet (original Minotaurus: 10 000x). Allowed 1000..100000.");
            ToroEngine.MaxWinX = Mathf.Clamp(MaxWinX.Value, 1000f, 100000f);
            ScreenMargin = Config.Bind("TL_Visual", "TL_ScreenSafeMargin", 0.03f, "Inset of the slot screen on each side (0..0.2) so the bezel never cuts symbols.");
            RestyleCabinet = Config.Bind("TL_Visual", "TL_RestyleCabinet", true, "Recolor the cabinet in Toro Leap colors, logo topper and side light strips (client side).");
            Particles = Config.Bind("TL_Visual", "TL_ParticleAmount", 1f, "Dust/sparkle particle amount multiplier (0 = off, 1 = normal, 2 = lots).");
            ShakeAmount = Config.Bind("TL_Visual", "TL_ScreenShake", 1f, "Slot screen shake strength when Toro slams down (0 = off).");
            ToroReelWeights = Config.Bind("TL_Math", "TL_ToroReelWeights_v110", "50,32,18",
                "Host: relative chance that a natural Minotaur lands on reel 2,3,4 (default 50,32,18 = reel 2 1/182 spins, reel 3 1/285, reel 4 1/499). RTP ~96% was simulated with the default; other values change RTP.");
            try { var ws = ToroReelWeights.Value.Split(',').Select(x => double.Parse(x.Trim(), System.Globalization.CultureInfo.InvariantCulture)).ToArray(); if (ws.Length == 3 && ws.All(x => x >= 0) && ws.Sum() > 0) ToroEngine.ToroReelW = ws; else Logger.LogWarning("[TL] TL_ToroReelWeights needs 3 numbers, using default"); }
            catch (Exception e) { Logger.LogWarning("[TL] TL_ToroReelWeights invalid (" + e.Message + "), using default"); }
            Verbose = Config.Bind("TL_Debug", "TL_VerboseLogging", true, "Write detailed [TL] lines to LogOutput.log.");
            using (var md5 = MD5.Create())
                AssetId = BitConverter.ToUInt32(md5.ComputeHash(Encoding.UTF8.GetBytes(PrefabName + "|" + NetLayout)), 0);
            if (AssetId == 0) AssetId = 0x544C5031;
            ToroLeapGame.RegisterRpcs();
            V("RPC UserRpcShowSpin registered");
            var h = new Harmony(GUID);
            h.PatchAll(typeof(ToroLeapPlugin).Assembly);
            foreach (var m in h.GetPatchedMethods()) V("Harmony patched: " + m.DeclaringType?.Name + "." + m.Name);
            try
            {
                var runner = new GameObject("ToroLeapRunner");
                runner.hideFlags = HideFlags.HideAndDontSave;
                UnityEngine.Object.DontDestroyOnLoad(runner);
                runner.AddComponent<ToroRunner>();
            }
            catch (Exception e) { Logger.LogError("Runner creation failed: " + e); }
            Logger.LogInfo($"Toro Leap {Version} loaded, assetId={AssetId}, spawnKey={SpawnKey.Value}, replaceVanillaSlots={ReplaceAllSlots.Value}");
        }

        void Update() => Tick();

        static int _lastTickFrame = -1;
        static bool _tickLogged;
        /// Called from our own runner object, the plugin object and every machine; runs once per frame.
        public void Tick()
        {
            if (Time.frameCount == _lastTickFrame) return;
            _lastTickFrame = Time.frameCount;
            if (!_tickLogged) { _tickLogged = true; V("Tick running (input + spawn handler checks active)"); }
            try { TickInner(); } catch (Exception e) { if (Time.frameCount % 600 == 0) Log.LogError("[TL] Tick error: " + e); }
        }

        void TickInner()
        {
            CheckHotkey();
            if (KeyPressed(TurboKey.Value) && NetworkServer.active)
                foreach (var g in FindObjectsByType<ToroLeapGame>(FindObjectsSortMode.None)) g.ToggleTurbo(null);
            if (EnableForceBonusKey.Value && KeyPressed(ForceBonusKey.Value)) ToggleForceBonus("key");
            if (EnableForceBonusKey.Value && KeyPressed(ForceToroKey.Value))
            {
                if (!NetworkServer.active) Log.LogWarning("[TL] Force Toro works only for the HOST.");
                else { ToroLeapGame.ForceToroNext = ToroLeapGame.ForceToroNext >= 3 ? 0 : ToroLeapGame.ForceToroNext + 1; Log.LogInfo("[TL] Force Toro on next spin: " + (ToroLeapGame.ForceToroNext == 0 ? "OFF" : "reel " + (ToroLeapGame.ForceToroNext + 1))); }
            }
            if (Time.unscaledTime < _nextCheck) return;
            _nextCheck = Time.unscaledTime + 1f;
            try
            {
                var dict = (Dictionary<uint, SpawnHandlerDelegate>)AccessTools.Field(typeof(NetworkClient), "spawnHandlers").GetValue(null);
                if (!dict.ContainsKey(AssetId))
                {
                    NetworkClient.RegisterSpawnHandler(AssetId, ClientSpawn, ClientUnspawn);
                    V("Client spawn handler registered");
                }
            }
            catch (Exception e) { Logger.LogError("Spawn handler registration failed: " + e); _nextCheck += 30f; }
            // try to build the prefab early (once a casino is loaded) so problems show up in the log
            if (Prefab == null && NetworkClient.active && Time.unscaledTime > _nextBuildAttempt)
            {
                _nextBuildAttempt = Time.unscaledTime + 10f;
                EnsurePrefab(null, quiet: true);
            }
        }

        public static void ToggleForceBonus(string source)
        {
            if (!NetworkServer.active) { Log.LogWarning($"[TL] Force bonus ({source}) works only for the HOST."); return; }
            ToroLeapGame.ForceToroNext = ToroLeapGame.ForceToroNext > 0 ? 0 : UnityEngine.Random.Range(1, 4);
            Log.LogInfo($"[TL] Force Minotaur on next spin: {(ToroLeapGame.ForceToroNext > 0 ? "reel " + (ToroLeapGame.ForceToroNext + 1) : "OFF")} (via {source})");
        }

        static bool KeyHeld(KeyCode k)
        {
            try { var kb = UnityEngine.InputSystem.Keyboard.current; if (kb != null && Enum.TryParse<UnityEngine.InputSystem.Key>(k.ToString(), out var key) && kb[key].isPressed) return true; } catch { }
            if (_legacyBroken) return false;
            try { return Input.GetKey(k); } catch { _legacyBroken = true; return false; }
        }

        static bool KeyPressed(KeyCode k)
        {
            bool r = KeyPressedRaw(k);
            if (r) Log.LogInfo($"[TL] Key {k} pressed (host={NetworkServer.active})");
            return r;
        }

        static bool KeyPressedRaw(KeyCode k)
        {
            if (k == KeyCode.None) return false;
            try
            {
                var kb = UnityEngine.InputSystem.Keyboard.current;
                if (kb != null && Enum.TryParse<UnityEngine.InputSystem.Key>(k.ToString(), out var key) && kb[key].wasPressedThisFrame) return true;
            }
            catch { }
            if (_legacyBroken) return false;
            try { return Input.GetKeyDown(k); } catch { _legacyBroken = true; return false; }
        }

        void CheckHotkey()
        {
            if (!KeyPressed(SpawnKey.Value)) return;
            V($"Spawn key {SpawnKey.Value} pressed (server active={NetworkServer.active})");
            if (!NetworkServer.active) { Log.LogWarning("[TL] Spawn key works only for the HOST."); return; }
            if (!EnsurePrefab(null)) { Log.LogError("[TL] Cannot spawn: prefab could not be built (see messages above)."); return; }
            var lp = NetworkClient.localPlayer;
            Transform t = lp != null ? lp.transform : (Camera.main != null ? Camera.main.transform : null);
            if (t == null) { Log.LogError("[TL] Cannot spawn: no local player found."); return; }
            var fwd = Vector3.ProjectOnPlane(t.forward, Vector3.up); if (fwd.sqrMagnitude < 0.01f) fwd = Vector3.forward; fwd.Normalize();
            var pos = t.position + fwd * 3f;
            if (Physics.Raycast(pos + Vector3.up * 2f, Vector3.down, out var hit, 10f)) pos = hit.point;
            var rot = Quaternion.LookRotation(-fwd, Vector3.up);
            try
            {
                var go = Instantiate(Prefab, pos, rot);
                go.name = PrefabName;
                go.transform.localScale = Prefab.transform.localScale;
                NetworkServer.Spawn(go);
                Log.LogInfo($"[TL] Hotkey spawned Toro Leap at {pos}. If it faces the wrong way, walk around it :)");
            }
            catch (Exception e) { Log.LogError("[TL] Hotkey spawn failed: " + e); }
        }

        static GameObject ClientSpawn(SpawnMessage msg)
        {
            V($"Client spawn request netId={msg.netId} pos={msg.position}");
            if (!EnsurePrefab(null)) { Log.LogError("[TL] Cannot spawn Toro Leap on client: no template machine found."); return null; }
            var go = UnityEngine.Object.Instantiate(Prefab, msg.position, msg.rotation);
            go.transform.localScale = msg.scale;
            go.name = PrefabName;
            V("Client spawned Toro Leap instance");
            return go;
        }
        static void ClientUnspawn(GameObject go) { V("Client unspawn Toro Leap"); UnityEngine.Object.Destroy(go); }

        static GameObject FindTemplate(out string how)
        {
            how = null;
            var all = Resources.FindObjectsOfTypeAll<GameBase>().Where(g => g != null).ToList();
            var assets = all.Where(g => !g.gameObject.scene.IsValid()).ToList();
            if (all.Count != _lastTemplateCount) V($"Template search: {all.Count} GameBase objects loaded, {assets.Count} are prefabs: " +
              string.Join(", ", assets.Select(g => g.GetType().Name + "@" + g.transform.root.name).Distinct().Take(30)));
            _lastTemplateCount = all.Count;
            GameBase pick = assets.FirstOrDefault(g => g is Slots && g.transform.root.GetComponent<NetworkIdentity>() != null);
            if (pick != null) { how = "vanilla Slots prefab"; return pick.transform.root.gameObject; }
            pick = assets.FirstOrDefault(g => g.GetType() != typeof(ToroLeapGame) && g.transform.root.GetComponent<NetworkIdentity>() != null
                                               && g.transform.root.GetComponentsInChildren<NetworkBehaviour>(true).Length <= 3);
            if (pick != null) { how = "fallback prefab " + pick.GetType().Name; return pick.transform.root.gameObject; }
            return null;
        }

        /// Build our prefab by cloning a vanilla machine and swapping its game script.
        public static bool EnsurePrefab(GameObject template, bool quiet = false)
        {
            if (Prefab != null) return true;
            string how = "loot table template";
            if (template == null) template = FindTemplate(out how);
            if (template == null)
            {
                if (!quiet) Log.LogError("[TL] No template machine prefab loaded yet (enter the casino first).");
                return false;
            }
            V($"Building prefab from '{template.name}' ({how})");
            try
            {
                if (_holder == null)
                {
                    _holder = new GameObject("ToroLeap_PrefabHolder");
                    _holder.SetActive(false);
                    UnityEngine.Object.DontDestroyOnLoad(_holder);
                }
                var clone = UnityEngine.Object.Instantiate(template, _holder.transform);
                clone.name = PrefabName;
                var old = clone.GetComponentsInChildren<GameBase>(true).FirstOrDefault(g => !(g is ToroLeapGame));
                if (old == null) { Log.LogError("[TL] Template has no GameBase"); UnityEngine.Object.Destroy(clone); return false; }
                V($"Template game script: {old.GetType().FullName} on '{old.gameObject.name}'");
                var game = old.gameObject.AddComponent<ToroLeapGame>();
                int copied = 0;
                foreach (var f in typeof(GameBase).GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.DeclaredOnly))
                    try { f.SetValue(game, f.GetValue(old)); copied++; } catch { }
                V($"Copied {copied} GameBase fields (keypadSpawnPoint={(game.keypadSpawnPoint != null ? game.keypadSpawnPoint.name : "NULL")})");
                if (old is Slots s) game.CopyFromSlots(s); else game.SetDefaults();
                V($"Anchor images={game.symbolLocations?.Count ?? 0}, reels={game.reels?.Count ?? 0}, payoutText={(game.payoutText != null)}");
                foreach (var trig in clone.GetComponentsInChildren<InteractableEventTrigger>(true))
                {
                    var ev = trig.serverOnInteractEvent; if (ev == null) continue;
                    for (int i = 0; i < ev.GetPersistentEventCount(); i++)
                        if (ev.GetPersistentTarget(i) == old)
                        {
                            V($"Button '{trig.name}' -> {ev.GetPersistentMethodName(i)} rewired");
                            ev.SetPersistentListenerState(i, UnityEngine.Events.UnityEventCallState.Off);
                            if (ev.GetPersistentMethodName(i) == "TryStartGame") game.playButtons.Add(trig);
                        }
                }
                try { CreateTurboButton(game); } catch (Exception e) { Log.LogError("[TL] Turbo button creation failed: " + e); }
                try { ToroLeapGame.CreateScreenButtons(game, clone); } catch (Exception e) { Log.LogError("[TL] Screen buttons creation failed: " + e); }
                if (game.playButtons.Count == 0) Log.LogWarning("[TL] No play button found on template - machine will not start!");
                UnityEngine.Object.DestroyImmediate(old);
                var id = clone.GetComponent<NetworkIdentity>();
                AccessTools.Property(typeof(NetworkIdentity), "assetId").SetValue(id, AssetId);
                Prefab = clone;
                Log.LogInfo($"[TL] Prefab READY from '{template.name}' ({how}), play buttons={game.playButtons.Count}, assetId={id.assetId}");
                return true;
            }
            catch (Exception e) { Log.LogError("[TL] Building prefab failed: " + e); return false; }
        }

        static void CreateTurboButton(ToroLeapGame game)
        {
            var play = game.playButtons.FirstOrDefault(); if (play == null) return;
            var pt = play.transform;
            var col = play.GetComponentInChildren<Collider>(true);
            var parent = pt.parent;
            float width = 0.4f;
            if (col is BoxCollider bc) width = bc.size.x * Mathf.Abs(bc.transform.lossyScale.x) / Mathf.Max(1e-4f, Mathf.Abs(parent != null ? parent.lossyScale.x : 1f));
            Vector3 right = pt.localRotation * Vector3.right; float colW = width; width = GwyfShared.ButtonFit.Measure(pt, right, width); V($"Play button width: collider {colW:0.###}, visible {width:0.###}");
            Vector3 basePos = pt.localPosition, baseScale = pt.localScale;
            // layout (fractions of the original SPIN button width), always identical on every client:
            // [BUY .15][ANTE .15][- .10][SPIN .28][+ .10][TURBO .15]  (+ small gaps)
            GameObject Make(string name, float center, float frac, string label)
            {
                var go = UnityEngine.Object.Instantiate(play.gameObject, parent); go.name = name;
                go.transform.localScale = new Vector3(baseScale.x * frac * .9f, baseScale.y, baseScale.z); // 10 % gap between buttons
                go.transform.localPosition = basePos + right * width * center;
                foreach (var t in go.GetComponentsInChildren<TMPro.TMP_Text>(true))
                {
                    foreach (var c in t.GetComponents<MonoBehaviour>()) if (c != null && c.GetType().Name.IndexOf("Locali", StringComparison.OrdinalIgnoreCase) >= 0) UnityEngine.Object.DestroyImmediate(c);
                    
                    t.text = label; GwyfShared.ButtonFit.FitLabel(t, parent, width * frac * .78f, frac * .9f); // layout fix: labels clamped to their own button
                }
                return go;
            }
            // v1.1.0: [BONUS POP .15][REEL .15][- .085][SPIN .24][+ .085][TURBO .13]
            var buy = Make("TL_BuyButton", -0.40f, 0.15f, "BONUS POP\n<size=55%>17.5x BET</size>");
            var sel = Make("TL_BuySelect", -0.23f, 0.15f, "REEL\n<size=60%>3</size>");
            var minus = Make("TL_BetMinus", -0.04f, 0.085f, "BET\n-");
            var plus = Make("TL_BetPlus", 0.32f, 0.085f, "BET\n+");
            var turbo = Make("TL_TurboButton", 0.44f, 0.13f, "TURBO\n<size=70%>OFF</size>");
            pt.localScale = new Vector3(baseScale.x * 0.24f, baseScale.y, baseScale.z);
            pt.localPosition = basePos + right * width * 0.14f;
            foreach (var t in pt.GetComponentsInChildren<TMPro.TMP_Text>(true)) GwyfShared.ButtonFit.FitLabel(t, parent, width * 0.24f * .8f, 0.24f);
            game.turboButton = turbo.GetComponent<InteractableEventTrigger>();
            game.buyButton = buy.GetComponent<InteractableEventTrigger>();
            game.buySelectButton = sel.GetComponent<InteractableEventTrigger>();
            game.betMinusButton = minus.GetComponent<InteractableEventTrigger>();
            game.betPlusButton = plus.GetComponent<InteractableEventTrigger>();
            V($"Buttons BONUS POP/REEL/BET-/BET+/TURBO created next to '{play.name}' (width {width:0.###})");
        }

        static bool IsVanillaSlots(GameObject g) => g != null && g.GetComponentInChildren<Slots>(true) != null;

        [HarmonyPatch(typeof(StampManager), "GetLootTableForFloor")]
        static class LootPatch
        {
            static void Postfix(CasinoFloor floor, MMLootTableGameObjectSO __result)
            {
                try
                {
                    string fname = floor != null ? floor.name + "#" + floor.floorIndex : "null";
                    var objs = __result?.LootTable?.ObjectsToLoot;
                    if (objs == null) { if (_loggedFloors.Add(fname + "-empty")) V($"Loot table for floor {fname}: none"); return; }
                    if (_loggedFloors.Add(fname))
                        V($"Loot table for floor {fname} ({objs.Count}): " + string.Join(", ", objs.Where(x => x?.Loot != null).Select(x => x.Loot.name)));
                    var slotEntry = objs.FirstOrDefault(x => IsVanillaSlots(x?.Loot));
                    var template = slotEntry?.Loot;
                    if (!EnsurePrefab(template, quiet: true)) return;
                    if (objs.Any(x => x != null && x.Loot == Prefab)) return;
                    objs.Add(new MMLootGameObject { Loot = Prefab, Weight = slotEntry?.Weight ?? 1f, ChancePercentage = 0f });
                    V($"Injected Toro Leap into floor {fname}");
                }
                catch (Exception e) { Log.LogError("[TL] Loot injection failed: " + e); }
            }
        }

        [HarmonyPatch(typeof(StampManager), "GetCappedLootForFloor")]
        static class CappedLootPatch
        {
            static void Postfix(CasinoFloor floor, Vector3 stampPosition, ref GameObject __result)
            {
                try
                {
                    V($"Stamp at {stampPosition} floor {(floor != null ? floor.name : "null")} -> {(__result != null ? __result.name : "null")}");
                    if (ReplaceAllSlots.Value && IsVanillaSlots(__result) && EnsurePrefab(__result))
                    {
                        __result = Prefab;
                        V("  replaced vanilla slot with Toro Leap");
                    }
                }
                catch (Exception e) { Log.LogError("[TL] CappedLoot patch failed: " + e); }
            }
        }

        [HarmonyPatch(typeof(NetworkServer), "Spawn", new Type[] { typeof(GameObject), typeof(NetworkConnectionToClient) })]
        static class SpawnLogPatch
        {
            static void Postfix(GameObject obj)
            {
                if (obj != null && obj.GetComponentInChildren<ToroLeapGame>(true) != null)
                    Log.LogInfo($"[TL] Server spawned Toro Leap at {obj.transform.position}");
            }
        }
    }

    /// Independent per-frame driver (some games destroy/disable the BepInEx manager object, which stops plugin Update()).
    public class ToroRunner : MonoBehaviour
    {
        void Update() { if (ToroLeapPlugin.Instance != null) ToroLeapPlugin.Instance.Tick(); }
    }
}
