using UnityEngine;
namespace ToroLeap
{
    public partial class ToroLeapGame
    {
        static Texture2D _freshSheet, _freshLogos, _freshToro;
        static Sprite FreshSpriteKey(string key)
        {
            if (key.StartsWith("blur_")) key = "sym_" + key.Substring(5);
            if (key == "logo" || key == "topper")
            {
                if (_freshLogos == null) _freshLogos = LoadPng("fresh_logos");
                return GwyfShared.FreshAtlas.Logo(_freshLogos, 3);
            }
            if (_freshSheet == null) _freshSheet = LoadPng("fresh_atlas");

            if (key == "toro_tall")
            {
                if (_freshToro == null) _freshToro = LoadPng("fresh_toro");
                return UnityEngine.Sprite.Create(_freshToro, new Rect(0, 0, _freshToro.width, _freshToro.height), new Vector2(.5f, .5f), 100f);
            }

            int index;
            switch (key)
            {
                case "sym_10": index = 0; break;
                case "sym_J": index = 1; break;
                case "sym_Q": index = 2; break;
                case "sym_K": index = 3; break;
                case "sym_A": index = 4; break;
                case "sym_yarn": index = 5; break;
                case "sym_helmet": index = 6; break;
                case "sym_shield": index = 7; break;
                case "sym_heroine": index = 8; break;
                case "toro_head": index = 9; break;
                default: return null;
            }
            return GwyfShared.FreshAtlas.Sprite(_freshSheet, 4, 4, index);
        }
    }
}
