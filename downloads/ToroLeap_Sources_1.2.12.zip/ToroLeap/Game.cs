using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using FMODUnity;
using Mirror;
using Mirror.RemoteCalls;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace ToroLeap
{
    [Serializable]
    public class TlMsg
    {
        public string t;              // spin | end | turbo | bet | sel | auto
        public ToroEngine.Step first;
        public ToroEngine.Step[] rs;  // MINOTAUR RE-SPINS (empty if no Toro)
        public int toro = -1;         // Toro reel index (1..3 = reel 2..4) or -1
        public int ptoro = -1, ps;    // v1.2.0 partial Minotaur: reel + shift (visible cells are WILD, no feature)
        public float w;               // round win before cap (x bet)
        public float tot;             // round total after cap (x bet)
        public int x;                 // final multiplier X of the feature
        public int cap;               // 1 = MaxWinX cap hit
        public int tb, by, sel, au;   // turbo, bought (0 = paid spin, 1..3 = Bonus Pop reel 2..4), buy selection, auto spins left
        public string bet;
        public double bn;
    }

    public partial class ToroLeapGame : GameBase
    {
        const string RpcSig = "System.Void ToroLeap.ToroLeapGame::UserRpcShowSpin(System.String)";
        public bool turbo; public int buySel = 1; // Bonus Pop reel: 1..3 = reel 2..4
        public InteractableEventTrigger turboButton, buyButton, buySelectButton, betMinusButton, betPlusButton;
        int _spinCount;
        BigNumber _charged = BigNumber.Zero; bool _roundActive, _paid; float _deadline; int _roundGen;
        readonly List<RenderTexture> _ownRts = new List<RenderTexture>();
        public static int ForceToroNext;

        public TextMeshPro payoutText;
        public List<Image> symbolLocations = new List<Image>();
        public List<SlotReel> reels = new List<SlotReel>();
        public EventReference spinReelSFX, spinDoneSFX, multiplierSFX, finaltextSFX;
        public List<InteractableEventTrigger> playButtons = new List<InteractableEventTrigger>();

        static bool _rpcRegistered;
        public static void RegisterRpcs()
        {
            if (_rpcRegistered) return; _rpcRegistered = true;
            GwyfShared.RpcGuard.Register(typeof(ToroLeapGame), RpcSig, (obj, reader, conn) =>
            {
                if (!NetworkClient.active) return;
                ((ToroLeapGame)obj).UserRpcShowSpin(reader.ReadString());
            });
        }
        public override bool Weaved() => true;

        public void CopyFromSlots(Slots s)
        {
            T Get<T>(string n) => (T)HarmonyLib.AccessTools.Field(typeof(Slots), n).GetValue(s);
            try { payoutText = Get<TextMeshPro>("payoutText"); } catch { }
            try { symbolLocations = Get<List<Image>>("symbolLocations"); } catch { }
            try { reels = Get<List<SlotReel>>("reels"); } catch { }
            try { spinReelSFX = Get<EventReference>("spinReelSFX"); spinDoneSFX = Get<EventReference>("spinDoneSFX");
                  multiplierSFX = Get<EventReference>("multiplierSFX"); finaltextSFX = Get<EventReference>("finaltextSFX"); } catch { }
            gameName = "Toro Leap";
        }
        public void SetDefaults() { gameName = "Toro Leap"; }

        protected override void OnAwake()
        {
            base.OnAwake();
            try { var pb = playButtons != null && playButtons.Count > 0 && playButtons[0] != null ? playButtons[0].transform : null; var r = GwyfShared.CabinetScaler.Apply(transform, ToroLeapPlugin.CabinetScale.Value, pb, "TL"); if (r != null) ToroLeapPlugin.Log.LogInfo("[TL] " + r); } catch (Exception e) { ToroLeapPlugin.Log.LogError("[TL] cabinet scale: " + e.Message); }
            // ScreenIso removed: the slot screen is a direct world-space canvas (no camera/RT); the camera it found was the keypad camera.
        }

        // ---------------- art ----------------
        static readonly Dictionary<string, Sprite> _sprites = new Dictionary<string, Sprite>();
        public static Texture2D LoadPng(string key)
        {
            using (var st = typeof(ToroLeapGame).Assembly.GetManifestResourceStream("ToroLeap.art." + key + ".png"))
            {
                if (st == null) { ToroLeapPlugin.Log.LogError("[TL] Missing embedded art: " + key); return null; }
                var ms = new System.IO.MemoryStream(); st.CopyTo(ms);
                var tex = new Texture2D(2, 2, TextureFormat.RGBA32, true);
                ImageConversion.LoadImage(tex, ms.ToArray());
                tex.name = "TL_" + key; GwyfShared.ReelFx.ConfigureTexture(tex);
                return tex;
            }
        }
        public static Sprite Spr(string key)
        {
            if (_sprites.TryGetValue(key, out var sp)) return sp;
            try { sp = FreshSpriteKey(key); if (sp != null) { _sprites[key] = sp; return sp; } var tex = LoadPng(key); sp = tex != null ? Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), new Vector2(.5f, .5f), 100f) : null; }
            catch (Exception e) { ToroLeapPlugin.Log.LogError("[TL] Sprite load failed " + key + ": " + e.Message); sp = null; }
            _sprites[key] = sp; return sp;
        }
        public static Sprite BlurSprite(int sym)
        {
            if (sym == ToroEngine.WILD) return null;
            string key = "blur_" + ToroEngine.ArtKeys[Mathf.Clamp(sym, 0, ToroEngine.NSYM - 1)];
            return typeof(ToroLeapGame).Assembly.GetManifestResourceInfo("ToroLeap.art." + key + ".png") != null ? Spr(key) : null;
        }
        static readonly Dictionary<Sprite, Sprite> _blurOf = new Dictionary<Sprite, Sprite>();
        public static Sprite BlurOf(Sprite s)
        {
            if (s == null) return null; if (_blurOf.TryGetValue(s, out var b)) return b;
            string n = s.texture != null ? s.texture.name : ""; int k = n.IndexOf("sym_"); b = null;
            if (k >= 0) { string key = "blur_" + n.Substring(k + 4); if (typeof(ToroLeapGame).Assembly.GetManifestResourceInfo("ToroLeap.art." + key + ".png") != null) b = Spr(key); }
            _blurOf[s] = b; return b;
        }
        public static Sprite SymSprite(int sym)
        {
            if (sym == ToroEngine.WILD) return Spr("toro_head"); // visible during spin and landing, before expansion
            return Spr("sym_" + ToroEngine.ArtKeys[Mathf.Clamp(sym, 0, ToroEngine.NSYM - 1)]);
        }

        // ---------------- server ----------------
        static void Hook(InteractableEventTrigger b, UnityEngine.Events.UnityAction<PlayerInteract> a)
        {
            if (b == null) return;
            if (b.serverOnInteractEvent == null) b.serverOnInteractEvent = new UnityEngine.Events.UnityEvent<PlayerInteract>();
            b.serverOnInteractEvent.AddListener(a);
        }
        public override void OnStartServer()
        {
            base.OnStartServer();
            foreach (var b in playButtons) Hook(b, TryStartGame);
            Hook(buyButton, TryBuy); Hook(buySelectButton, CycleBuy); Hook(turboButton, ToggleTurbo);
            Hook(betMinusButton, p => StepBet(-1)); Hook(betPlusButton, p => StepBet(+1));
            HookScreenButtons();
            ToroLeapPlugin.V($"OnStartServer: {playButtons.Count} play button(s), buy={(buyButton != null)} reel={(buySelectButton != null)} keypad={(keypad != null)}");
        }

        public static double BuyCost(int sel) => ToroEngine.BuyCostX[Mathf.Clamp(sel, 1, 3) - 1];
        public static string BuyCostLabel(int sel) => BuyCost(sel).ToString("0.#", System.Globalization.CultureInfo.InvariantCulture);
        public static string BuyName(int sel) => "BONUS POP REEL " + (Mathf.Clamp(sel, 1, 3) + 1);
        BigNumber BuyPrice(int sel) => BigNumber.FromDouble(Math.Round(currentBet.ToDouble() * BuyCost(sel), 2));

        [Server]
        public override void TryStartGame(PlayerInteract pi)
        {
            if (!NetworkServer.active || pi == null) return;
            if (!CanGameStart() || isPlaying) return;
            if (pi.TryGetComponent<PlayerProfile>(out var prof)) interactingPlayer = prof;
            if (interactingPlayer == null) return;
            if (!isGoldenChipApplied)
            {
                BigNumber cost = currentBet;
                if (currentBet < MinBet || currentBet > MaxBet || !Extensions.NetworkSingleton<MoneyManager>.Instance.TryChangeBalance(-cost, interactingPlayer, ChangeType.Bet))
                { try { keypad.ServerInvalidBetAmountFb(); } catch { } return; }
                _charged = cost;
            }
            else { isGoldenBet = true; _charged = BigNumber.Zero; }
            isPlaying = true; canBet = false;
            StartGame();
        }

        [Server]
        protected override void StartGame()
        {
            if (!NetworkServer.active) return;
            ToroLeapPlugin.V("StartGame by " + (interactingPlayer != null ? interactingPlayer.name : "?"));
            StartCoroutine(RoundRoutine(0));
        }

        /// by: 0 = paid spin, 1..3 = Bonus Pop with Toro on reel 2..4
        IEnumerator RoundRoutine(int by)
        {
            ToroEngine.Round round = null; int gen = ++_roundGen;
            _roundActive = true; _paid = false; _deadline = Time.time + 30f;
            int forceToro = by == 0 ? ForceToroNext : 0;
            int everyN = ToroLeapPlugin.ForceBonusEveryNSpins?.Value ?? 0;
            _spinCount++;
            if (by == 0 && forceToro == 0 && ((ToroLeapPlugin.AlwaysBonusNextSpin?.Value ?? false) || (everyN > 0 && _spinCount % everyN == 0))) forceToro = 1 + _spinCount % 3;
            if (by == 0) ForceToroNext = 0;
            bool byAuto = _autoRound; _autoRound = false;
            try { var rnd = GetSeededRandom(7171 + by); round = by > 0 ? ToroEngine.PlayBuy(rnd, by) : ToroEngine.Play(rnd, forceToro); }
            catch (Exception e) { ToroLeapPlugin.Log.LogError(e); }
            if (round == null) { Refund("engine error"); SafeReset(); Broadcast(new TlMsg { t = "end", tb = turbo ? 1 : 0 }); StopAuto(); yield break; }
            var b = round.baseSpin;
            ToroLeapPlugin.V($"Round: bet={currentBet} by={by} toro={(b.toro >= 0 ? "reel " + (b.toro + 1) : "-")} respins={b.respins.Count} X={b.xEnd} win={b.win:0.##}x total={round.total:0.##}x{(round.capped ? " (CAP)" : "")}");
            string betS = FormatBet(currentBet); double bnum = currentBet.ToDouble();
            bool tb = turbo;
            var m = new TlMsg { t = "spin", first = b.first, rs = b.respins.ToArray(), toro = b.toro, ptoro = b.ptoro, ps = b.ps, w = (float)b.win, tot = (float)round.total, x = b.xEnd, cap = round.capped ? 1 : 0, tb = tb ? 1 : 0, by = by, sel = buySel, au = _autoLeft, bet = betS, bn = bnum };
            Broadcast(m);
            float wait = TlTiming.Spin(m) + 0.1f;
            _deadline = Time.time + wait + 30f; // watchdog follows the real (possibly long) respin chain
            yield return new WaitForSeconds(wait);
            if (gen != _roundGen) yield break;   // refunded/disabled meanwhile: never pay after a refund
            PayNow(round, by);
            _roundActive = false; _charged = BigNumber.Zero;
            Broadcast(new TlMsg { t = "end", tot = (float)round.total, x = b.xEnd, cap = round.capped ? 1 : 0, by = by, tb = tb ? 1 : 0, bet = betS, bn = bnum });
            SafeReset();
            ContinueAuto(b.toro >= 0, byAuto);
        }

        void PayNow(ToroEngine.Round round, int by)
        {
            if (_paid) return; _paid = true;
            try
            {
                if (interactingPlayer != null)
                {
                    if (by > 0) { double c = BuyCost(by); Payout(round.total / c * EstimatedValue, ChangeType.GameResult, null, BuyPrice(by)); }
                    else Payout(round.total * EstimatedValue);
                    ToroLeapPlugin.V($"Payout: {round.total:0.##}x * floor {EstimatedValue:0.##}");
                }
                else ToroLeapPlugin.Log.LogWarning("[TL] Player left before payout.");
            }
            catch (Exception e) { ToroLeapPlugin.Log.LogError("[TL] Payout failed: " + e); }
        }

        static string FormatBet(BigNumber b) { try { return MoneyFormatter.FormatWithDollar(b); } catch { return "$" + b; } }

        [Server]
        public void TryBuy(PlayerInteract pi)
        {
            if (!NetworkServer.active || pi == null) return;
            if (!CanGameStart() || isPlaying) return;
            if (pi.TryGetComponent<PlayerProfile>(out var prof)) interactingPlayer = prof;
            if (interactingPlayer == null) return;
            int sel = Mathf.Clamp(buySel, 1, 3); BigNumber cost = BuyPrice(sel);
            if (isGoldenChipApplied || currentBet < MinBet || currentBet > MaxBet || !Extensions.NetworkSingleton<MoneyManager>.Instance.TryChangeBalance(-cost, interactingPlayer, ChangeType.Bet))
            { ToroLeapPlugin.Log.LogInfo($"[TL] Buy refused: bet {currentBet}, cost {cost}"); try { keypad.ServerInvalidBetAmountFb(); } catch { } return; }
            _charged = cost;
            ToroLeapPlugin.Log.LogInfo($"[TL] {BuyName(sel)} bought by {interactingPlayer.name} for {cost}");
            isPlaying = true; canBet = false;
            StartCoroutine(RoundRoutine(sel));
        }

        [Server]
        public void CycleBuy(PlayerInteract pi = null)
        {
            if (!NetworkServer.active || isPlaying) return;
            buySel = buySel % 3 + 1; ToroLeapPlugin.V("Buy -> " + BuyName(buySel));
            Broadcast(State("sel"));
        }

        [Server]
        public void ToggleTurbo(PlayerInteract pi = null)
        {
            if (!NetworkServer.active) return;
            turbo = !turbo; ToroLeapPlugin.V("Turbo " + (turbo ? "ON" : "OFF") + " (applies from the next spin message)");
            Broadcast(State("turbo"));
        }

        static readonly double[] BetLadder = { 1, 1.5, 2, 2.5, 3, 4, 5, 6, 8 };
        [Server]
        void StepBet(int dir)
        {
            if (!NetworkServer.active || isPlaying || !canBet || keypad == null || isGoldenChipApplied) return;
            try
            {
                double m = MinBet.ToDouble(), mx = MaxBet.ToDouble(), cur = currentBet.ToDouble();
                if (double.IsInfinity(mx) || mx > 1e15) mx = 1e15;
                var list = new List<double> { m };
                for (double dec = Math.Pow(10, Math.Floor(Math.Log10(Math.Max(1e-9, m)))); dec <= mx; dec *= 10)
                    foreach (var l in BetLadder) { double v = l * dec; if (v > m * 1.0001 && v < mx * 0.9999) list.Add(v); }
                list.Add(mx);
                double pick = cur;
                if (dir > 0) { pick = list.Last(); foreach (var v in list) if (v > cur * 1.0001) { pick = v; break; } }
                else { pick = list[0]; foreach (var v in list) if (v < cur * 0.9999) pick = v; }
                pick = Math.Max(1, Math.Round(pick));
                if (Math.Abs(pick - cur) < 1e-9) return;
                var nb = BigNumber.FromDouble(pick);
                var apply = HarmonyLib.AccessTools.Method(typeof(Keypad), "ApplyInput");
                if (apply != null) apply.Invoke(keypad, new object[] { nb.ToKeypadString(), true });
                else { keypad.Network_currentInput = nb.ToKeypadString(); ServerSetBet(nb); }
                ToroLeapPlugin.V($"Bet {(dir > 0 ? "+" : "-")} -> {nb}");
                var bm = State("bet"); bm.bet = FormatBet(nb); bm.bn = pick; Broadcast(bm);
            }
            catch (Exception e) { ToroLeapPlugin.Log.LogError("[TL] Bet step failed: " + e); }
        }

        void Refund(string why)
        {
            try
            {
                if (!_paid && _charged > BigNumber.Zero && interactingPlayer != null)
                { Extensions.NetworkSingleton<MoneyManager>.Instance.TryChangeBalance(_charged, interactingPlayer, ChangeType.Bet); ToroLeapPlugin.Log.LogWarning($"[TL] Refunded {_charged} ({why})"); }
            }
            catch (Exception e) { ToroLeapPlugin.Log.LogError("[TL] Refund failed: " + e); }
            _charged = BigNumber.Zero; _roundActive = false; _roundGen++;
        }

        protected override void OnDisable()
        {
            try
            {
                if (NetworkServer.active && isPlaying) { Refund("machine disabled mid-round"); SafeReset(); }
                if (NetworkServer.active) { _autoLeft = 0; _autoPi = null; }
                _roundActive = false;
            }
            catch (Exception e) { ToroLeapPlugin.Log.LogError("[TL] OnDisable: " + e); }
            try { ClientAbort(); } catch { }
        }

        void OnDestroy()
        {
            foreach (var rt in _ownRts) if (rt != null) { rt.Release(); Destroy(rt); }
            _ownRts.Clear();
        }

        void ServerWatchdog()
        {
            if (!NetworkServer.active || !_roundActive) return;
            if (Time.time > _deadline)
            {
                ToroLeapPlugin.Log.LogError("[TL] Round stalled (coroutine died?) - refunding and unlocking machine");
                Refund("watchdog"); SafeReset(); StopAuto();
                Broadcast(new TlMsg { t = "end", tb = turbo ? 1 : 0 });
            }
        }

        void SafeReset() { _roundActive = false; try { ResetGame(); } catch (Exception e) { ToroLeapPlugin.Log.LogError(e); isPlaying = false; canBet = true; } }

        void Broadcast(TlMsg msg)
        {
            if (!NetworkServer.active) return;
            try
            {
                var writer = NetworkWriterPool.Get();
                writer.WriteString(GwyfShared.MiniJson.ToJson(msg));
                SendRPCInternal(RpcSig, RpcSig.GetStableHashCode(), writer, 0, true);
                NetworkWriterPool.Return(writer);
            }
            catch (Exception e) { ToroLeapPlugin.Log.LogError("[TL] Broadcast failed: " + e.Message); }
        }

        // ---------------- client ----------------
        public void UserRpcShowSpin(string json)
        {
            if (!NetworkClient.active) return;
            TlMsg msg;
            try { msg = GwyfShared.MiniJson.FromJson<TlMsg>(json); } catch (Exception e) { ToroLeapPlugin.Log.LogError("[TL] Bad RPC json: " + e.Message); return; }
            ToroLeapPlugin.V($"RPC {msg.t} toro={msg.toro} respins={(msg.rs?.Length ?? 0)} X={msg.x} win={msg.w:0.##} tot={msg.tot:0.##} tb={msg.tb} ({json.Length} bytes)");
            EnsureUi();
            if (_ui == null) return;
            if (!string.IsNullOrEmpty(msg.bet)) _betLabel = msg.bet;
            if (msg.bn > 0) _betNum = msg.bn;
            if (msg.t == "turbo" || msg.t == "bet" || msg.t == "sel" || msg.t == "auto") { UpdateButtonsVisual(msg.tb == 1, msg.sel); UpdateAutoVisual(msg.au); RefreshBar(); return; }
            if (msg.t == "spin") { UpdateButtonsVisual(_clientTurbo, msg.sel); UpdateAutoVisual(msg.au); }
            if (_anim != null) StopCoroutine(_anim);
            ClearFx(); HideBanner(); ResetTransforms();
            _anim = StartCoroutine(Safe(Show(msg)));
        }

        void Update() { if (ToroLeapPlugin.Instance != null) ToroLeapPlugin.Instance.Tick(); UpdateIdle(); UpdateCabinetFx(); DriveBanner(); ServerWatchdog(); UpdateHudSpin(); ServerStateSync(); }

        void Start()
        {
            if (NetworkClient.active) { try { EnsureUi(); SetIdle(); } catch (Exception e) { ToroLeapPlugin.Log.LogError("[TL] UI build failed: " + e); } }
            try
            {
                foreach (var tmp in GetComponentsInChildren<TextMeshPro>(true))
                    if (tmp != payoutText && tmp.text != null && tmp.text.IndexOf("slot", StringComparison.OrdinalIgnoreCase) >= 0) tmp.text = "TORO LEAP";
            }
            catch { }
            try { if (ToroLeapPlugin.RestyleCabinet == null || ToroLeapPlugin.RestyleCabinet.Value) BuildCabinet(); GwyfShared.CabinetSkin.Build(transform, playButtons.FirstOrDefault(b => b != null)?.transform, "toro"); } catch (Exception e) { ToroLeapPlugin.Log.LogError("[TL] Cabinet restyle failed: " + e); }
        }

        void EnsureUi()
        {
            if (_ui != null) return;
            var imgs = (symbolLocations ?? new List<Image>()).Where(i => i != null).ToList();
            if (imgs.Count == 0 && reels != null) imgs = reels.Where(r => r != null).SelectMany(r => r.symbols ?? new Image[0]).Where(i => i != null).ToList();
            if (imgs.Count == 0 || imgs[0].canvas == null)
            {
                ToroLeapPlugin.V("No vanilla screen found: building floating screen above the machine");
                var cgo = new GameObject("ToroLeapScreen", typeof(RectTransform), typeof(Canvas));
                cgo.GetComponent<Canvas>().renderMode = RenderMode.WorldSpace;
                var cr = (RectTransform)cgo.transform; cr.SetParent(transform, false);
                cr.sizeDelta = new Vector2(640, 400); cr.localScale = Vector3.one * 0.004f;
                cr.localPosition = new Vector3(0, 2.3f, 0); cr.localRotation = Quaternion.Euler(0, 180, 0);
                BuildPanel(cr, new Vector2(-320, -200), new Vector2(320, 200));
                return;
            }
            var canvas = imgs[0].canvas;
            var croot = (RectTransform)canvas.transform;
            var rect = croot.rect;
            ToroLeapPlugin.V($"Screen canvas '{canvas.name}' mode={canvas.renderMode} rect={rect} layer={canvas.gameObject.layer}");
            if (rect.width < 10 || rect.height < 10) rect = new Rect(-500, -400, 1000, 800);
            foreach (var r in reels) if (r != null) foreach (var g in r.GetComponentsInChildren<Graphic>(true)) g.enabled = false;
            foreach (var im in imgs) im.enabled = false;
            var fmin = rect.min; var fmax = rect.max;
            try { ToroLeapPlugin.Log.LogInfo("[TL] Screen " + GwyfShared.ScreenFit.Fit(transform, croot, ref fmin, ref fmax)); } catch (Exception e) { ToroLeapPlugin.Log.LogWarning("[TL] screen fit: " + e.Message); }
            BuildPanel(croot, fmin, fmax);
            SetLayer(_ui.gameObject, canvas.gameObject.layer);
        }

        static void SetLayer(GameObject go, int layer) { go.layer = layer; foreach (Transform c in go.transform) SetLayer(c.gameObject, layer); }

        void Sfx(EventReference ev, float value, string param = "Multiplier")
        {
            try
            {
                if (ev.IsNull) return;
                SFXManager.SFXOneShotWithParameters(ev, new[] { new SFXParams(param, Mathf.Clamp(value, 0f, param == "Multiplier" ? 1000f : 100000f)) }, transform.position);
            }
            catch { }
        }
    }

    /// Shared timing: the host waits exactly as long as the clients animate (both read tb from the same message).
    public static class TlTiming
    {
        public static float Out(bool t) => t ? 0.12f : 0.26f;
        public static float Stagger(bool t) => t ? 0.03f : 0.08f;
        public static float Fall(bool t) => t ? 0.2f : 0.4f;
        public static float Ant(bool t) => t ? 0.35f : 0.9f;        // reel glow + slow push-in before the drop
        public static float Land(bool t) => t ? 0.65f : 1.35f;      // drop + slam + zoom/flash + dust + shake
        public static float Lines(bool t) => t ? 0.35f : 0.9f;
        public static float Jump(bool t) => t ? 0.42f : 0.9f;       // squat, jump in place, slam
        public static float Apply(bool t) => t ? 0.5f : 1.1f;
        public static float Settle(bool t) => t ? 0.2f : 0.5f;
        public static float PLand(bool t) => t ? 0.45f : 0.95f;     // partial Minotaur slides in (1-2 cells)
        /// long re-spin chains speed up (same on host and client)
        public static float Speed(int k) => k < 8 ? 1f : k < 20 ? .6f : k < 50 ? .35f : .2f;
        public static float SpinIn(bool t, int cols) => Out(t) + Stagger(t) * (cols - 1) + Fall(t) + 0.05f;
        public static float Spin(TlMsg m)
        {
            bool t = m.tb == 1;
            float d = SpinIn(t, ToroEngine.Cols);
            if (m.toro >= 0) d += Ant(t) + Land(t);
            if (m.ptoro >= 0) d += PLand(t);
            if (m.first != null && m.first.w > 0) d += Lines(t);
            if (m.rs != null && m.toro >= 0)
                for (int k = 0; k < m.rs.Length; k++)
                {
                    float sp = Speed(k);
                    d += SpinIn(t, ToroEngine.Cols - 1) * sp;
                    d += (m.rs[k].w > 0 ? Lines(t) + Apply(t) : Jump(t)) * sp;
                    d += 0.03f; // host-only slack per step so client frame overrun never gets cut
                }
            if (m.w > 0) d += Settle(t);
            return d;
        }
    }
}
