using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using BepInEx;
using BepInEx.Configuration;
using Mirror;
using UnityEngine;
using UnityEngine.InputSystem;
namespace PocketPhone;
[BepInPlugin("com.avekerrigan.pocketphone", "Pocket Phone", "1.0.0")]
public sealed class Plugin : BaseUnityPlugin
{
    readonly BrowserClient _browser=new(); readonly List<InputAction> _disabled=new();
    PhoneModel _model; Texture2D _display;
    bool _held,_zoom,_typing,_addressFocus,_oldVisible,_oldHeadLocked; float _ease,_volume=.6f;
    CursorLockMode _oldCursor; PlayerController _lockedController;
    InteractableEventTrigger _spin; GameBase _game;
    string _url="https://www.tiktok.com/foryou",_spinStatus="Наведитесь на слот перед открытием телефона";
    Rect _web; Vector2 _mouseDown; bool _drag;
    string _helper,_profile,_lastBrowserStatus; ConfigEntry<float> _scale; ConfigEntry<int> _fps; ConfigEntry<string> _home;
    Keyboard _keyboard; string _pendingSite; char _surrogate;
    void Awake()
    {
        string root=Path.GetDirectoryName(typeof(Plugin).Assembly.Location);
        _helper=Path.Combine(root,"PhoneBrowser.exe"); _profile=Path.Combine(Paths.ConfigPath,"PocketPhone","BrowserProfile");
        _scale=Config.Bind("Display","Scale",1f,"Phone size: 0.65..1.25; preserves page proportions.");
        _fps=Config.Bind("Display","MaximumFps",24,"Browser screen update rate: 8..30 FPS.");
        _home=Config.Bind("Browser","Home","https://www.tiktok.com/foryou","Default HTTPS page.");
        _url=PhoneProtocol.Website(_home.Value,out var home)?home:"https://www.tiktok.com/foryou";
        Logger.LogInfo("PocketPhone 1.0.0: P phone, RMB zoom, E spin, Esc close. Private browser; no Item patches.");
    }
    Camera View => Extensions.MonoSingleton<LocalManager>.Instance != null ? Extensions.MonoSingleton<LocalManager>.Instance.mainCamera : Camera.main;
    void Update()
    {
        if (NetworkClient.localPlayer==null) { if(_held) PutAway(); return; }
        var k=Keyboard.current; var mouse=Mouse.current; if(k==null||mouse==null)return;
        if(k.pKey.wasPressedThisFrame && !_typing && !GuiTyping()) { if(_held)PutAway();else Equip(); }
        if(!_held)return;
        var pc=NetworkClient.localPlayer.GetComponent<PlayerController>();
        if(pc!=null && pc.State==PlayerController.PlayerState.Ragdoll){PutAway();return;}
        var inventory=NetworkClient.localPlayer.GetComponent<PlayerInventory>();
        if(inventory!=null&&inventory.NetworkholdingItem!=null){PutAway();return;}
        if(k.escapeKey.wasPressedThisFrame && _zoom) { Zoom(false); return; }
        if(mouse.rightButton.wasPressedThisFrame) Zoom(!_zoom);
        if(k.qKey.wasPressedThisFrame && !_typing && !GuiTyping()) { PutAway();return; }
        if(_zoom)
        {
            if(k.eKey.wasPressedThisFrame && !_typing && !GuiTyping()) Spin();
            if(_typing)
            {
                if(k.backspaceKey.wasPressedThisFrame) _browser.Send(new{type="key",key="Backspace"});
                if(k.enterKey.wasPressedThisFrame) _browser.Send(new{type="key",key="Enter"});
                if(k.tabKey.wasPressedThisFrame) _browser.Send(new{type="key",key="Tab"});
                if(k.upArrowKey.wasPressedThisFrame) _browser.Send(new{type="key",key="ArrowUp"});
                if(k.downArrowKey.wasPressedThisFrame) _browser.Send(new{type="key",key="ArrowDown"});
                if((k.leftCtrlKey.isPressed||k.rightCtrlKey.isPressed)&&k.vKey.wasPressedThisFrame) _browser.Send(new{type="text",text=GUIUtility.systemCopyBuffer});
            }
        }
        if(_browser.Ready && _pendingSite!=null) { _browser.Send(new{type="navigate",url=_pendingSite});_pendingSite=null;_browser.Send(new{type="volume",value=_volume});_browser.Send(new{type="fps",value=Mathf.Clamp(_fps.Value,8,30)}); }
        if(_browser.Running&&_lastBrowserStatus!=_browser.Status){_lastBrowserStatus=_browser.Status;Logger.LogInfo("Phone browser: "+_lastBrowserStatus);}
        var frame=_browser.Frame();
        if(frame!=null && _display!=null) try { ImageConversion.LoadImage(_display,frame,false); } catch(Exception e){Logger.LogWarning("Phone frame: "+e.GetType().Name);}
    }
    bool GuiTyping() => _addressFocus;
    void Equip()
    {
        var inv=NetworkClient.localPlayer.GetComponent<PlayerInventory>();
        if(inv!=null && inv.NetworkholdingItem!=null) { _spinStatus="Сначала уберите предмет из рук";Logger.LogInfo(_spinStatus);return; }
        _held=true;
        if(_display==null)
        {
            _display=new Texture2D(PhoneProtocol.Width,PhoneProtocol.Height,TextureFormat.RGB24,false);
            var pixels=new Color32[PhoneProtocol.Width*PhoneProtocol.Height]; for(int i=0;i<pixels.Length;i++)pixels[i]=new Color32(15,20,32,255);
            _display.SetPixels32(pixels);_display.Apply();
        }
        var go=new GameObject("PocketPhone_Held");_model=go.AddComponent<PhoneModel>();_model.Build(_display);
        var cam=View;if(cam!=null){go.transform.position=cam.transform.position+cam.transform.forward*.5f;go.transform.rotation=cam.transform.rotation;}
    }
    void PutAway()
    {
        Zoom(false);_held=false;_browser.Stop();_pendingSite=null;
        if(_model!=null)Destroy(_model.gameObject);_model=null;_game=null;_spin=null;
    }
    void Zoom(bool value)
    {
        if(_zoom==value)return;
        _zoom=value;
        if(value)
        {
            SelectSlot();_oldCursor=Cursor.lockState;_oldVisible=Cursor.visible;
            var reader=InputReader.Instance;
            var actions=reader!=null?typeof(InputReader).GetField("_inputActions",BindingFlags.Instance|BindingFlags.NonPublic)?.GetValue(reader) as InputActions:null;
            if(actions!=null)foreach(var a in actions.asset.FindActionMap("Player"))
                if(a.name!="PushToTalk"&&a.enabled){_disabled.Add(a);a.Disable();}
            InputEvents.OnMoveEvent?.Invoke(Vector2.zero);InputEvents.OnAimEvent?.Invoke(Vector2.zero);InputEvents.UpdateInteract(false);
            _lockedController=NetworkClient.localPlayer?.GetComponent<PlayerController>();
            if(_lockedController!=null && _lockedController.head!=null){_oldHeadLocked=_lockedController.head.isLocked;_lockedController.head.isLocked=true;}
            if(!_browser.Running) { _browser.Start(_helper,_profile);_pendingSite=_url; }
            else _browser.Send(new{type="active",value=true});
            _keyboard=Keyboard.current;if(_keyboard!=null)_keyboard.onTextInput+=TextInput;
        }
        else
        {
            _typing=false;_drag=false;_addressFocus=false;_surrogate='\0';
            if(_keyboard!=null)_keyboard.onTextInput-=TextInput;_keyboard=null;
            foreach(var a in _disabled)a.Enable();_disabled.Clear();
            if(_lockedController!=null && _lockedController.head!=null)_lockedController.head.isLocked=_oldHeadLocked;
            _lockedController=null;Cursor.lockState=_oldCursor;Cursor.visible=_oldVisible;
            _browser.Send(new{type="active",value=false});GUIUtility.keyboardControl=0;
        }
    }
    void TextInput(char c)
    {
        var k=Keyboard.current;
        if(!_zoom||!_typing||GuiTyping()||char.IsControl(c)||(k?.leftCtrlKey.isPressed??false)||(k?.rightCtrlKey.isPressed??false))return;
        if(char.IsHighSurrogate(c)){_surrogate=c;return;}
        string text=char.IsLowSurrogate(c)&&_surrogate!='\0'?new string(new[]{_surrogate,c}):c.ToString();
        _surrogate='\0';_browser.Send(new{type="text",text});
    }
    void SelectSlot()
    {
        _spin=null;_game=null;var cam=View;var player=NetworkClient.localPlayer;if(cam==null||player==null)return;
        var pi=player.GetComponent<PlayerInteract>();float reach=pi!=null?pi.raycastDistance:3f;var aimed=pi?.TargetInteractable as InteractableEventTrigger;
        float best=float.MaxValue;
        foreach(var game in FindObjectsByType<GameBase>(FindObjectsSortMode.None))
        {
            foreach(var entry in SpinButtons(game))
            {
                if(entry is not InteractableEventTrigger button || button==null)continue;
                var offset=button.transform.position-cam.transform.position;float distance=offset.magnitude;
                if(distance>reach || Vector3.Dot(offset.normalized,cam.transform.forward)<.25f)continue;
                float score=button==aimed?-100f:distance+Vector3.Angle(offset,cam.transform.forward)*.04f;
                if(score<best){best=score;_spin=button;_game=game;}
            }
        }
        _spinStatus=_game!=null?"E — спин: "+_game.GameName:"Слот не выбран: закройте экран и наведитесь на автомат";
    }
    static IEnumerable SpinButtons(GameBase game)
    {
        var field=game.GetType().GetField("playButtons",BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic);
        if(field?.GetValue(game) is IEnumerable buttons) { foreach(var entry in buttons)yield return entry;yield break; }
        if(game is not Slots)yield break;
        foreach(var button in game.GetComponentsInChildren<InteractableEventTrigger>())
        {
            var ev=button.serverOnInteractEvent;if(ev==null)continue;
            for(int i=0;i<ev.GetPersistentEventCount();i++)
                if(ev.GetPersistentMethodName(i)=="TryStartGame" && ev.GetPersistentTarget(i)==game){yield return button;break;}
        }
    }
    void Spin()
    {
        var player=NetworkClient.localPlayer; if(player==null||_spin==null||_game==null){_spinStatus="Нет выбранного слота. Наведитесь на него и откройте телефон заново.";return;}
        var pi=player.GetComponent<PlayerInteract>();var cam=View;
        if(pi==null||cam==null||Vector3.Distance(cam.transform.position,_spin.transform.position)>pi.raycastDistance){_spinStatus="Подойдите ближе к выбранному автомату";return;}
        if(_game.isPlaying){_spinStatus="Идёт вращение — дождитесь результата";return;}
        var inv=player.GetComponent<PlayerInventory>();
        if(inv!=null&&inv.NetworkholdingItem!=null){_spinStatus="Уберите другой предмет из рук";return;}
        if(!_spin.IsInteractable||!_spin.MeetRequirements){_spinStatus="Кнопка запуска сейчас недоступна";return;}
        try{_spin.OnInteract(pi);_spinStatus="Спин отправлен: "+_game.GameName;}catch(Exception e){Logger.LogWarning("Phone spin: "+e.Message);_spinStatus="Не удалось нажать кнопку слота";}
    }
    void LateUpdate()
    {
        if(!_held)return;
        var cam=View;if(cam==null)return;
        _ease=Mathf.MoveTowards(_ease,_zoom?1:0,Time.unscaledDeltaTime*5);
        if(_model!=null)
        {
            _model.gameObject.SetActive(_ease<.95f);
            var pose=Vector3.Lerp(new Vector3(.23f,-.18f,.50f),new Vector3(.12f,-.03f,.34f),Mathf.SmoothStep(0,1,_ease));
            _model.transform.SetPositionAndRotation(cam.transform.TransformPoint(pose),cam.transform.rotation*Quaternion.Euler(Mathf.Lerp(-8,0,_ease),Mathf.Lerp(-15,0,_ease),Mathf.Lerp(-6,0,_ease)));
        }
        if(_zoom){Cursor.lockState=CursorLockMode.None;Cursor.visible=true;}
    }
    void Navigate(string url)
    {
        if(!PhoneProtocol.Website(url,out string safe)){_spinStatus="Нужен полный адрес https://…";return;}
        _url=safe;_typing=false;GUIUtility.keyboardControl=0;
        if(_browser.Ready)_browser.Send(new{type="navigate",url=safe});else _pendingSite=safe;
    }
    void OnGUI()
    {
        if(!_held)return;
        if(!_zoom){GUI.Label(new Rect(20,Screen.height-60,600,50),"Телефон: ПКМ — открыть · P / Q — убрать");return;}
        float height=Mathf.Min(Screen.height-180,768*Mathf.Clamp(_scale.Value,.65f,1.25f));height=Mathf.Max(140,height);
        float width=height*PhoneProtocol.Width/PhoneProtocol.Height;
        float x=Screen.width-width-40,y=(Screen.height-height)*.5f;
        var phone=new Rect(x-12,y-76,width+24,height+152);
        Rounded(phone,new Color(.27f,.30f,.37f),22);
        Rounded(new Rect(phone.x+3,phone.y+3,phone.width-6,phone.height-6),new Color(.035f,.04f,.065f),20);
        GUI.Label(new Rect(x+8,y-70,width-50,26),"POCKET PHONE");
        if(GUI.Button(new Rect(x+width-32,y-70,28,25),"×")){Zoom(false);return;}
        float third=(width-8)/3;
        if(GUI.Button(new Rect(x,y-41,third,29),"TikTok"))Navigate("https://www.tiktok.com/foryou");
        if(GUI.Button(new Rect(x+third+4,y-41,third,29),"Instagram"))Navigate("https://www.instagram.com/reels/");
        if(GUI.Button(new Rect(x+2*(third+4),y-41,third,29),"Обновить"))_browser.Send(new{type="reload"});
        _web=new Rect(x,y,width,height);
        if(_display!=null)GUI.DrawTexture(_web,_display,ScaleMode.StretchToFill,false);
        if(!_browser.Ready)GUI.Label(new Rect(x+15,y+height*.4f,width-30,110),_browser.Status);
        if(GUI.Button(new Rect(x,y+height+8,40,25),"←"))_browser.Send(new{type="back"});
        if(GUI.Button(new Rect(x+44,y+height+8,width-44,25),_typing?"Клавиатура: ВКЛ · E — текст":"Клавиатура · E — спин")){_typing=!_typing;GUIUtility.keyboardControl=0;}
        GUI.Label(new Rect(x,y+height+38,64,24),"Звук");
        float volume=GUI.HorizontalSlider(new Rect(x+60,y+height+45,width-60,20),_volume,0,1);
        if(Mathf.Abs(volume-_volume)>.01f){_volume=volume;_browser.Send(new{type="volume",value=volume});}
        GUI.Box(new Rect(20,25,Mathf.Min(540,x-40),125),GUIContent.none);
        GUI.Label(new Rect(32,34,Mathf.Min(520,x-60),34),_spinStatus);
        GUI.Label(new Rect(32,70,Mathf.Min(520,x-60),64),"Колёсико — прокрутка · ЛКМ — кнопки и комментарии\nПКМ / Esc — отдалить · P / Q — убрать телефон");
        float optionsWidth=Mathf.Min(540,x-40);
        if(optionsWidth>200)
        {
            GUI.SetNextControlName("address");_url=GUI.TextField(new Rect(20,158,optionsWidth-85,28),_url,1000);
            if(GUI.Button(new Rect(25+optionsWidth-85,158,80,28),"Открыть"))Navigate(_url);
            if(GUI.Button(new Rect(20,195,125,28),"Перезапуск")){_browser.Stop();_browser.Start(_helper,_profile);_pendingSite=_url;}
            GUI.Label(new Rect(20,232,optionsWidth,66),_browser.Status);
        }
        _addressFocus=GUI.GetNameOfFocusedControl()=="address";
        WebInput(Event.current);
    }
    static void Rounded(Rect rect,Color color,float radius)
    {GUI.DrawTexture(rect,Texture2D.whiteTexture,ScaleMode.StretchToFill,true,0,color,0,radius);}
    void WebInput(Event e)
    {
        if(!_browser.Ready)return;
        if(PhoneProtocol.Point(e.mousePosition.x,e.mousePosition.y,_web.x,_web.y,_web.width,_web.height,out int x,out int y))
        {
            if(e.type==EventType.ScrollWheel){_browser.Send(new{type="scroll",x,y,delta=(int)(e.delta.y*80)});e.Use();}
            if(e.type==EventType.MouseDown&&e.button==0){_mouseDown=e.mousePosition;_drag=true;GUIUtility.keyboardControl=0;e.Use();}
            if(e.type==EventType.MouseUp&&e.button==0&&_drag)
            {
                float dy=_mouseDown.y-e.mousePosition.y;
                if(Mathf.Abs(dy)>30)_browser.Send(new{type="scroll",x,y,delta=(int)(dy*PhoneProtocol.Height/_web.height)});
                else _browser.Send(new{type="click",x,y});_drag=false;e.Use();
            }
        }
        if(e.type==EventType.MouseUp)_drag=false;
    }
    void OnDestroy(){PutAway();if(_display!=null)Destroy(_display);}
    void OnApplicationQuit(){PutAway();}
}
