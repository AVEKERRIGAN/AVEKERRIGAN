using System;
using System.Text;
namespace PocketPhone;
public static class PhoneProtocol
{
    public const int Width = 432, Height = 768;
    public static string Quote(string value)
    {
        var text = new StringBuilder("\""); int slashes = 0;
        foreach (char c in value ?? "")
        {
            if (c == '\\') { slashes++; continue; }
            text.Append('\\', c == '"' ? slashes * 2 + 1 : slashes); slashes = 0; text.Append(c);
        }
        text.Append('\\', slashes * 2); return text.Append('"').ToString();
    }
    public static bool Website(string text, out string url)
    {
        url = null;
        if (!Uri.TryCreate(text?.Trim(), UriKind.Absolute, out var uri) || uri.Scheme != "https" || !string.IsNullOrEmpty(uri.UserInfo)) return false;
        url = uri.AbsoluteUri; return true;
    }
    public static bool Point(float x, float y, float left, float top, float width, float height, out int px, out int py)
    {
        px = py = 0;
        if (width <= 0 || height <= 0 || x < left || y < top || x >= left + width || y >= top + height) return false;
        px = Math.Min(Width - 1, (int)((x - left) / width * Width));
        py = Math.Min(Height - 1, (int)((y - top) / height * Height)); return true;
    }
}
