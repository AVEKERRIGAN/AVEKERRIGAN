using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
namespace PocketPhone;
public sealed class PhoneModel : MonoBehaviour
{
    readonly List<Material> _materials = new(); readonly List<Mesh> _meshes = new();
    public Material ScreenMaterial;
    public void Build(Texture screen)
    {
        var body = Mat(new Color(.035f,.04f,.055f)); var rim = Mat(new Color(.22f,.25f,.30f)); var lens = Mat(new Color(.015f,.025f,.035f));
        Rounded("Aluminium rim", .094f, .181f, .011f, .010f, rim, 0);
        Rounded("Phone body", .090f, .177f, .010f, .009f, body, -.001f);
        ScreenMaterial = Mat(Color.white, true); ScreenMaterial.mainTexture = screen;
        if (ScreenMaterial.HasProperty("_BaseMap")) ScreenMaterial.SetTexture("_BaseMap", screen);
        var display = new GameObject("Phone screen"); display.transform.SetParent(transform, false); display.transform.localPosition = new Vector3(0, 0, -.0066f);
        var mesh = new Mesh { name = "Portrait display" };
        mesh.vertices = new[] { new Vector3(-.041f,-.073f,0), new Vector3(.041f,-.073f,0),new Vector3(.041f,.073f,0),new Vector3(-.041f,.073f,0) };
        mesh.uv = new[] { Vector2.zero, Vector2.right, Vector2.one, Vector2.up }; mesh.triangles = new[] {0,2,1,0,3,2}; mesh.RecalculateNormals(); _meshes.Add(mesh);
        display.AddComponent<MeshFilter>().sharedMesh=mesh; display.AddComponent<MeshRenderer>().sharedMaterial=ScreenMaterial;
        Rounded("Speaker notch",.021f,.004f,.001f,.002f,lens,-.007f,.080f);
        for (int i=0;i<3;i++) Rounded("Rear camera",.018f,.018f,.003f,.008f,lens,.007f,.060f-i*.023f,-.026f);
        Rounded("Volume rocker",.002f,.029f,.003f,.001f,rim,0,.028f,-.047f);
        Rounded("Power key",.002f,.020f,.003f,.001f,rim,0,.018f,.047f);
        foreach (var r in GetComponentsInChildren<MeshRenderer>()) { r.shadowCastingMode=ShadowCastingMode.Off; r.receiveShadows=false; }
    }
    Material Mat(Color color,bool unlit=false)
    {
        var shader = unlit ? Shader.Find("Universal Render Pipeline/Unlit") ?? Shader.Find("Unlit/Texture") : Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard");
        var mat=new Material(shader); mat.color=color;
        if(mat.HasProperty("_BaseColor")) mat.SetColor("_BaseColor",color);
        if(mat.HasProperty("_Smoothness")) mat.SetFloat("_Smoothness",.7f);
        _materials.Add(mat); return mat;
    }
    void Rounded(string name,float w,float h,float d,float radius,Material material,float z,float y=0,float x=0)
    {
        const int n=8; var vertices=new List<Vector3>(); var triangles=new List<int>();
        for(int face=0;face<2;face++) for(int corner=0;corner<4;corner++) for(int k=0;k<n;k++)
        {
            float angle=(corner*90f+k*90f/(n-1))*Mathf.Deg2Rad;
            float cx=(corner==0||corner==3?1:-1)*(w*.5f-radius), cy=(corner<2?1:-1)*(h*.5f-radius);
            vertices.Add(new Vector3(cx+radius*Mathf.Cos(angle),cy+radius*Mathf.Sin(angle),(face==0?-1:1)*d*.5f));
        }
        int ring=n*4;
        for(int i=1;i<ring-1;i++) { triangles.AddRange(new[]{0,i+1,i,ring,ring+i,ring+i+1}); }
        for(int i=0;i<ring;i++) { int j=(i+1)%ring; triangles.AddRange(new[]{i,j,ring+j,i,ring+j,ring+i}); }
        var mesh=new Mesh();mesh.SetVertices(vertices);mesh.SetTriangles(triangles,0);mesh.RecalculateNormals();mesh.RecalculateBounds();_meshes.Add(mesh);
        var go=new GameObject(name);go.transform.SetParent(transform,false);go.transform.localPosition=new Vector3(x,y,z);go.AddComponent<MeshFilter>().sharedMesh=mesh;go.AddComponent<MeshRenderer>().sharedMaterial=material;
    }
    void OnDestroy() { foreach(var m in _materials) Destroy(m); foreach(var m in _meshes) Destroy(m); }
}
