#nullable enable
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using PocketPhone;

namespace PhoneBrowser;
public static class Program
{
    static readonly object output = new();
    static Process? browser;
    static long nextFrame;
    static int maximumFps=24;
    static bool casting;
    static float volume = .6f;
    static readonly CancellationTokenSource lifetime = new();
    static void Send(object value) { lock (output) { Console.WriteLine(JsonSerializer.Serialize(value)); Console.Out.Flush(); } }
    static void Status(string text) => Send(new { type = "status", text });
    static string FindBrowser()
    {
        foreach (string root in new[] { Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) })
            foreach (string path in new[] { "Microsoft/Edge/Application/msedge.exe", "Google/Chrome/Application/chrome.exe" })
            { string file = Path.Combine(root, path); if (File.Exists(file)) return file; }
        throw new FileNotFoundException("Не найден Edge или Chrome. Установите браузер и перезапустите телефон.");
    }
    public static async Task<int> Main(string[] args)
    {
        Console.OutputEncoding = new UTF8Encoding(false); Console.InputEncoding = new UTF8Encoding(false);
        bool test = args.Contains("--test-headless");
        string profile = args.Length > 0 ? Path.GetFullPath(args[0]) : throw new ArgumentException("Profile required");
        int parent = args.Length > 1 && int.TryParse(args[1], out int pid) ? pid : 0;
        Directory.CreateDirectory(profile);
        try
        {
            var start = new ProcessStartInfo { FileName = test ? "/usr/bin/chromium" : FindBrowser(), UseShellExecute = false, CreateNoWindow = true, RedirectStandardError = true, RedirectStandardOutput = true };
            var flags = new[] { "--user-data-dir=" + profile, "--remote-debugging-port=0", "--remote-debugging-address=127.0.0.1", "--no-first-run", "--disable-background-mode", "--no-default-browser-check", "--disable-backgrounding-occluded-windows", "--disable-renderer-backgrounding", "--autoplay-policy=no-user-gesture-required", "--window-position=-2400,-2400", "--window-size=480,840", "--app=about:blank" };
            foreach (string flag in flags) start.ArgumentList.Add(flag);
            if (test) { start.ArgumentList.Add("--headless=new"); start.ArgumentList.Add("--no-sandbox"); }
            string portFile = Path.Combine(profile, "DevToolsActivePort");
            if (File.Exists(portFile)) File.Delete(portFile);
            browser = Process.Start(start) ?? throw new IOException("Не удалось запустить браузер.");
            browser.OutputDataReceived += (_, _) => { }; browser.ErrorDataReceived += (_, _) => { };
            browser.BeginOutputReadLine(); browser.BeginErrorReadLine(); Status("Запускаю браузер…");
            _ = Task.Run(async () => { while (!lifetime.IsCancellationRequested) { if (parent > 0) { try { if (Process.GetProcessById(parent).HasExited) lifetime.Cancel(); } catch { lifetime.Cancel(); } } await Task.Delay(1000); } });
            var deadline = Stopwatch.StartNew();
            while (!File.Exists(portFile)) { if (browser.HasExited || deadline.Elapsed.TotalSeconds > 30) throw new IOException("Браузер не запустился за 30 секунд. Закройте телефон и повторите."); await Task.Delay(100, lifetime.Token); }
            string[] portInfo = await File.ReadAllLinesAsync(portFile, lifetime.Token);
            if (portInfo.Length < 1 || !int.TryParse(portInfo[0], out int port) || port < 1 || port > 65535) throw new IOException("Неверный порт браузера.");
            using var http = new HttpClient { Timeout = TimeSpan.FromSeconds(10) };
            using var targets = JsonDocument.Parse(await http.GetStringAsync("http://127.0.0.1:" + port + "/json/list", lifetime.Token));
            var target = targets.RootElement.EnumerateArray().First(t => t.GetProperty("type").GetString() == "page");
            await using var cdp = new Cdp(); await cdp.Connect(target.GetProperty("webSocketDebuggerUrl").GetString()!);
            cdp.Closed += () => { Status("Браузер закрыл соединение. Нажмите «Перезапуск»."); lifetime.Cancel(); };
            cdp.Event += (method, data) =>
            {
                if (method == "Page.screencastFrame")
                {
                    long now = Stopwatch.GetTimestamp();
                    if (now >= Interlocked.Read(ref nextFrame))
                    { Interlocked.Exchange(ref nextFrame, Math.Max(Interlocked.Read(ref nextFrame)+Stopwatch.Frequency/maximumFps,now)); Send(new { type = "frame", data = data.GetProperty("data").GetString() }); }
                    _ = Ack(cdp, data.GetProperty("sessionId").GetInt32());
                }
                if (method == "Page.loadEventFired") { _ = ApplyVolume(cdp); Status("Страница загружена. Нажимайте кнопки прямо на экране телефона."); }
                if (method == "Inspector.detached") { Status("Соединение с браузером закрыто. Перезапустите телефон."); lifetime.Cancel(); }
            };
            await cdp.Call("Page.enable");
            await cdp.Call("Emulation.setDeviceMetricsOverride", new { width = PhoneProtocol.Width, height = PhoneProtocol.Height, deviceScaleFactor = 1, mobile = true, screenWidth = PhoneProtocol.Width, screenHeight = PhoneProtocol.Height });
            await cdp.Call("Emulation.setFocusEmulationEnabled", new { enabled = true });
            await cdp.Call("Page.addScriptToEvaluateOnNewDocument", new { source = "(()=>{function v(){document.querySelectorAll('video,audio').forEach(e=>{e.volume=window.__pocketPhoneVolume??" + volume.ToString(System.Globalization.CultureInfo.InvariantCulture) + ";});}new MutationObserver(v).observe(document,{subtree:true,childList:true});document.addEventListener('DOMContentLoaded',v);})();" });
            await cdp.Call("Page.startScreencast", new { format = "jpeg", quality = 72, maxWidth = PhoneProtocol.Width, maxHeight = PhoneProtocol.Height, everyNthFrame = 2 }); casting = true;
            MoveOffscreen(parent); Send(new { type = "ready" }); Status("Браузер готов. Выберите TikTok или Instagram.");
            while (!lifetime.IsCancellationRequested)
            {
                string? line = await Console.In.ReadLineAsync(lifetime.Token);
                if (line == null) break;
                if (line.Length > 65536) continue;
                try
                {
                    using var input = JsonDocument.Parse(line); var cmd = input.RootElement;
                    string action = cmd.GetProperty("type").GetString()!;
                    if (action == "close") break;
                    switch (action)
                    {
                        case "navigate":
                            if (!PhoneProtocol.Website(cmd.GetProperty("url").GetString()!, out string url)) { Status("Введите адрес HTTPS."); break; }
                            Status("Загружаю страницу…"); var navigation = await cdp.Call("Page.navigate", new { url });
                            if(navigation.TryGetProperty("errorText",out var navigationError)) Status("Сайт не загрузился: "+navigationError.GetString()); break;
                        case "click":
                            int x = Math.Clamp(cmd.GetProperty("x").GetInt32(), 0, PhoneProtocol.Width - 1), y = Math.Clamp(cmd.GetProperty("y").GetInt32(), 0, PhoneProtocol.Height - 1);
                            await cdp.Call("Input.dispatchMouseEvent", new { type = "mouseMoved", x, y });
                            await cdp.Call("Input.dispatchMouseEvent", new { type = "mousePressed", x, y, button = "left", clickCount = 1 });
                            await cdp.Call("Input.dispatchMouseEvent", new { type = "mouseReleased", x, y, button = "left", clickCount = 1 }); break;
                        case "scroll":
                            await cdp.Call("Input.dispatchMouseEvent", new { type = "mouseWheel", x = Math.Clamp(cmd.GetProperty("x").GetInt32(), 0, PhoneProtocol.Width - 1), y = Math.Clamp(cmd.GetProperty("y").GetInt32(), 0, PhoneProtocol.Height - 1), deltaX = 0, deltaY = Math.Clamp(cmd.GetProperty("delta").GetInt32(), -900, 900) }); break;
                        case "text": await cdp.Call("Input.insertText", new { text = cmd.GetProperty("text").GetString() }); break;
                        case "key":
                            string key = cmd.GetProperty("key").GetString()!;
                            if (key is "Backspace" or "Enter" or "Tab" or "ArrowUp" or "ArrowDown" or "ArrowLeft" or "ArrowRight")
                            {
                                int code = key switch { "Backspace" => 8, "Enter" => 13, "Tab" => 9, "ArrowUp" => 38, "ArrowDown" => 40, "ArrowLeft" => 37, _ => 39 };
                                await cdp.Call("Input.dispatchKeyEvent", new { type = "keyDown", key, code = key, windowsVirtualKeyCode = code });
                                await cdp.Call("Input.dispatchKeyEvent", new { type = "keyUp", key, code = key, windowsVirtualKeyCode = code });
                            } break;
                        case "fps": maximumFps = Math.Clamp(cmd.GetProperty("value").GetInt32(), 8, 30); break;
                        case "volume": volume = Math.Clamp(cmd.GetProperty("value").GetSingle(), 0, 1); await ApplyVolume(cdp); break;
                        case "reload": await cdp.Call("Page.reload"); break;
                        case "back":
                            var history = await cdp.Call("Page.getNavigationHistory"); int index = history.GetProperty("currentIndex").GetInt32();
                            if (index > 0) await cdp.Call("Page.navigateToHistoryEntry", new { entryId = history.GetProperty("entries")[index - 1].GetProperty("id").GetInt32() }); break;
                        case "active":
                            bool active = cmd.GetProperty("value").GetBoolean();
                            if (active && !casting) { await cdp.Call("Page.startScreencast", new { format = "jpeg", quality = 72, maxWidth = PhoneProtocol.Width, maxHeight = PhoneProtocol.Height, everyNthFrame = 2 }); casting = true; }
                            if (!active && casting) { await cdp.Call("Page.stopScreencast"); casting = false; }
                            await cdp.Call("Runtime.evaluate", new { expression = "document.querySelectorAll('video,audio').forEach(e=>e." + (active ? "play().catch(()=>{})" : "pause()") + ");" }); break;
                    }
                }
                catch (Exception e) { Status("Не удалось выполнить действие: " + e.GetType().Name + ". Попробуйте обновить страницу."); }
            }
            try { await cdp.Call("Browser.close").WaitAsync(TimeSpan.FromSeconds(3)); await browser.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(2)); } catch { }
            return 0;
        }
        catch (OperationCanceledException) { return 0; }
        catch (Exception e) { Status(e.Message); return 1; }
        finally { lifetime.Cancel(); if (browser != null) { try { if (!browser.HasExited) browser.Kill(true); } catch { } browser.Dispose(); } }
    }
    static async Task Ack(Cdp cdp, int id) { try { await cdp.Call("Page.screencastFrameAck", new { sessionId = id }); } catch { } }
    static async Task ApplyVolume(Cdp cdp) { try { await cdp.Call("Runtime.evaluate", new { expression = "window.__pocketPhoneVolume=" + volume.ToString(System.Globalization.CultureInfo.InvariantCulture) + ";document.querySelectorAll('video,audio').forEach(e=>e.volume=window.__pocketPhoneVolume);" }); } catch { } }
    delegate bool EnumProc(IntPtr hwnd, IntPtr unused);
    [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc callback, IntPtr unused);
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint pid);
    [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr hwnd, IntPtr after, int x, int y, int width, int height, uint flags);
    [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr hwnd);
    static void MoveOffscreen(int parent)
    {
        if (!OperatingSystem.IsWindows() || browser == null) return;
        EnumWindows((hwnd, _) => { GetWindowThreadProcessId(hwnd, out uint id); if (id == browser.Id) SetWindowPos(hwnd, IntPtr.Zero, -2400, -2400, 480, 840, 0x14); return true; }, IntPtr.Zero);
        try { if (parent > 0) SetForegroundWindow(Process.GetProcessById(parent).MainWindowHandle); } catch { }
    }
}
