#nullable enable
using System.Collections.Concurrent;
using System.Net.WebSockets;
using System.Text;
using System.Text.Json;
using System.Threading.Channels;

namespace PhoneBrowser;
public sealed class Cdp : IAsyncDisposable
{
    readonly ClientWebSocket socket = new();
    readonly ConcurrentDictionary<long, TaskCompletionSource<JsonElement>> pending = new();
    readonly Channel<byte[]> outgoing = Channel.CreateBounded<byte[]>(new BoundedChannelOptions(256) { FullMode = BoundedChannelFullMode.Wait });
    readonly CancellationTokenSource cancel = new();
    long next; int failed;
    public event Action? Closed; Task? reader, writer;
    public event Action<string, JsonElement>? Event;
    public async Task Connect(string uri)
    {
        using var deadline = new CancellationTokenSource(TimeSpan.FromSeconds(15));
        await socket.ConnectAsync(new Uri(uri), deadline.Token);
        reader = Read(); writer = Write();
    }
    public async Task<JsonElement> Call(string method, object? args = null)
    {
        long id = Interlocked.Increment(ref next);
        var wait = new TaskCompletionSource<JsonElement>(TaskCreationOptions.RunContinuationsAsynchronously); pending[id] = wait;
        try
        {
            byte[] bytes = JsonSerializer.SerializeToUtf8Bytes(new { id, method, @params = args ?? new { } });
            await outgoing.Writer.WriteAsync(bytes, cancel.Token);
            return await wait.Task.WaitAsync(TimeSpan.FromSeconds(15), cancel.Token);
        }
        finally { pending.TryRemove(id, out _); }
    }
    async Task Write()
    {
        try { await foreach (var bytes in outgoing.Reader.ReadAllAsync(cancel.Token)) await socket.SendAsync(bytes, WebSocketMessageType.Text, true, cancel.Token); }
        catch (Exception e) { Fail(e); }
    }
    async Task Read()
    {
        byte[] chunk = new byte[65536];
        try
        {
            while (!cancel.IsCancellationRequested)
            {
                using var message = new MemoryStream(); WebSocketReceiveResult read;
                do
                {
                    read = await socket.ReceiveAsync(chunk, cancel.Token);
                    if (read.MessageType == WebSocketMessageType.Close) throw new IOException("Браузер закрыл соединение.");
                    message.Write(chunk, 0, read.Count);
                    if (message.Length > 8 * 1024 * 1024) throw new IOException("Слишком большой кадр браузера.");
                } while (!read.EndOfMessage);
                using var json = JsonDocument.Parse(message.ToArray()); var root = json.RootElement;
                if (root.TryGetProperty("id", out var id) && pending.TryGetValue(id.GetInt64(), out var wait))
                {
                    if (root.TryGetProperty("error", out var error)) wait.TrySetException(new IOException(error.GetProperty("message").GetString()));
                    else wait.TrySetResult(root.GetProperty("result").Clone());
                }
                else if (root.TryGetProperty("method", out var method)) Event?.Invoke(method.GetString()!, root.GetProperty("params").Clone());
            }
        }
        catch (Exception e) { Fail(e); }
    }
    void Fail(Exception e) { cancel.Cancel(); foreach (var wait in pending.Values) wait.TrySetException(e); if(Interlocked.Exchange(ref failed,1)==0) Closed?.Invoke(); }
    public async ValueTask DisposeAsync()
    {
        cancel.Cancel(); socket.Abort();
        foreach (var task in new[] { reader, writer }) if (task != null) try { await task; } catch { }
        socket.Dispose(); cancel.Dispose();
    }
}
