using System.Collections.Concurrent;
using System.Diagnostics;
using System.Text.Json;
using PocketPhone;
using PhoneBrowser;

int assertions=0;
void Check(bool value,string name){assertions++;if(!value)throw new Exception(name);}
async Task Until(Func<bool> test,string name,int ms=15000)
{var sw=Stopwatch.StartNew();while(!test()){if(sw.ElapsedMilliseconds>ms)throw new Exception("Timeout: "+name);await Task.Delay(50);}assertions++;}
foreach(string invalid in new[]{"javascript:alert(1)","file:///c:/test","http://tiktok.com","https://user:pass@tiktok.com","tiktok.com","",null})Check(!PhoneProtocol.Website(invalid,out _),"reject unsafe URL");
Check(PhoneProtocol.Website("https://www.instagram.com/reels/?a=1",out var valid)&&valid.Contains("instagram.com"),"valid HTTPS");
Check(PhoneProtocol.Point(100,200,100,200,216,384,out int x,out int y)&&x==0&&y==0,"top left");
Check(PhoneProtocol.Point(315.99f,583.99f,100,200,216,384,out x,out y)&&x==431&&y==767,"bottom right");
Check(!PhoneProtocol.Point(316,200,100,200,216,384,out _,out _),"outside right");
Check(!PhoneProtocol.Point(99,200,100,200,216,384,out _,out _),"outside left");
Check(!PhoneProtocol.Point(100,200,100,200,0,384,out _,out _),"zero width");
string Unquote(string argument)
{
 var b=new System.Text.StringBuilder();bool quoted=false;
 for(int i=0;i<argument.Length;){int slash=0;while(i<argument.Length&&argument[i]=='\\'){slash++;i++;}if(i<argument.Length&&argument[i]=='"'){b.Append('\\',slash/2);if(slash%2==1)b.Append('"');else quoted=!quoted;i++;}else{b.Append('\\',slash);if(i<argument.Length)b.Append(argument[i++]);}}
 return b.ToString();
}
foreach(string value in new[]{"","normal","C:\\Games\\GWYF mods\\profile\\","C:\\path\\with\"quotes", "a\nb\t$()`test", "кириллица\\"})Check(Unquote(PhoneProtocol.Quote(value))==value,"Windows quoting");
string root=args.Length>0?Path.GetFullPath(args[0]):Path.GetFullPath(Path.Combine(AppContext.BaseDirectory,"../../../..")),profile=Path.Combine(Path.GetTempPath(),"phone-integration-"+Guid.NewGuid().ToString("N"));
string helper=Path.Combine(root,"PhoneBrowser/test-dist/PhoneBrowser");
using var process=new Process{StartInfo=new ProcessStartInfo(helper){UseShellExecute=false,RedirectStandardInput=true,RedirectStandardOutput=true,RedirectStandardError=true}};
process.StartInfo.ArgumentList.Add(profile);process.StartInfo.ArgumentList.Add("0");process.StartInfo.ArgumentList.Add("--test-headless");
process.Start();var messages=new ConcurrentQueue<string>();int frames=0;byte[] latest=null;bool ready=false;
var reader=Task.Run(async()=>{string line;while((line=await process.StandardOutput.ReadLineAsync())!=null){using var j=JsonDocument.Parse(line);var t=j.RootElement.GetProperty("type").GetString();if(t=="ready")ready=true;else if(t=="frame"){latest=Convert.FromBase64String(j.RootElement.GetProperty("data").GetString());Interlocked.Increment(ref frames);}else messages.Enqueue(j.RootElement.GetProperty("text").GetString());}});
var error=process.StandardError.ReadToEndAsync();
async Task Send(object command){await process.StandardInput.WriteLineAsync(JsonSerializer.Serialize(command));await process.StandardInput.FlushAsync();}
try
{
 await Until(()=>ready,"browser ready",40000);
 var portFile=Path.Combine(profile,"DevToolsActivePort");int port=int.Parse(File.ReadLines(portFile).First());
 using var http=new HttpClient();using var targets=JsonDocument.Parse(await http.GetStringAsync("http://127.0.0.1:"+port+"/json/list"));
 string socket=targets.RootElement.EnumerateArray().First(t=>t.GetProperty("type").GetString()=="page").GetProperty("webSocketDebuggerUrl").GetString();
 await using var cdp=new Cdp();await cdp.Connect(socket);
 await cdp.Call("Page.enable");var frame=await cdp.Call("Page.getFrameTree");string id=frame.GetProperty("frameTree").GetProperty("frame").GetProperty("id").GetString();
 string html="<meta name='viewport' content='width=device-width,initial-scale=1'><body style='margin:0;background:#28a6cb;height:5000px'><button id=b style='position:absolute;left:20px;top:40px;width:160px;height:70px' onclick='window.clicks=(window.clicks||0)+1'>Comments</button><textarea id=t style='position:absolute;left:20px;top:140px;width:300px;height:80px'></textarea><div style='position:absolute;top:700px;width:100%;height:2000px;background:linear-gradient(red,yellow)'></div></body>";
 await cdp.Call("Page.setDocumentContent",new{frameId=id,html});
 await Send(new{type="click",x=80,y=70});
 async Task<string> Eval(string exp){var r=await cdp.Call("Runtime.evaluate",new{expression=exp,returnByValue=true});return r.GetProperty("result").GetProperty("value").ToString();}
 var sw=Stopwatch.StartNew();while(await Eval("window.clicks||0")!="1"){if(sw.Elapsed.TotalSeconds>10)throw new Exception("click not delivered");await Task.Delay(50);}assertions++;
 await Send(new{type="click",x=100,y=170});await Send(new{type="text",text="привет TikTok"});await Send(new{type="key",key="Backspace"});
 sw.Restart();while(await Eval("document.getElementById('t').value")!="привет TikTo"){if(sw.Elapsed.TotalSeconds>10)throw new Exception("text input/backspace");await Task.Delay(50);}assertions++;
 await Send(new{type="scroll",x=200,y=600,delta=550});
 sw.Restart();while(int.Parse(await Eval("Math.round(window.scrollY)"))<100){if(sw.Elapsed.TotalSeconds>10)throw new Exception("scroll");await Task.Delay(50);}assertions++;
 await Send(new{type="volume",value=.27});
 sw.Restart();while(await Eval("window.__pocketPhoneVolume")!="0.27"){if(sw.Elapsed.TotalSeconds>10)throw new Exception("volume");await Task.Delay(50);}assertions++;
 await Until(()=>frames>=3&&latest!=null,"live frames");
 Check(latest[0]==255&&latest[1]==216,"JPEG frame");await File.WriteAllBytesAsync(Path.Combine(root,"phone-test-frame.jpg"),latest);
 await Send(new{type="navigate",url="http://example.com"});await Until(()=>messages.Any(m=>m.Contains("HTTPS")),"HTTP rejected");
 await Send(new{type="active",value=false});await Task.Delay(300);int paused=frames;await Task.Delay(500);Check(frames==paused,"screencast stops when pocketed");
 await Send(new{type="active",value=true});await cdp.Call("Runtime.evaluate",new{expression="document.body.style.background='purple'"});await Until(()=>frames>paused,"screencast resume");
 await Send(new{type="close"});await process.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(15));Check(process.ExitCode==0,"helper closes cleanly");await reader;
 string wrapper=Path.Combine(Path.GetTempPath(),"phone-browser-test-wrapper-"+Guid.NewGuid().ToString("N"));
 await File.WriteAllTextAsync(wrapper,"#!/bin/sh\nexec "+helper+" \"$@\" --test-headless\n");File.SetUnixFileMode(wrapper,UnixFileMode.UserRead|UnixFileMode.UserWrite|UnixFileMode.UserExecute);
 var client=new BrowserClient();string clientProfile=profile+"-client";
 client.Start(wrapper,clientProfile);await Until(()=>client.Ready,"client starts",40000);
 int clientPort=int.Parse(File.ReadLines(Path.Combine(clientProfile,"DevToolsActivePort")).First());
 using(var clientTargets=JsonDocument.Parse(await http.GetStringAsync("http://127.0.0.1:"+clientPort+"/json/list")))
 {
  var clientTarget=clientTargets.RootElement.EnumerateArray().First(t=>t.GetProperty("type").GetString()=="page");
  await using var clientCdp=new Cdp();await clientCdp.Connect(clientTarget.GetProperty("webSocketDebuggerUrl").GetString());
  var clientTree=await clientCdp.Call("Page.getFrameTree");
  await clientCdp.Call("Page.setDocumentContent",new{frameId=clientTree.GetProperty("frameTree").GetProperty("frame").GetProperty("id").GetString(),html});
  client.Send(new{type="click",x=100,y=170});client.Send(new{type="text",text="Тест 🦊"});
  sw.Restart();while(true){var result=await clientCdp.Call("Runtime.evaluate",new{expression="document.getElementById('t').value",returnByValue=true});if(result.GetProperty("result").GetProperty("value").GetString()=="Тест 🦊")break;if(sw.Elapsed.TotalSeconds>10)throw new Exception("client Unicode IPC");await Task.Delay(50);}assertions++;
  await Until(()=>client.Frame()!=null,"client latest-frame delivery");
 }
 client.Stop();
 client.Start(wrapper,clientProfile);await Until(()=>client.Ready,"client restart waits for old profile",40000);client.Send(new{type="close"});await Until(()=>!client.Ready,"client exit status");client.Stop();
 Console.WriteLine($"PASS: {assertions} assertions, actual Chromium IPC, screenshot, click, comment typing, scroll, volume, pause/resume and restart.");
}
finally{try{if(!process.HasExited){await Send(new{type="close"});await process.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(15));}}catch{try{process.Kill(true);}catch{}}}
