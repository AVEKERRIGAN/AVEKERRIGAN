using FruitParty;using GwyfShared;using System.Globalization;
int assertions=0,rounds=0,spins=0,steps=0,maxSpins=0,maxTumbles=0;double baseSum=0,buySum=0;
void Check(bool value,string msg){assertions++;if(!value)throw new Exception(msg);}
void Near(double a,double b,string msg)=>Check(Math.Abs(a-b)<1e-5,msg+": "+a+" != "+b);
int At(int col,int row)=>col*7+row;
int[] Grid()=>FruitPartyEngine.InitialGrid();
// Connected clusters pay once, diagonal contacts and reel-edge wrapping do not.
var single=Grid();foreach(int i in new[]{At(0,0),At(0,1),At(1,1),At(2,1),At(2,2)})single[i]=0;
var chosen=FruitPartyEngine.Clusters(single);Check(chosen.Any(g=>g.Contains(At(0,0))&&g.Contains(At(2,2))),"orthogonal irregular cluster connects");
var diagonal=Grid();for(int n=0;n<5;n++)diagonal[At(n,n)]=0;
Check(!FruitPartyEngine.Clusters(diagonal).Any(g=>Enumerable.Range(0,5).All(n=>g.Contains(At(n,n)))),"diagonal symbols do not merge");
var wrap=Grid();for(int row=3;row<7;row++)wrap[At(0,row)]=0;wrap[At(1,0)]=0;
Check(!FruitPartyEngine.Clusters(wrap).Any(g=>g.Contains(At(0,6))&&g.Contains(At(1,0))),"rows never wrap into next reel");
for(int symbol=0;symbol<7;symbol++)foreach(int count in new[]{4,5,6,7,8,9,10,11,12,13,14,15,20,49})
{
 var grid=Enumerable.Repeat(7,49).ToArray();for(int i=0;i<count;i++)grid[i]=symbol;
 var st=FruitPartyEngine.Resolve(new Random(8),grid,false,Enumerable.Repeat(1,49).ToArray());
 if(count<5)Near(st.win,0,"four symbols do not pay");else{Check(st.clusters.Count==1,"one connected block");Near(st.win,FruitPartyEngine.Pays[symbol][Math.Min(15,count)-5],"paytable count tier");}
}
// Separate same-symbol clusters are not combined and their wins are added.
var separate=Enumerable.Repeat(7,49).ToArray();for(int r=0;r<5;r++){separate[At(0,r)]=0;separate[At(6,r)]=0;}
var sep=FruitPartyEngine.Resolve(new Random(4),separate,false,Enumerable.Repeat(1,49).ToArray());Check(sep.clusters.Count==2,"separate blocks pay independently");Near(sep.win,2,"two five-strawberry clusters pay 2x");
// Tile multipliers are products, not sums, and capped per winning block at 256.
var five=Enumerable.Repeat(7,49).ToArray();for(int i=0;i<5;i++)five[i]=0;var mult=Enumerable.Repeat(1,49).ToArray();mult[0]=2;mult[1]=4;
var product=FruitPartyEngine.Resolve(new Random(8),five,true,mult);Near(product.win,8,"x2 * x4 = x8");Check(product.m[0]==2&&product.m[1]==4,"each actual tile value retained");
for(int i=0;i<5;i++)mult[i]=4;var cappedBlock=FruitPartyEngine.Resolve(new Random(8),five,true,mult);Near(cappedBlock.win,256,"block multiplier capped at 256");
var giant=FruitPartyEngine.Resolve(new Random(8),Enumerable.Repeat(0,49).ToArray(),true,Enumerable.Repeat(4,49).ToArray());FruitPartyEngine.Credit(giant,5000);Near(giant.win,5000,"oversized win reaches exactly round cap");Check(giant.capped,"cap stops further play");Near(giant.clusters.Sum(c=>c.pay),5000,"credited cluster values respect cap");
var remainder=FruitPartyEngine.Resolve(new Random(1),five,true,mult);FruitPartyEngine.Credit(remainder,.75);Near(remainder.win,.75,"only remaining round budget credited");
for(int sc=0;sc<=7;sc++)Check(FruitPartyEngine.Retrigger(sc)==(sc<3?0:sc+7),"reference retrigger table");
for(int seed=0;seed<2000;seed++)foreach(bool buy in new[]{false,true})
{
 var round=buy?FruitPartyEngine.PlayBuyVariant(new Random(seed),0):FruitPartyEngine.Play(new Random(seed));rounds++;if(buy)buySum+=round.total;else baseSum+=round.total;
 Check(round.total>=0&&round.total<=5000,"round cap");Near(round.spins.Sum(s=>s.win),round.total,"spin total = paid round");maxSpins=Math.Max(maxSpins,round.spins.Count);
 if(buy)Check(round.spins[0].scatters>=3&&round.spins[0].awarded==10,"100x purchase triggers exactly ten starting free spins");
 int left=round.spins[0].left;double running=0;
 foreach(var spin in round.spins)
 {
  spins++;maxTumbles=Math.Max(maxTumbles,spin.steps.Count);running+=spin.win;Near(spin.total,running,"running round total");Near(spin.steps.Sum(st=>st.win),spin.win,"all cascades added");
  if(spin.bonus==1){Check(spin.awarded==FruitPartyEngine.Retrigger(spin.scatters),"retrigger amount");if(!spin.capped)Check(spin.left==left-1+spin.awarded,"remaining free spins equation");left=spin.left;}
  foreach(var st in spin.steps)
  {
   steps++;Check(st.g.Length==49&&st.m.Length==49&&st.g.All(n=>n>=0&&n<=7),"valid wire grid");Check(st.m.All(n=>n==1||n==2||spin.bonus==1&&n==4),"base x2 / bonus x2 or x4");
   var removed=new HashSet<int>(st.removed);Check(st.clusters.Sum(c=>c.cells.Length)==removed.Count,"disjoint winning blocks");
   Check(st.m.Where((m,i)=>!removed.Contains(i)).All(m=>m==1),"non-winning tiles have no multipliers");
   Near(st.clusters.Sum(c=>c.pay),st.win,"step = sum independent cluster wins");
   foreach(var c in st.clusters)
   {
    Check(c.cells.Length>=5&&c.cells.All(i=>st.g[i]==c.symbol),"matching cluster");int prod=1;foreach(int i in c.cells)prod=Math.Min(256,prod*st.m[i]);Check(prod==c.multi,"actual tile product");
    Check(c.pay<=c.baseWin*c.multi+1e-8&&c.multi<=256,"paid award bounded");
   }
   if(st.after!=null)
   {
    Check(st.source.Length==49&&st.after.Length==49,"complete gravity result");
    for(int col=0;col<7;col++)
    {
     var survivors=Enumerable.Range(col*7,7).Where(i=>!removed.Contains(i)).ToArray();var mapped=st.source.Skip(col*7).Take(7).Where(i=>i>=0).ToArray();Check(mapped.SequenceEqual(survivors),"survivor order unchanged");
     Check(st.after.Skip(col*7).Take(7).Count(v=>v==7)<=1,"no duplicate scatter on a reel");
    }
    for(int i=0;i<49;i++)
    {
     int src=st.source[i];if(src>=0)Check(src/7==i/7&&src%7<=i%7&&!removed.Contains(src)&&st.after[i]==st.g[src],"survivor falls inside same column");
     else Check(FruitPartyTimeline.FromRow(st,i)<0,"new fruit enters from above");
     Near(FruitPartyTimeline.DropRow(st,i,1),i%7,"all fruits settle at exact row centre");
    }
   }
  }
  foreach(int mode in new[]{0,1,2})
  {
   float d=FruitPartyTiming.Duration(spin,mode);var final=FruitPartyTimeline.At(spin,d,mode);Check(final.phase==FruitPartyTimeline.Phase.Done,"server duration covers every animation");Near(final.win,spin.win,"timeline final win");
   double previousWin=-1;for(int frame=0;frame<=24;frame++){var t=FruitPartyTimeline.At(spin,d*frame/24,mode);Check(t.win>=previousWin-1e-6&&t.win<=spin.win+1e-6,"animation does not count wins twice");previousWin=t.win;}
  }
 }
}
for(int mode=0;mode<3;mode++)for(int col=0;col<7;col++)
{
 float d=FruitPartyTiming.ReelEnd(col,mode);int travel=Math.Max(8,(int)Math.Round(d*9));float last=0;
 for(int frame=0;frame<=120;frame++){float p=CellReelMotion.Position(d*frame/120,d,travel);Check(p>=last-1e-5&&p<=travel+1e-5,"smooth one-way reel strip");last=p;}
 Near(last,travel,"integer landing");for(int row=0;row<7;row++)Near(3+(travel-row-travel),3-row,"each of seven icons lands centrally");
 Check(CellReelMotion.Position(.001f,d,travel)/.001f<.03,"reel starts at rest");Check((travel-CellReelMotion.Position(d-.001f,d,travel))/.001f<.10,"reel stops at rest");
}
for(int mode=0;mode<3;mode++)
{
 var bonus=FruitPartyEngine.PlayBuyVariant(new Random(10),0).spins[0];float end=FruitPartyTiming.ReelEnd(6,mode)+bonus.steps.Count(st=>st.removed.Length>0)*FruitPartyTiming.Hit(mode)+bonus.steps.Count(st=>st.after!=null)*FruitPartyTiming.Drop(mode)+FruitPartyTiming.Count(mode);
 Check(FruitPartyTimeline.At(bonus,end+.01f,mode).phase==FruitPartyTimeline.Phase.BonusFocus,"trigger reserves scatter camera focus before intro");
 Check(FruitPartyPresentation.Zoom(0)==1&&FruitPartyPresentation.Zoom(1)==1,"camera returns to original FOV on both boundaries");
 Check(FruitPartyPresentation.Zoom(.5f)>1.5f,"bonus push-in is visible");Check(FruitPartyPresentation.Fall(0)==0&&FruitPartyPresentation.Fall(1)==1,"tumble rebound preserves endpoints");
}
var sample=FruitPartyEngine.PlayBuyVariant(new Random(16),0);var msg=new FruitPartyMsg{t="spin",s=sample.spins[1],seq=18,speed=1,settingSpeed=2,sent=100.125,total=sample.spins[1].total,duration=FruitPartyTiming.Duration(sample.spins[1],1)};
CultureInfo.CurrentCulture=new CultureInfo("ru-RU");string wire=MiniJson.ToJson(msg);var decoded=MiniJson.FromJson<FruitPartyMsg>(wire);
Check(decoded.s.steps.Count==msg.s.steps.Count&&decoded.s.steps[0].g.SequenceEqual(msg.s.steps[0].g),"nested wire grids survive RPC");Check(decoded.speed==1&&decoded.settingSpeed==2,"phase speed remains separate from live control setting");Near(decoded.sent,100.125,"invariant network time");
// The live log failed in DrawSpin's Drop branch: the codec turned a missing
// terminal refill into []. Exercise the CLIENT timeline after the real codec.
Check(decoded.s.steps.Last().after==null&&decoded.s.steps.Last().source==null,"absent terminal refill stays null after network transport");
for(int seed=0;seed<180;seed++)
{
 var original=FruitPartyEngine.PlaySpin(new Random(seed),seed%2==0,10,5000,seed%11==0);
 var replay=MiniJson.FromJson<FruitPartyMsg>(MiniJson.ToJson(new FruitPartyMsg{t="spin",s=original})).s;
 foreach(int mode in new[]{0,1,2})
 {
  float duration=FruitPartyTiming.Duration(original,mode);Near(FruitPartyTiming.Duration(replay,mode),duration,"client timeline matches host after nullable refill roundtrip");
  for(int frame=0;frame<=Math.Ceiling(duration*30);frame++)
  {
   var pose=FruitPartyTimeline.At(replay,frame/30f,mode);Check(pose.step>=0&&pose.step<replay.steps.Count,"decoded pose selects a real step");
   if(pose.phase==FruitPartyTimeline.Phase.Drop){var state=replay.steps[pose.step];Check(FruitPartyTimeline.HasDrop(state),"every decoded drop has both complete 49-cell arrays");for(int i=0;i<49;i++)Check(float.IsFinite(FruitPartyTimeline.DropRow(state,i,pose.p)),"live drop reads every cell without the logged index error");}
  }
 }
}
var legacyEmpty=new FruitPartyEngine.Step{after=Array.Empty<int>(),source=Array.Empty<int>()};Check(!FruitPartyTimeline.HasDrop(legacyEmpty),"legacy empty nullable arrays do not invent a tumble");
Near(FruitPartyTiming.Elapsed(100.5,100,3),.5,"late RPC resumes phase");Near(FruitPartyTiming.Elapsed(108,100,3),3,"completed phase settles");Near(FruitPartyTiming.Elapsed(99,100,3),0,"negative clock skew clamped");
Check(MiniJson.ToJson(FruitPartyEngine.Play(new Random(82)))==MiniJson.ToJson(FruitPartyEngine.Play(new Random(82))),"deterministic host result");
Directory.CreateDirectory("/workspace/outputs");
var report=new {pass=true,assertions,rounds,spins,steps,max_free_round_spins=maxSpins,max_tumble_steps=maxTumbles,base_sample_mean=baseSum/2000,buy_sample_mean=buySum/2000,original_rtp_claimed=false,scope="Actual production engine, timeline, reel motion and RPC codec; no Unity runtime/live coop"};
File.WriteAllText("/workspace/outputs/FruitParty_Checks_1.2.0.json",System.Text.Json.JsonSerializer.Serialize(report,new System.Text.Json.JsonSerializerOptions{WriteIndented=true}));
File.WriteAllText("/workspace/outputs/FruitParty_InternalFixtures.json",System.Text.Json.JsonSerializer.Serialize(new {round=sample,cap=giant},new System.Text.Json.JsonSerializerOptions{IncludeFields=true}));
Console.WriteLine($"PASS {assertions} checks / {rounds} rounds / {spins} spins / {steps} steps. Base mean {baseSum/2000:0.000}, buy mean {buySum/2000:0.00}. Max spins {maxSpins}, tumbles {maxTumbles}.");
