using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BepInEx;
using BepInEx.Configuration;
using Mirror;
using UnityEngine;
using UnityEngine.InputSystem;

namespace FreshBoombox;

[BepInPlugin("com.malenki.boombox", "JBL YouTube Boombox", "3.6.0")]
public sealed class Plugin : BaseUnityPlugin
{
    public static Plugin Instance;
    public static ConfigEntry<float> Volume, Distance, ThrowSpeed,Size;
    public static ConfigEntry<bool> SpatialAudio;
    readonly Dictionary<uint, Speaker> _boxes = new();
    readonly Dictionary<int, float> _lastRequest = new();
    readonly HashSet<NetworkConnectionToClient> _peers=new();Speaker hovered;float loadStarted;
    sealed class SendQueue { public readonly ConcurrentQueue<BoxAudioV32> Packets = new(); public int Count; }
    SendQueue _outgoing = new();
    uint _nextId = 1, _selected;
    bool _serverReady, _clientReady, _open;
    float _nextSync,_ackDeadline,_volumeSaveAt;uint _waitingId,_waitingEpoch;
    Rect _window;
    string _query = "", _status = "Введите название песни, исполнителя или ссылку YouTube";
    Track[] _tracks = Array.Empty<Track>();
    bool _searching;
    uint _playingBox;
    AudioListener _listener;
    readonly List<InputAction> _disabled = new();
    CursorLockMode _oldCursor; bool _oldVisible, _oldHeadLocked;

    void Awake()
    {
        Instance = this;
        Size=Config.Bind("Model","Scale",1.25f,"Speaker size relative to original model; host sends to all clients (0.8..1.8).");
        ThrowSpeed=Config.Bind("Physics","ThrowSpeed",7.5f,"Throw speed in look direction (4..12 metres/sec).");
        Volume = Config.Bind("Audio", "Volume", .7f, "Local boombox volume (0..1).");
        if(float.IsNaN(Volume.Value)||float.IsInfinity(Volume.Value))Volume.Value=.7f;
        else Volume.Value=Mathf.Clamp01(Volume.Value);
        Distance = Config.Bind("Audio", "Distance", 35f, "Maximum distance at which players hear the speaker.");
        SpatialAudio = Config.Bind("Audio", "SpatialAudio", true, "True: sound originates at the speaker and fades with distance.");
        var spatialVersion=Config.Bind("Audio","SpatialPresetVersion",0,"Migration marker for the distance-based audio default.");
        if(spatialVersion.Value<1){SpatialAudio.Value=true;spatialVersion.Value=1;}
        YouTube.Tools = Path.Combine(Path.GetDirectoryName(typeof(Plugin).Assembly.Location), "tools");
        Wire.Install(); Logger.LogInfo("[JBL36] Standalone boombox 3.6.0: no Bongo/Item patches, custom host-controlled objects.");
        _window = new Rect(0, 0, 660, 610);
    }

    void Update()
    {
        if(_volumeSaveAt>0&&Time.unscaledTime>=_volumeSaveAt&&(Mouse.current==null||!Mouse.current.leftButton.isPressed))SaveVolume();
        for (int i = 0; i < 16 && YouTube.Main.TryDequeue(out var action); i++)
            try { action(); } catch (Exception e) { Logger.LogError("[JBL36] " + e.Message); }
        if (NetworkServer.active && !_serverReady)
        {
            NetworkServer.RegisterHandler<BoxRequestV32>(Request, true); _serverReady = true;
        }
        if(!NetworkServer.active){_serverReady=false;_peers.Clear();}
        if (NetworkClient.active && NetworkClient.isConnected && NetworkClient.connection != null && NetworkClient.connection.isAuthenticated && NetworkClient.localPlayer!=null && !_clientReady)
        {
            NetworkClient.RegisterHandler<BoxStateV32>(Receive, true);
            NetworkClient.RegisterHandler<BoxNoticeV32>(Notice,true);
            NetworkClient.RegisterHandler<BoxAudioV32>(Audio, true); _clientReady = true; Send(6, 0);
        }
        if ((!NetworkClient.active||!NetworkClient.isConnected) && _clientReady) { _clientReady = false; Close(); Clear(); }
        if (NetworkServer.active)
        {
            if(_playingBox!=0&&_boxes.TryGetValue(_playingBox,out var waiting)&&waiting!=null&&waiting.State.loading&&Time.unscaledTime-loadStarted>60f)Stop(waiting,"Не удалось начать звук за 60 секунд. Откройте LogOutput.log: [JBL36].");
            var outgoing = _outgoing;
            for (int i = 0; i < 8 && outgoing.Packets.TryDequeue(out var packet); i++)
            {
                System.Threading.Interlocked.Decrement(ref outgoing.Count);
                if (!_boxes.TryGetValue(packet.id, out var speaker) || speaker == null || speaker.State.epoch != packet.epoch || (!speaker.State.playing&&!speaker.State.loading)) continue;
                if(speaker.State.loading){var started=speaker.State;started.loading=false;started.playing=true;started.status="Играет";speaker.Apply(started);Broadcast(started);Logger.LogInfo("[JBL36] First audio received for box "+started.id);}
                speaker.Audio(packet); // The host consumes PCM directly; network echo is sequence-filtered.
                Broadcast(packet,Channels.Unreliable);
            }
            if (Time.unscaledTime >= _nextSync)
            {
                _nextSync = Time.unscaledTime + .05f;
                foreach (uint id in _boxes.Where(p => p.Value == null).Select(p => p.Key).ToArray())
                {
                    _boxes.Remove(id);
                    if (id == _playingBox) { YouTube.Stop(); _playingBox = 0; }
                    Broadcast(new BoxStateV32 { id = id, removed = true });
                }
                foreach (var speaker in _boxes.Values.ToArray())
                {
                    if (speaker == null) continue;
                    var state = speaker.State;
                    if (state.owner != 0 && !NetworkServer.spawned.ContainsKey(state.owner)) Drop(speaker, null,Vector3.zero,Vector3.forward);
                    state = speaker.State; state.position=state.owner==0?speaker.Body.position:speaker.transform.position;state.rotation=state.owner==0?speaker.Body.rotation:speaker.transform.rotation;state.velocity=state.owner==0?speaker.Body.linearVelocity:Vector3.zero; speaker.State = state;
                    Broadcast(state);
                }
            }
        }
        if(_waitingId!=0&&Time.unscaledTime>_ackDeadline){_waitingId=0;_status="Хост не подтвердил запрос за 5 секунд. Проверьте версии мода и повторите.";}
        if (!_clientReady || NetworkClient.localPlayer == null) return;
        var keyboard = Keyboard.current;
        if (keyboard == null) return;
        if (keyboard.escapeKey.wasPressedThisFrame && _open) { Close(); return; }
        if (keyboard.insertKey.wasPressedThisFrame && !_open) Send(1, 0);
        var held = HeldBy(NetworkClient.localPlayer.netId);
        if (keyboard.qKey.wasPressedThisFrame && held != null) { Close(); Send(3, held.State.id); return; }
        if (_open) return;
        Speaker target = Aim();if(hovered!=target){if(hovered!=null)hovered.Hover(false);hovered=target;if(hovered!=null)hovered.Hover(true);}
        if (keyboard.eKey.wasPressedThisFrame && target != null) Send(2, target.State.id);
        if (Mouse.current != null && Mouse.current.leftButton.wasPressedThisFrame)
        {
            var selected = target ?? held;
            if (selected != null) Open(selected.State.id);
        }
    }

    void Broadcast<T>(T message,int channel=Channels.Reliable) where T:struct,NetworkMessage
    {
        foreach(var peer in _peers.ToArray())
            if(NetworkServer.connections.TryGetValue(peer.connectionId,out var current)&&ReferenceEquals(peer,current)&&peer.isAuthenticated)peer.Send(message,channel);
            else _peers.Remove(peer);
    }
    Speaker HeldBy(uint player) => _boxes.Values.FirstOrDefault(s => s != null && s.State.owner == player);
    Speaker Aim()
    {
        var camera = View; if (camera == null) return null;
        return Physics.Raycast(camera.transform.position, camera.transform.forward, out var hit, 4f) ? hit.collider.GetComponentInParent<Speaker>() : null;
    }
    Camera View=>Extensions.MonoSingleton<LocalManager>.Instance!=null?Extensions.MonoSingleton<LocalManager>.Instance.mainCamera:Camera.main;
    void Send(byte action, uint id, string text = "")
    {
        var view=View;
        if(NetworkClient.isConnected)NetworkClient.Send(new BoxRequestV32{action=action,id=id,text=text??"",origin=view!=null?view.transform.position:Vector3.zero,direction=view!=null?view.transform.forward:Vector3.forward});
    }
    void Notice(BoxNoticeV32 notice){if(notice.id==_selected){_waitingId=0;_status=notice.text;}}


    void Request(NetworkConnectionToClient connection, BoxRequestV32 request)
    {
        if (connection == null || connection.identity == null) return;
        _peers.Add(connection);
        if (request.text != null && request.text.Length > 300) return;
        if(request.action!=3&&request.action!=5&&request.action!=6&&_lastRequest.TryGetValue(connection.connectionId,out float last)&&Time.unscaledTime-last<.1f){connection.Send(new BoxNoticeV32{id=request.id,text="Слишком быстро. Повторите выбор."});return;}
        _lastRequest[connection.connectionId] = Time.unscaledTime;
        var player = connection.identity;
        if (request.action == 6) { foreach (var speaker in _boxes.Values) if (speaker != null) connection.Send(speaker.State); return; }
        if (request.action == 1)
        {
            if (_boxes.Count >= 24) return;
            var state = new BoxStateV32 { id = _nextId++,scale=Mathf.Clamp(Size.Value,.8f,1.8f), position = ReleasePosition(player.transform,request.origin,request.direction), rotation = player.transform.rotation, title = "JBL · YouTube",status="Выберите трек" };
            Create(state); Broadcast(state); return;
        }
        if (!_boxes.TryGetValue(request.id, out var box) || box == null) return;
        if(box.State.owner!=player.netId&&Vector3.Distance(player.transform.position,box.transform.position)>5f){connection.Send(new BoxNoticeV32{id=request.id,text="Подойдите ближе к колонке."});return;}
        if(box.State.owner!=0&&box.State.owner!=player.netId){connection.Send(new BoxNoticeV32{id=request.id,text="Колонка у другого игрока."});return;}
        if (request.action == 2 && box.State.owner == 0 && HeldBy(player.netId) == null)
        {
            var state = box.State; state.owner = player.netId; box.Apply(state); Broadcast(state);
        }
        else if (request.action == 3 && box.State.owner == player.netId) Drop(box,player.transform,request.origin,request.direction);
        else if (request.action == 5) Stop(box, "Остановлено");
        else if (request.action == 4)
        {
            var parts = (request.text ?? "").Split('\n'); if (parts.Length == 0 || !YouTube.ValidId(parts[0])) return;
            foreach (var other in _boxes.Values.Where(s => s != null && (s.State.playing||s.State.loading)).ToArray()) Stop(other, "Остановлено");
            var state = box.State; state.epoch++; state.playing=false;state.loading=true;state.status="Подключаю аудио YouTube…"; state.title = parts.Length > 1 ? parts[1] : parts[0];
            box.Apply(state); Broadcast(state); _playingBox = state.id;loadStarted=Time.unscaledTime;
            Logger.LogInfo("[JBL36] YouTube playback requested for box " + state.id + " video " + parts[0]);
            uint id = state.id, epoch = state.epoch;
            uint sequence = 0; var outgoing = new SendQueue(); _outgoing = outgoing;
            YouTube.Play(id, epoch, parts[0], pcm =>
            {
                if (System.Threading.Interlocked.Increment(ref outgoing.Count) <= 50) outgoing.Packets.Enqueue(new BoxAudioV32 { id = id, epoch = epoch, sequence = ++sequence, pcm = pcm });
                else System.Threading.Interlocked.Decrement(ref outgoing.Count);
            },message=>{if(message=="Трек завершён")StartCoroutine(FinishAudio(id,epoch,message));else if(_boxes.TryGetValue(id,out var live)&&live!=null&&live.State.epoch==epoch)Stop(live,message);},stage=>{if(_boxes.TryGetValue(id,out var live)&&live!=null&&live.State.epoch==epoch&&live.State.loading){var progress=live.State;progress.status=stage;live.Apply(progress);Broadcast(progress);Logger.LogInfo("[JBL36] Box "+id+": "+stage);}});
        }
    }
    System.Collections.IEnumerator FinishAudio(uint id,uint epoch,string message){yield return new WaitForSecondsRealtime(.5f);if(_boxes.TryGetValue(id,out var live)&&live!=null&&live.State.epoch==epoch)Stop(live,message);}
    static Vector3 AimDirection(Vector3 direction)
    {var n=ThrowMotion.Normalize(direction.x,direction.y,direction.z);return new Vector3(n.X,n.Y,n.Z);}
    Vector3 ReleasePosition(Transform player,Vector3 origin,Vector3 direction)
    {
        if(!ThrowMotion.Near(origin.x,origin.y,origin.z,player.position.x,player.position.y,player.position.z))origin=player.position+Vector3.up*1.3f;
        var aim=AimDirection(direction);var horizontal=Vector3.ProjectOnPlane(aim,Vector3.up);
        if(horizontal.sqrMagnitude<.01f)horizontal=Vector3.ProjectOnPlane(player.forward,Vector3.up);
        if(horizontal.sqrMagnitude<.01f)horizontal=Vector3.forward;horizontal.Normalize();
        float distance=1.15f;
        foreach(var hit in Physics.SphereCastAll(origin,.34f,horizontal,distance,~0,QueryTriggerInteraction.Ignore))
            if(hit.collider!=null&&!hit.collider.transform.IsChildOf(player)&&hit.collider.GetComponentInParent<Speaker>()==null)distance=Mathf.Min(distance,Mathf.Max(0,hit.distance-.05f));
        // Put the model centre in front of the camera; root is at its base.
        return origin+horizontal*distance+aim*.12f-Vector3.up*(BoomMesh.H*.5f+.13f);
    }
    void Drop(Speaker speaker,Transform player,Vector3 origin,Vector3 direction)
    {
        var state=speaker.State;state.owner=0;
        if(player!=null)
        {
            var aim=AimDirection(direction);aim.y=Mathf.Clamp(aim.y,-.35f,.75f);aim.Normalize();state.position=ReleasePosition(player,origin,direction);
            var horizontal=Vector3.ProjectOnPlane(aim,Vector3.up);if(horizontal.sqrMagnitude<.01f)horizontal=player.forward;
            state.rotation=Quaternion.LookRotation(horizontal.normalized,Vector3.up);
            var rigid=player.GetComponent<Rigidbody>();var carry=rigid!=null?rigid.linearVelocity:Vector3.zero;
            var velocity=ThrowMotion.Velocity(aim.x,aim.y,aim.z,ThrowSpeed.Value,carry.x,carry.y,carry.z);state.velocity=new Vector3(velocity.X,velocity.Y,velocity.Z);
        }
        else{state.position=speaker.transform.position;state.rotation=speaker.transform.rotation;state.velocity=Vector3.zero;}
        speaker.transform.SetPositionAndRotation(state.position,state.rotation);speaker.Body.position=state.position;speaker.Body.rotation=state.rotation;speaker.Apply(state);
        speaker.Body.useGravity=true;speaker.Body.isKinematic=false;
        if(player!=null)speaker.IgnoreThrower(player,.55f);
        speaker.Body.linearVelocity=state.velocity;speaker.Body.angularVelocity=player!=null?state.rotation*Vector3.right*4.5f+Vector3.up*.6f:Vector3.zero;speaker.Body.WakeUp();
        Broadcast(state);Logger.LogInfo("[JBL36] Thrown box "+state.id+" speed "+state.velocity.magnitude.ToString("0.0")+" m/s");
    }
    void Stop(Speaker speaker, string title)
    {
        if (speaker.State.id == _playingBox) { YouTube.Stop(); _playingBox = 0; }
        var state = speaker.State; state.playing=false;state.loading=false;state.epoch++;state.status=title;
        Logger.LogInfo("[JBL36] Box "+state.id+": "+ToolRunner.SafeError(title));
        speaker.Apply(state); Broadcast(state);
    }
    void Create(BoxStateV32 state)
    {
        var go = new GameObject("JBL_YouTube_" + state.id); go.transform.SetPositionAndRotation(state.position, state.rotation);
        var speaker = go.AddComponent<Speaker>(); _boxes[state.id] = speaker; speaker.Initialize(state);
    }
    void Receive(BoxStateV32 state)
    {
        if(state.id==_waitingId&&state.epoch!=_waitingEpoch)_waitingId=0;
        if (state.removed) { if (_boxes.TryGetValue(state.id, out var dead)) Destroy(dead.gameObject); _boxes.Remove(state.id); return; }
        if (!_boxes.TryGetValue(state.id, out var box) || box == null) Create(state); else box.Apply(state);
        if (state.playing && _listener == null && !FindObjectsByType<AudioListener>(FindObjectsSortMode.None).Any(l => l.isActiveAndEnabled))
        { var camera = View; if (camera != null) _listener = camera.gameObject.AddComponent<AudioListener>(); }
    }
    public void LoggerForAudio(string message)=>Logger.LogInfo("[JBL36] "+message);
    void Audio(BoxAudioV32 packet) { if (_boxes.TryGetValue(packet.id, out var box)) box.Audio(packet); }
    void Clear()
    {
        YouTube.Stop(); foreach (var box in _boxes.Values) if (box != null) Destroy(box.gameObject); _boxes.Clear();
        _outgoing = new SendQueue(); _playingBox = 0; _lastRequest.Clear();_peers.Clear();_waitingId=0;
        if (_listener != null) Destroy(_listener); _listener = null;
    }

    void Open(uint id)
    {
        _selected = id; _open = true; _oldCursor = Cursor.lockState; _oldVisible = Cursor.visible;
        _window.width=Mathf.Min(660,Screen.width-40);_window.height=Mathf.Clamp(Screen.height-70,390,610);
        _window.x = (Screen.width - _window.width) / 2; _window.y = (Screen.height - _window.height) / 2;
        var inputField = typeof(InputReader).GetField("_inputActions", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
        var actions = InputReader.Instance != null ? inputField?.GetValue(InputReader.Instance) as InputActions : null;
        if (actions != null)
            foreach (var action in new[] { actions.Player.Move, actions.Player.Aim, actions.Player.UseItem, actions.Player.Interact })
                if (action.enabled) { _disabled.Add(action); action.Disable(); }
        var controller = NetworkClient.localPlayer != null ? NetworkClient.localPlayer.GetComponent<PlayerController>() : null;
        if (controller != null && controller.head != null) { _oldHeadLocked = controller.head.isLocked; controller.head.isLocked = true; }
    }
    void Close()
    {
        SaveVolume();
        if (!_open) return; _open = false;
        foreach (var action in _disabled) action.Enable(); _disabled.Clear();
        var controller = NetworkClient.localPlayer != null ? NetworkClient.localPlayer.GetComponent<PlayerController>() : null;
        if (controller != null && controller.head != null) controller.head.isLocked = _oldHeadLocked;
        Cursor.lockState = _oldCursor; Cursor.visible = _oldVisible;
    }
    void LateUpdate() { if (_open) { Cursor.lockState = CursorLockMode.None; Cursor.visible = true; } }
    void OnGUI()
    {
        if (!_open) return;
        _window = GUI.Window(903031, _window, Menu, "JBL · YouTube Music");
    }
    Vector2 _scroll;
    void SetVolume(float value)
    {
        value=Mathf.Clamp01(value);if(Mathf.Abs(value-Volume.Value)<.001f)return;
        // Apply immediately, but do not rewrite the config on every slider event.
        bool autoSave=Config.SaveOnConfigSet;Config.SaveOnConfigSet=false;
        try{Volume.Value=value;}finally{Config.SaveOnConfigSet=autoSave;}
        _volumeSaveAt=Time.unscaledTime+.35f;
    }
    void SaveVolume(){if(_volumeSaveAt<=0)return;_volumeSaveAt=0;Config.Save();}
    void Menu(int id)
    {
        GUILayout.Space(12);
        if(_boxes.TryGetValue(_selected,out var box)){GUILayout.Label((box.State.loading?"… ":box.State.playing?"▶ ":"■ ")+box.State.title,GUILayout.Height(34));GUILayout.Label(_waitingId==_selected?"Отправляю запрос хосту…":box.State.status??"Выберите трек",GUILayout.Height(54));}
        GUILayout.BeginHorizontal();
        GUILayout.Label("Громкость: "+Mathf.RoundToInt(Volume.Value*100)+"%",GUILayout.Width(135),GUILayout.Height(26));
        SetVolume(GUILayout.HorizontalSlider(Volume.Value,0f,1f,GUILayout.Height(26)));
        GUILayout.Label("0–100%",GUILayout.Width(60),GUILayout.Height(26));
        GUILayout.EndHorizontal();
        GUILayout.BeginHorizontal(); _query = GUILayout.TextField(_query, 180, GUILayout.Height(30));
        GUI.enabled = !_searching && !string.IsNullOrWhiteSpace(_query);
        if (GUILayout.Button("Найти на YouTube", GUILayout.Width(155), GUILayout.Height(30)))
        {
            _searching = true; _status = "Поиск…";
            YouTube.Search(_query, tracks => { _tracks = tracks; _searching = false; _status = tracks.Length > 0 ? "Выбери трек:" : "Ничего не найдено. Попробуй другое название."; }, error => { _status = error; _searching = false; });
        }
        GUI.enabled = true; GUILayout.EndHorizontal(); GUILayout.Label(_status,GUILayout.Height(36));
        _scroll = GUILayout.BeginScrollView(_scroll, GUILayout.Height(Mathf.Max(140,_window.height-336)));
        foreach (var track in _tracks)
            if (GUILayout.Button(track.title + "  " + (track.duration > 0 ? TimeSpan.FromSeconds(track.duration).ToString(@"m\:ss") : ""), GUILayout.Height(36)))
            { string title = (track.title ?? "").Replace("\n", " "); if (title.Length > 200) title = title.Substring(0, 200); _waitingId=_selected;_waitingEpoch=box!=null?box.State.epoch:0;_ackDeadline=Time.unscaledTime+5;_status="";Send(4,_selected,track.id+"\n"+title); }
        GUILayout.EndScrollView(); GUILayout.BeginHorizontal();
        if(GUILayout.Button("Стоп",GUILayout.Height(30))){_waitingId=0;Send(5,_selected);}
        if (GUILayout.Button("Взять", GUILayout.Height(30))) { Send(2, _selected); Close(); }
        if (GUILayout.Button("Закрыть", GUILayout.Height(30))) Close();
        GUILayout.EndHorizontal(); GUILayout.Label("ЛКМ — музыка · E — взять · Q — бросить · Insert — создать колонку");
        GUI.DragWindow(new Rect(0, 0, _window.width, 20));
    }
    void OnDestroy() { Close(); Clear(); YouTube.Shutdown(); }
    void OnApplicationQuit(){SaveVolume();YouTube.Shutdown();}
}
