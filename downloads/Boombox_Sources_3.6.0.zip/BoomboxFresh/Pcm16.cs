using System;
namespace FreshBoombox;
public static class Pcm16
{
    public static void Encode(float[] source,byte[] output)
    {
        if(source==null||output==null||output.Length<source.Length*2)throw new ArgumentException("PCM buffer size");
        for(int i=0;i<source.Length;i++){float sample=float.IsNaN(source[i])?0:source[i];short value=(short)Math.Max(short.MinValue,Math.Min(short.MaxValue,sample*32768));output[i*2]=(byte)value;output[i*2+1]=(byte)(value>>8);}
    }
}
