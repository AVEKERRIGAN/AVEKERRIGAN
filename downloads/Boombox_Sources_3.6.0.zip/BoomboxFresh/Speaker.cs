using System;using System.Collections;
using System.Collections.Generic;
using Mirror;
using UnityEngine;

namespace FreshBoombox;

public sealed class Speaker : MonoBehaviour
{
    public BoxStateV32 State;
    public Rigidbody Body;
    public BoxCollider Collider;
    public readonly AudioQueue Samples = new();
    AudioSource _sound; FmodPcmOutput _native;
    AudioClip _clip;
    MeshRenderer _glow;Outline outline;
    readonly MaterialPropertyBlock _properties = new();
    readonly List<Mesh> _meshes = new();
    readonly List<Material> _materials = new();
    uint _sequence; bool _hadSequence;
    bool _playing;float _received,_outputStarted;bool _outputChecked;UnityEngine.PhysicsMaterial _physics;

    public void Initialize(BoxStateV32 state)
    {
        State = state;transform.localScale=Vector3.one*(state.scale>=.8f?Mathf.Clamp(state.scale,.8f,1.8f):1.25f);
        Body = gameObject.AddComponent<Rigidbody>(); Body.mass = 3f;
        Body.interpolation = NetworkServer.active ? RigidbodyInterpolation.Interpolate : RigidbodyInterpolation.None;
        Body.linearDamping=.08f;Body.angularDamping=.18f;Body.useGravity=NetworkServer.active;
        _physics=new UnityEngine.PhysicsMaterial("JBL rubber") {dynamicFriction=.65f,staticFriction=.7f,bounciness=.16f};
        Body.collisionDetectionMode = CollisionDetectionMode.ContinuousSpeculative;
        Body.isKinematic = !NetworkServer.active;
        Collider = gameObject.AddComponent<BoxCollider>();Collider.sharedMaterial=_physics;
        Collider.center = new Vector3(0, BoomMesh.H * .5f + .012f, 0); Collider.size = new Vector3(BoomMesh.W, BoomMesh.H, BoomMesh.D);
        var parts = BoomMesh.Build();
        foreach (bool glow in new[] { false, true })
        {
            var vertices = new List<Vector3>(); var triangles = new Dictionary<int, List<int>>();
            foreach (var part in parts)
            {
                bool luminous = part.mat == BoomMesh.RING || part.mat == BoomMesh.STRIP;
                if (glow != luminous) continue;
                int offset = vertices.Count;
                for (int i = 0; i < part.v.Count; i += 3) vertices.Add(new Vector3(part.v[i], part.v[i + 1], part.v[i + 2]));
                if (!triangles.TryGetValue(part.mat, out var indices)) triangles[part.mat] = indices = new List<int>();
                foreach (int index in part.t) indices.Add(index + offset);
            }
            var go = new GameObject(glow ? "JBL_Lights" : "JBL_Body"); go.transform.SetParent(transform, false);
            go.transform.localPosition = new Vector3(0, BoomMesh.H * .5f + .012f, 0);
            var mesh = new Mesh(); mesh.SetVertices(vertices); mesh.subMeshCount = triangles.Count;
            var materials = new List<Material>(); int submesh = 0;
            var shader = Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard");
            foreach (var group in triangles)
            {
                mesh.SetTriangles(group.Value, submesh++);
                var material = new Material(shader);
                var color = glow ? new Color(.02f, .75f, .86f) : group.Key == BoomMesh.LABEL ? new Color(.88f, .9f, .93f) : group.Key == BoomMesh.GRILLE ? new Color(.085f, .09f, .095f) : new Color(.025f, .03f, .035f);
                if (material.HasProperty("_BaseColor")) material.SetColor("_BaseColor", color);
                if (material.HasProperty("_Color")) material.SetColor("_Color", color);
                if (material.HasProperty("_Smoothness")) material.SetFloat("_Smoothness", glow ? .65f : .3f);
                if (glow) { material.EnableKeyword("_EMISSION"); material.SetColor("_EmissionColor", color); }
                materials.Add(material); _materials.Add(material);
            }
            mesh.RecalculateNormals(); mesh.RecalculateBounds(); _meshes.Add(mesh);
            go.AddComponent<MeshFilter>().sharedMesh = mesh;
            var renderer = go.AddComponent<MeshRenderer>(); renderer.sharedMaterials = materials.ToArray();
            if (glow) _glow = renderer;
        }
        if(Resources.Load<Material>("Materials/OutlineMask")!=null&&Resources.Load<Material>("Materials/OutlineFill")!=null){outline=gameObject.AddComponent<Outline>();outline.OutlineMode=Outline.Mode.OutlineVisible;outline.OutlineColor=Color.white;outline.OutlineWidth=4;outline.enabled=false;}
        Apply(state);
    }

    public void Apply(BoxStateV32 state)
    {
        if (State.epoch != state.epoch) { Samples.Reset(); _hadSequence = false; }
        uint oldOwner=State.owner;
        State = state; _received=Time.unscaledTime; Collider.enabled = state.owner == 0;
        bool kinematic=state.owner!=0||!NetworkServer.active;if(Body.isKinematic!=kinematic)Body.isKinematic=kinematic;Body.useGravity=NetworkServer.active&&state.owner==0;
        if (!NetworkServer.active && state.owner == 0 && oldOwner!=0) { transform.position = state.position; transform.rotation = state.rotation; }
        SetPlaying(state.playing);
    }
    void SetPlaying(bool playing)
    {
        if (_playing == playing) return;
        _playing = playing; Samples.Reset();
        if(!playing&&_native!=null){_native.Dispose();_native=null;}
        if(playing&&_native==null)
        {
            try{_native=new FmodPcmOutput(Samples,Plugin.SpatialAudio.Value,Plugin.Volume.Value,Plugin.Distance.Value);_outputStarted=Time.unscaledTime;_outputChecked=false;Plugin.Instance.LoggerForAudio("Native FMOD PCM output ready for box "+State.id);}
            catch(Exception error){Plugin.Instance.LoggerForAudio(error.Message);}
        }
        if(_native!=null)return;
        if (playing && _sound == null)
        {
            _sound = gameObject.AddComponent<AudioSource>(); _sound.playOnAwake = false; _sound.loop = true;
            _sound.spatialBlend = Plugin.SpatialAudio.Value ? 1f : 0f; _sound.dopplerLevel = 0; _sound.rolloffMode = AudioRolloffMode.Linear;
            _sound.minDistance = 2.5f; _sound.maxDistance = Plugin.Distance.Value; _sound.volume = Plugin.Volume.Value;
            _clip = AudioClip.Create("JBL YouTube PCM", 24000, 1, 24000, true, Samples.Read); _sound.clip = _clip;
        }
        if (_sound != null) { if (playing) _sound.Play(); else _sound.Stop(); }
    }
    public void Audio(BoxAudioV32 packet)
    {
        if (!State.playing || packet.epoch != State.epoch || packet.pcm == null || packet.pcm.Length > 960) return;
        if (_hadSequence && (int)(packet.sequence - _sequence) <= 0) return;
        _hadSequence = true; _sequence = packet.sequence; Samples.Push(packet.pcm);
    }
    void LateUpdate()
    {
        if (State.owner != 0 && NetworkClient.spawned.TryGetValue(State.owner, out var player))
        {
            var inventory = player.GetComponent<PlayerInventory>();
            var hand = inventory != null ? inventory.handTransform : player.transform;
            transform.SetPositionAndRotation(hand.position + hand.right * .15f - hand.up * .35f + hand.forward * .20f, hand.rotation * Quaternion.Euler(0, 180, 0));
        }
        else if(!NetworkServer.active)
        {
            float dt=Mathf.Clamp(Time.unscaledTime-_received,0,.08f),blend=ThrowMotion.Smooth(Time.unscaledDeltaTime);
            transform.position=Vector3.Lerp(transform.position,State.position+State.velocity*dt,blend);
            transform.rotation=Quaternion.Slerp(transform.rotation,State.rotation,blend);
        }
        if (_glow != null)
        {
            _properties.SetColor("_EmissionColor", new Color(.02f, .8f, .9f) * (_playing ? 1f + .3f * Mathf.Sin(Time.time * 4) : .25f));
            _glow.SetPropertyBlock(_properties);
        }
        if(_native!=null&&!_outputChecked&&Time.unscaledTime-_outputStarted>2){_outputChecked=true;Plugin.Instance.LoggerForAudio("FMOD requested "+_native.ReadSamples+" PCM samples; local volume "+Plugin.Volume.Value);}
        if(_native!=null)_native.Update(transform.position,Plugin.Volume.Value,Plugin.Distance.Value);
        if (_sound != null) { _sound.volume = Plugin.Volume.Value; _sound.maxDistance = Plugin.Distance.Value; }
    }
    public void Hover(bool active){if(outline!=null)outline.enabled=active&&State.owner==0;}
    public void IgnoreThrower(Transform player,float seconds){StartCoroutine(ReleaseCollision(player,seconds));}
    IEnumerator ReleaseCollision(Transform player,float seconds)
    {
        var colliders=player.GetComponentsInChildren<Collider>(true);foreach(var other in colliders)if(other!=null&&other!=Collider)Physics.IgnoreCollision(Collider,other,true);
        yield return new WaitForSecondsRealtime(seconds);if(Collider!=null)foreach(var other in colliders)if(other!=null&&other!=Collider)Physics.IgnoreCollision(Collider,other,false);
    }
    void OnDestroy()
    {
        if(_native!=null){_native.Dispose();_native=null;}Samples.Reset(); if (_sound != null) { _sound.Stop(); _sound.clip = null; }
        if (_clip != null) Destroy(_clip);
        if(_physics!=null)Destroy(_physics);
        foreach (var mesh in _meshes) if (mesh != null) Destroy(mesh);
        foreach (var material in _materials) if (material != null) Destroy(material);
    }
}
