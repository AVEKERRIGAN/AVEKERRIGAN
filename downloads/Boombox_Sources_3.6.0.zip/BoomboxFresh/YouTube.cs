using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
namespace FreshBoombox;
[Serializable]public sealed class Track{public string id,title;public float duration;}
public static class YouTube
{
    public static string Tools;
    public static readonly ConcurrentQueue<Action> Main=new();
    public static TimeSpan SearchLimit=TimeSpan.FromSeconds(25),FirstAudioLimit=TimeSpan.FromSeconds(18),StallLimit=TimeSpan.FromSeconds(12);
    sealed class Job
    {
        public readonly CancellationTokenSource Cancel=new();public readonly CancellationToken Token;public volatile bool Stopped;
        public Job(){Token=Cancel.Token;}
    }
    static Job _search,_playback;
    static void Cancel(Job job){if(job==null)return;job.Stopped=true;_ = Task.Run(()=>{try{job.Cancel.Cancel();}catch{ }});}
    static string Tool(string name)=>Path.Combine(Tools,name+".exe");
    static string Runtime{get{string path=Tool("deno");if(!File.Exists(path))throw new FileNotFoundException("Не найден tools/deno.exe. Хосту нужен архив Boombox_YouTube_Runtime.");return "deno:"+path;}}
    static void SearchPost(Job job,Action action)=>Main.Enqueue(()=>{if(ReferenceEquals(_search,job)&&!job.Stopped)action();});
    static void PlayPost(Job job,Action action)=>Main.Enqueue(()=>{if(ReferenceEquals(_playback,job)&&!job.Stopped)action();});
    public static void Search(string query,Action<Track[]> complete,Action<string> error)
    {
        var old=_search;var job=new Job();_search=job;Cancel(old);
        _ = Task.Run(()=>
        {
            try
            {
                using var deadline=CancellationTokenSource.CreateLinkedTokenSource(job.Token);deadline.CancelAfter(SearchLimit);
                string target=VideoId(query) is string video?"https://www.youtube.com/watch?v="+video:"ytsearch8:"+query;
                using var process=new ToolRunner(Tool("yt-dlp"),new[]{"--encoding","utf-8","--flat-playlist","--dump-json","--skip-download","--no-playlist","--socket-timeout","8","--retries","1","--extractor-retries","1",target},deadline.Token);
                string output=process.Capture(deadline.Token);var tracks=new List<Track>();
                foreach(string line in output.Split('\n'))
                {
                    if(string.IsNullOrWhiteSpace(line))continue;
                    try{var item=JObject.Parse(line);string id=(string)item["id"];if(ValidId(id))tracks.Add(new Track{id=id,title=(string)item["title"]??id,duration=(float?)item["duration"]??0});}catch{ }
                }
                SearchPost(job,()=>complete(tracks.ToArray()));
            }
            catch(OperationCanceledException){SearchPost(job,()=>error("Поиск не ответил за "+(int)SearchLimit.TotalSeconds+" секунд. Проверьте доступ к YouTube."));}
            catch(Exception e){string message=ToolRunner.SafeError(e.Message);SearchPost(job,()=>error(message));}
            finally{job.Cancel.Dispose();}
        });
    }
    public static bool ValidId(string id)
    {
        if(id==null||id.Length!=11)return false;
        foreach(char c in id)if(c!='-'&&c!='_'&&(c>127||!char.IsLetterOrDigit(c)))return false;return true;
    }
    public static string VideoId(string value)
    {
        value=value?.Trim();if(ValidId(value))return value;
        if(!Uri.TryCreate(value,UriKind.Absolute,out var uri))return null;
        string host=uri.Host.ToLowerInvariant(),id=null;
        if(host=="youtu.be")id=uri.AbsolutePath.Trim('/');
        else if(host=="youtube.com"||host=="www.youtube.com"||host=="m.youtube.com")
        {
            var parts=uri.AbsolutePath.Trim('/').Split('/');
            if(parts.Length==2&&(parts[0]=="shorts"||parts[0]=="embed"))id=parts[1];
            else foreach(string parameter in uri.Query.TrimStart('?').Split('&'))if(parameter.StartsWith("v="))id=Uri.UnescapeDataString(parameter.Substring(2));
        }
        return ValidId(id)?id:null;
    }
    public static string[] DownloadArguments(string video,string client)
    {
        var args=new List<string>{"--encoding","utf-8","--js-runtimes",Runtime,"--no-playlist","--quiet","--no-progress","--no-part","--socket-timeout","8","--retries","1","--fragment-retries","1","--extractor-retries","1","--ffmpeg-location",Tools,"--format","bestaudio/best","--output","-"};
        // Start with yt-dlp's maintained defaults. An alternate extraction obtains a
        // fresh URL; reusing a rejected signed link cannot repair a 403.
        if(client!="default")args.AddRange(new[]{"--extractor-args","youtube:player_client="+client});
        args.Add("https://www.youtube.com/watch?v="+video);return args.ToArray();
    }
    public static string[] PipeAudioArguments()=>new[]{"-nostdin","-hide_banner","-loglevel","error","-re","-i","pipe:0","-vn","-sn","-dn","-f","s16le","-ac","1","-ar","24000","pipe:1"};
    static bool Retryable(string error)=>error.IndexOf("403",StringComparison.OrdinalIgnoreCase)>=0||error.IndexOf("Forbidden",StringComparison.OrdinalIgnoreCase)>=0||error.IndexOf("Requested format",StringComparison.OrdinalIgnoreCase)>=0;
    static string PlaybackError(string error)
    {
        if(error.IndexOf("confirm your age",StringComparison.OrdinalIgnoreCase)>=0||error.IndexOf("age-restricted",StringComparison.OrdinalIgnoreCase)>=0)return "Этот ролик требует подтверждения возраста в YouTube. Выберите другой трек.";
        if(error.IndexOf("403",StringComparison.OrdinalIgnoreCase)>=0||error.IndexOf("Forbidden",StringComparison.OrdinalIgnoreCase)>=0)return "YouTube отклонил аудио (403) и после повторного подключения. Выберите другой трек или проверьте доступ к YouTube.";
        return ToolRunner.SafeError(error);
    }
    public static void Play(uint id,uint epoch,string video,Action<byte[]> packet,Action<string> done,Action<string> stage=null)
    {
        Stop();var job=new Job();_playback=job;
        _ = Task.Run(()=>
        {
            bool started=false;
            try
            {
                if(!ValidId(video))throw new IOException("Неверный идентификатор YouTube.");
                var clients=new[]{"default","mweb","android_vr"};
                for(int attempt=0;attempt<clients.Length;attempt++)
                {
                    job.Token.ThrowIfCancellationRequested();
                    if(stage!=null){string message=attempt==0?"Подключаю аудио YouTube…":"YouTube отказал в потоке. Повторное подключение "+attempt+"/2…";PlayPost(job,()=>stage(message));}
                    using var watchdog=CancellationTokenSource.CreateLinkedTokenSource(job.Token);watchdog.CancelAfter(FirstAudioLimit);
                    using var downloader=new ToolRunner(Tool("yt-dlp"),DownloadArguments(video,clients[attempt]),watchdog.Token);
                    using var decoder=new ToolRunner(Tool("ffmpeg"),PipeAudioArguments(),watchdog.Token,input:true);
                    // yt-dlp downloads with the selected client's own headers, cookies
                    // and fragment handling. FFmpeg receives bytes, never a signed URL.
                    var transfer=Task.Run(()=>
                    {
                        try
                        {
                            downloader.Process.StandardOutput.BaseStream.CopyTo(decoder.Process.StandardInput.BaseStream,32768);
                            downloader.Process.WaitForExit();watchdog.Token.ThrowIfCancellationRequested();
                            if(downloader.Process.ExitCode!=0)throw new IOException(downloader.Error);
                        }
                        finally{try{decoder.Process.StandardInput.Close();}catch{}}
                    });
                    string failure=null;
                    try
                    {
                        var stream=decoder.Process.StandardOutput.BaseStream;
                        while(true)
                        {
                            var pcm=new byte[960];int used=0;
                            while(used<pcm.Length){int n=stream.Read(pcm,used,pcm.Length-used);if(n==0)break;used+=n;}
                            watchdog.Token.ThrowIfCancellationRequested();if(used==0)break;
                            if(used<pcm.Length)Array.Resize(ref pcm,used&~1);if(pcm.Length==0)continue;
                            started=true;watchdog.CancelAfter(StallLimit);packet(pcm);
                        }
                        transfer.GetAwaiter().GetResult();decoder.Process.WaitForExit();watchdog.Token.ThrowIfCancellationRequested();
                        if(!started||decoder.Process.ExitCode!=0)throw new IOException("Звук не начался: "+decoder.Error);
                    }
                    catch(Exception error)
                    {
                        failure=error is OperationCanceledException?(started?"Поток звука не ответил за "+(int)StallLimit.TotalSeconds+" секунд.":"YouTube не начал звук за "+(int)FirstAudioLimit.TotalSeconds+" секунд."):error.Message;
                        string downloadError=downloader.Error;if(!string.IsNullOrEmpty(downloadError))failure=downloadError;
                    }
                    finally
                    {
                        downloader.Kill();decoder.Kill();try{transfer.GetAwaiter().GetResult();}catch{}
                    }
                    job.Token.ThrowIfCancellationRequested();
                    if(failure==null){PlayPost(job,()=>done("Трек завершён"));return;}
                    if(started||!Retryable(failure)||attempt==clients.Length-1)throw new IOException(PlaybackError(failure));
                }
            }
            catch(OperationCanceledException){}
            catch(Exception e){string message=PlaybackError(e.Message);PlayPost(job,()=>done(message));}
            finally{job.Cancel.Dispose();}
        });
    }
    public static void Stop(){var old=_playback;_playback=null;Cancel(old);}
    public static void Shutdown(){Stop();var old=_search;_search=null;Cancel(old);}
}
