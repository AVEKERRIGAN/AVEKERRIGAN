using System;
using System.Collections.Generic;

namespace Boombox
{
    /// Procedural party-speaker geometry (original design, metres, +Z = front). Pure math, no Unity types,
    /// so the same code feeds the in-game Mesh and the offline preview renderer.
    public static class BoomMesh
    {
        // material ids
        public const int BODY = 0, RUBBER = 1, GRILLE = 2, RIM = 3, CONE = 4, RING = 5, STRIP = 6, CAP = 7, LABEL = 8;
        public class Part { public string name; public int mat; public List<float> v = new List<float>(); public List<int> t = new List<int>(); public float cx, cy, cz;
            public int V(double x, double y, double z) { v.Add((float)x); v.Add((float)y); v.Add((float)z); return v.Count / 3 - 1; }
            public void Q(int a, int b, int c, int d) { t.Add(a); t.Add(b); t.Add(c); t.Add(a); t.Add(c); t.Add(d); } }

        public const float W = .31f, H = .62f, D = .28f;       // slim JBL-style chassis
        public const float DriverY = .118f, DriverR = .082f;     // two drivers (upper / lower)

        /// rounded-rect footprint (x/z) with corner radius rc; returns closed loop of points
        static List<double[]> RRect(double hw, double hd, double rc, int seg)
        {
            var p = new List<double[]>();
            double[,] c = { { hw - rc, hd - rc, 0 }, { -(hw - rc), hd - rc, 90 }, { -(hw - rc), -(hd - rc), 180 }, { hw - rc, -(hd - rc), 270 } };
            for (int k = 0; k < 4; k++) for (int i = 0; i <= seg; i++) { double a = (c[k, 2] + 90.0 * i / seg) * Math.PI / 180; p.Add(new[] { c[k, 0] + rc * Math.Cos(a), c[k, 1] + rc * Math.Sin(a) }); }
            return p;
        }

        /// box rounded on all edges: footprint corners rc, top/bottom edges re. Axis: footprint in plane (a,b), height along h.
        /// orient: 0 = footprint XZ / height Y, 1 = footprint XY / height Z (panels facing front)
        public static Part RoundBox(string name, int mat, double w, double h, double d, double rc, double re, double cx, double cy, double cz, int orient = 0, int seg = 6)
        {
            var P = new Part { name = name, mat = mat, cx = (float)cx, cy = (float)cy, cz = (float)cz };
            rc = Math.Min(rc, Math.Min(w, orient == 0 ? d : h) / 2 - 1e-4); re = Math.Min(re, Math.Min(rc, (orient == 0 ? h : d) / 2 - 1e-4));
            double fa = w / 2, fb = (orient == 0 ? d : h) / 2, hh = (orient == 0 ? h : d) / 2;
            var rows = new List<double[]>(); // (inset, height)
            for (int i = 0; i <= seg; i++) { double a = -Math.PI / 2 + Math.PI / 2 * i / seg; rows.Add(new[] { re * (1 - Math.Cos(a)), -hh + re + re * Math.Sin(a) }); }
            for (int i = 0; i <= seg; i++) { double a = Math.PI / 2 * i / seg; rows.Add(new[] { re * (1 - Math.Cos(a)), hh - re + re * Math.Sin(a) }); }
            int n = -1; var idx = new List<int[]>();
            foreach (var r in rows)
            {
                var loop = RRect(fa - r[0], fb - r[0], Math.Max(1e-4, rc - r[0]), seg); n = loop.Count; var ids = new int[n];
                for (int i = 0; i < n; i++) ids[i] = orient == 0 ? P.V(cx + loop[i][0], cy + r[1], cz + loop[i][1]) : P.V(cx + loop[i][0], cy + loop[i][1], cz + r[1]);
                idx.Add(ids);
            }
            for (int k = 0; k + 1 < idx.Count; k++) for (int i = 0; i < n; i++) { int j = (i + 1) % n; if (orient == 0) P.Q(idx[k][i], idx[k][j], idx[k + 1][j], idx[k + 1][i]); else P.Q(idx[k][i], idx[k + 1][i], idx[k + 1][j], idx[k][j]); }
            int b0 = orient == 0 ? P.V(cx, cy - hh, cz) : P.V(cx, cy, cz - hh), t0 = orient == 0 ? P.V(cx, cy + hh, cz) : P.V(cx, cy, cz + hh);
            var lb = idx[0]; var lt = idx[idx.Count - 1];
            for (int i = 0; i < n; i++) { int j = (i + 1) % n;
                if (orient == 0) { P.t.AddRange(new[] { b0, lb[j], lb[i] }); P.t.AddRange(new[] { t0, lt[i], lt[j] }); }
                else { P.t.AddRange(new[] { b0, lb[i], lb[j] }); P.t.AddRange(new[] { t0, lt[j], lt[i] }); } }
            return P;
        }

        /// hourglass / figure-8 light path in the front plane (closed), x half-width A, y half-height B, waist pinch c
        public static List<double[]> Hourglass(int n, double A = .118, double B = .228, double c = .36, double cy = 0)
        {
            var p = new List<double[]>();
            for (int i = 0; i < n; i++)
            {
                double t = 2 * Math.PI * i / n, s = Math.Sin(t), co = Math.Cos(t);
                double x = A * Math.Sign(s) * Math.Pow(Math.Abs(s), .55), y = B * Math.Sign(co) * Math.Pow(Math.Abs(co), .55);
                double pinch = 1 - c * Math.Exp(-Math.Pow(y / (B * .36), 2));
                p.Add(new[] { x * pinch, cy + y });
            }
            return p;
        }

        /// tube swept along a closed path in plane z = zf
        public static Part Tube(string name, int mat, List<double[]> path, double r, double zf, int rs = 8)
        {
            var P = new Part { name = name, mat = mat }; int n = path.Count; var ids = new int[n, rs];
            for (int i = 0; i < n; i++)
            {
                var a = path[(i + n - 1) % n]; var b = path[(i + 1) % n]; double tx = b[0] - a[0], ty = b[1] - a[1], l = Math.Sqrt(tx * tx + ty * ty) + 1e-9; tx /= l; ty /= l;
                double nx = ty, ny = -tx;
                for (int k = 0; k < rs; k++) { double f = 2 * Math.PI * k / rs; ids[i, k] = P.V(path[i][0] + r * Math.Cos(f) * nx, path[i][1] + r * Math.Cos(f) * ny, zf + r * Math.Sin(f)); }
            }
            for (int i = 0; i < n; i++) for (int k = 0; k < rs; k++) { int i2 = (i + 1) % n, k2 = (k + 1) % rs; P.Q(ids[i, k], ids[i, k2], ids[i2, k2], ids[i2, k]); }
            return P;
        }

        /// flat annulus (r0..r1) facing +Z, optionally dished toward -Z at the inner edge (cone)
        public static Part Disc(string name, int mat, double cx, double cy, double zf, double r0, double r1, double dish, int seg = 40, int rings = 3)
        {
            var P = new Part { name = name, mat = mat, cx = (float)cx, cy = (float)cy, cz = (float)zf }; var ids = new int[rings + 1, seg];
            for (int k = 0; k <= rings; k++) { double r = r0 + (r1 - r0) * k / rings, z = zf - dish * (1 - (double)k / rings);
                for (int i = 0; i < seg; i++) { double a = 2 * Math.PI * i / seg; ids[k, i] = P.V(cx + r * Math.Cos(a), cy + r * Math.Sin(a), z); } }
            for (int k = 0; k < rings; k++) for (int i = 0; i < seg; i++) { int j = (i + 1) % seg; P.Q(ids[k, i], ids[k, j], ids[k + 1, j], ids[k + 1, i]); }
            if (r0 <= 1e-6) { }
            return P;
        }

        public static List<Part> Build()
        {
            var parts = new List<Part>();
            double front = D / 2;
            parts.Add(RoundBox("BB_Chassis", BODY, W, H, D, .073, .035, 0, 0, 0, 0, 5));
            parts.Add(RoundBox("BB_FrontFabric", GRILLE, W - .025, H - .045, .012, .075, .004, 0, 0, front - .003, 1, 4));
            foreach (double y in new[] { .145, -.145 })
            {
                parts.Add(Disc("BB_DriverRim", RIM, 0, y, front + .004, .070, .089, 0, 32, 1));
                parts.Add(Disc("BB_Driver", CONE, 0, y, front + .003, .012, .071, .014, 32, 3));
                parts.Add(Disc("BB_DustCap", CAP, 0, y, front - .007, 0, .029, -.006, 24, 2));
            }
            parts.Add(Tube("BB_HourglassLight", RING, Hourglass(96, .117, .262, .43), .005, front + .010, 6));
            // Two short curved caps complete the reference speaker's turquoise/blue lighting.
            foreach (int side in new[] { -1, 1 })
            {
                parts.Add(RoundBox("BB_LightCap", STRIP, .115, .009, .009, .004, .002, 0, side * (H / 2 - .017), front + .003, 1, 2));
                parts.Add(RoundBox("BB_SideGrip", RUBBER, .013, .38, .18, .006, .005, side * (W / 2 + .003), 0, -.018, 0, 3));
            }
            parts.Add(RoundBox("BB_TopControls", RUBBER, .205, .012, .145, .038, .005, 0, H / 2 + .003, -.012, 0, 3));
            for (int i = 0; i < 4; i++) parts.Add(RoundBox("BB_ControlButton", RIM, .022, .005, .024, .009, .002, -.06 + i * .04, H / 2 + .010, -.006, 0, 2));
            parts.Add(RoundBox("BB_Base", RUBBER, W - .012, .018, D - .012, .06, .006, 0, -H / 2, 0, 0, 3));
            // Static fabric ridges; no animated cones or extra renderer components.
            for (int i = -9; i <= 9; i++) parts.Add(RoundBox("BB_GrilleRib", GRILLE, .20, .0015, .002, .0007, .0005, 0, i * .024, front + .006, 1, 1));
            parts.Add(RoundBox("BB_Badge", RUBBER, .105, .060, .006, .007, .002, 0, 0, front + .013, 1, 2));
            string[][] letters = {
                new[] {"..111", "...1.", "...1.", "...1.", "1..1.", "1..1.", ".11.."},
                new[] {"1111.", "1...1", "1...1", "1111.", "1...1", "1...1", "1111."},
                new[] {"1....", "1....", "1....", "1....", "1....", "1....", "11111"}
            };
            double cell = .005;
            for (int letter = 0; letter < 3; letter++)
                for (int y = 0; y < 7; y++) for (int x = 0; x < 5; x++)
                    if (letters[letter][y][x] == '1')
                        parts.Add(RoundBox("BB_JBL", LABEL, cell * .95, cell * .95, .002, .0004, .0003, (letter * 6 + x - 8) * cell, (3 - y) * cell, front + .017, 1, 1));
            foreach (var part in parts)
                for (int i = 0; i < part.t.Count; i += 3) { int index = part.t[i + 1]; part.t[i + 1] = part.t[i + 2]; part.t[i + 2] = index; }
            return parts;
        }
    }
}
