using System;
using Mirror;

namespace Boombox
{
    // kind: 1 = audio chunk (host->all), 2 = state (host->all), 3 = toggle request (client->host), 4 = spawn request (client->host)
    public struct BBMsg : NetworkMessage
    {
        public byte kind; public uint netId; public uint seq; public int rate; public byte channels; public string text; public byte[] data;
    }

    public static class BBNet
    {
        static bool _init;
        public static void InitSerializers()
        {
            if (_init) return; _init = true;
            Writer<BBMsg>.write = (w, m) =>
            {
                w.WriteByte(m.kind); w.WriteUInt(m.netId); w.WriteUInt(m.seq); w.WriteInt(m.rate); w.WriteByte(m.channels);
                w.WriteString(m.text ?? ""); w.WriteBytesAndSize(m.data);
            };
            Reader<BBMsg>.read = r => new BBMsg
            {
                kind = r.ReadByte(), netId = r.ReadUInt(), seq = r.ReadUInt(), rate = r.ReadInt(), channels = r.ReadByte(),
                text = r.ReadString(), data = r.ReadBytesAndSize()
            };
        }
    }

    // IMA ADPCM, 4 bits/sample, per-channel planar blocks: [int16 pred][byte idx] + nibbles
    public static class Adpcm
    {
        static readonly int[] Idx = { -1, -1, -1, -1, 2, 4, 6, 8, -1, -1, -1, -1, 2, 4, 6, 8 };
        static readonly int[] Step = {
            7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 19, 21, 23, 25, 28, 31, 34, 37, 41, 45, 50, 55, 60, 66, 73, 80, 88, 97, 107, 118, 130, 143,
            157, 173, 190, 209, 230, 253, 279, 307, 337, 371, 408, 449, 494, 544, 598, 658, 724, 796, 876, 963, 1060, 1166, 1282, 1411, 1552,
            1707, 1878, 2066, 2272, 2499, 2749, 3024, 3327, 3660, 4026, 4428, 4871, 5358, 5894, 6484, 7132, 7845, 8630, 9493, 10442, 11487,
            12635, 13899, 15289, 16818, 18500, 20350, 22385, 24623, 27086, 29794, 32767 };

        public struct State { public int pred, idx; }

        // pcm: interleaved int16, frames x ch
        public static byte[] Encode(short[] pcm, int frames, int ch, State[] st)
        {
            int per = 3 + (frames + 1) / 2;
            var o = new byte[per * ch];
            for (int c = 0; c < ch; c++)
            {
                int b = c * per; int pred = st[c].pred, idx = st[c].idx;
                o[b] = (byte)pred; o[b + 1] = (byte)(pred >> 8); o[b + 2] = (byte)idx;
                for (int f = 0; f < frames; f++)
                {
                    int s = pcm[f * ch + c]; int step = Step[idx]; int diff = s - pred; int code = 0;
                    if (diff < 0) { code = 8; diff = -diff; }
                    int dq = step >> 3;
                    if (diff >= step) { code |= 4; diff -= step; dq += step; } step >>= 1;
                    if (diff >= step) { code |= 2; diff -= step; dq += step; } step >>= 1;
                    if (diff >= step) { code |= 1; dq += step; }
                    pred += (code & 8) != 0 ? -dq : dq; if (pred > 32767) pred = 32767; else if (pred < -32768) pred = -32768;
                    idx += Idx[code]; if (idx < 0) idx = 0; else if (idx > 88) idx = 88;
                    int p = b + 3 + (f >> 1);
                    if ((f & 1) == 0) o[p] = (byte)code; else o[p] |= (byte)(code << 4);
                }
                st[c].pred = pred; st[c].idx = idx;
            }
            return o;
        }

        // returns interleaved floats (frames x ch)
        public static float[] Decode(byte[] d, int ch)
        {
            if (d == null || ch < 1) return null;
            int per = d.Length / ch; int frames = (per - 3) * 2; if (frames <= 0) return null;
            var o = new float[frames * ch];
            for (int c = 0; c < ch; c++)
            {
                int b = c * per; int pred = (short)(d[b] | d[b + 1] << 8); int idx = Math.Min(88, (int)d[b + 2]);
                for (int f = 0; f < frames; f++)
                {
                    int code = (d[b + 3 + (f >> 1)] >> ((f & 1) * 4)) & 15; int step = Step[idx];
                    int dq = step >> 3; if ((code & 4) != 0) dq += step; if ((code & 2) != 0) dq += step >> 1; if ((code & 1) != 0) dq += step >> 2;
                    pred += (code & 8) != 0 ? -dq : dq; if (pred > 32767) pred = 32767; else if (pred < -32768) pred = -32768;
                    idx += Idx[code]; if (idx < 0) idx = 0; else if (idx > 88) idx = 88;
                    o[f * ch + c] = pred / 32768f;
                }
            }
            return o;
        }
    }
}
