using System;
using System.Collections.Concurrent;
using System.Threading;

namespace Boombox
{
    // Bounded audio queue. The callback never waits for the main thread or calls Unity.
    public sealed class AudioPackets
    {
        sealed class Packet { public float[] data; public int channels, rate, epoch; }
        readonly ConcurrentQueue<Packet> _queue = new ConcurrentQueue<Packet>();
        const int Capacity = 48;
        int _queued, _epoch, _seenEpoch;
        Packet _current;
        double _position;
        bool _primed;
        public int Queued => Math.Max(0, Volatile.Read(ref _queued));
        public int JitterPackets = 6;
        public float Volume = 1f;
        public void Push(float[] data, int channels, int rate)
        {
            if (data == null || (channels != 1 && channels != 2) || rate < 8000 || rate > 48000 || data.Length == 0 || data.Length % channels != 0 || data.Length > 16384) return;
            _queue.Enqueue(new Packet { data = data, channels = channels, rate = rate, epoch = Volatile.Read(ref _epoch) }); Interlocked.Increment(ref _queued);
            for (int i = 0; i < Capacity && Queued > Capacity; i++)
                if (_queue.TryDequeue(out _)) Interlocked.Decrement(ref _queued); else break;
        }
        public void Reset()
        {
            Interlocked.Increment(ref _epoch);
            for (int i = 0; i <= Capacity && _queue.TryDequeue(out _); i++) Interlocked.Decrement(ref _queued);
        }
        bool Next(int epoch)
        {
            for (int i = 0; i <= Capacity; i++)
            {
                if (!_queue.TryDequeue(out var p)) { _current = null; return false; }
                Interlocked.Decrement(ref _queued);
                if (p.epoch == epoch) { _current = p; return true; }
            }
            _current = null; return false;
        }
        public void Read(float[] output, int outputRate)
        {
            Array.Clear(output, 0, output.Length);
            if (outputRate < 8000 || outputRate > 192000) return;
            int epoch = Volatile.Read(ref _epoch);
            if (_seenEpoch != epoch) { _seenEpoch = epoch; _current = null; _position = 0; _primed = false; }
            if (!_primed)
            {
                if (Queued < Math.Max(1, Math.Min(32, JitterPackets))) return;
                _primed = true;
            }
            float volume = Math.Max(0f, Math.Min(3f, Volume));
            for (int frame = 0; frame < output.Length / 2; frame++)
            {
                if (_current == null && !Next(epoch)) { _primed = false; _position = 0; break; }
                int frames = _current.data.Length / _current.channels;
                if (_position >= frames)
                {
                    _position -= frames;
                    if (!Next(epoch)) { _primed = false; _position = 0; break; }
                    frames = _current.data.Length / _current.channels;
                    if (_position >= frames) _position = 0;
                }
                int a = (int)_position, b = Math.Min(a + 1, frames - 1), ch = _current.channels;
                float fraction = (float)(_position - a);
                float left = _current.data[a * ch] + (_current.data[b * ch] - _current.data[a * ch]) * fraction;
                float right = ch == 2 ? _current.data[a * ch + 1] + (_current.data[b * ch + 1] - _current.data[a * ch + 1]) * fraction : left;
                output[frame * 2] = Safe(left * volume); output[frame * 2 + 1] = Safe(right * volume);
                _position += (double)_current.rate / outputRate;
            }
        }
        static float Safe(float sample) => float.IsNaN(sample) || float.IsInfinity(sample) ? 0 : Math.Max(-1f, Math.Min(1f, sample));
    }
}
