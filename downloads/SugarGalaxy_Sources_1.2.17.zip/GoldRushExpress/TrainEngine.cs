using System;
using System.Collections.Generic;
using System.Linq;

namespace GoldRushExpress
{
    /// Money Train 2 style rules (Gold Rush Express design): base 5x4 / 40 lines, 2-scatter respin feature,
    /// MONEY WAGON hold-and-respin bonus 5x4 -> 7x4 with specials. Pure logic shared by the plugin (host) and the simulator.
    public static class TrainEngine
    {
        public const int Rows = 4, Cols = 5, Cells = 20, BCols = 7, BCells = 28;
        public const int J = 0, Q = 1, K = 2, A = 3, HAT = 4, GUN = 5, BAG = 6, SCAT = 7, GOLD = 8, NLINE = 7;
        // bonus symbol types
        public const int COIN = 0, GCOIN = 1, BANKER = 2, MARSHAL = 3, TYCOON = 4, OUTLAW = 5, SPIRIT = 6, IBANKER = 7, IMARSHAL = 8, IOUTLAW = 9;
        public static readonly string[] Names = { "J", "Q", "K", "A", "Hat", "Revolver", "Money Bag" };
        public static readonly string[] ArtKeys = { "J", "Q", "K", "A", "hat", "revolver", "moneybag" };
        public static readonly string[] BNames = { "COIN", "GOLD COIN", "BANKER", "MARSHAL", "TYCOON", "OUTLAW", "SPIRIT", "IRON BANKER", "IRON MARSHAL", "IRON OUTLAW" };
        public static bool IsIron(int t) => t >= IBANKER;
        public static bool IsSpecial(int t) => t >= BANKER;
        public static double MaxWinX = 50000, FullBoardBonus = 500;
        /// x TOTAL bet for 3/4/5 on a line (design table)
        public static readonly double[,] Pay = { { .2, .6, 2 }, { .2, .6, 2 }, { .3, 1, 3 }, { .3, 1, 3 }, { .6, 2, 7.5 }, { .8, 2.5, 10 }, { 1, 4, 20 } };
        public static readonly int[][] Lines = MakeLines();
        static int[][] MakeLines()
        {
            // own 40-line set: every path with steps of at most one row, fewest direction changes first (straight rows, then waves)
            var all = new List<int[]>();
            void Rec(int[] p, int c) { if (c == 5) { all.Add((int[])p.Clone()); return; } for (int r = 0; r < Rows; r++) { if (c > 0 && Math.Abs(r - p[c - 1]) > 1) continue; p[c] = r; Rec(p, c + 1); } }
            Rec(new int[5], 0);
            int Score(int[] p) { int ch = 0; for (int c = 1; c < 5; c++) if (p[c] != p[c - 1]) ch++; bool sym = p[0] == p[4] && p[1] == p[3]; return ch * 10 + (sym ? 0 : 5); }
            return all.OrderBy(Score).ThenBy(p => string.Join("", p.Select(x => Math.Abs(x - 1.5)))).ThenBy(p => string.Join("", p)).Take(40).ToArray();
        }
        // ---- tunables ----
        public static double[] SymW = { 30, 30, 24, 24, 14, 10, 7 };
        public static double ScatChance = 0.069;     // per reel (max 1 bonus loco per reel)
        public static double GoldShare = 0.006;      // share of locos that are golden (persistent)
        public static double[] RespinVals = { 0.2, 0.4, 0.6, 1, 2 }; public static double[] RespinValW = { 34, 30, 19, 12, 5 };
        public static int RespinMax = 40;
        public static int[] CoinVals = { 1, 2, 3, 4, 5, 6, 8, 10 }; public static double[] CoinW = { 22, 20, 16, 12, 10, 8, 6, 5 };
        public static int[] GoldVals = { 20, 25, 50, 100, 200 }; public static double[] GoldW = { 40, 28, 18, 9, 5 };
        /// landing weights in the bonus: coin, gold coin, banker, marshal, tycoon, outlaw, spirit, iron banker, iron marshal, iron outlaw
        public static double[] BonusW = { 1000, 18, 22, 22, 1.15, 14, 4, 0.15, 0.15, 0.003 };
        /// trigger locos (non golden): coin, gold, banker, marshal, tycoon, outlaw, spirit (no iron)
        public static double[] TrigW = { 1000, 15, 40, 40, 10, 30, 0, 0, 0, 0 };
        public static double[] GoldTrigW = { 0, 0, 0, 0, 0, 0, 0, 1, 1, 0 };   // golden loco carries a persistent special (iron banker / iron marshal)
        public static double LandChance = 0.045;    // per empty unlocked cell per respin
        public const int BuyCostX = 100, StartRespins = 3;

        [Serializable] public class Lw { public int l; public int s; public int n; public float w; }
        [Serializable] public class Rsp { public int[] g; public Lw[] lines; public float lw; public int mult; public float pay; }
        [Serializable] public class Spin
        {
            public int[] g;          // 5x4 grid (cell = col*4+row)
            public int[] it;         // bonus item type on loco cells (-1 = none)
            public float[] iv;       // value on loco cells
            public Lw[] lines; public float lw; public int sc;
            public Rsp[] rs;         // 2-scatter respin feature steps (null if none)
            public float rsum;       // respin feature: sum of the 2 loco values
            public float win;        // total spin win (lines + feature) before the round cap
        }
        [Serializable] public class Ev { public int k; public int s; public int by = -1; public int[] tg; public float[] after; }
        [Serializable] public class BStep
        {
            public int[] bt;         // board types after landing (-1 empty), 28 cells
            public float[] bv;       // values after landing, before actions
            public int[] nw;         // newly landed cells this step
            public Ev[] ev;          // actions in order
            public int cols0, cols;  // unlocked columns before/after this step
            public int left;         // respins left after this step
            public float tot;        // board total after actions (x bet)
            public int full;         // 1 = full 7x4 board (+500x)
        }
        public class Round { public Spin baseSpin; public List<BStep> bonus = new List<BStep>(); public double bonusWin; public double total; public bool capped; public bool bought; }

        static int Pick(Random r, double[] w) { double s = 0; foreach (var x in w) s += x; double v = r.NextDouble() * s; for (int i = 0; i < w.Length; i++) { v -= w[i]; if (v < 0) return i; } return w.Length - 1; }
        public static int Idx(int c, int row) => c * Rows + row;
        public static double ItemValue(Random r, int t) => t == GCOIN ? GoldVals[Pick(r, GoldW)] : CoinVals[Pick(r, CoinW)];

        static List<Lw> EvalLines(int[] g)
        {
            var lws = new List<Lw>();
            for (int l = 0; l < Lines.Length; l++)
            {
                int sym = g[Idx(0, Lines[l][0])]; if (sym >= NLINE) continue;
                int n = 1; while (n < Cols && g[Idx(n, Lines[l][n])] == sym) n++;
                if (n >= 3) lws.Add(new Lw { l = l, s = sym, n = n, w = (float)Pay[sym, n - 3] });
            }
            return lws;
        }

        public static Spin PlaySpin(Random r, int forceScatters = 0, int forceGold = 0)
        {
            var g = new int[Cells]; var it = new int[Cells]; var iv = new float[Cells];
            for (int i = 0; i < Cells; i++) { g[i] = Pick(r, SymW); it[i] = -1; }
            var have = new bool[Cols]; int n = 0;
            for (int c = 0; c < Cols; c++) if (r.NextDouble() < ScatChance) { have[c] = true; n++; }
            for (int guard = 0; n < forceScatters && guard < 100; guard++) { int c = r.Next(Cols); if (!have[c]) { have[c] = true; n++; } }
            for (int c = 0; c < Cols; c++) if (have[c]) g[Idx(c, r.Next(Rows))] = r.NextDouble() < GoldShare ? GOLD : SCAT;
            if (forceGold > 0) { int ng = 0; for (int i = 0; i < Cells; i++) if (g[i] == GOLD) ng++; for (int i = 0; i < Cells && ng < forceGold; i++) if (g[i] == SCAT) { g[i] = GOLD; ng++; } }
            var s = new Spin { g = g, it = it, iv = iv };
            var lws = EvalLines(g); s.lines = lws.ToArray(); foreach (var x in lws) s.lw += x.w;
            for (int i = 0; i < Cells; i++) if (g[i] == SCAT || g[i] == GOLD) s.sc++;
            if (s.sc >= 3)
            {
                for (int i = 0; i < Cells; i++) if (g[i] == SCAT || g[i] == GOLD)
                { int t = Pick(r, g[i] == GOLD ? GoldTrigW : TrigW); it[i] = t; iv[i] = (float)ItemValue(r, t); }
            }
            else if (s.sc == 2)
            {
                for (int i = 0; i < Cells; i++) if (g[i] == SCAT || g[i] == GOLD) { it[i] = COIN; iv[i] = (float)RespinVals[Pick(r, RespinValW)]; s.rsum += iv[i]; }
                var rs = new List<Rsp>();
                if (s.lw > 0) rs.Add(new Rsp { g = (int[])g.Clone(), lines = s.lines, lw = 0, mult = 1, pay = s.rsum });   // already a win: pays x1 at once
                else
                {
                    int mult = 1;
                    for (int k = 0; k < RespinMax; k++)
                    {
                        var ng = (int[])g.Clone();
                        for (int i = 0; i < Cells; i++) if (ng[i] != SCAT && ng[i] != GOLD) ng[i] = Pick(r, SymW);
                        var l2 = EvalLines(ng); float w2 = 0; foreach (var x in l2) w2 += x.w;
                        var st = new Rsp { g = ng, lines = l2.ToArray(), lw = w2, mult = mult };
                        if (w2 > 0 || k == RespinMax - 1) { st.pay = w2 + s.rsum * mult; rs.Add(st); break; }
                        rs.Add(st); mult++;
                    }
                }
                s.rs = rs.ToArray();
            }
            s.win = s.lw; if (s.rs != null) foreach (var x in s.rs) s.win += x.pay;
            return s;
        }

        public static Round Play(Random r, bool forceBonus = false) => PlayInner(r, forceBonus ? 3 : 0, false);
        public static Round PlayBuy(Random r) => PlayBuyVariant(r, 0);

        // ---- bonus buy variants (exact trigger) ----
        public static readonly string[] BuyNames = { "MONEY WAGON", "SUPER WAGON", "MEGA WAGON", "GOLDEN WAGON" };
        public static readonly string[] BuyDesc = { "3 bonus locos start the wagon", "4 bonus locos - more coins & specials", "5 bonus locos - fullest start", "3 locos incl. a GOLDEN one: persistent IRON special" };
        public static readonly int[] BuyLocos = { 3, 4, 5, 3 }, BuyGold = { 0, 0, 0, 1 };
        /// price in x total bet; tuned by 3M-round sim per variant so every variant returns ~96.4-96.5 %
        public static double[] BuyCost = { 80, 84.6, 95.6, 1082 };
        public static int Variants => BuyNames.Length;
        public static Round PlayBuyVariant(Random r, int v)
        {
            v = Math.Max(0, Math.Min(Variants - 1, v));
            int k = BuyLocos[v], gold = BuyGold[v];
            Spin b = null;
            for (int guard = 0; guard < 500; guard++)
            {
                b = PlaySpin(r, k, gold);
                int ng = 0; for (int i = 0; i < Cells; i++) if (b.g[i] == GOLD) ng++;
                if (b.sc == k && ng == gold) break;
            }
            var rd = new Round { bought = true, baseSpin = b };
            double run = Math.Min(b.win, MaxWinX);
            if (b.sc >= 3 && run < MaxWinX) rd.bonusWin = PlayBonus(r, b, rd.bonus, MaxWinX - run);
            double t = b.win + rd.bonusWin; if (t >= MaxWinX) { t = MaxWinX; rd.capped = true; }
            rd.total = t; return rd;
        }

        static Round PlayInner(Random r, int force, bool buy)
        {
            var rd = new Round { bought = buy };
            Spin b;
            if (buy) { b = PlaySpin(r, 3); int guard = 0; while (b.sc < 3 && guard++ < 50) b = PlaySpin(r, 3); }
            else b = PlaySpin(r, force);
            rd.baseSpin = b;
            double run = Math.Min(b.win, MaxWinX);
            if (b.sc >= 3 && run < MaxWinX) { rd.bonusWin = PlayBonus(r, b, rd.bonus, MaxWinX - run); }
            double t = b.win + rd.bonusWin;
            if (t >= MaxWinX) { t = MaxWinX; rd.capped = true; }
            rd.total = t; return rd;
        }

        // ---------------- MONEY WAGON ----------------
        static double Sum(int[] bt, double[] bv, int skip = -1) { double s = 0; for (int i = 0; i < BCells; i++) if (bt[i] >= 0 && i != skip) s += bv[i]; return s; }
        static void Act(Random r, int t, int src, int[] bt, double[] bv, List<Ev> evs, int by, HashSet<int> fired)
        {
            var tg = new List<int>();
            switch (t)
            {
                case BANKER: case IBANKER:
                    for (int i = 0; i < BCells; i++) if (bt[i] >= 0 && i != src) { bv[i] += bv[src]; tg.Add(i); }
                    break;
                case MARSHAL: case IMARSHAL:
                    for (int i = 0; i < BCells; i++) if (bt[i] >= 0 && i != src) tg.Add(i);
                    bv[src] += Sum(bt, bv, src); break;
                case TYCOON:
                    for (int i = 0; i < BCells; i++) if (bt[i] >= 0 && i != src) tg.Add(i);
                    bv[src] += Sum(bt, bv, src); foreach (var i in tg) bv[i] += bv[src]; break;
                case OUTLAW: case IOUTLAW:
                    {
                        var others = Enumerable.Range(0, BCells).Where(i => bt[i] >= 0 && i != src).ToList();
                        if (others.Count == 0) break;
                        int shots = 3 + r.Next(6);
                        for (int k = 0; k < shots; k++) { int i = others[r.Next(others.Count)]; bv[i] *= 2; tg.Add(i); }
                        break;
                    }
            }
            if (t != SPIRIT && t != COIN && t != GCOIN) { evs.Add(new Ev { k = t, s = src, by = by, tg = tg.ToArray(), after = bv.Select(x => (float)x).ToArray() }); if (!IsIron(t)) fired.Add(src); }
        }
        /// order: new specials left->right (column by column, top->bottom), then persistent (iron) ones, then SPIRITs that landed
        static void Resolve(Random r, int[] bt, double[] bv, List<int> nw, List<Ev> evs, HashSet<int> fired)
        {
            var newOrd = nw.OrderBy(i => i).ToList();
            foreach (var i in newOrd) if (IsSpecial(bt[i]) && bt[i] != SPIRIT) Act(r, bt[i], i, bt, bv, evs, -1, fired);
            for (int i = 0; i < BCells; i++) if (bt[i] >= 0 && IsIron(bt[i]) && !nw.Contains(i)) Act(r, bt[i], i, bt, bv, evs, -1, fired);
            foreach (var sp in newOrd.Where(i => bt[i] == SPIRIT))
            {
                var pool = fired.Where(i => bt[i] >= BANKER && bt[i] <= OUTLAW).OrderBy(i => i).ToList();
                if (pool.Count == 0) { evs.Add(new Ev { k = SPIRIT, s = sp, tg = new int[0], after = bv.Select(x => (float)x).ToArray() }); continue; }
                int k = Math.Min(pool.Count, 2 + r.Next(6));
                var pick = pool.OrderBy(_ => r.Next()).Take(k).OrderBy(i => i).ToList();
                evs.Add(new Ev { k = SPIRIT, s = sp, tg = pick.ToArray(), after = bv.Select(x => (float)x).ToArray() });
                foreach (var i in pick) Act(r, bt[i], i, bt, bv, evs, sp, fired);
            }
        }
        static bool Unlocked(int cell, int cols) => cell / Rows < cols;

        static double PlayBonus(Random r, Spin b, List<BStep> steps, double room)
        {
            var bt = Enumerable.Repeat(-1, BCells).ToArray(); var bv = new double[BCells]; int cols = Cols;
            var fired = new HashSet<int>(); var opened = new HashSet<int>();
            var nw = new List<int>();
            for (int i = 0; i < Cells; i++) if (b.it[i] >= 0) { bt[i] = b.it[i]; bv[i] = b.iv[i]; nw.Add(i); }
            int left = StartRespins; bool full = false;
            for (int round = 0; round < 400; round++)
            {
                var st = new BStep { bt = (int[])bt.Clone(), bv = bv.Select(x => (float)x).ToArray(), nw = nw.ToArray(), cols0 = cols };
                var evs = new List<Ev>(); Resolve(r, bt, bv, nw, evs, fired); st.ev = evs.ToArray();
                // column unlock: a completely filled column opens the next locked one (max 2)
                for (int c = 0; c < cols && cols < BCols; c++)
                {
                    if (opened.Contains(c)) continue;
                    bool colFull = true; for (int row = 0; row < Rows; row++) if (bt[Idx(c, row)] < 0) colFull = false;
                    if (colFull) { opened.Add(c); cols++; }
                }
                if (round > 0) left = nw.Count > 0 ? StartRespins : left - 1;
                full = cols == BCols && bt.All(x => x >= 0);
                st.cols = cols; st.left = full ? 0 : left; st.full = full ? 1 : 0;
                st.tot = (float)(Sum(bt, bv) + (full ? FullBoardBonus : 0));
                steps.Add(st);
                if (full || left <= 0 || st.tot >= room) break;
                // next respin: every empty unlocked cell may land a symbol
                nw = new List<int>();
                for (int i = 0; i < BCells; i++)
                    if (bt[i] < 0 && Unlocked(i, cols) && r.NextDouble() < LandChance)
                    { int t = Pick(r, BonusW); bt[i] = t; bv[i] = ItemValue(r, t); nw.Add(i); }
            }
            return Math.Min(room, Sum(bt, bv) + (full ? FullBoardBonus : 0));
        }
    }
}
