using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using FMODUnity;
using Mirror;
using Mirror.RemoteCalls;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace SugarGalaxy
{
    [Serializable]
    public class SgMsg
    {
        public string t;          // spin | intro | end | turbo | ante | bet
        public SugarEngine.Step[] steps;
        public int bs;            // bomb sum on this spin (applied only if tumble win > 0)
        public int sc;            // scatter count
        public float sp;          // scatter pay (x bet)
        public float tw;          // tumble win before multipliers (x bet)
        public float w;           // final spin win (x bet)
        public float tot;         // running total (x bet)
        public int fsi, fsn;      // free spin index (1-based) / awarded total (0 = base game)
        public int tm;            // FS total multiplier after this spin
        public int rt;            // 1 = retrigger on this spin
        public int tb, an, by;    // turbo, ante, bought
        public string bet;        // formatted base bet
        public double bn;         // base bet as double (for client money labels)
    }

    public partial class SugarGalaxyGame : GameBase
    {
        const string RpcSig = "System.Void SugarGalaxy.SugarGalaxyGame::UserRpcShowSpinSG(System.String)";
        public bool turbo, ante;
        public InteractableEventTrigger turboButton, buyButton, anteButton, betMinusButton, betPlusButton;
        int _spinCount;
        BigNumber _charged = BigNumber.Zero; bool _roundActive; float _lastProgress;
        readonly List<RenderTexture> _ownRts = new List<RenderTexture>();
        public static bool ForceBonusNext;

        public TextMeshPro payoutText;
        public List<Image> symbolLocations = new List<Image>();
        public List<SlotReel> reels = new List<SlotReel>();
        public EventReference spinReelSFX, spinDoneSFX, multiplierSFX, finaltextSFX;
        public List<InteractableEventTrigger> playButtons = new List<InteractableEventTrigger>();

        static bool _rpcRegistered;
        public static void RegisterRpcs()
        {
            if (_rpcRegistered) return; _rpcRegistered = true;
            GwyfShared.RpcGuard.Register(typeof(SugarGalaxyGame), RpcSig, (obj, reader, conn) =>
            {
                if (!NetworkClient.active) return;
                ((SugarGalaxyGame)obj).UserRpcShowSpin(reader.ReadString());
            });
        }
        public override bool Weaved() => true;

        public void CopyFromSlots(Slots s)
        {
            T Get<T>(string n) => (T)HarmonyLib.AccessTools.Field(typeof(Slots), n).GetValue(s);
            try { payoutText = Get<TextMeshPro>("payoutText"); } catch { }
            try { symbolLocations = Get<List<Image>>("symbolLocations"); } catch { }
            try { reels = Get<List<SlotReel>>("reels"); } catch { }
            try { spinReelSFX = Get<EventReference>("spinReelSFX"); spinDoneSFX = Get<EventReference>("spinDoneSFX");
                  multiplierSFX = Get<EventReference>("multiplierSFX"); finaltextSFX = Get<EventReference>("finaltextSFX"); } catch { }
            gameName = "Sugar Bonanza";
        }
        public void SetDefaults() { gameName = "Sugar Bonanza"; }

        protected override void OnAwake()
        {
            base.OnAwake();
            // own screen render texture per machine (vanilla slots share one asset)
            try { var pb = playButtons != null && playButtons.Count > 0 && playButtons[0] != null ? playButtons[0].transform : null; var r = GwyfShared.CabinetScaler.Apply(transform, SugarGalaxyPlugin.CabinetScale.Value, pb, "SG"); if (r != null) SugarGalaxyPlugin.Log.LogInfo("[SG] " + r); } catch (Exception e) { SugarGalaxyPlugin.Log.LogError("[SG] cabinet scale: " + e.Message); }
            // ScreenIso removed: the slot screen is a direct world-space canvas (no camera/RT); the camera it found was the keypad camera.
        }

        // ---------------- art ----------------
        static readonly Dictionary<string, Sprite> _sprites = new Dictionary<string, Sprite>();
        public static Texture2D LoadPng(string key)
        {
            using (var st = typeof(SugarGalaxyGame).Assembly.GetManifestResourceStream("SugarGalaxy.art." + key + ".png"))
            {
                if (st == null) { SugarGalaxyPlugin.Log.LogError("[SG] Missing embedded art: " + key); return null; }
                var ms = new System.IO.MemoryStream(); st.CopyTo(ms);
                var tex = new Texture2D(2, 2, TextureFormat.RGBA32, true);
                ImageConversion.LoadImage(tex, ms.ToArray());
                tex.name = "SG_" + key; GwyfShared.ReelFx.ConfigureTexture(tex);
                return tex;
            }
        }
        public static Sprite Spr(string key)
        {
            if (_sprites.TryGetValue(key, out var sp)) return sp;
            try { sp = FreshSpriteKey(key); if (sp != null) { _sprites[key] = sp; return sp; } var tex = LoadPng(key); sp = tex != null ? Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), new Vector2(.5f, .5f), 100f) : null; }
            catch (Exception e) { SugarGalaxyPlugin.Log.LogError("[SG] Sprite load failed " + key + ": " + e.Message); sp = null; }
            _sprites[key] = sp; return sp;
        }
        static readonly Dictionary<Sprite, Sprite> _blurOf = new Dictionary<Sprite, Sprite>();
        /// pre-blurred twin of a symbol sprite (art key "blur_<name>"), null when missing
        public static Sprite BlurOf(Sprite s)
        {
            if (s == null) return null; if (_blurOf.TryGetValue(s, out var b)) return b;
            string n = s.texture != null ? s.texture.name : ""; int k = n.IndexOf("sym_"); b = null;
            if (k >= 0) { string key = "blur_" + n.Substring(k + 4); if (typeof(SugarGalaxyGame).Assembly.GetManifestResourceInfo("SugarGalaxy.art." + key + ".png") != null) b = Spr(key); }
            _blurOf[s] = b; return b;
        }
        public static Sprite SymSprite(int sym, int bomb)
        {
            if (sym == SugarEngine.SCATTER) return Spr("sym_scatter");
            if (sym == SugarEngine.BOMB) return Spr("sym_bomb_x" + (bomb > 0 ? bomb : 2));
            return Spr("sym_" + SugarEngine.ArtKeys[Mathf.Clamp(sym, 0, 8)]);
        }

        // ---------------- server ----------------
        static void Hook(InteractableEventTrigger b, UnityEngine.Events.UnityAction<PlayerInteract> a)
        {
            if (b == null) return;
            if (b.serverOnInteractEvent == null) b.serverOnInteractEvent = new UnityEngine.Events.UnityEvent<PlayerInteract>();
            b.serverOnInteractEvent.AddListener(a);
        }
        public override void OnStartServer()
        {
            base.OnStartServer();
            foreach (var b in playButtons) Hook(b, TryStartGame);
            Hook(buyButton, TryBuyBonus); Hook(turboButton, ToggleTurbo); Hook(anteButton, ToggleAnte);
            Hook(betMinusButton, p => StepBet(-1)); Hook(betPlusButton, p => StepBet(+1));
            HookScreenButtons();
            SugarGalaxyPlugin.V($"OnStartServer: {playButtons.Count} play button(s), buy={(buyButton != null)} ante={(anteButton != null)} bet+-={(betPlusButton != null)} keypad={(keypad != null)}");
        }

        bool AnteActive => ante && !isGoldenChipApplied;

        [Server]
        public override void TryStartGame(PlayerInteract pi)
        {
            if (!NetworkServer.active || pi == null) return;
            if (!CanGameStart() || isPlaying) return;
            if (pi.TryGetComponent<PlayerProfile>(out var prof)) interactingPlayer = prof;
            if (interactingPlayer == null) return;
            if (!isGoldenChipApplied)
            {
                BigNumber cost = AnteActive ? currentBet * SugarEngine.AnteCost : currentBet;
                if (currentBet < MinBet || currentBet > MaxBet || !Extensions.NetworkSingleton<MoneyManager>.Instance.TryChangeBalance(-cost, interactingPlayer, ChangeType.Bet))
                { try { keypad.ServerInvalidBetAmountFb(); } catch { } return; }
                _charged = cost;
            }
            else { isGoldenBet = true; _charged = BigNumber.Zero; }
            isPlaying = true; canBet = false;
            StartGame();
        }

        [Server]
        protected override void StartGame()
        {
            if (!NetworkServer.active) return;
            SugarGalaxyPlugin.V("StartGame by " + (interactingPlayer != null ? interactingPlayer.name : "?") + (AnteActive ? " (ante)" : ""));
            StartCoroutine(RoundRoutine(false));
        }

        int _roundGen; // bumped by refund/watchdog: a late-resuming round coroutine must never pay after a refund
        IEnumerator RoundRoutine(bool buy)
        {
            SugarEngine.Round round = null; int gen = ++_roundGen;
            _roundActive = true; _lastProgress = Time.time;
            _spinCount++;
            int everyN = SugarGalaxyPlugin.ForceBonusEveryNSpins?.Value ?? 0;
            bool force = !buy && (ForceBonusNext || (SugarGalaxyPlugin.AlwaysBonusNextSpin?.Value ?? false) || (everyN > 0 && _spinCount % everyN == 0));
            if (!buy) ForceBonusNext = false;
            bool an = !buy && AnteActive;
            try { round = buy ? SugarEngine.PlayBuy(GetSeededRandom(5353)) : SugarEngine.Play(GetSeededRandom(5252), an, force); }
            catch (Exception e) { SugarGalaxyPlugin.Log.LogError(e); }
            bool byAuto = _autoRound; _autoRound = false;
            if (round == null) { Refund("engine error"); SafeReset(); ContinueAuto(false, byAuto); yield break; }
            SugarGalaxyPlugin.V($"Round: bet={currentBet} buy={buy} ante={an} base={round.baseSpin.win:0.##}x tumbles={round.baseSpin.steps.Count} sc={round.baseSpin.scatters} FS={round.fsAwarded} total={round.total:0.##}x");
            string betS = FormatBet(currentBet); double bnum = currentBet.ToDouble();
            bool tb = turbo;
            double running = Math.Min(round.baseSpin.win, SugarEngine.MaxWinX);
            var bm = Make(round.baseSpin, running, 0, 0, tb, an, buy, betS); bm.bn = bnum;
            Broadcast(bm);
            { float wsec = SgTiming.Spin(bm) + 0.1f; _lastProgress = Time.time + wsec; yield return new WaitForSeconds(wsec); } _lastProgress = Time.time; // watchdog never fires inside a long (tumble/bomb) animation
            if (gen != _roundGen) yield break;
            if (round.fsAwarded > 0)
            {
                Broadcast(new SgMsg { t = "intro", fsn = 10, tot = (float)running, tb = tb ? 1 : 0, by = buy ? 1 : 0, bet = betS, bn = bnum });
                { float wsec = SgTiming.Intro(tb) + 0.1f; _lastProgress = Time.time + wsec; yield return new WaitForSeconds(wsec); } _lastProgress = Time.time; // watchdog never fires inside a long (tumble/bomb) animation
                if (gen != _roundGen) yield break;
                int awarded = 10;
                for (int k = 0; k < round.free.Count; k++)
                {
                    tb = turbo;
                    var f = round.free[k];
                    bool rt = f.scatters >= 3; if (rt) awarded += 5;
                    running = Math.Min(running + f.win, SugarEngine.MaxWinX);
                    var fm = Make(f, running, k + 1, awarded, tb, false, buy, betS); fm.tm = f.totalMulti; fm.rt = rt ? 1 : 0; fm.bn = bnum;
                    Broadcast(fm);
                    { float wsec = SgTiming.Spin(fm) + 0.1f; _lastProgress = Time.time + wsec; yield return new WaitForSeconds(wsec); } _lastProgress = Time.time; // watchdog never fires inside a long (tumble/bomb) animation
                    if (gen != _roundGen) yield break;
                }
            }
            try
            {
                if (interactingPlayer != null)
                {
                    if (buy) Payout(round.total / SugarEngine.BuyCostX * EstimatedValue, ChangeType.GameResult, null, currentBet * SugarEngine.BuyCostX);
                    else Payout(round.total * EstimatedValue);
                    SugarGalaxyPlugin.V($"Payout: {round.total:0.##}x * floor {EstimatedValue:0.##}");
                }
                else SugarGalaxyPlugin.Log.LogWarning("[SG] Player left before payout.");
            }
            catch (Exception e) { SugarGalaxyPlugin.Log.LogError("[SG] Payout failed: " + e); }
            _roundActive = false; _charged = BigNumber.Zero;
            Broadcast(new SgMsg { t = "end", tot = (float)round.total, fsn = round.fsAwarded, tb = tb ? 1 : 0, bet = betS, bn = bnum });
            SafeReset();
            ContinueAuto(round.fsAwarded > 0, byAuto);
        }

        static string FormatBet(BigNumber b) { try { return MoneyFormatter.FormatWithDollar(b); } catch { return "$" + b; } }

        [Server]
        public void TryBuyBonus(PlayerInteract pi)
        {
            if (!NetworkServer.active || pi == null) return;
            if (!CanGameStart() || isPlaying) return;
            if (ante) { SugarGalaxyPlugin.Log.LogInfo("[SG] Bonus buy disabled while DOUBLE CHANCE is on"); try { keypad.ServerInvalidBetAmountFb(); } catch { } return; }
            if (pi.TryGetComponent<PlayerProfile>(out var prof)) interactingPlayer = prof;
            if (interactingPlayer == null) return;
            BigNumber cost = currentBet * SugarEngine.BuyCostX;
            if (isGoldenChipApplied || currentBet < MinBet || currentBet > MaxBet || !Extensions.NetworkSingleton<MoneyManager>.Instance.TryChangeBalance(-cost, interactingPlayer, ChangeType.Bet))
            { SugarGalaxyPlugin.Log.LogInfo($"[SG] Bonus buy refused: bet {currentBet}, cost {cost}"); try { keypad.ServerInvalidBetAmountFb(); } catch { } return; }
            _charged = cost;
            SugarGalaxyPlugin.Log.LogInfo($"[SG] Bonus bought by {interactingPlayer.name} for {cost}");
            isPlaying = true; canBet = false;
            StartCoroutine(RoundRoutine(true));
        }

        [Server]
        public void ToggleTurbo(PlayerInteract pi = null)
        {
            if (!NetworkServer.active) return;
            turbo = !turbo; SugarGalaxyPlugin.V("Turbo " + (turbo ? "ON" : "OFF"));
            Broadcast(new SgMsg { t = "turbo", tb = turbo ? 1 : 0, an = ante ? 1 : 0 });
        }

        [Server]
        public void ToggleAnte(PlayerInteract pi = null)
        {
            if (!NetworkServer.active || isPlaying) return;
            ante = !ante; SugarGalaxyPlugin.V("Double chance " + (ante ? "ON" : "OFF"));
            Broadcast(new SgMsg { t = "ante", tb = turbo ? 1 : 0, an = ante ? 1 : 0 });
        }

        static readonly double[] Ladder = { 1, 1.5, 2, 2.5, 3, 4, 5, 6, 8 };
        [Server]
        void StepBet(int dir)
        {
            if (!NetworkServer.active || isPlaying || !canBet || keypad == null || isGoldenChipApplied) return;
            try
            {
                double m = MinBet.ToDouble(), mx = MaxBet.ToDouble(), cur = currentBet.ToDouble();
                if (double.IsInfinity(mx) || mx > 1e15) mx = 1e15;
                var list = new List<double> { m };
                for (double dec = Math.Pow(10, Math.Floor(Math.Log10(Math.Max(1e-9, m)))); dec <= mx; dec *= 10)
                    foreach (var l in Ladder) { double v = l * dec; if (v > m * 1.0001 && v < mx * 0.9999) list.Add(v); }
                list.Add(mx);
                list = list.Select(v => Math.Max(1, Math.Round(v, MidpointRounding.AwayFromZero))).Where(v => v >= Math.Ceiling(m - 1e-9) && v <= mx + 1e-9).Distinct().OrderBy(v => v).ToList();
                if (list.Count == 0) return;
                double pick = cur;
                if (dir > 0) { pick = list.Last(); foreach (var v in list) if (v > cur * 1.0001) { pick = v; break; } }
                else { pick = list[0]; foreach (var v in list) if (v < cur * 0.9999) pick = v; }
                                if (Math.Abs(pick - cur) < 1e-9) return;
                var nb = BigNumber.FromDouble(pick);
                var apply = HarmonyLib.AccessTools.Method(typeof(Keypad), "ApplyInput");
                if (apply != null) apply.Invoke(keypad, new object[] { nb.ToKeypadString(), true });
                else { SugarGalaxyPlugin.V("Keypad.ApplyInput not found - fallback"); keypad.Network_currentInput = nb.ToKeypadString(); ServerSetBet(nb); }
                SugarGalaxyPlugin.V($"Bet {(dir > 0 ? "+" : "-")} -> {nb}");
                Broadcast(new SgMsg { t = "bet", bet = FormatBet(nb), bn = pick, tb = turbo ? 1 : 0, an = ante ? 1 : 0 });
            }
            catch (Exception e) { SugarGalaxyPlugin.Log.LogError("[SG] Bet step failed: " + e); }
        }

        void Refund(string why)
        {
            try
            {
                if (_charged > BigNumber.Zero && interactingPlayer != null)
                { Extensions.NetworkSingleton<MoneyManager>.Instance.TryChangeBalance(_charged, interactingPlayer, ChangeType.Bet); SugarGalaxyPlugin.Log.LogWarning($"[SG] Refunded {_charged} ({why})"); }
            }
            catch (Exception e) { SugarGalaxyPlugin.Log.LogError("[SG] Refund failed: " + e); }
            _charged = BigNumber.Zero; _roundActive = false; _roundGen++;
        }

        // floor change / day end / despawn while a round runs: coroutines die with the object, so refund what was really charged
        protected override void OnDisable()
        {
            try
            {
                if (NetworkServer.active && isPlaying) { Refund("machine disabled mid-round"); SafeReset(); }
                _roundActive = false;
            }
            catch (Exception e) { SugarGalaxyPlugin.Log.LogError("[SG] OnDisable: " + e); }
            try { ClientAbort(); } catch { }
        }

        void OnDestroy()
        {
            StopAllCoroutines();
            try { foreach (var r in GetComponentsInChildren<Renderer>(true)) foreach (var m in r.sharedMaterials) if (m != null && m.name.EndsWith("(Instance)")) Destroy(m); } catch { }
            foreach (var rt in _ownRts) if (rt != null) { rt.Release(); Destroy(rt); }
            _ownRts.Clear();
        }

        void ServerWatchdog()
        {
            if (!NetworkServer.active || !_roundActive) return;
            if (Time.time - _lastProgress > 60f)
            {
                SugarGalaxyPlugin.Log.LogError("[SG] Round stalled (coroutine died?) - refunding and unlocking machine");
                Refund("watchdog"); SafeReset(); _autoLeft = 0; _autoPi = null; Broadcast(new SgMsg { t = "auto", fsi = 0, tb = turbo ? 1 : 0, an = ante ? 1 : 0 });
                Broadcast(new SgMsg { t = "end", tb = turbo ? 1 : 0 });
            }
        }

        void SafeReset() { _roundActive = false; try { ResetGame(); } catch (Exception e) { SugarGalaxyPlugin.Log.LogError(e); isPlaying = false; canBet = true; } }

        static SgMsg Make(SugarEngine.Spin s, double running, int fsi, int fsn, bool tb, bool an, bool by, string bet) => new SgMsg
        {
            t = "spin", steps = s.steps.ToArray(), bs = s.bombSum, sc = s.scatters, sp = (float)s.scatterPay, tw = (float)s.tumbleWin,
            w = (float)s.win, tot = (float)running, fsi = fsi, fsn = fsn, tm = s.totalMulti, tb = tb ? 1 : 0, an = an ? 1 : 0, by = by ? 1 : 0, bet = bet
        };

        void Broadcast(SgMsg msg)
        {
            if (!NetworkServer.active) return;
            try
            {
                var writer = NetworkWriterPool.Get();
                writer.WriteString(GwyfShared.MiniJson.ToJson(msg));
                SendRPCInternal(RpcSig, RpcSig.GetStableHashCode(), writer, 0, true);
                NetworkWriterPool.Return(writer);
            }
            catch (Exception e) { SugarGalaxyPlugin.Log.LogError("[SG] Broadcast failed: " + e.Message); }
        }

        // ---------------- client ----------------
        public void UserRpcShowSpin(string json)
        {
            if (!NetworkClient.active) return;
            SgMsg msg;
            try { msg = GwyfShared.MiniJson.FromJson<SgMsg>(json); } catch (Exception e) { SugarGalaxyPlugin.Log.LogError("[SG] Bad RPC json: " + e.Message); return; }
            if (msg.t != "spin" || msg.fsi <= 1) SugarGalaxyPlugin.V($"RPC {msg.t} fs={msg.fsi}/{msg.fsn} win={msg.w:0.##} tot={msg.tot:0.##} ({json.Length} bytes)");
            EnsureUi();
            if (_ui == null) return;
            if (!string.IsNullOrEmpty(msg.bet)) _betLabel = msg.bet;
            if (msg.bn > 0) _betNum = msg.bn;
            if (msg.t == "auto") { UpdateAutoVisual(msg.fsi); UpdateButtonsVisual(msg.tb == 1, msg.an == 1); RefreshBar(); return; }
            if (msg.t == "turbo" || msg.t == "ante" || msg.t == "bet") { UpdateButtonsVisual(msg.tb == 1, msg.an == 1); RefreshBar(); return; }
            if (_anim != null) StopCoroutine(_anim);
            ClearFx(); HideBanner(); ResetTransientVisuals();
            _anim = StartCoroutine(Safe(Show(msg)));
        }

        void Update() { if (SugarGalaxyPlugin.Instance != null) SugarGalaxyPlugin.Instance.Tick(); UpdateIdle(); UpdateCabinetFx(); DriveBanner(); ServerWatchdog(); UpdateHudSpin(); ServerStateSync(); }

        void Start()
        {
            if (NetworkClient.active) { try { EnsureUi(); SetIdle(); } catch (Exception e) { SugarGalaxyPlugin.Log.LogError("[SG] UI build failed: " + e); } }
            try
            {
                foreach (var tmp in GetComponentsInChildren<TextMeshPro>(true))
                    if (tmp != payoutText && tmp.text != null && tmp.text.IndexOf("slot", StringComparison.OrdinalIgnoreCase) >= 0) tmp.text = "SUGAR BONANZA";
            }
            catch { }
            try { if (SugarGalaxyPlugin.RestyleCabinet == null || SugarGalaxyPlugin.RestyleCabinet.Value) BuildCabinet(); GwyfShared.CabinetSkin.Build(transform, playButtons.FirstOrDefault(b => b != null)?.transform, "sugar"); } catch (Exception e) { SugarGalaxyPlugin.Log.LogError("[SG] Cabinet restyle failed: " + e); }
        }

        void EnsureUi()
        {
            if (_ui != null) return;
            var imgs = (symbolLocations ?? new List<Image>()).Where(i => i != null).ToList();
            if (imgs.Count == 0 && reels != null) imgs = reels.Where(r => r != null).SelectMany(r => r.symbols ?? new Image[0]).Where(i => i != null).ToList();
            if (imgs.Count == 0 || imgs[0].canvas == null)
            {
                SugarGalaxyPlugin.V("No vanilla screen found: building floating screen above the machine");
                var cgo = new GameObject("SugarGalaxyScreen", typeof(RectTransform), typeof(Canvas));
                cgo.GetComponent<Canvas>().renderMode = RenderMode.WorldSpace;
                var cr = (RectTransform)cgo.transform; cr.SetParent(transform, false);
                cr.sizeDelta = new Vector2(640, 400); cr.localScale = Vector3.one * 0.004f;
                cr.localPosition = new Vector3(0, 2.3f, 0); cr.localRotation = Quaternion.Euler(0, 180, 0);
                BuildPanel(cr, new Vector2(-320, -200), new Vector2(320, 200));
                return;
            }
            var canvas = imgs[0].canvas;
            var croot = (RectTransform)canvas.transform;
            var rect = croot.rect;
            SugarGalaxyPlugin.V($"Screen canvas '{canvas.name}' mode={canvas.renderMode} rect={rect} layer={canvas.gameObject.layer}");
            if (rect.width < 10 || rect.height < 10) rect = new Rect(-500, -400, 1000, 800);
            foreach (var r in reels) if (r != null) foreach (var g in r.GetComponentsInChildren<Graphic>(true)) g.enabled = false;
            foreach (var im in imgs) im.enabled = false;
            var fmin = rect.min; var fmax = rect.max;
            try { SugarGalaxyPlugin.Log.LogInfo("[SG] Screen " + GwyfShared.ScreenFit.Fit(transform, croot, ref fmin, ref fmax)); } catch (Exception e) { SugarGalaxyPlugin.Log.LogWarning("[SG] screen fit: " + e.Message); }
            BuildPanel(croot, fmin, fmax);
            SetLayer(_ui.gameObject, canvas.gameObject.layer);
        }

        static void SetLayer(GameObject go, int layer) { go.layer = layer; foreach (Transform c in go.transform) SetLayer(c.gameObject, layer); }

        void Sfx(EventReference ev, float value, string param = "Multiplier")
        {
            try
            {
                if (ev.IsNull) return;
                SFXManager.SFXOneShotWithParameters(ev, new[] { new SFXParams(param, Mathf.Clamp(value, 0f, param == "Multiplier" ? 1000f : 100000f)) }, transform.position);
            }
            catch { }
        }
    }

    /// Shared timing: the host waits exactly as long as the clients animate.
    public static class SgTiming
    {
        public static float Out(bool t) => t ? 0.12f : 0.28f;
        public static float Stagger(bool t) => t ? 0.03f : 0.075f;
        public static float Fall(bool t) => t ? 0.22f : 0.42f;
        public static float Glow(bool t) => t ? 0.35f : 0.85f;
        public static float Explode(bool t) => t ? 0.22f : 0.38f;
        public static float Refill(bool t) => t ? 0.25f : 0.45f;
        public static float BombEach(bool t) => t ? 0.18f : 0.4f;
        public static float Fly(bool t) => t ? 0.25f : 0.55f;
        public static float Scatter(bool t) => t ? 0.5f : 1.1f;
        public static float Intro(bool t) => t ? 1.8f : 3.6f;
        public static float Settle(bool t) => t ? 0.2f : 0.5f;
        public static float Zoom(bool t) => t ? 0.8f : 2.0f;
        public static float AntEach(bool t) => t ? 0.3f : 0.75f;
        /// columns that spin longer because 2+ scatters already landed in the columns before them
        /// v1.2.0: like the original, anticipation starts once 3 scatters are visible (one more triggers the bonus)
        public static bool AntCol(int[] g, int c) { if (g == null) return false; int n = 0; for (int k = 0; k < c * SugarEngine.Rows && k < g.Length; k++) if (g[k] == SugarEngine.SCATTER) n++; return n >= 3; }
        public static float AntBefore(int[] g, int c, bool t) { float e = 0; for (int k = 0; k <= c; k++) if (AntCol(g, k)) e += AntEach(t); return e; }
        public static float AntTotal(int[] g, bool t) => AntBefore(g, SugarEngine.Cols - 1, t);
        public static float Spin(SgMsg m)
        {
            bool t = m.tb == 1;
            float d = Out(t) + Stagger(t) * (SugarEngine.Cols - 1) + Fall(t) + 0.1f;
            int wins = 0; if (m.steps != null) foreach (var s in m.steps) if (s.win != null && s.win.Length > 0) wins++;
            d += wins * (Glow(t) + Explode(t) + Refill(t) + 0.06f);
            if (m.tw > 0 && m.bs > 0)
            {
                int nb = 0; var last = m.steps != null && m.steps.Length > 0 ? m.steps[m.steps.Length - 1].g : null;
                if (last != null) foreach (var g in last) if (g == SugarEngine.BOMB) nb++;
                d += Mathf.Min(nb, 8) * BombEach(t) + Fly(t) + Settle(t);
            }
            if ((m.fsn == 0 && m.sc >= 4) || m.rt == 1) d += Scatter(t);
            if (m.fsn == 0 && m.sc >= 4) d += Zoom(t);
            if (m.steps != null && m.steps.Length > 0) d += AntTotal(m.steps[0].g, t);
            if (m.w > 0) d += Settle(t);
            return d;
        }
    }
}
