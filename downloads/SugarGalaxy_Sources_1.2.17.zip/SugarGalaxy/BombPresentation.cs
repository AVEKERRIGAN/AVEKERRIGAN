namespace SugarGalaxy
{
    public static class BombPresentation
    {
        public static string Label(int value)=>value>0?"X"+value.ToString(System.Globalization.CultureInfo.InvariantCulture):"";
    }
}
