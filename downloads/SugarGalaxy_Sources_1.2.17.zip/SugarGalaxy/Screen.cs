using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace SugarGalaxy
{
    /// Client-side screen: floating symbols, tumbles, explosions, bombs, banners.
    public partial class SugarGalaxyGame
    {
        const int C = SugarEngine.Cols, R = SugarEngine.Rows, N = SugarEngine.Cells;
        RectTransform _ui, _grid, _fx, _bannerRt;
        GwyfShared.ReelFx.Column[] _reel; Image _frameGlow; Image[] _dim;
        Image[] _cell = new Image[N]; Image[] _cellGlow = new Image[N];
        Vector2[] _home = new Vector2[N];
        int[] _g = new int[N], _bv = new int[N];
        float _cs;  // cell size
        float _gw, _gh;
        TMP_FontAsset _font;
        Coroutine _anim;
        TextMeshProUGUI _winLabel, _panelTitle, _panelValue, _panelMulti, _panelSub, _bar, _buyText, _anteText, _bannerText, _bannerSub;
        Image _bannerDim, _bannerIcon;
        string _betLabel = "-"; double _betNum; float _lastWinX; bool _clientTurbo, _clientAnte;
        readonly List<GameObject> _fxObjs = new List<GameObject>();
        float _bannerUntil; int _particleBudget;
        const int MaxFxObjects = 220;

        // overlays can never stay stuck: the banner is shown only while its deadline is in the future (checked every frame)
        void ShowBanner(float seconds) { if (_bannerDim == null) return; _bannerUntil = Time.time + seconds; _bannerDim.gameObject.SetActive(true); _bannerRt.SetAsLastSibling(); }
        void HideBanner() { _bannerUntil = 0; if (_bannerDim != null) _bannerDim.gameObject.SetActive(false); }
        void DriveBanner() { if (_bannerDim != null && _bannerDim.gameObject.activeSelf && Time.time > _bannerUntil) { SugarGalaxyPlugin.V("Banner hidden by per-frame check"); HideBanner(); } }

        IEnumerator Safe(IEnumerator inner)
        {
            while (true)
            {
                object cur;
                try { if (!inner.MoveNext()) break; cur = inner.Current; }
                catch (Exception e) { SugarGalaxyPlugin.Log.LogError("[SG] Animation error: " + e); break; }
                yield return cur;
            }
            _anim = null;
            for (int i = 0; i < N; i++) if (_cell[i] != null) { _cell[i].rectTransform.localScale = Vector3.one; _cell[i].rectTransform.localRotation = Quaternion.identity; }
        }

        void ClientAbort()
        {
            if (_anim != null) { try { StopCoroutine(_anim); } catch { } _anim = null; }
            HideBanner(); ClearFx(); ResetTransientVisuals();
            for (int i = 0; i < N; i++) if (_cell[i] != null) { _cell[i].enabled = _cell[i].sprite != null; _cell[i].rectTransform.anchoredPosition = _home[i]; _cell[i].rectTransform.localScale = Vector3.one; _cell[i].rectTransform.localRotation = Quaternion.identity; }
        }
        static readonly Color Pink = new Color(1f, .45f, .8f), Gold = new Color(1f, .85f, .25f), Mint = new Color(.4f, 1f, .8f);
        // banana, grapes, watermelon, plum, apple, blue, green, purple, heart
        static readonly Color[] SymColor = {
            new Color(1f,.9f,.25f), new Color(.45f,.4f,1f), new Color(.35f,.85f,.35f), new Color(.75f,.3f,.85f), new Color(1f,.3f,.3f),
            new Color(.35f,.6f,1f), new Color(.4f,1f,.45f), new Color(1f,.4f,1f), new Color(1f,.25f,.35f) };
        Image _bgImg;

        // ---------- building ----------
        static Image Img(string name, Transform parent, Sprite sp = null)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Image)); go.transform.SetParent(parent, false); go.layer = parent.gameObject.layer;
            var im = go.GetComponent<Image>(); im.sprite = sp; im.raycastTarget = false; im.preserveAspect = sp != null; return im;
        }
        TextMeshProUGUI Txt(string name, Transform parent, Color c, float maxSize = 300)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer)); go.transform.SetParent(parent, false); go.layer = parent.gameObject.layer;
            var t = go.AddComponent<TextMeshProUGUI>(); var canvasRenderer = t.canvasRenderer; if (_font != null) { t.font = _font; if (_font.material != null) t.fontSharedMaterial = _font.material; }
            t.alignment = TextAlignmentOptions.Center; t.enableAutoSizing = true; t.fontSizeMin = 1; t.fontSizeMax = maxSize;
            t.color = c; t.raycastTarget = false; t.outlineWidth = .22f; t.outlineColor = new Color32(40, 0, 50, 255); t.textWrappingMode = TMPro.TextWrappingModes.NoWrap;
            return t;
        }
        static RectTransform Place(RectTransform rt, Vector2 center, Vector2 size) { rt.anchorMin = rt.anchorMax = new Vector2(.5f, .5f); rt.pivot = new Vector2(.5f, .5f); rt.sizeDelta = size; rt.anchoredPosition = center; return rt; }
        static void Stretch(RectTransform rt) { rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one; rt.offsetMin = rt.offsetMax = Vector2.zero; }

        void BuildPanel(RectTransform croot, Vector2 min, Vector2 max)
        {
            _font = payoutText != null ? payoutText.font : TMP_Settings.defaultFontAsset;
            if (_font == null) { var any = GetComponentsInChildren<TMP_Text>(true).FirstOrDefault(x => x.font != null); _font = any != null ? any.font : Resources.FindObjectsOfTypeAll<TMP_FontAsset>().FirstOrDefault(); }
            if (_font == null) SugarGalaxyPlugin.Log.LogWarning("[SG] No TMP font found - texts may be invisible");
            var bg = Img("SugarGalaxyUI", croot, Spr("bg")); bg.preserveAspect = false; _bgImg = bg;
            if (bg.sprite == null) bg.color = new Color(1f, .78f, .88f);
            _ui = bg.rectTransform; _ui.anchorMin = _ui.anchorMax = new Vector2(.5f, .5f);
            float margin = SugarGalaxyPlugin.ScreenMargin != null ? Mathf.Clamp(SugarGalaxyPlugin.ScreenMargin.Value, 0f, .2f) : .03f;
            Vector2 size = (max - min) * (1f - 2f * margin); _ui.sizeDelta = size; _ui.anchoredPosition = (min + max) / 2f - croot.rect.center;
            _ui.SetAsLastSibling();
            float W = size.x, H = size.y; _uiSize = size;

            // geometry: logo on top, grid centre, side panels, bottom bar
            // v1.2.0 layout: logo top, white candy frame right of centre, left panel column, bottom bar
            float barH = H * .09f, logoH = H * .12f;
            float availH = H - barH - logoH - H * .07f;
            // v1.2.5: frame (1.21x grid) kept inside x .265W..870W and above the SPIN button (.235H from bottom) so no button overlaps the candy frame
            _cs = Mathf.Min(H * .655f / 1.21f / R, W * .605f / 1.21f / C);
            _gw = _cs * C; _gh = _cs * R;
            float gy = H * .0625f;
            float gx = W * .0675f;
            var gridCenter = new Vector2(gx, gy); _gridCenter = gridCenter;

            // v1.2.4 machine surround: candy side rail behind the left panels, soft grid backdrop, candy frame with drop shadow, logo plate
            var rail = Img("SideRail", _ui, Spr("side_rail")); rail.preserveAspect = false; rail.raycastTarget = false;
            rail.rectTransform.anchorMin = rail.rectTransform.anchorMax = new Vector2(.135f, .47f); rail.rectTransform.pivot = new Vector2(.5f, .5f);
            rail.rectTransform.sizeDelta = new Vector2(W * .27f, H * .74f); rail.rectTransform.anchoredPosition = Vector2.zero;
            var gback = Img("GridBack", _ui, Spr("grid_back")); gback.preserveAspect = false; gback.raycastTarget = false; Place(gback.rectTransform, gridCenter, new Vector2(_gw, _gh));
            var frame = Img("Frame", _ui, Spr("frame_candy") ?? Spr("frame")); frame.preserveAspect = false; frame.raycastTarget = false;
            Place(frame.rectTransform, gridCenter, new Vector2(_gw * 1.21f, _gh * 1.21f));
            var plate = Img("LogoPlate", _ui, Spr("logo_plate")); plate.preserveAspect = false; plate.raycastTarget = false;
            Place(plate.rectTransform, new Vector2(gx, H / 2 - logoH * .52f), new Vector2(W * .56f, logoH * 1.2f));
            var logo = Img("Logo", _ui, Spr("logo")); logo.preserveAspect = true; Place(logo.rectTransform, new Vector2(gx, H / 2 - logoH * .5f), new Vector2(W * .46f, logoH * .8f));
            var pays = Txt("Pays", _ui, Color.white); Place(pays.rectTransform, new Vector2(gx, gridCenter.y - _gh * .53f), new Vector2(_gw * .7f, _cs * .17f));
            pays.outlineColor = new Color32(150, 20, 80, 255);
            pays.text = $"PAYS ANYWHERE \u2022 {SugarEngine.MinMatch}+ SYMBOLS \u2022 TUMBLE";

            var gridGo = new GameObject("Grid", typeof(RectTransform), typeof(RectMask2D));
            _grid = Place((RectTransform)gridGo.transform, gridCenter, new Vector2(_gw, _gh)); _grid.SetParent(_ui, false); Place(_grid, gridCenter, new Vector2(_gw, _gh));
            for (int i = 0; i < N; i++)
            {
                int c = i / R, r = i % R;
                _home[i] = new Vector2(-_gw / 2 + _cs * (c + .5f), _gh / 2 - _cs * (r + .5f));
                var gl = Img("Glow" + i, _grid, Spr("glow")); Place(gl.rectTransform, _home[i], Vector2.one * _cs * 1.25f); gl.gameObject.SetActive(false); _cellGlow[i] = gl;
            }
            for (int i = 0; i < N; i++) { var im = Img("Cell" + i, _grid); im.preserveAspect = true; Place(im.rectTransform, _home[i], Vector2.one * _cs * .92f); _cell[i] = im; }
            _reel = new GwyfShared.ReelFx.Column[C];
            for (int c = 0; c < C; c++)
            {
                var cells = new Image[R]; for (int r = 0; r < R; r++) cells[r] = _cell[c * R + r];
                _reel[c] = new GwyfShared.ReelFx.Column(cells, _home[c * R], new Vector2(0, -_cs), Vector2.one * _cs * .92f, _grid, (n, par) => Img(n, par), Spr("reel_shade"), _cs, _gh);
            }
            _dim = new Image[C];
            for (int c = 0; c < C; c++) { _dim[c] = Img("Dim" + c, _grid, Spr("px")); _dim[c].preserveAspect = false; _dim[c].raycastTarget = false; Place(_dim[c].rectTransform, new Vector2(-_gw / 2 + _cs * (c + .5f), 0), new Vector2(_cs, _gh)); _dim[c].color = new Color(0, 0, 0, 0); }
            _frameGlow = Img("FrameGlow", _ui, Spr("glow")); _frameGlow.preserveAspect = false; Place(_frameGlow.rectTransform, gridCenter, new Vector2(_gw * 1.12f, _gh * 1.12f)); _frameGlow.color = new Color(1, 1, 1, 0); _frameGlow.raycastTarget = false; _frameGlow.transform.SetSiblingIndex(_grid.GetSiblingIndex());
            var fxGo = new GameObject("Fx", typeof(RectTransform)); _fx = (RectTransform)fxGo.transform; _fx.SetParent(_ui, false); Place(_fx, gridCenter, new Vector2(_gw, _gh));

            // win line label lives on its own dark plate directly below the reel frame (never over the symbols); footer moves below it
            float frameBot = gridCenter.y - _gh * 1.1f * .5f, plateH = H * .052f;
            var winPlate = Img("WinPlate", _ui, Spr("px")); winPlate.preserveAspect = false; winPlate.color = new Color(.05f, .02f, .08f, .78f);
            Place(winPlate.rectTransform, new Vector2(gridCenter.x, frameBot - plateH * .5f - H * .004f), new Vector2(_gw * 1.02f, plateH));
            _winLabel = Txt("WinLabel", winPlate.transform, Gold); Place(_winLabel.rectTransform, Vector2.zero, new Vector2(_gw * .98f, plateH * .9f)); _winLabel.text = "";
            _winLabel.margin = new Vector4(plateH * .15f, plateH * .08f, plateH * .15f, plateH * .08f); _winLabel.overflowMode = TextOverflowModes.Truncate; _winLabel.outlineWidth = .15f;
            pays.rectTransform.anchoredPosition = new Vector2(pays.rectTransform.anchoredPosition.x, Mathf.Min(pays.rectTransform.anchoredPosition.y, frameBot - plateH - H * .004f - pays.rectTransform.sizeDelta.y * .55f));

            // side panels
            float pw = (W - _gw * 1.12f) / 2f - W * .03f; float px = _gw * .56f + W * .015f + pw / 2f;
            var lp = Img("BuyPanel", _ui, Spr("panel_buy")); lp.preserveAspect = false; PlaceN(lp.rectTransform, BtnRect("Buy"));
            pw = lp.rectTransform.sizeDelta.x; float ph = lp.rectTransform.sizeDelta.y;
            _buyText = Txt("BuyText", lp.transform, Color.white); Place(_buyText.rectTransform, new Vector2(0, -ph * .03f), new Vector2(pw * .8f, ph * .72f));
            _buyText.outlineColor = new Color32(150, 60, 0, 255); _buyText.text = "BUY\nFEATURE\n<size=55%>100x BET</size>";
            var ap = Img("BetPanel", _ui, Spr("panel_bet")); ap.preserveAspect = false; PlaceN(ap.rectTransform, BtnRect("Ante"));
            float ah = ap.rectTransform.sizeDelta.y;
            _anteText = Txt("AnteText", ap.transform, Color.white); Place(_anteText.rectTransform, new Vector2(0, -ah * .02f), new Vector2(pw * .82f, ah * .8f));
            _anteText.outlineColor = new Color32(20, 80, 20, 255);
            // info panel (tumble win / free spins left / bomb multiplier) under the bet panel
            var rp = Img("InfoPanel", _ui, Spr("panel_info")); rp.preserveAspect = false;
            rp.rectTransform.anchorMin = rp.rectTransform.anchorMax = new Vector2(.135f, .225f); rp.rectTransform.pivot = new Vector2(.5f, .5f);
            rp.rectTransform.sizeDelta = new Vector2(W * .23f, H * .2f); rp.rectTransform.anchoredPosition = Vector2.zero;
            float ih = H * .2f;
            _panelTitle = Txt("PTitle", rp.transform, Color.white); Place(_panelTitle.rectTransform, new Vector2(0, ih * .3f), new Vector2(pw * .8f, ih * .2f));
            _panelValue = Txt("PValue", rp.transform, Gold); Place(_panelValue.rectTransform, new Vector2(0, ih * .07f), new Vector2(pw * .82f, ih * .26f));
            _panelMulti = Txt("PMulti", rp.transform, new Color(1f, .95f, .4f)); Place(_panelMulti.rectTransform, new Vector2(pw * .3f, ih * .07f), new Vector2(pw * .3f, ih * .28f));
            _panelSub = Txt("PSub", rp.transform, Color.white); Place(_panelSub.rectTransform, new Vector2(0, -ih * .25f), new Vector2(pw * .8f, ih * .3f));
            foreach (var tx in new[] { _panelTitle, _panelValue, _panelMulti, _panelSub }) tx.outlineColor = new Color32(120, 10, 70, 255);

            var bar = Img("Bar", _ui, Spr("bar")); bar.preserveAspect = false; Place(bar.rectTransform, new Vector2(0, -H / 2 + barH * .55f), new Vector2(W * .96f, barH * .9f));
            _bar = Txt("BarText", bar.transform, Color.white); Stretch(_bar.rectTransform); _bar.margin = new Vector4(20, 6, 20, 6);
            _bar.rectTransform.anchorMax = new Vector2(.6f, 1f); // right part of the bar holds the HUD buttons
            BuildHud();

            // banner overlay
            _bannerDim = Img("Banner", _ui); _bannerDim.color = new Color(.05f, 0, .12f, .78f); _bannerRt = _bannerDim.rectTransform; Stretch(_bannerRt);
            _bannerIcon = Img("BannerIcon", _bannerRt, Spr("sym_scatter")); Place(_bannerIcon.rectTransform, new Vector2(0, H * .17f), Vector2.one * H * .3f);
            _bannerText = Txt("BannerText", _bannerRt, Gold); Place(_bannerText.rectTransform, new Vector2(0, -H * .07f), new Vector2(W * .8f, H * .2f));
            _bannerSub = Txt("BannerSub", _bannerRt, Color.white); Place(_bannerSub.rectTransform, new Vector2(0, -H * .23f), new Vector2(W * .7f, H * .1f));
            _bannerDim.gameObject.SetActive(false);
            UpdateButtonsVisual(false, false); SetPanelBase(0); RefreshBar();
            SugarGalaxyPlugin.V($"UI built {W:0}x{H:0}, cell {_cs:0.#}");
        }

        void SetBg(bool fs) { if (_bgImg == null) return; var s = Spr(fs ? "bg_fs" : "bg"); if (s != null) _bgImg.sprite = s; }
        void SetPanelBase(double win)
        {
            _panelTitle.text = "TUMBLE WIN"; _panelValue.text = Money(win); _panelMulti.text = ""; _panelSub.text = "";
        }
        string Money(double x) { if (_betNum <= 0) return x.ToString("0.##") + "x"; try { return MoneyFormatter.FormatWithDollar(BigNumber.FromDouble(x * _betNum)); } catch { return "$" + (x * _betNum).ToString("0.00"); } }
        void RefreshBar() { UpdateAnteText(); if (_bar != null) _bar.text = $"<color=#ffb8f0>BET</color> {_betLabel}{(_clientAnte ? " <size=70%>(+25%)</size>" : "")}     <color=#ffb8f0>WIN</color> {Money(_lastWinX)}     <size=70%>{(_clientTurbo ? "<color=#ffe066>TURBO</color>" : "")}</size>"; }

        void UpdateButtonsVisual(bool tb, bool an)
        {
            _clientTurbo = tb; _clientAnte = an; HudTurbo(tb);
            GwyfShared.ToggleTint.Physical(turboButton, tb); GwyfShared.ToggleTint.Physical(anteButton, an); GwyfShared.ToggleTint.Ui(_hudTurbo, tb);
            void Label(InteractableEventTrigger b, string s) { if (b == null) return; foreach (var t in b.GetComponentsInChildren<TMP_Text>(true)) t.text = s; }
            Label(turboButton, "TURBO\n<size=70%>" + (tb ? "ON" : "OFF") + "</size>");
            Label(anteButton, "DOUBLE\n<size=55%>CHANCE " + (an ? "ON" : "OFF") + "</size>");
            Label(buyButton, an ? "BUY\n<size=55%>OFF (ANTE)</size>" : "BUY\n<size=55%>BONUS 100x</size>");
            UpdateAnteText();
            if (_buyText != null) { _buyText.color = an ? new Color(.75f, .75f, .75f) : Color.white; _buyText.text = an ? "BUY\nFEATURE\n<size=50%>OFF WITH DOUBLE CHANCE</size>" : "BUY\nFEATURE\n<size=55%>100x BET</size>"; }
        }

        void UpdateAnteText()
        {
            if (_anteText == null) return;
            GwyfShared.ToggleTint.Ui(_anteText.transform.parent != null ? _anteText.transform.parent.GetComponent<UnityEngine.UI.Graphic>() : null, _clientAnte);
            _anteText.text = $"<size=70%>BET</size>\n{_betLabel}{(_clientAnte ? "<size=60%> +25%</size>" : "")}\n<size=62%><color=#fff07a>DOUBLE CHANCE</color></size>\n<size=50%>to win feature</size>\n<size=75%>" + (_clientAnte ? "<color=#ffe040>\u25CF ON</color>" : "<color=#dddddd>OFF \u25CB</color>") + "</size>";
        }
        // ---------- cells ----------
        void SetCell(int i, int sym, int bomb)
        {
            _g[i] = sym; _bv[i] = bomb;
            var im = _cell[i]; im.sprite = SymSprite(sym, bomb); im.color = Color.white; im.enabled = im.sprite != null;
            var rt = im.rectTransform; rt.localScale = Vector3.one; rt.localRotation = Quaternion.identity; rt.anchoredPosition = _home[i];
            if (_anim != null && (sym == SugarEngine.SCATTER || sym == SugarEngine.BOMB)) StartCoroutine(GwyfShared.BonusArrival.Pulse(im, _cellGlow[i], new Color(1f, .8f, .35f)));
        }
        void SetIdle()
        {
            var r = new System.Random(GetInstanceID());
            for (int i = 0; i < N; i++) SetCell(i, r.Next(SugarEngine.NSYM), 0);
        }
        void UpdateIdle()
        {
            if (_ui == null || _anim != null) return;
            float t = Time.time;
            for (int i = 0; i < N; i++)
                if (_cell[i] != null) _cell[i].rectTransform.anchoredPosition = _home[i] + new Vector2(0, Mathf.Sin(t * 1.6f + i * .7f) * _cs * .025f);
        }
        void ClearFx()
        {
            foreach (var g in _fxObjs) if (g != null) Destroy(g); _fxObjs.Clear();
            if (_cellGlow[0] != null) foreach (var g in _cellGlow) g.gameObject.SetActive(false);
            if (_winLabel != null) _winLabel.text = "";
        }

        // squash/bounce scale after landing: k in 0..1 of the bounce phase
        static Vector3 Squash(float k) { float a = Mathf.Sin(k * Mathf.PI) * (1 - k) * .35f; return new Vector3(1 + a, 1 - a, 1); }

        /// Generic fall: every cell i moves from home+from[i] to home; delay[i]; dur. Bounce in the last 30 %.
        IEnumerator Fall(float[] fromY, float[] delay, float dur)
        {
            float end = 0; for (int i = 0; i < N; i++) if (fromY[i] != 0) end = Mathf.Max(end, delay[i] + dur);
            float t0 = Time.time; var sharpS = new Sprite[N];
            while (true)
            {
                float t = Time.time - t0;
                for (int i = 0; i < N; i++)
                {
                    if (fromY[i] == 0) continue;
                    float p = Mathf.Clamp01((t - delay[i]) / dur); var rt = _cell[i].rectTransform;
                    // gravity ease + decaying bounce + motion-blurred sprite while fast (shared ReelFx), same duration
                    if (sharpS[i] == null) sharpS[i] = _cell[i].sprite;
                    var bl = GwyfShared.ReelFx.FallBlur(p, Mathf.Abs(fromY[i]) / _cs) ? BlurOf(sharpS[i]) : null;
                    _cell[i].sprite = bl ?? sharpS[i];
                    rt.anchoredPosition = _home[i] + new Vector2(0, fromY[i] * GwyfShared.ReelFx.GravityFall(p));
                    rt.localScale = GwyfShared.ReelFx.FallScale(p);
                }
                if (t >= end) break;
                yield return null;
            }
            for (int i = 0; i < N; i++) { if (sharpS[i] != null) _cell[i].sprite = sharpS[i]; _cell[i].rectTransform.anchoredPosition = _home[i]; _cell[i].rectTransform.localScale = Vector3.one; }
        }

        IEnumerator DropOut(float dur)
        {
            float t0 = Time.time;
            while (Time.time - t0 < dur)
            {
                float p = (Time.time - t0) / dur;
                for (int i = 0; i < N; i++) { int c = i / R; float q = Mathf.Clamp01(p * 1.3f - c * .05f); _cell[i].rectTransform.anchoredPosition = _home[i] - new Vector2(0, q * q * _gh * 1.2f); }
                yield return null;
            }
            for (int i = 0; i < N; i++) _cell[i].enabled = false;
        }

        GameObject FxImg(string spr, Vector2 pos, float size, Color col, Transform parent = null)
        {
            _fxObjs.RemoveAll(g => g == null);
            if (_fxObjs.Count >= MaxFxObjects) { var old = _fxObjs[0]; _fxObjs.RemoveAt(0); if (old != null) Destroy(old); }
            var im = Img("fx", parent ?? _fx, Spr(spr)); im.color = col; Place(im.rectTransform, pos, Vector2.one * size); _fxObjs.Add(im.gameObject); return im.gameObject;
        }

        IEnumerator Flipbook(Image im, string prefix, int from, int to, float dur)
        {
            float t0 = Time.time; int n = to - from + 1;
            while (Time.time - t0 < dur) { if (im == null) yield break; int f = from + Mathf.Min(n - 1, (int)((Time.time - t0) / dur * n)); im.sprite = Spr(prefix + f); yield return null; }
            if (im != null) Destroy(im.gameObject);
        }

        IEnumerator Particles(Vector2 pos, Color col, int count, float dur, float dist)
        {
            float amt = SugarGalaxyPlugin.Particles != null ? Mathf.Max(0, SugarGalaxyPlugin.Particles.Value) : 1f;
            count = Mathf.Min(Mathf.RoundToInt(count * amt * .5f), _particleBudget); if (count <= 0) yield break; _particleBudget -= count;
            var parts = new List<(RectTransform rt, Image im, Vector2 v, float s)>();
            var rnd = new System.Random(pos.GetHashCode());
            for (int k = 0; k < count; k++)
            {
                float a = (float)(rnd.NextDouble() * Math.PI * 2), sp = dist * (.4f + (float)rnd.NextDouble() * .8f);
                bool star = rnd.NextDouble() < .25;
                var go = FxImg(star ? "sparkle" : "dot", pos, _cs * (star ? .22f : .13f) * (.6f + (float)rnd.NextDouble() * .8f), Color.Lerp(col, Color.white, (float)rnd.NextDouble() * .5f));
                parts.Add(((RectTransform)go.transform, go.GetComponent<Image>(), new Vector2(Mathf.Cos(a), Mathf.Sin(a)) * sp, (float)rnd.NextDouble() * 360));
            }
            float t0 = Time.time;
            while (Time.time - t0 < dur)
            {
                float p = (Time.time - t0) / dur, e = 1 - (1 - p) * (1 - p) * (1 - p), fa = Mathf.Min(1f, p * 10f) * (1 - p * p);
                foreach (var q in parts) { if (q.rt == null || q.im == null) continue; q.rt.anchoredPosition = pos + q.v * e + new Vector2(0, -p * p * _cs * .2f); q.rt.localRotation = Quaternion.Euler(0, 0, q.s + e * 90); q.rt.localScale = Vector3.one * (1f - .4f * p); var c = q.im.color; c.a = fa; q.im.color = c; }
                yield return null;
            }
            foreach (var q in parts) if (q.rt != null) Destroy(q.rt.gameObject);
        }

        static string Hex(Color c) => ColorUtility.ToHtmlStringRGB(c);

        // ---------- the show ----------
        IEnumerator WaitT(float d) { float t0 = Time.time; while (Time.time - t0 < d) yield return null; }
        IEnumerator Show(SgMsg m)
        {
            bool t = m.tb == 1;
            _clientTurbo = t; if (m.bn > 0) _betNum = m.bn;
            if (m.t == "intro") { yield return IntroRoutine(m, t); _anim = null; yield break; }
            if (m.t == "end" && m.tot <= 0 && m.fsn <= 0) { _lastWinX = 0; RefreshBar(); _anim = null; yield break; }
            if (m.t == "end") { yield return EndRoutine(m); _anim = null; yield break; }
            if (m.t != "spin" || m.steps == null || m.steps.Length == 0) { _anim = null; yield break; }
            bool fs = m.fsn > 0;
            HideBanner();
            SetBg(fs);
            if (fs) { _panelTitle.text = $"FREE SPINS LEFT {Mathf.Max(0, m.fsn - m.fsi)}"; _panelMulti.text = ""; _panelSub.text = "TOTAL WIN\n" + Money(m.tot - m.w); _panelValue.text = Money(0); }
            else { SetPanelBase(0); _lastWinX = 0; RefreshBar(); }
            Sfx(spinReelSFX, 0);

            // 1) drop out, 2) fall in per column with stagger
            // v-next: no drop-out before the reel spin - the strip starts seamlessly from the symbols on screen
            var from = new float[N]; var del = new float[N];
            yield return SpinIn(m, t);   // reel-style spin per column, anticipation after 2 scatters
            yield return WaitT(SgTiming.Out(t)); // keeps host timing parity (the old drop-out duration)
            Sfx(spinDoneSFX, 0);
            yield return new WaitForSeconds(.1f);

            double stepAcc = 0;
            for (int si = 0; si < m.steps.Length; si++)
            {
                var st = m.steps[si];
                if (st.win == null || st.win.Length == 0) break;
                // a) glow + swell + win label
                stepAcc += st.w;
                var names = st.ws.Select(k => { int cnt = st.g.Count(x => x == k); return $"<color=#{Hex(SymColor[k])}>{cnt}x {SugarEngine.Names[k].ToUpper()}</color>"; });
                _winLabel.text = string.Join("  ", names) + " = " + Money(st.w);
                _panelValue.text = Money(stepAcc); _panelSub.text = fs ? "TOTAL WIN\n" + Money(m.tot - m.w) : (si > 0 ? "tumble " + (si + 1) : "");
                Sfx(multiplierSFX, Mathf.Min(1000f, (float)st.w * 10f));
                foreach (var i in st.win) { _cellGlow[i].gameObject.SetActive(true); _cellGlow[i].color = new Color(SymColor[st.g[i]].r, SymColor[st.g[i]].g, SymColor[st.g[i]].b, 0); _cell[i].transform.SetAsLastSibling(); }
                float gd = SgTiming.Glow(t), t0 = Time.time;
                while (Time.time - t0 < gd)
                {
                    float p = (Time.time - t0) / gd;
                    foreach (var i in st.win)
                    {
                        float sw = 1 + .2f * Mathf.SmoothStep(0, 1, Mathf.Min(1, p * 2.5f)) + Mathf.Sin(p * 18) * .04f;
                        _cell[i].rectTransform.localScale = Vector3.one * sw; _cell[i].rectTransform.localRotation = Quaternion.Euler(0, 0, Mathf.Sin(p * 25 + i) * 6 * p);
                        var c = _cellGlow[i].color; c.a = .55f + .35f * Mathf.Sin(p * 14); _cellGlow[i].color = c; _cellGlow[i].rectTransform.localScale = Vector3.one * (1 + .15f * Mathf.Sin(p * 10));
                    }
                    yield return null;
                }
                // b) explode: pop strip frames 3..7 + particles (budget-capped)
                _particleBudget = 120;
                float ed = SgTiming.Explode(t);
                foreach (var i in st.win)
                {
                    _cellGlow[i].gameObject.SetActive(false);
                    var pop = FxImg("pop_3", _home[i], _cs * 1.5f, Color.white);
                    StartCoroutine(Flipbook(pop.GetComponent<Image>(), "pop_", 3, 7, ed));
                    StartCoroutine(Particles(_home[i], SymColor[st.g[i]], 9, ed * 1.6f, _cs * .9f));
                }
                t0 = Time.time;
                while (Time.time - t0 < ed)
                {
                    float p = (Time.time - t0) / ed;
                    foreach (var i in st.win) { _cell[i].rectTransform.localScale = Vector3.one * (1.2f + p * .6f) * (p < .35f ? 1 : Mathf.Max(0, 1 - (p - .35f) / .3f)); }
                    yield return null;
                }
                foreach (var i in st.win) { _cell[i].enabled = false; _cell[i].rectTransform.localRotation = Quaternion.identity; }
                // c) tumble: survivors slide down, new symbols fall in from the top
                if (si + 1 < m.steps.Length)
                {
                    var nx = m.steps[si + 1]; var dead = new bool[N]; var newSc = new List<int>(); foreach (var i in st.win) dead[i] = true;
                    for (int i = 0; i < N; i++) { from[i] = 0; del[i] = 0; }
                    for (int c = 0; c < C; c++)
                    {
                        var oldRows = new List<int>(); for (int r = R - 1; r >= 0; r--) if (!dead[c * R + r]) oldRows.Add(r);
                        int k = 0, nNew = R - oldRows.Count;
                        for (int r = R - 1; r >= 0; r--, k++)
                        {
                            int i = c * R + r; SetCell(i, nx.g[i], nx.bv[i]);
                            if (k < oldRows.Count) from[i] = (r - oldRows[k]) * _cs;       // fell this many rows
                            else from[i] = (nNew + .4f) * _cs; // new ones fall in from above the frame
                            if (k >= oldRows.Count) { del[i] = c * (t ? .01f : .02f); if (nx.g[i] == SugarEngine.SCATTER) newSc.Add(i); }
                            _cell[i].rectTransform.anchoredPosition = _home[i] + new Vector2(0, from[i]);
                        }
                    }
                    yield return Fall(from, del, SgTiming.Refill(t) - (t ? .08f : .15f));
                    if (newSc.Count > 0)
                    {   // scatters that tumble in count too (Bonanza rule): make them visible with the same landing accent + running count
                        foreach (var i in newSc) StartCoroutine(LandDust(i));
                        int scNow = nx.g.Count(x => x == SugarEngine.SCATTER);
                        _winLabel.text = scNow >= 4 && !fs ? $"<color=#7dfcff>{scNow} SCATTERS!</color>" : $"<color=#7dfcff>{scNow} SCATTER{(scNow == 1 ? "" : "S")}</color>";
                    }
                    yield return new WaitForSeconds(t ? .08f : .15f);
                }
                yield return new WaitForSeconds(.06f);
            }
            _winLabel.text = "";

            // 3) multiplier bombs
            var last = m.steps[m.steps.Length - 1];
            int multiShown = 0;
            if (m.tw > 0 && m.bs > 0)
            {
                _particleBudget = 90;
                var bombs = Enumerable.Range(0, N).Where(i => last.g[i] == SugarEngine.BOMB).Take(8).ToList();
                float bd = SgTiming.BombEach(t);
                foreach (var i in bombs)
                {
                    float t0 = Time.time; bool burst = false;
                    var target = PanelMultiPos();
                    while (Time.time - t0 < bd)
                    {
                        float p = (Time.time - t0) / bd;
                        if (p < .45f) { _cell[i].rectTransform.localRotation = Quaternion.Euler(0, 0, Mathf.Sin(p * 70) * 14); _cell[i].rectTransform.localScale = Vector3.one * (1 + p * .5f); }
                        else if (!burst)
                        {
                            burst = true; _cell[i].enabled = false;
                            // The legacy burst frames have X25 baked into them.
                            // Use the number-free ring/particles and the actual host value.
                            var ring = FxImg("glow", _home[i], _cs, new Color(1f, .5f, .9f, .9f)); StartCoroutine(Shockwave(ring.GetComponent<Image>(), bd * .6f));
                            StartCoroutine(Particles(_home[i], Pink, 12, bd * .9f, _cs * 1.2f));
                            StartCoroutine(FlyValue(last.bv[i], _home[i], target, SgTiming.Fly(t) * .8f));
                            Sfx(multiplierSFX, last.bv[i]);
                        }
                        yield return null;
                    }
                    multiShown += last.bv[i];
                    _panelMulti.text = "x" + multiShown;
                }
                yield return new WaitForSeconds(SgTiming.Fly(t));
                // original rule: the bombs of this spin are added and multiply this spin's tumble win only
                _panelMulti.text = "x" + m.bs; StartCoroutine(Pop(_panelMulti.transform));
                _winLabel.text = $"<size=120%>{Money(m.tw)} <color=#ffe066>x{m.bs}</color> = {Money(m.tw * m.bs)}</size>";
                yield return new WaitForSeconds(SgTiming.Settle(t));
                _winLabel.text = "";
            }
            // 4) scatters
            if ((!fs && m.sc >= 4) || m.rt == 1)
            {
                var scs = Enumerable.Range(0, N).Where(i => last.g[i] == SugarEngine.SCATTER).ToList();
                foreach (var i in scs) { _cellGlow[i].gameObject.SetActive(true); _cellGlow[i].color = new Color(.5f, .8f, 1f, .8f); }
                if (m.rt == 1) _winLabel.text = "<color=#7dfcff>+5 FREE SPINS!</color>";
                else _winLabel.text = $"<color=#7dfcff>{m.sc} SCATTERS</color>" + (m.sp > 0 ? " = " + Money(m.sp) : "");
                if (!fs && m.sc >= 4 && scs.Count >= 4) yield return ZoomScatter(scs, t);
                else if (!fs && m.sc >= 4) SugarGalaxyPlugin.Log.LogWarning($"[trigger] host says {m.sc} scatters, board shows {scs.Count}");
                float sd = SgTiming.Scatter(t), t0 = Time.time;
                while (Time.time - t0 < sd)
                {
                    float p = (Time.time - t0) / sd;
                    foreach (var i in scs) { _cell[i].rectTransform.localScale = Vector3.one * (1.15f + .1f * Mathf.Sin(p * 20)); _cell[i].rectTransform.localRotation = Quaternion.Euler(0, 0, p * 360); }
                    yield return null;
                }
                foreach (var i in scs) { _cell[i].rectTransform.localScale = Vector3.one; _cell[i].rectTransform.localRotation = Quaternion.identity; _cellGlow[i].gameObject.SetActive(false); }
                _winLabel.text = "";
            }
            // 5) settle
            if (m.w > 0)
            {
                _panelValue.text = Money(m.w); StartCoroutine(Pop(_panelValue.transform));
                if (fs) _panelSub.text = "TOTAL WIN\n" + Money(m.tot);
                _lastWinX = m.tot; RefreshBar();
                _winLabel.text = "<size=120%>" + Money(m.w) + "</size>";
                yield return new WaitForSeconds(SgTiming.Settle(t));
            }
            else if (fs) _panelSub.text = "TOTAL WIN\n" + Money(m.tot);
            _anim = null;
        }

        static int PrevMulti(SgMsg m) => m.tw > 0 && m.bs > 0 ? m.tm - m.bs : m.tm;

        Vector2 PanelMultiPos()
        {
            // convert right-panel multiplier text position into fx space
            var wp = _panelMulti.rectTransform.position; Vector3 lp = _fx.InverseTransformPoint(wp); return new Vector2(lp.x, lp.y);
        }

        IEnumerator Shockwave(Image im, float dur)
        {
            float t0 = Time.time; var rt = im.rectTransform;
            while (Time.time - t0 < dur) { if (im == null) yield break; float p = (Time.time - t0) / dur; rt.localScale = Vector3.one * (1 + (1 - (1 - p) * (1 - p) * (1 - p)) * 2.6f); var c = im.color; c.a = .8f * (1 - p) * (1 - p); im.color = c; yield return null; }
            if (im != null) Destroy(im.gameObject);
        }

        IEnumerator FlyValue(int value, Vector2 from, Vector2 to, float dur)
        {
            string s=BombPresentation.Label(value);if(s.Length==0)yield break;
            if(_freshDigits==null)_freshDigits=LoadPng("fresh_digits");
            var root=new GameObject("fly",typeof(RectTransform));root.layer=_fx.gameObject.layer;var rt=(RectTransform)root.transform;rt.SetParent(_fx,false);Place(rt,from,new Vector2(_cs*1.1f,_cs*.35f));_fxObjs.Add(root);
            float width=_cs*1.1f/s.Length;
            for(int k=0;k<s.Length;k++){var glyph=Img("ValueGlyph",rt,GwyfShared.FreshAtlas.ValueGlyph(_freshDigits,s[k]));glyph.preserveAspect=false;Place(glyph.rectTransform,new Vector2((k-(s.Length-1)*.5f)*width,0),new Vector2(width,_cs*.35f));}
            float t0 = Time.time;
            while (Time.time - t0 < dur)
            {
                float p = (Time.time - t0) / dur, e = p * p * (3 - 2 * p);
                if (rt == null) yield break;
                rt.anchoredPosition = Vector2.Lerp(from, to, e) + new Vector2(0, Mathf.Sin(p * Mathf.PI) * _cs * 1.2f);
                rt.localScale = Vector3.one * (1.3f - .5f * p); yield return null;
            }
            if (root != null) Destroy(root);
        }

        IEnumerator Pop(Transform tr)
        {
            float t0 = Time.time;
            while (Time.time - t0 < .5f) { float el = Time.time - t0; if (tr == null) yield break; tr.localScale = Vector3.one * (1 + .24f * Mathf.Exp(-7f * el) * Mathf.Sin(el * 22f)); yield return null; }   // damped spring
            if (tr != null) tr.localScale = Vector3.one;
        }

        IEnumerator IntroRoutine(SgMsg m, bool t)
        {
            _bannerIcon.sprite = Spr("sym_scatter"); _bannerText.text = "<size=60%>" + (m.by == 1 ? "BONUS BOUGHT" : "CONGRATULATIONS") + "</size>\n10 FREE SPINS";
            _bannerSub.text = "rainbow bombs multiply the win of their spin  \u2022  3+ scatters = +5 spins";
            SetBg(true);
            float d = SgTiming.Intro(t) - .1f, t0 = Time.time;
            ShowBanner(d + .2f); _particleBudget = 40;
            StartCoroutine(Particles(new Vector2(0, _gh * .3f), Gold, 30, d * .6f, _gw * .6f));
            while (Time.time - t0 < d)
            {
                float p = (Time.time - t0) / d;
                float s = p < .15f ? Mathf.SmoothStep(0, 1.15f, p / .15f) : 1 + .05f * Mathf.Sin(p * 20);
                _bannerText.transform.localScale = Vector3.one * s; _bannerIcon.rectTransform.localRotation = Quaternion.Euler(0, 0, -p * 540);
                _bannerIcon.rectTransform.localScale = Vector3.one * (.8f + .2f * Mathf.Sin(p * 8));
                var c = _bannerDim.color; c.a = .78f * Mathf.Clamp01(Mathf.Min(p * 8, (1 - p) * 8)); _bannerDim.color = c;
                yield return null;
            }
            HideBanner(); _bannerDim.color = new Color(.05f, 0, .12f, .78f);
            _panelTitle.text = "FREE SPINS"; _panelValue.text = Money(0); _panelMulti.text = ""; _panelSub.text = "TOTAL WIN\n" + Money(m.tot);
        }

        IEnumerator EndRoutine(SgMsg m)
        {
            _lastWinX = m.tot; RefreshBar(); SetBg(false);
            if (m.fsn <= 0 && m.tot < 10) { yield break; }
            Sfx(finaltextSFX, m.tot);
            _bannerIcon.sprite = Spr("logo");
            _bannerIcon.rectTransform.localRotation = Quaternion.identity; _bannerIcon.rectTransform.localScale = Vector3.one;
            string title = m.tot >= 100 ? "MEGA WIN" : m.tot >= 50 ? "SUPER WIN" : m.tot >= 20 ? "BIG WIN" : "TOTAL WIN";
            _bannerSub.text = m.fsn > 0 ? $"in {m.fsn} free spins  \u2022  {m.tot:0.##}x bet" : $"{m.tot:0.##}x bet";
            float d = m.tb == 1 ? 1.5f : 3f, t0 = Time.time;
            ShowBanner(d + (m.tb == 1 ? 1f : 2.5f) + .2f); _particleBudget = 40;
            StartCoroutine(Particles(new Vector2(0, 0), Gold, 40, d * .8f, _gw * .7f));
            while (Time.time - t0 < d)
            {
                float p = Mathf.Clamp01((Time.time - t0) / (d * .7f));
                _bannerText.text = $"<size=55%>{title}</size>\n" + Money(m.tot * (1 - Mathf.Pow(1 - p, 3)));
                _bannerText.transform.localScale = Vector3.one * (1 + .06f * Mathf.Sin(Time.time * 9)); yield return null;
            }
            _bannerText.text = $"<size=55%>{title}</size>\n" + Money(m.tot);
            yield return new WaitForSeconds(m.tb == 1 ? 1f : 2.5f);
            HideBanner();
        }
    }
}
