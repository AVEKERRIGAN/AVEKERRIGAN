using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using Mirror;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace SugarGalaxy
{
    /// v1.1.0: on-screen HUD (raycast/E clickable), reel-style spin-in with anticipation, scatter zoom + flash,
    /// AUTO, late-join state sync, transient visual reset.
    public partial class SugarGalaxyGame
    {
        Vector2 _uiSize, _uiBasePos, _gridCenter;
        Image _hudTurbo, _hudAuto, _hudSpin, _colGlow, _flash;
        TextMeshProUGUI _hudAutoText;

        /// Rects in panel space: x from left, y from BOTTOM (0..1). Shared by the drawn HUD and the world colliders.
        public struct BtnDef { public string id, sprite, tip; public float cx, cy, w, h; public BtnDef(string i, string s, string t, float x, float y, float ww, float hh) { id = i; sprite = s; tip = t; cx = x; cy = y; w = ww; h = hh; } }
        public static readonly BtnDef[] Buttons = {
            // v1.2.0 Sweet-Bonanza-style layout (matches mockup_cabinet.png): left BUY FEATURE + BET/DOUBLE CHANCE, round SPIN with -/+ bottom right
            new BtnDef("Buy",   null,         "Buy feature (100x bet)",    .135f, .725f, .23f, .19f),
            new BtnDef("Ante",  null,         "Double chance",             .135f, .47f,  .23f, .27f),
            new BtnDef("Minus", "btn_minus",  "Bet -",                     .80f,  .045f, .05f, .0625f),
            new BtnDef("Plus",  "btn_plus",   "Bet +",                     .862f, .045f, .05f, .0625f),
            new BtnDef("Turbo", "btn_turbo",  "Turbo",                     .66f,  .045f, .045f, .056f),
            new BtnDef("Spin",  "btn_spin",   "Spin",                      .935f, .155f, .115f, .144f),
            new BtnDef("Auto",  "btn_auto",   "Auto spin",                 .72f,  .045f, .045f, .056f),
        };
        static BtnDef BtnRect(string id) => Buttons.First(b => b.id == id);
        void PlaceN(RectTransform rt, BtnDef b) { rt.anchorMin = rt.anchorMax = new Vector2(b.cx, b.cy); rt.pivot = new Vector2(.5f, .5f); rt.sizeDelta = new Vector2(_uiSize.x * b.w, _uiSize.y * b.h); rt.anchoredPosition = Vector2.zero; }

        void BuildHud()
        {
            _uiBasePos = _ui.anchoredPosition;
            foreach (var b in Buttons)
            {
                if (b.sprite == null) continue;
                var im = Img("Hud" + b.id, _ui, Spr(b.sprite)); im.preserveAspect = true; PlaceN(im.rectTransform, b);
                if (im.sprite == null) im.color = new Color(.8f, .3f, .7f, .8f);
                if (b.id == "Turbo") _hudTurbo = im; else if (b.id == "Auto") _hudAuto = im; else if (b.id == "Spin") _hudSpin = im;
            }
            _hudAutoText = Txt("HudAutoN", _ui, Color.white); var a = BtnRect("Auto");
            _hudAutoText.rectTransform.anchorMin = new Vector2(a.cx - .03f, .0f); _hudAutoText.rectTransform.anchorMax = new Vector2(a.cx + .03f, .02f); _hudAutoText.rectTransform.offsetMin = _hudAutoText.rectTransform.offsetMax = Vector2.zero; _hudAutoText.text = "";
            _colGlow = Img("ColGlow", _grid, Spr("glow")); _colGlow.preserveAspect = false; _colGlow.gameObject.SetActive(false); _colGlow.transform.SetAsFirstSibling();
            _flash = Img("Flash", _ui); _flash.color = new Color(1, 1, 1, 0); Stretch(_flash.rectTransform); _flash.gameObject.SetActive(false);
        }

        void HudTurbo(bool on) { if (_hudTurbo != null) _hudTurbo.sprite = Spr(on ? "btn_turbo_on" : "btn_turbo") ?? _hudTurbo.sprite; }
        void UpdateAutoVisual(int left)
        {
            GwyfShared.ToggleTint.Ui(_hudAuto, left > 0);
            if (_hudAuto != null) _hudAuto.sprite = Spr(left > 0 ? "btn_auto_on" : "btn_auto") ?? _hudAuto.sprite;
            if (_hudAutoText != null) _hudAutoText.text = left > 0 ? left.ToString() : "";
        }
        void UpdateHudSpin() { if (_hudSpin == null) return; if (_anim != null && _spinning) _hudSpin.transform.Rotate(0, 0, -540f * Time.deltaTime); else _hudSpin.transform.localRotation = Quaternion.identity; }
        bool _spinning;

        /// Clears zoom/flash/anticipation left over when an animation is interrupted by a newer RPC or a scene change.
        void ResetTransientVisuals()
        {
            _spinning = false;
            if (_ui == null) return;
            if (_uiSize != Vector2.zero) { _ui.localScale = Vector3.one; _ui.anchoredPosition = _uiBasePos; } GwyfShared.CamZoom.Clear(this);
            if (_flash != null) _flash.gameObject.SetActive(false);
            if (_colGlow != null) _colGlow.gameObject.SetActive(false);
            if (_hudSpin != null) _hudSpin.transform.localRotation = Quaternion.identity;
            for (int i = 0; i < N; i++) if (_cell[i] != null) { var rt = _cell[i].rectTransform; rt.localScale = Vector3.one; rt.localRotation = Quaternion.identity; rt.anchoredPosition = _home[i]; _cell[i].color = Color.white; }
        }

        /// Reel-style spin: every column scrolls random symbols, then the real ones land column by column.
        /// Once 2 scatters are visible the next columns spin longer with a glow (anticipation). Duration == SgTiming.
        IEnumerator SpinIn(SgMsg m, bool t)
        {
            // premium reel spin (shared ReelFx) for the initial drop; stop times identical to SgTiming
            var s0 = m.steps[0]; _spinning = true;
            float fall = SgTiming.Fall(t), landDur = fall * .55f;
            var landEnd = new float[C]; for (int c = 0; c < C; c++) landEnd[c] = fall + SgTiming.Stagger(t) * c + SgTiming.AntBefore(s0.g, c, t);
            var landed = new bool[C]; var landing = new bool[C]; var ct = new float[C]; var warp = new float[C]; for (int c = 0; c < C; c++) warp[c] = 1f; float lastEl = 0, dimA = 0;
            var rnd = new System.Random(GetInstanceID() ^ Time.frameCount);
            System.Func<int> pick = () => rnd.NextDouble() < .04 ? SugarEngine.SCATTER : rnd.Next(SugarEngine.NSYM);
            System.Func<int, Sprite> sharp = id => SymSprite(id, 0);
            System.Func<int, Sprite> blur = id => BlurOf(sharp(id));
            float speed = t ? 16f : 11f;
            for (int c = 0; c < C; c++) { _reel[c].BlurOf = BlurOf; _reel[c].Start(sharp, blur, pick); }
            for (int i = 0; i < N; i++) _cell[i].enabled = true;
            float t0 = Time.time, end = landEnd[C - 1]; int scShown = 0;
            while (true)
            {
                float el = Time.time - t0; int antCol = -1;
                for (int c = 0; c < C; c++)
                {
                    float ls = landEnd[c] - landDur;
                    if (el < ls)
                    {
                        bool ant = c > 0 && landed[c - 1] && SgTiming.AntCol(s0.g, c);
                        warp[c] = Mathf.MoveTowards(warp[c], ant ? .5f : 1f, (el - lastEl) * 1.2f); ct[c] += (el - lastEl) * warp[c];
                        _reel[c].Spin(ct[c], speed, pick);
                        if (antCol < 0 && SgTiming.AntCol(s0.g, c) && (c == 0 || landed[c - 1])) antCol = c;
                    }
                    else
                    {
                        if (!landing[c]) { landing[c] = true; var fin = new Sprite[R]; for (int r = 0; r < R; r++) fin[r] = SymSprite(s0.g[c * R + r], s0.bv[c * R + r]); _reel[c].BeginLand(fin, landDur, BlurOf); }
                        float p = Mathf.Clamp01((el - ls) / landDur); _reel[c].Land(p);
                        if (!landed[c] && p >= .55f)
                        {
                            landed[c] = true;
                            for (int r = 0; r < R; r++) { int i = c * R + r; if (s0.g[i] == SugarEngine.SCATTER) { scShown++;  StartCoroutine(LandDust(i)); } }
                            Sfx(spinDoneSFX, 0);
                        }
                    }
                }
                dimA = Mathf.MoveTowards(dimA, antCol >= 0 ? .5f : 0f, (el - lastEl) * 2.5f);
                for (int c = 0; c < C; c++) if (_dim != null && _dim[c] != null) { _dim[c].color = new Color(0, 0, 0, c == antCol ? 0f : dimA); _dim[c].transform.SetAsLastSibling(); }
                lastEl = el;
                if (_frameGlow != null) { float fa = el < end - .2f ? Mathf.Clamp01(el / .3f) : Mathf.Clamp01((end - el) / .2f); _frameGlow.color = new Color(1f, .6f, .9f, (antCol >= 0 ? .5f : .25f) * fa * (.85f + .15f * Mathf.Sin(el * (antCol >= 0 ? 14f : 6f)))); }
                if (antCol >= 0)
                {
                    if (!_colGlow.gameObject.activeSelf) { _colGlow.gameObject.SetActive(true); Sfx(multiplierSFX, 5f); }
                    var rt = _colGlow.rectTransform; rt.anchorMin = rt.anchorMax = new Vector2(.5f, .5f); rt.sizeDelta = new Vector2(_cs * 1.15f, _gh * 1.04f);
                    rt.anchoredPosition = new Vector2(-_gw / 2 + _cs * (antCol + .5f), 0);
                    _colGlow.color = new Color(1f, .6f, .9f, .45f + .35f * Mathf.Sin(el * 14f));
                    if (_winLabel != null) _winLabel.text = $"<color=#7dfcff>{scShown} SCATTERS...</color>";
                }
                else if (_colGlow.gameObject.activeSelf) _colGlow.gameObject.SetActive(false);
                if (el >= end) break;
                yield return null;
            }
            _colGlow.gameObject.SetActive(false); if (_winLabel != null) _winLabel.text = "";
            if (_frameGlow != null) _frameGlow.color = new Color(1, 1, 1, 0);
            if (_dim != null) foreach (var dm in _dim) if (dm != null) dm.color = new Color(0, 0, 0, 0);
            for (int c = 0; c < C; c++) _reel[c].Finish();
            for (int i = 0; i < N; i++) SetCell(i, s0.g[i], s0.bv[i]);
            _spinning = false;
        }

        /// special landing: flash ring + sparks (visual only, timing-neutral)
        IEnumerator LandDust(int i)
        {
            StartCoroutine(Particles(_home[i], new Color(1f, .6f, .9f), 12, .5f, _cs * .8f));
            var fl = FxImg("glow", _home[i], _cs * 1.2f, new Color(1, 1, 1, .45f)); float t0 = Time.time;
            while (Time.time - t0 < .35f) { if (fl == null) yield break; float p = (Time.time - t0) / .35f, e = 1 - (1 - p) * (1 - p) * (1 - p); fl.GetComponent<Image>().color = new Color(1, 1, 1, .35f * Mathf.Min(1f, p * 8f) * (1 - p) * (1 - p)); fl.transform.localScale = Vector3.one * (1 + e * .5f); yield return null; }
            if (fl != null) Destroy(fl);
        }

        /// Bonus trigger: slow push-in on the last scatter, then a sharp zoom with a white flash, then back.
        IEnumerator ZoomScatter(List<int> scs, bool t)
        {
            // cinematic: eased push-in -> impact punch (ease-out back) + flash + shockwave -> hold -> eased pull-out. Total == SgTiming.Zoom
            int last = scs[scs.Count - 1];
            Vector2 c = _gridCenter + _home[last];
            float T = SgTiming.Zoom(t), tIn = T * .42f, tPunch = T * .16f, tHold = T * .17f, tOut = T - tIn - tPunch - tHold;
            const float Z1 = 1.1f, Z2 = 1.38f;
            _winLabel.text = "";
            bool hit = false; float t0 = Time.time; Image ring = null;
            while (true)
            {
                float el = Time.time - t0; if (el >= T) break;
                float s, shake = 0;
                if (el < tIn) { float q = el / tIn; s = Mathf.Lerp(1f, Z1, q * q * (3 - 2 * q)); }
                else if (el < tIn + tPunch)
                {
                    float q = (el - tIn) / tPunch; s = Mathf.LerpUnclamped(Z1, Z2, GwyfShared.ReelFx.EaseOutBack(q, 1.2f));
                    if (!hit)
                    {
                        hit = true; Sfx(multiplierSFX, 50f); _flash.gameObject.SetActive(true); _flash.transform.SetAsLastSibling();
                        ring = Img("Shock", _fx, Spr("glow")); ring.preserveAspect = true; ring.raycastTarget = false; _fxObjs.Add(ring.gameObject); Place(ring.rectTransform, _home[last], Vector2.one * _cs);
                        _particleBudget = 40; StartCoroutine(Particles(_home[last], new Color(1f, .6f, .9f), 24, T * .4f, _cs * 1.6f));
                        _winLabel.text = $"<color=#ff9be6>{scs.Count} SCATTERS!</color>";
                    }
                    shake = (1 - q) * (1 - q) * _cs * .01f;
                }
                else if (el < tIn + tPunch + tHold) s = Z2;
                else { float q = (el - tIn - tPunch - tHold) / tOut; s = Mathf.Lerp(Z2, 1f, q * q * (3 - 2 * q)); }
                var sh = shake > 0 ? new Vector2(Mathf.Sin(el * 90f), Mathf.Cos(el * 77f)) * shake : Vector2.zero;
                _ui.localScale = Vector3.one; _ui.anchoredPosition = _uiBasePos; GwyfShared.CamZoom.Set(this, _ui.TransformPoint(c), s * (1f + sh.magnitude * .002f)); // camera zoom; screen stays put
                if (hit)
                {
                    float he = el - tIn, fa = Mathf.Clamp01(1f - he / (tPunch + tHold * .6f)); _flash.color = new Color(1, 1, 1, .28f * fa * fa * Mathf.Clamp01(he / .06f));
                    if (ring != null) { float rq = Mathf.Clamp01(he / (tPunch + tHold)); ring.rectTransform.localScale = Vector3.one * (1f + rq * 4f); ring.color = new Color(1f, .6f, .9f, .45f * (1 - rq) * (1 - rq)); }
                }
                foreach (var i in scs) { float pul = i == last ? .12f : .06f; _cell[i].rectTransform.localScale = Vector3.one * (1f + pul * (.5f - .5f * Mathf.Cos(el * 7f))); }
                yield return null;
            }
            if (ring != null) Destroy(ring.gameObject);
            _ui.localScale = Vector3.one; _ui.anchoredPosition = _uiBasePos; GwyfShared.CamZoom.Clear(this); _flash.gameObject.SetActive(false);
            foreach (var i in scs) _cell[i].rectTransform.localScale = Vector3.one;
        }

        // ---------------- server: screen buttons, AUTO, late-join sync ----------------
        int _autoLeft; PlayerInteract _autoPi; bool _autoRound;

        void HookScreenButtons()
        {
            foreach (var trig in GetComponentsInChildren<InteractableEventTrigger>(true))
            {
                if (!trig.name.StartsWith("SGScr_")) continue;
                switch (trig.name.Substring(6))
                {
                    case "Spin": Hook(trig, TryStartGame); break;
                    case "Buy": Hook(trig, TryBuyBonus); break;
                    case "Ante": Hook(trig, ToggleAnte); break;
                    case "Turbo": Hook(trig, ToggleTurbo); break;
                    case "Plus": Hook(trig, p => StepBet(+1)); break;
                    case "Minus": Hook(trig, p => StepBet(-1)); break;
                    case "Auto": Hook(trig, ToggleAuto); break;
                }
            }
        }

        [Server]
        public void ToggleAuto(PlayerInteract pi)
        {
            if (!NetworkServer.active) return;
            if (_autoLeft > 0) { _autoLeft = 0; _autoPi = null; Broadcast(new SgMsg { t = "auto", fsi = 0, tb = turbo ? 1 : 0, an = ante ? 1 : 0 }); SugarGalaxyPlugin.V("Auto OFF"); return; }
            if (pi == null) return;
            _autoLeft = Mathf.Clamp(SugarGalaxyPlugin.AutoSpins?.Value ?? 10, 1, 100); _autoPi = pi;
            Broadcast(new SgMsg { t = "auto", fsi = _autoLeft, tb = turbo ? 1 : 0, an = ante ? 1 : 0 });
            SugarGalaxyPlugin.V($"Auto ON: {_autoLeft} spins");
            if (!isPlaying) StartCoroutine(AutoNext(0.05f));
        }

        void ContinueAuto(bool bonusHit, bool byAuto)
        {
            if (_autoLeft <= 0) return;
            if (byAuto) { _autoLeft--; if (bonusHit && (SugarGalaxyPlugin.AutoStopOnBonus?.Value ?? true)) _autoLeft = 0; }
            if (_autoPi == null) _autoLeft = 0;
            Broadcast(new SgMsg { t = "auto", fsi = _autoLeft, tb = turbo ? 1 : 0, an = ante ? 1 : 0 });
            if (_autoLeft > 0) StartCoroutine(AutoNext(turbo ? .3f : .8f));
        }

        IEnumerator AutoNext(float delay)
        {
            yield return new WaitForSeconds(delay);
            if (_autoLeft <= 0 || _autoPi == null || isPlaying) yield break;
            _autoRound = true;
            try { TryStartGame(_autoPi); } catch (Exception e) { SugarGalaxyPlugin.Log.LogError(e); }
            if (!isPlaying) { _autoRound = false; _autoLeft = 0; Broadcast(new SgMsg { t = "auto", fsi = 0, tb = turbo ? 1 : 0, an = ante ? 1 : 0 }); SugarGalaxyPlugin.V("Auto stopped (spin refused: money/bet)"); }
        }

        int _lastConnCount = -1; float _nextSync;
        void ServerStateSync()
        {
            if (!NetworkServer.active || Time.unscaledTime < _nextSync) return;
            _nextSync = Time.unscaledTime + 2f;
            int n = NetworkServer.connections.Count; if (n == _lastConnCount) return;
            _lastConnCount = n;
            string bet = null; double bn = 0; try { if (!currentBet.IsZero) { bet = FormatBet(currentBet); bn = currentBet.ToDouble(); } } catch { }
            Broadcast(new SgMsg { t = "bet", bet = bet, bn = bn, tb = turbo ? 1 : 0, an = ante ? 1 : 0 });
            Broadcast(new SgMsg { t = "auto", fsi = _autoLeft, tb = turbo ? 1 : 0, an = ante ? 1 : 0 });
        }

        // ---------------- prefab: invisible raycast colliders over the screen ----------------
        public static void CreateScreenButtons(SugarGalaxyGame game, GameObject clone)
        {
            var play = game.playButtons.FirstOrDefault(); if (play == null) { SugarGalaxyPlugin.Log.LogWarning("[SG] Screen buttons: no play button template"); return; }
            RenderTexture rtex = GwyfShared.ScreenIso.FindRT(clone);
            Renderer scr = null;
            foreach (var r in clone.GetComponentsInChildren<Renderer>(true))
            {
                if (rtex == null || scr != null) break;
                foreach (var m in r.sharedMaterials) if (m != null) foreach (var p in m.GetTexturePropertyNames()) if (m.GetTexture(p) == rtex) scr = r;
            }
            var mf = scr != null ? scr.GetComponent<MeshFilter>() : null;
            if (scr == null || mf == null || mf.sharedMesh == null) SugarGalaxyPlugin.Log.LogWarning($"[SG] Screen buttons: screen mesh not found (rt={(rtex != null)}, renderer={(scr != null)}) - use the cabinet buttons");
            Bounds b = mf != null && mf.sharedMesh != null ? mf.sharedMesh.bounds : new Bounds(Vector3.zero, Vector3.one);
            Vector3 ext = b.size; int nAx = ext.x <= ext.y && ext.x <= ext.z ? 0 : ext.y <= ext.z ? 1 : 2;
            int[] rest = new[] { 0, 1, 2 }.Where(a => a != nAx).ToArray();
            int uAx = ext[rest[0]] >= ext[rest[1]] ? rest[0] : rest[1], vAx = uAx == rest[0] ? rest[1] : rest[0];
            float uSign = 1f, vSign = 1f;
            try
            {
                var mesh = mf != null ? mf.sharedMesh : null;
                if (mesh != null && mesh.isReadable)
                {
                    var vs = mesh.vertices; var uv = mesh.uv;
                    if (uv != null && uv.Length == vs.Length && vs.Length >= 3)
                    {
                        int iu0 = 0, iu1 = 0, iv0 = 0, iv1 = 0;
                        for (int i = 1; i < uv.Length; i++) { if (uv[i].x < uv[iu0].x) iu0 = i; if (uv[i].x > uv[iu1].x) iu1 = i; if (uv[i].y < uv[iv0].y) iv0 = i; if (uv[i].y > uv[iv1].y) iv1 = i; }
                        Vector3 du = vs[iu1] - vs[iu0];
                        uAx = Mathf.Abs(du[rest[0]]) >= Mathf.Abs(du[rest[1]]) ? rest[0] : rest[1]; vAx = uAx == rest[0] ? rest[1] : rest[0];
                        uSign = Mathf.Sign(du[uAx]); vSign = Mathf.Sign((vs[iv1] - vs[iv0])[vAx]);
                        if (uSign == 0) uSign = 1; if (vSign == 0) vSign = 1;
                        SugarGalaxyPlugin.V($"Screen UV orientation from mesh: u=axis{uAx}{(uSign > 0 ? "+" : "-")} v=axis{vAx}{(vSign > 0 ? "+" : "-")}");
                    }
                }
            }
            catch (Exception e) { SugarGalaxyPlugin.V("Screen UV read failed: " + e.Message); }
            if (SugarGalaxyPlugin.ScreenFlipX != null && SugarGalaxyPlugin.ScreenFlipX.Value) uSign = -uSign;
            if (SugarGalaxyPlugin.ScreenFlipY != null && SugarGalaxyPlugin.ScreenFlipY.Value) vSign = -vSign;
            float margin = SugarGalaxyPlugin.ScreenMargin != null ? Mathf.Clamp(SugarGalaxyPlugin.ScreenMargin.Value, 0f, .2f) : .03f;
            Transform parent = scr != null ? scr.transform : game.transform;
            float nScale = Mathf.Max(1e-4f, Mathf.Abs(parent.lossyScale[nAx]));
            int made = 0;
            foreach (var d in Buttons)
            {
                var go = UnityEngine.Object.Instantiate(play.gameObject, parent); go.name = "SGScr_" + d.id;
                for (int i = go.transform.childCount - 1; i >= 0; i--) UnityEngine.Object.DestroyImmediate(go.transform.GetChild(i).gameObject);
                foreach (var c in go.GetComponents<Collider>()) UnityEngine.Object.DestroyImmediate(c);
                foreach (var c in go.GetComponents<Renderer>()) UnityEngine.Object.DestroyImmediate(c);
                foreach (var c in go.GetComponents<MeshFilter>()) UnityEngine.Object.DestroyImmediate(c);
                go.transform.localRotation = Quaternion.identity; go.transform.localScale = Vector3.one;
                float u = .5f + (d.cx - .5f) * (1f - 2f * margin), v = .5f + (d.cy - .5f) * (1f - 2f * margin);
                Vector3 pos = b.center, size = Vector3.zero;
                pos[uAx] += uSign * (u - .5f) * ext[uAx]; pos[vAx] += vSign * (v - .5f) * ext[vAx];
                size[uAx] = d.w * (1f - 2f * margin) * ext[uAx]; size[vAx] = d.h * (1f - 2f * margin) * ext[vAx]; size[nAx] = .05f / nScale;
                go.transform.localPosition = pos;
                var bc = go.AddComponent<BoxCollider>(); bc.size = size;
                var trig = go.GetComponent<InteractableEventTrigger>();
                if (trig != null)
                {
                    foreach (var ev in new UnityEngine.Events.UnityEventBase[] { trig.onInteractEvent, trig.serverOnInteractEvent, trig.rpcOnInteractEvent, trig.onHoverEvent, trig.onHoverExitEvent, trig.onHoldEvent, trig.onHoldExitEvent })
                        if (ev != null) for (int i = 0; i < ev.GetPersistentEventCount(); i++) ev.SetPersistentListenerState(i, UnityEngine.Events.UnityEventCallState.Off);
                    try { AccessTools.Field(typeof(InteractableBase), "tooltipMessage").SetValue(trig, "[E] " + d.tip); } catch { }
                    try { AccessTools.Field(typeof(InteractableBase), "interactableName").SetValue(trig, "Sugar Galaxy: " + d.tip); } catch { }
                }
                made++;
            }
            SugarGalaxyPlugin.V($"Screen buttons: {made} colliders on '{(scr != null ? scr.name : "machine root")}' (normal axis {nAx}, mesh size {ext})");
        }
    }
}
