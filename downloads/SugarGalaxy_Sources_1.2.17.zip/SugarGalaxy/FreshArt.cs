using UnityEngine;
namespace SugarGalaxy
{
    public partial class SugarGalaxyGame
    {
        static Texture2D _freshSheet, _freshDigits, _freshLogos;
        static Sprite FreshSpriteKey(string key)
        {
            if (key.StartsWith("blur_")) key = "sym_" + key.Substring(5);
            if (key == "logo" || key == "topper")
            {
                if (_freshLogos == null) _freshLogos = LoadPng("fresh_logos");
                return GwyfShared.FreshAtlas.Logo(_freshLogos, 2);
            }
            if (_freshSheet == null) _freshSheet = LoadPng("fresh_atlas");

            if (key.StartsWith("sym_bomb_x") && int.TryParse(key.Substring(10), out int bomb))
            {
                if (_freshDigits == null) _freshDigits = LoadPng("fresh_digits");
                return GwyfShared.FreshAtlas.Sprite(_freshSheet, 4, 4, bomb < 20 ? 10 : 11, bomb, _freshDigits, .43f, .55f, .22f);
            }

            int index;
            switch (key)
            {
                case "sym_banana": index = 0; break;
                case "sym_grapes": index = 1; break;
                case "sym_melon": index = 2; break;
                case "sym_plum": index = 3; break;
                case "sym_apple": index = 4; break;
                case "sym_blue": index = 5; break;
                case "sym_green": index = 6; break;
                case "sym_purple": index = 7; break;
                case "sym_heart": index = 8; break;
                case "sym_scatter": index = 9; break;
                default: return null;
            }
            return GwyfShared.FreshAtlas.Sprite(_freshSheet, 4, 4, index);
        }
    }
}
