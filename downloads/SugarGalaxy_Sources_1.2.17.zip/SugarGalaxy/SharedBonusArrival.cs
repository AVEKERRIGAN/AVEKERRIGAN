using System.Collections;
using UnityEngine;
using UnityEngine.UI;

namespace GwyfShared
{
    public static class BonusArrival
    {
        public static IEnumerator Pulse(Image symbol, Image glow, Color color)
        {
            if (symbol == null) yield break;
            float started = Time.time;
            if (glow != null) { glow.gameObject.SetActive(true); glow.color = color; }
            while (Time.time - started < .38f)
            {
                if (symbol == null) yield break;
                float p = (Time.time - started) / .38f;
                symbol.rectTransform.localScale = Vector3.one * (1f + .22f * Mathf.Sin(p * Mathf.PI) * (1 - p * .3f));
                if (glow != null) { var c = color; c.a = .75f * Mathf.Sin(p * Mathf.PI); glow.color = c; glow.rectTransform.localScale = Vector3.one * (1f + p * .25f); }
                yield return null;
            }
            if (symbol != null) symbol.rectTransform.localScale = Vector3.one;
            if (glow != null) { glow.rectTransform.localScale = Vector3.one; glow.gameObject.SetActive(false); }
        }
    }
}
