using System;
using System.Collections.Generic;

namespace SugarGalaxy
{
    /// 6x5 pays-anywhere tumble slot. Pure logic, shared by the plugin (host) and the offline simulator.
    public static class SugarEngine
    {
        public const int Cols = 6, Rows = 5, Cells = 30;
        public const int SCATTER = 9, BOMB = 10, NSYM = 9;
        public const double MaxWinX = 21100;
        public static readonly string[] Names = { "Banana", "Grapes", "Watermelon", "Plum", "Apple", "Blue Candy", "Green Candy", "Purple Candy", "Red Heart" };
        public static readonly string[] ArtKeys = { "banana", "grapes", "melon", "plum", "apple", "blue", "green", "purple", "heart" };
        /// v1.2.0: original rule = 8+ anywhere. Configurable (MinMatch config); values below 8 pay the 8-9 tier and are NOT RTP-tuned.
        public static int MinMatch = 8;
        // original paytable, x total bet, tiers 8-9 / 10-11 / 12+
        public static double[,] Pay = {
            {0.25,0.75,2},{0.4,0.9,4},{0.5,1,5},{0.8,1.2,8},{1,1.5,10},{1.5,2,12},{2,5,15},{2.5,10,25},{10,25,50} };
        public static void ScalePay(double f){ for(int i=0;i<Pay.GetLength(0);i++) for(int j=0;j<Pay.GetLength(1);j++) Pay[i,j]=Math.Round(Pay[i,j]*f,3); }
        public static readonly int[] BombVals = { 2, 3, 4, 5, 6, 8, 10, 12, 15, 20, 25, 50, 100 };
        public static readonly double[] BombW = { 1 };
        public static double[] BombWFree = { 24, 18, 14, 11, 9, 7, 5.5, 4, 3, 2, 1.4, 0.6, 0.25 };

        // tunable weights (relative), chances per cell
        public static double[] SymW = { 23.075, 19.535, 17.035, 14, 11.165, 8.165, 6.165, 4.165, 1.7 };
        public static double[] SymWFree = { 24.69, 20.69, 17.845, 14, 10.655, 7.655, 5.655, 3.905, 1.53 }; // free-spin reels are richer (like the original FS reel set)
        public static double ScatterChance = 0.0132;     // per cell, base game
        public static double ScatterChanceFree = 0.006; // per cell during free spins (retriggers)
        public static double BombChanceBase = 0;      // original: bombs only in free spins    // per cell, base game (rare)
        public static double BombChanceFree = 0.05;    // per cell during free spins
        public static double AnteScatterMult = 1.27;  // per-cell; gives ~2.2x bonus frequency (original: "doubles the chance")
        public const double AnteCost = 1.25;
        public const int BuyCostX = 100;

        [Serializable] public class Step { public int[] g; public int[] bv; public int[] win; public double w; public int[] ws; }
        public class Spin
        {
            public List<Step> steps = new List<Step>();
            public double tumbleWin;     // sum of steps (before bombs)
            public int bombSum;          // bombs on the final grid (0 if none)
            public double scatterPay;
            public int scatters;
            public double win;           // final win of this spin (x bet)
            public int totalMulti;       // FS: multiplier applied to this spin (per tumble sequence, not carried)
        }
        public class Round { public Spin baseSpin; public List<Spin> free = new List<Spin>(); public int fsAwarded; public double total; public bool capped; }

        static int Pick(Random r, double[] w) { double s = 0; foreach (var x in w) s += x; double v = r.NextDouble() * s; for (int i = 0; i < w.Length; i++) { v -= w[i]; if (v < 0) return i; } return w.Length - 1; }

        static void Fill(Random r, int[] g, int[] bv, int cell, bool free, bool ante)
        {
            double sc = (free ? ScatterChanceFree : ScatterChance) * (ante && !free ? AnteScatterMult : 1);
            double bc = free ? BombChanceFree : BombChanceBase;
            double v = r.NextDouble();
            if (v < sc) { g[cell] = SCATTER; bv[cell] = 0; return; }
            if (v < sc + bc) { g[cell] = BOMB; bv[cell] = BombVals[Pick(r, free ? BombWFree : BombW)]; return; }
            g[cell] = Pick(r, free ? SymWFree : SymW); bv[cell] = 0;
        }
        public static int Idx(int c, int row) => c * Rows + row; // row 0 = top

        public static Spin PlaySpin(Random r, bool free, bool ante, int forceScatters = 0)
        {
            var g = new int[Cells]; var bv = new int[Cells];
            for (int i = 0; i < Cells; i++) Fill(r, g, bv, i, free, ante);
            if (forceScatters > 0)
            {
                int have = 0; foreach (var x in g) if (x == SCATTER) have++;
                while (have < forceScatters)
                {
                    int c = r.Next(Cells); if (g[c] == SCATTER) continue;
                    // max one forced scatter per column keeps it looking natural
                    g[c] = SCATTER; bv[c] = 0; have++;
                }
            }
            var s = new Spin();
            for (int guard = 0; guard < 60; guard++)
            {
                var cnt = new int[NSYM]; for (int i = 0; i < Cells; i++) if (g[i] < NSYM) cnt[g[i]]++;
                var win = new List<int>(); var ws = new List<int>(); double w = 0;
                for (int k = 0; k < NSYM; k++) if (cnt[k] >= MinMatch)
                    {
                        w += Pay[k, cnt[k] >= 12 ? 2 : cnt[k] >= 10 ? 1 : 0]; ws.Add(k);
                        for (int i = 0; i < Cells; i++) if (g[i] == k) win.Add(i);
                    }
                s.steps.Add(new Step { g = (int[])g.Clone(), bv = (int[])bv.Clone(), win = win.ToArray(), w = w, ws = ws.ToArray() });
                if (w <= 0) break;
                s.tumbleWin += w;
                // gravity + refill
                var dead = new bool[Cells]; foreach (var i in win) dead[i] = true;
                for (int c = 0; c < Cols; c++)
                {
                    var keepG = new List<int>(); var keepB = new List<int>();
                    for (int row = Rows - 1; row >= 0; row--) { int i = Idx(c, row); if (!dead[i]) { keepG.Add(g[i]); keepB.Add(bv[i]); } }
                    for (int row = Rows - 1, k = 0; row >= 0; row--, k++)
                    {
                        int i = Idx(c, row);
                        if (k < keepG.Count) { g[i] = keepG[k]; bv[i] = keepB[k]; } else Fill(r, g, bv, i, free, ante);
                    }
                }
            }
            for (int i = 0; i < Cells; i++) { if (g[i] == SCATTER) s.scatters++; if (g[i] == BOMB) s.bombSum += bv[i]; }
            if (!free) s.scatterPay = s.scatters >= 6 ? 100 : s.scatters == 5 ? 5 : s.scatters == 4 ? 3 : 0;
            return s;
        }

        static void Finish(Round rd)
        {
            double t = rd.baseSpin.win; foreach (var f in rd.free) t += f.win;
            if (t > MaxWinX) { t = MaxWinX; rd.capped = true; }
            rd.total = t;
        }

        public static Round Play(Random r, bool ante, bool forceBonus = false) => PlayInner(r, ante, forceBonus ? 4 : 0);
        public static Round PlayBuy(Random r) => PlayInner(r, false, 4);

        static Round PlayInner(Random r, bool ante, int force)
        {
            var rd = new Round();
            var b = PlaySpin(r, false, ante, force);
            b.win = b.tumbleWin * (b.tumbleWin > 0 && b.bombSum > 0 ? b.bombSum : 1) + b.scatterPay;
            rd.baseSpin = b;
            if (b.scatters >= 4)
            {
                int left = 10; rd.fsAwarded = 10; double run = b.win;
                while (left > 0 && rd.free.Count < 300)
                {
                    left--;
                    var f = PlaySpin(r, true, false);
                    // original rule: bombs multiply only this spin's tumble sequence, nothing carries over
                    int m = f.tumbleWin > 0 && f.bombSum > 0 ? f.bombSum : 0;
                    f.totalMulti = m;
                    f.win = f.tumbleWin * (m > 0 ? m : 1);
                    if (f.scatters >= 3) { left += 5; rd.fsAwarded += 5; }
                    rd.free.Add(f); run += f.win;
                    if (run >= MaxWinX) break;
                }
            }
            Finish(rd);
            return rd;
        }
    }
}
