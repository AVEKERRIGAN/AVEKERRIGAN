using System;
using System.Collections.Generic;
using UnityEngine;

namespace GwyfShared
{
    // Sprite rectangles retain the generated assets intact. Value labels are composed
    // at runtime from a separate gold glyph sheet, so every actual game value is preserved.
    public static class FreshAtlas
    {
        static readonly Dictionary<Texture2D, Color[]> GlyphPixels = new Dictionary<Texture2D, Color[]>();
        static readonly int[] GlyphX = { 25, 232, 394, 591, 789, 990, 1183, 1384, 1563, 1761, 1938 };
        static readonly int[] GlyphW = { 184, 144, 184, 184, 184, 178, 184, 180, 184, 184, 216 };
        static readonly Dictionary<char,Sprite> ValueGlyphs=new Dictionary<char,Sprite>();
        public static Sprite ValueGlyph(Texture2D glyphs,char c)
        {
            if(ValueGlyphs.TryGetValue(c,out var sprite))return sprite;
            int glyph=c=='X'?10:c-'0';
            if(glyph<0||glyph>10)throw new ArgumentOutOfRangeException(nameof(c));
            var rect=new Rect(GlyphX[glyph]/2172f*glyphs.width,244f/724f*glyphs.height,GlyphW[glyph]/2172f*glyphs.width,284f/724f*glyphs.height);
            return ValueGlyphs[c]=UnityEngine.Sprite.Create(glyphs,rect,new Vector2(.5f,.5f),100);
        }
        public static Sprite Logo(Texture2D atlas, int index)
        {
            float[] rows = { 0f, .225f, .445f, .650f, .840f, 1f };
            var rect = new Rect(0, (1f - rows[index + 1]) * atlas.height, atlas.width, (rows[index + 1] - rows[index]) * atlas.height);
            return UnityEngine.Sprite.Create(atlas, rect, new Vector2(.5f, .5f), 100f, 0, SpriteMeshType.FullRect);
        }
        public static Sprite Sprite(Texture2D atlas, int columns, int rows, int index, int value = 0, Texture2D glyphs = null, float centerY = .48f, float labelWidth = .52f, float labelHeight = .22f, float trimY = 0)
        {
            int width = atlas.width / columns, height = atlas.height / rows;
            int col = index % columns, row = index / columns;
            int x = col * width + 2, y = atlas.height - (row + 1) * height + 2;
            width -= 4; height -= 4;
            int trim = (int)(height * trimY); y += trim; height -= trim * 2;
            var rect = new Rect(x, y, width, height);
            if (value <= 0 || glyphs == null) return UnityEngine.Sprite.Create(atlas, rect, new Vector2(.5f, .5f), 100f, 0, SpriteMeshType.FullRect);
            var pixels = atlas.GetPixels(x, y, width, height);
            if (!GlyphPixels.TryGetValue(glyphs, out var letters)) GlyphPixels[glyphs] = letters = glyphs.GetPixels();
            string label = SugarGalaxy.BombPresentation.Label(value);
            int labelW = (int)(width * labelWidth), labelH = (int)(height * labelHeight);
            int left = (width - labelW) / 2, bottom = (int)(height * centerY - labelH / 2);
            for (int cy = 0; cy < labelH; cy++) for (int cx = 0; cx < labelW; cx++)
            {
                int dx = left + cx, dy = bottom + cy;
                if (dx < 0 || dy < 0 || dx >= width || dy >= height) continue;
                float characterPos = (float)cx / labelW * label.Length;
                int character = Math.Min(label.Length - 1, (int)characterPos);
                int glyph = label[character] == 'X' ? 10 : label[character] - '0';
                float gx = (GlyphX[glyph] + (characterPos - character) * GlyphW[glyph]) / 2172f * glyphs.width;
                float gy = (244f + (float)cy / labelH * 284f) / 724f * glyphs.height;
                var source = Sample(letters, glyphs.width, glyphs.height, gx, gy);
                if (source.a < .005f) continue;
                int offset = dy * width + dx; var target = pixels[offset];
                float alpha = source.a + target.a * (1 - source.a);
                pixels[offset] = new Color((source.r * source.a + target.r * target.a * (1 - source.a)) / alpha,
                    (source.g * source.a + target.g * target.a * (1 - source.a)) / alpha,
                    (source.b * source.a + target.b * target.a * (1 - source.a)) / alpha, alpha);
            }
            var texture = new Texture2D(width, height, TextureFormat.RGBA32, true);
            texture.SetPixels(pixels); texture.Apply(true, false); texture.wrapMode = TextureWrapMode.Clamp;
            texture.filterMode = FilterMode.Trilinear;
            texture.name = "FreshValue_" + label;
            return UnityEngine.Sprite.Create(texture, new Rect(0, 0, width, height), new Vector2(.5f, .5f), 100f, 0, SpriteMeshType.FullRect);
        }
        static Color Sample(Color[] pixels, int width, int height, float x, float y)
        {
            int ix = Mathf.Clamp((int)x, 0, width - 1), iy = Mathf.Clamp((int)y, 0, height - 1);
            int nx = Math.Min(width - 1, ix + 1), ny = Math.Min(height - 1, iy + 1);
            return Color.Lerp(Color.Lerp(pixels[iy * width + ix], pixels[iy * width + nx], x - ix),
                Color.Lerp(pixels[ny * width + ix], pixels[ny * width + nx], x - ix), y - iy);
        }
    }
}
