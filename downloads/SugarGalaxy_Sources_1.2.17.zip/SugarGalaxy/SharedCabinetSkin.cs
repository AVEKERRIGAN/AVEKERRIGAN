using System;
using UnityEngine;

namespace GwyfShared
{
    public static class CabinetSkin
    {
        // World AABBs grow when a cabinet rotates. Use actual body geometry in
        // the machine's own coordinates and exclude the elevated neon submesh.
        public static bool BodyBounds(Transform machine, out Bounds body)
        {
            body = default; float best = 0;
            foreach (var mf in machine.GetComponentsInChildren<MeshFilter>(true))
            {
                var renderer = mf.GetComponent<MeshRenderer>(); var mesh = mf.sharedMesh;
                if (renderer == null || mesh == null || !renderer.enabled || renderer.GetComponent<TMPro.TMP_Text>() != null) continue;
                if (mf.GetComponentInParent<Canvas>() != null || mf.GetComponentInParent<InteractableEventTrigger>() != null) continue;
                string name = mf.name.ToLowerInvariant();
                if (name.Contains("screen") || name.Contains("glass") || name.Contains("light") || name.Contains("ligts") || name.Contains("keypad") || name.Contains("button")) continue;
                Bounds local = default; bool any = false;
                void Add(Vector3 vertex)
                {
                    var point = machine.InverseTransformPoint(mf.transform.TransformPoint(vertex));
                    if (!any) { local = new Bounds(point, Vector3.zero); any = true; } else local.Encapsulate(point);
                }
                if (mesh.isReadable)
                {
                    var vertices = mesh.vertices; var materials = renderer.sharedMaterials;
                    for (int sub = 0; sub < mesh.subMeshCount; sub++)
                    {
                        var material = sub < materials.Length ? materials[sub] : null;
                        if (material != null && material.HasProperty("_AlbedoMap")) continue;
                        foreach (int index in mesh.GetTriangles(sub)) Add(vertices[index]);
                    }
                }
                if (!any)
                {
                    var bounds = mesh.bounds;
                    for (int corner = 0; corner < 8; corner++)
                        Add(bounds.center + Vector3.Scale(bounds.extents, new Vector3((corner & 1) == 0 ? -1 : 1, (corner & 2) == 0 ? -1 : 1, (corner & 4) == 0 ? -1 : 1)));
                }
                float score = local.size.x * local.size.y * local.size.z;
                if (local.size.y > .1f && score > best) { best = score; body = local; }
            }
            return best > 0;
        }

        public static void Build(Transform machine, Transform spinButton, string theme)
        {
            // Native cabinet textures follow its bevels/slanted front. Separate
            // poles, arches and unsupported toppers have no surface to attach to.
            var old = machine.Find("FreshCabinetSkin");
            if (old != null) { old.gameObject.SetActive(false); UnityEngine.Object.Destroy(old.gameObject); }
            foreach (var text in machine.GetComponentsInChildren<TMPro.TextMeshPro>(true))
            {
                if (!text.name.Equals("GameName", StringComparison.OrdinalIgnoreCase)) continue;
                var renderer = text.GetComponent<MeshRenderer>(); if (renderer != null) renderer.enabled = false;
            }
        }
    }
}
