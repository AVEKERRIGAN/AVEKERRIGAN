using System;
using System.Linq;
using PuppyPalace;
using ToroLeap;
using GoldRushExpress;

static partial class Checks
{
    static int count;
    static void Require(bool condition, string message)
    { count++; if (!condition) throw new Exception(message); }
    static void Payout(double value, double cap)
    { Require(!double.IsNaN(value) && !double.IsInfinity(value) && value >= 0 && value <= cap, "Invalid round payout"); }

    static void Main(string[] args)
    {
        if (args.Length == 2 && args[0] == "--export-speaker")
        {
            System.IO.File.WriteAllText(args[1], System.Text.Json.JsonSerializer.Serialize(Boombox.BoomMesh.Build(), new System.Text.Json.JsonSerializerOptions { IncludeFields = true }));
            return;
        }
        CheckNewPresentationAndAudio();
        CheckSpeaker();
        CheckWireProtocol();
        var random = new Random(20261013);
        for (int i = 0; i < 3000; i++)
        {
            var z = ThunderOlympus.ZeusEngine.Play(random, false);
            Payout(z.total, ThunderOlympus.ZeusEngine.MaxWinX);
            var s = SugarGalaxy.SugarEngine.Play(random, false);
            Payout(s.total, SugarGalaxy.SugarEngine.MaxWinX);
            var f = ReelKingLake.FishEngine.Play(random);
            Payout(f.total, ReelKingLake.FishEngine.MaxWinX);
        }
        for (int i = 0; i < 500; i++)
        {
            var z = ThunderOlympus.ZeusEngine.PlayBuy(random);
            Payout(z.total, ThunderOlympus.ZeusEngine.MaxWinX); Require(z.fsAwarded >= 10 && z.free.Count > 0, "Olympus bonus purchase");
            var s = SugarGalaxy.SugarEngine.PlayBuy(random);
            Payout(s.total, SugarGalaxy.SugarEngine.MaxWinX); Require(s.fsAwarded >= 10 && s.free.Count > 0, "Sugar bonus purchase");
            var f = ReelKingLake.FishEngine.PlayBuy(random);
            Payout(f.total, ReelKingLake.FishEngine.MaxWinX); Require(f.fsAwarded >= 10 && f.free.Count > 0, "Lake bonus purchase");
        }
        Console.WriteLine("PASS: Olympus/Sugar/Lake: 3,000 base rounds + 500 purchased bonuses each.");
        int fullToro = 0, partialToro = 0;
        for (int i = 0; i < 10000; i++)
        {
            var p = PuppyEngine.Play(random);
            Payout(p.total, PuppyEngine.MaxWinTotalBet);
            Require(p.baseSpin.grid.Length == 15 && p.baseSpin.grid.All(s => s >= 0 && s < PuppyEngine.SYMBOLS), "Puppy grid");
            var t = ToroEngine.Play(random);
            Payout(t.total, ToroEngine.MaxWinX);
            var s = t.baseSpin;
            Require(s.first.g.Length == 15 && s.first.g.All(v => v >= 0 && v <= ToroEngine.WILD), "Toro grid");
            if (s.toro >= 0)
            {
                fullToro++;
                Require(s.toro >= 1 && s.toro <= 3, "Toro reel");
                Require(Enumerable.Range(0, 3).All(row => s.first.g[s.toro * 3 + row] == ToroEngine.WILD), "Full Toro must cover three cells");
                Require(s.respins.Count > 0 && s.respins.Last().w > 0, "Toro feature must finish on a win");
            }
            if (s.ptoro >= 0)
            {
                partialToro++;
                Require(s.respins.Count == 0, "Partial Toro must not start respins");
                for (int row = 0; row < 3; row++)
                    Require((s.first.g[s.ptoro * 3 + row] == ToroEngine.WILD) == ToroEngine.PartialRow(row, s.ps), "Partial Toro visible rows");
            }
        }
        Require(fullToro > 0 && partialToro > 0, "Both Toro landing types must be exercised");
        for (int reel = 1; reel <= 3; reel++)
            for (int i = 0; i < 1000; i++)
            {
                var t = ToroEngine.PlayBuy(random, reel);
                Require(t.baseSpin.toro == reel, "Bought Toro on selected reel");
                Payout(t.total, ToroEngine.MaxWinX);
            }
        for (int variant = 0; variant < TrainEngine.Variants; variant++)
            for (int i = 0; i < 1000; i++)
            {
                var t = TrainEngine.PlayBuyVariant(random, variant);
                Payout(t.total, TrainEngine.MaxWinX);
                Require(t.bought && t.bonus.Count > 0, "Purchased train feature must exist");
                foreach (var step in t.bonus)
                {
                    Require(step.bt.Length == TrainEngine.BCells && step.bv.Length == TrainEngine.BCells, "Train board dimensions");
                    Require(step.cols >= 5 && step.cols <= 7, "Train board columns");
                    Require(step.nw.All(cell => cell >= 0 && cell < step.cols * TrainEngine.Rows), "New train symbol index");
                }
            }
        Console.WriteLine($"PASS: {count} assertions; 10,000 Puppy rounds; 10,000 Toro rounds ({fullToro} full, {partialToro} partial); 3,000 Toro purchases; 4,000 train purchases across all variants.");
        Console.WriteLine("New Boombox audio buffer and model checks passed. Unity rendering, multiplayer and Windows audio output were not executed.");
    }

    static void CheckSpeaker()
    {
        var audio = new Boombox.AudioPackets { JitterPackets = 1 };
        var output = new float[960]; audio.Read(output, 48000);
        Require(output.All(x => x == 0), "Empty audio must be silent");
        var stereo = Enumerable.Range(0, 480).Select(i => i % 2 == 0 ? .25f : -.5f).ToArray();
        audio.Push(stereo, 2, 24000); audio.Read(output, 48000);
        Require(Enumerable.Range(0, output.Length).All(i => Math.Abs(output[i] - (i % 2 == 0 ? .25f : -.5f)) < .0001f), "Stereo/24k->48k resampling");
        audio.Reset(); audio.Read(output, 48000); Require(output.All(x => x == 0), "Reset must discard held/queued audio");
        audio.Push(stereo, 0, 24000); audio.Push(stereo, 2, 0); Require(audio.Queued == 0, "Invalid packet validation");
        for (int i = 0; i < 2000; i++) audio.Push(stereo, 2, 24000);
        Require(audio.Queued <= 48, "Audio backlog bounded");
        audio.Reset();
        var producer = System.Threading.Tasks.Task.Run(() =>
        {
            for (int i = 0; i < 30000; i++) { if (i % 100 == 0) audio.Reset(); audio.Push(stereo, 2, i % 2 == 0 ? 24000 : 48000); }
        });
        var consumer = System.Threading.Tasks.Task.Run(() =>
        {
            var block = new float[1024];
            for (int i = 0; i < 12000; i++)
            {
                audio.Read(block, 48000);
                if (block.Any(x => float.IsNaN(x) || float.IsInfinity(x) || Math.Abs(x) > 1f)) throw new Exception("Invalid concurrent audio sample");
            }
        });
        Require(System.Threading.Tasks.Task.WaitAll(new[] { producer, consumer }, 15000), "Audio producer/consumer must complete without hanging");
        var parts = Boombox.BoomMesh.Build(); int vertices = 0;
        foreach (var part in parts)
        {
            vertices += part.v.Count / 3;
            Require(part.v.Count % 3 == 0 && part.t.Count % 3 == 0, "Speaker mesh dimensions");
            Require(part.v.All(x => !float.IsNaN(x) && !float.IsInfinity(x)), "Speaker finite geometry");
            Require(part.t.All(x => x >= 0 && x < part.v.Count / 3), "Speaker triangle indices");
        }
        Require(vertices < 65535 && parts.Any(p => p.name == "BB_JBL") && parts.Any(p => p.name == "BB_HourglassLight"), "Speaker mesh budget and visible model details");
        Console.WriteLine($"PASS: Boombox buffer stereo/resampling/reset/overflow/30,000 packets + 12,000 concurrent reads; chassis {vertices} vertices.");
    }
    static void CheckWireProtocol()
    {
        Boombox.BBNet.InitSerializers();
        for (byte kind = 1; kind <= 9; kind++)
        {
            var message = new Boombox.BBMsg { kind = kind, netId = 123456, seq = 17, rate = 24000, channels = 2, text = "кооп JBL ✓", data = new byte[] { 1, 2, 3, 4 } };
            var writer = new Mirror.NetworkWriter();
            Mirror.Writer<Boombox.BBMsg>.write(writer, message);
            var reader = new Mirror.NetworkReader(writer.ToArraySegment());
            var decoded = Mirror.Reader<Boombox.BBMsg>.read(reader);
            Require(decoded.kind == message.kind && decoded.netId == message.netId && decoded.seq == message.seq && decoded.rate == message.rate && decoded.channels == message.channels && decoded.text == message.text && decoded.data.SequenceEqual(message.data), "Mirror message round trip");
        }
        Console.WriteLine("PASS: actual Mirror serializer round trips for nine Boombox message kinds; two-player gameplay still requires an in-game test.");
    }
}
