using System;
using System.Linq;
using System.Threading.Tasks;
using Mirror;
using PuppyPalace;
using GwyfShared;

static partial class Checks
{
    static void CheckNewPresentationAndAudio()
    {
        Require(FreshBoombox.YouTube.VideoId("https://youtu.be/dQw4w9WgXcQ?t=10") == "dQw4w9WgXcQ", "Short YouTube links preserve the video ID");
        Require(FreshBoombox.YouTube.VideoId("https://www.youtube.com/watch?v=dQw4w9WgXcQ&list=anything") == "dQw4w9WgXcQ", "Watch URLs select one video instead of a playlist");
        Require(FreshBoombox.YouTube.VideoId("https://youtube.com.evil.example/watch?v=dQw4w9WgXcQ") == null, "Only actual YouTube hosts are accepted as video URLs");
        Require(!FreshBoombox.YouTube.ValidId("a/b/c/d/e/f") && !FreshBoombox.YouTube.ValidId("ЮЮЮЮЮЮЮЮЮЮЮ"), "Invalid video IDs cannot enter playback requests");
        foreach (bool turbo in new[] { false, true })
        {
            float serverIntro = turbo ? 3 : 6.6f;
            float scatterPulse = turbo ? .3f : .8f;
            Require(BoneReelMotion.RevealDuration(turbo) + scatterPulse + .12f < serverIntro, "Bone reveal must finish before the host starts free spins");
            int[] picks = { 1, 2, 3, 3, 1, 2, 2, 3, 1 };
            var seen = new bool[9]; int sum = 0;
            for (int column = 0; column < 3; column++)
            {
                int n = BoneReelMotion.Travel(turbo, column); float duration = BoneReelMotion.Duration(turbo, column), settle = BoneReelMotion.Settle(turbo);
                float previous = 0;
                for (int frame = 0; frame <= 1000; frame++)
                {
                    float time = duration * frame / 1000;
                    float position = BoneReelMotion.Position(time, duration, n, settle);
                    Require(position >= previous - .0001f && position >= 0 && position <= n + .0001f, "Bone reel cannot reverse, jump or overshoot while spinning");
                    previous = position;
                }
                Require(Math.Abs(BoneReelMotion.Position(duration + settle, duration, n, settle) - n) < .00001f, "Bone strip must settle exactly on final symbols");
                for (int row = 0; row < 3; row++)
                {
                    int index = BoneReelMotion.PickIndex(column, row); Require(!seen[index], "Every awarded bone appears exactly once"); seen[index] = true; sum += picks[index];
                    Require(BoneReelMotion.FinalIndex(n, row) - 2 - n == -row, "Final bones must align with the three visible row centers");
                }
            }
            Require(seen.All(x => x) && sum == picks.Sum(), "Reveal must preserve all nine host awards and their total");
        }
        foreach (int value in new[] { 2, 5, 10, 15, 20, 25, 50, 2000 })
        {
            string label = value + "X"; float scale = ValueGlyphLayout.Scale(label, 235, 68);
            Require(scale > 0 && ValueGlyphLayout.NaturalWidth(label) * scale <= 235.001f && ValueGlyphLayout.Height * scale <= 68.001f, "Fish multiplier glyphs retain aspect ratio and fit inside their plate");
        }
        var queue = new FreshBoombox.AudioQueue(); var packet = new byte[960];
        for (int i = 0; i < packet.Length; i += 2) { packet[i] = 0; packet[i + 1] = 64; }
        var samples = new float[480]; queue.Push(packet); queue.Read(samples);
        Require(samples.All(v => v == 0), "Playback must prebuffer before starting");
        for (int i = 0; i < 8; i++) queue.Push(packet);
        queue.Read(samples); Require(samples.All(v => Math.Abs(v - .5f) < .00001f), "16-bit mono PCM decodes accurately");
        queue.Reset(); queue.Read(samples); Require(samples.All(v => v == 0), "Track change/drop cleanup cannot replay stale samples");
        Parallel.Invoke(() => { for (int i = 0; i < 30000; i++) { queue.Push(packet); if (i % 100 == 0) queue.Reset(); } },
            () => { var block = new float[512]; for (int i = 0; i < 12000; i++) { queue.Read(block); Require(block.All(v => float.IsFinite(v) && Math.Abs(v) <= 1), "Concurrent queue reset/read must remain finite and bounded"); } });
        FreshBoombox.Wire.Install();
        using (var writer = NetworkWriterPool.Get())
        {
            var request = new FreshBoombox.BoxRequestV32 { action = 4, id = 123, text = "dQw4w9WgXcQ\nПример музыки" };
            Writer<FreshBoombox.BoxRequestV32>.write(writer, request);
            using var reader = NetworkReaderPool.Get(writer.ToArraySegment()); var result = Reader<FreshBoombox.BoxRequestV32>.read(reader);
            Require(result.id == request.id && result.action == request.action && result.text == request.text, "Fresh control protocol preserves Unicode titles");
        }
        using (var writer = NetworkWriterPool.Get())
        {
            var state = new FreshBoombox.BoxStateV32 { id = 13, owner = 50, epoch = 3, playing = true, position = new UnityEngine.Vector3(1, 2, 3), rotation = UnityEngine.Quaternion.identity, title = "Музыка" };
            Writer<FreshBoombox.BoxStateV32>.write(writer, state);
            using var reader = NetworkReaderPool.Get(writer.ToArraySegment()); var result = Reader<FreshBoombox.BoxStateV32>.read(reader);
            Require(result.id == 13 && result.owner == 50 && result.epoch == 3 && result.playing && result.position.x == 1 && result.position.y == 2 && result.title == state.title, "Late-join snapshots preserve pose, holder and track epoch");
        }
        using (var writer = NetworkWriterPool.Get())
        {
            var audio = new FreshBoombox.BoxAudioV32 { id = 1, epoch = 2, sequence = 19, pcm = packet };
            Writer<FreshBoombox.BoxAudioV32>.write(writer, audio);
            Require(writer.Position < 1200, "Audio datagram fits the transport's usual MTU budget");
            using var reader = NetworkReaderPool.Get(writer.ToArraySegment()); var result = Reader<FreshBoombox.BoxAudioV32>.read(reader);
            Require(result.epoch == 2 && result.sequence == 19 && result.pcm.SequenceEqual(packet), "Fresh audio protocol preserves complete PCM packets");
        }
        Console.WriteLine("PASS: bone strip timing/final row mapping, fish glyph proportions, standalone audio queue stress and all three new network messages.");
    }
}
