using System;
using System.Collections.Generic;

namespace PuppyPalace
{
    /// Pure game math (no Unity). Grid index = reel*3 + row (row 0 = top).
    public static class PuppyEngine
    {
        public const int Reels = 5, Rows = 3;
        public const int WILD = 11, SCATTER = 12, SYMBOLS = 13;
        public static readonly string[] Names = {
            "BOSS","PUG","CORGI","POODLE","COLLAR","BONE","A","K","Q","J","10","KENNEL","PAW" };

        // Line pays in multiples of the LINE bet (total bet / 20) for 3/4/5 of a kind.
        public static readonly int[,] Pays = {
            {25,75,375},  // BOSS
            {15,50,250},  // PUG
            {10,30,150},  // CORGI
            {8,20,100},   // POODLE
            {5,15,75},    // COLLAR
            {4,12,60},    // BONE
            {2,5,25},     // A
            {2,5,25},     // K
            {1,4,20},     // Q
            {1,4,20},     // J
            {1,4,20},     // 10
        };
        public const double ScatterPayTotalBet = 5.0;   // 3 paws pay 5x total bet
        public const double MaxWinTotalBet = 6750.0;

        // 20 paylines: row per reel
        public static readonly int[][] Lines = {
            new[]{1,1,1,1,1}, new[]{0,0,0,0,0}, new[]{2,2,2,2,2}, new[]{0,1,2,1,0}, new[]{2,1,0,1,2},
            new[]{1,0,0,0,1}, new[]{1,2,2,2,1}, new[]{0,0,1,2,2}, new[]{2,2,1,0,0}, new[]{1,2,1,0,1},
            new[]{1,0,1,2,1}, new[]{0,1,1,1,0}, new[]{2,1,1,1,2}, new[]{0,1,0,1,0}, new[]{2,1,2,1,2},
            new[]{1,1,0,1,1}, new[]{1,1,2,1,1}, new[]{0,0,2,0,0}, new[]{2,2,0,2,2}, new[]{0,2,2,2,0},
        };

        // Per-cell symbol weights (paying symbols 0..10). Wild/scatter weights separate.
        public static int[] BaseWeights = { 3, 4, 5, 6, 7, 8, 10, 10, 11, 11, 11 };
        public static double WildChanceBase = 0.08;     // per cell on reels 2-4
        public static double WildChanceFree = 0.0295;
        public static double ScatterChance = 0.0511;      // per cell on reels 1,3,5 (max one per reel)
        public static double PayScale = 1.554;             // global tuning knob

        public class Spin
        {
            public int[] grid = new int[15];
            public int[] mult = new int[15];   // wild multipliers (0 if not wild)
            public int[] sticky = new int[15]; // 1 if wild is a sticky one carried over
            public List<int> winLines = new List<int>();
            public List<int> winCounts = new List<int>();
            public List<double> winAmounts = new List<double>(); // x total bet
            public double win;                  // x total bet
            public int scatters;
        }

        public class Round
        {
            public Spin baseSpin;
            public List<Spin> freeSpins = new List<Spin>();
            public int freeSpinsAwarded;
            public double total;   // x total bet (capped)
            public bool capped;
            public int[] picks;     // 9 bone values (free spins)
        }

        static int PickSymbol(Random r)
        {
            int sum = 0; foreach (var w in BaseWeights) sum += w;
            int x = r.Next(sum);
            for (int i = 0; i < BaseWeights.Length; i++) { x -= BaseWeights[i]; if (x < 0) return i; }
            return BaseWeights.Length - 1;
        }

        public static double Mult5Chance = 0.06, Mult3Chance = 0.32;
        static int RollMult(Random r) { double x = r.NextDouble(); return x < Mult5Chance ? 5 : x < Mult5Chance + Mult3Chance ? 3 : 2; }

        static void Fill(Spin s, Random r, bool free, int[] stickyMult, bool forceScatter = false)
        {
            for (int reel = 0; reel < Reels; reel++)
            {
                int scatterRow = -1;
                if (!free && (reel == 0 || reel == 2 || reel == 4) && (forceScatter || r.NextDouble() < ScatterChance * 3))
                    scatterRow = r.Next(3);
                for (int row = 0; row < Rows; row++)
                {
                    int i = reel * 3 + row;
                    if (stickyMult != null && stickyMult[i] > 0)
                    { s.grid[i] = WILD; s.mult[i] = stickyMult[i]; s.sticky[i] = 1; continue; }
                    if (row == scatterRow) { s.grid[i] = SCATTER; continue; }
                    if (reel >= 1 && reel <= 3 && r.NextDouble() < (free ? WildChanceFree : WildChanceBase))
                    { s.grid[i] = WILD; s.mult[i] = RollMult(r); continue; }
                    s.grid[i] = PickSymbol(r);
                }
            }
        }

        static void Evaluate(Spin s)
        {
            for (int li = 0; li < Lines.Length; li++)
            {
                var line = Lines[li];
                int first = s.grid[0 * 3 + line[0]];
                if (first == SCATTER || first == WILD) continue; // wilds never on reel 1
                int count = 1; int m = 0; // original rule: wild multipliers on a line are ADDED
                for (int reel = 1; reel < Reels; reel++)
                {
                    int i = reel * 3 + line[reel];
                    int sym = s.grid[i];
                    if (sym == first) count++;
                    else if (sym == WILD) { count++; m += s.mult[i]; }
                    else break;
                }
                if (count >= 3)
                {
                    if (m == 0) m = 1;
                    double w = Pays[first, count - 3] * PayScale / 20.0 * m;
                    s.winLines.Add(li); s.winCounts.Add(count); s.winAmounts.Add(w); s.win += w;
                }
            }
            for (int i = 0; i < 15; i++) if (s.grid[i] == SCATTER) s.scatters++;
            if (s.scatters >= 3) s.win += ScatterPayTotalBet;
        }

        /// Cells taking part in line wins (and scatters when they pay).
        public static List<int> WinCells(Spin s)
        {
            var set = new HashSet<int>();
            foreach (var li in s.winLines)
            {
                var line = Lines[li]; int first = s.grid[line[0]];
                set.Add(line[0]);
                for (int reel = 1; reel < Reels; reel++)
                {
                    int i = reel * 3 + line[reel];
                    if (s.grid[i] == first || s.grid[i] == WILD) set.Add(i); else break;
                }
            }
            if (s.scatters >= 3) for (int i = 0; i < 15; i++) if (s.grid[i] == SCATTER) set.Add(i);
            return new List<int>(set);
        }

        /// Base-game suspense: paws on reels 1 and 3 -> reel 5 spins longer.
        public static bool Anticipation(int[] grid, bool free)
        {
            if (free) return false;
            bool r1 = false, r3 = false;
            for (int row = 0; row < 3; row++) { if (grid[row] == SCATTER) r1 = true; if (grid[6 + row] == SCATTER) r3 = true; }
            return r1 && r3;
        }

        /// Free-spin pick values for the 3x3 bone reveal: 1 (55%), 2 (30%), 3 (15%) -> total 9..27.
        public static double PickP1 = 0.55, PickP2 = 0.30;
        public static double FreeScale = 1.0;   // tuning knob for free-spin line wins only
        public static int[] RollFreeSpinPicks(Random r)
        {
            var p = new int[9];
            for (int i = 0; i < 9; i++) { double x = r.NextDouble(); p[i] = x < PickP1 ? 1 : x < PickP1 + PickP2 ? 2 : 3; }
            return p;
        }

        public static Round Play(Random r, bool forceBonus = false) => PlayInternal(r, forceBonus, false);
        /// Bonus buy: the trigger spin shows 3 paws but pays nothing; the round total is only the free spins.
        public static Round PlayBuy(Random r) => PlayInternal(r, true, true);

        static Round PlayInternal(Random r, bool forceBonus, bool buy)
        {
            var round = new Round();
            var b = new Spin(); Fill(b, r, false, null, forceBonus); Evaluate(b);
            if (buy) { b.win = 0; b.winLines.Clear(); b.winCounts.Clear(); b.winAmounts.Clear(); }
            round.baseSpin = b; round.total = b.win;
            if (b.scatters >= 3)
            {
                round.picks = RollFreeSpinPicks(r);
                int n = 0; foreach (var v in round.picks) n += v;
                round.freeSpinsAwarded = n;
                var sticky = new int[15];
                for (int k = 0; k < n; k++)
                {
                    var f = new Spin(); Fill(f, r, true, sticky); Evaluate(f);
                    if (FreeScale != 1.0) { f.win *= FreeScale; for (int j = 0; j < f.winAmounts.Count; j++) f.winAmounts[j] *= FreeScale; }
                    for (int i = 0; i < 15; i++) if (f.grid[i] == WILD) sticky[i] = f.mult[i];
                    round.freeSpins.Add(f); round.total += f.win;
                    if (round.total >= MaxWinTotalBet) break;
                }
            }
            if (round.total >= MaxWinTotalBet) { round.total = MaxWinTotalBet; round.capped = true; }
            return round;
        }
    }
}
