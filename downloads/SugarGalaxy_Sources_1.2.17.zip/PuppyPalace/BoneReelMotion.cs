using System;

namespace PuppyPalace
{
    // A finite strip keeps the final host-awarded bones moving in from above,
    // rather than replacing symbols already visible on the screen.
    public static class BoneReelMotion
    {
        public static int Travel(bool turbo, int column) => (turbo ? 7 : 14) + column * (turbo ? 2 : 4);
        public static float Duration(bool turbo, int column) => (turbo ? .90f : 2.20f) + column * (turbo ? .17f : .60f);
        public static float Settle(bool turbo) => turbo ? .15f : .23f;
        public static float Hold(bool turbo) => turbo ? .40f : 1.10f;
        public static float Fade(bool turbo) => turbo ? .18f : .35f;
        public static float RevealDuration(bool turbo) => Duration(turbo, 2) + Settle(turbo) + Hold(turbo) + Fade(turbo);
        public static int FinalIndex(int travel, int row) => travel + 2 - row;
        public static int PickIndex(int column, int row) => row * 3 + column;

        public static float Position(float elapsed, float duration, int travel, float settle)
        {
            if (elapsed <= 0) return 0;
            const float ramp = .16f, brake = .40f;
            float speed = travel / (duration - (ramp + brake) * .5f);
            if (elapsed < ramp) return speed * elapsed * elapsed / (2 * ramp);
            if (elapsed < duration - brake) return speed * (elapsed - ramp * .5f);
            if (elapsed < duration)
            {
                float q = elapsed - (duration - brake);
                return speed * (duration - brake - ramp * .5f + q - q * q / (2 * brake));
            }
            if (elapsed >= duration + settle) return travel;
            float p = (elapsed - duration) / settle;
            return travel + .075f * (float)Math.Sin(p * Math.PI * 2) * (1 - p) * (1 - p);
        }
    }
}
