using System;
using System.Collections.Generic;

namespace ToroLeap
{
    /// v1.1.0 - Minotaurus-style: 5x3, 10 fixed lines. Toro = full-reel WILD only on reels 2-4.
    /// Landing spin pays, then MINOTAUR RE-SPINS: Toro stays, other reels respin until a line wins.
    /// Respin multiplier X starts at x1 and grows +1 per dead respin (uncapped); the first win pays line win * X and ends the feature.
    /// No scatters, no free spins. Pure logic shared by the plugin (host) and the offline simulator.
    public static class ToroEngine
    {
        public const int Cols = 5, Rows = 3, Cells = 15, NSYM = 9, WILD = 9;
        public static double MaxWinX = 10000;          // config TL_MaxWinX
        public static int MaxRespins = 250;            // safety: at this point a win is forced (P ~ 0)
        public static readonly string[] Names = { "10", "J", "Q", "K", "A", "Yarn", "Helmet", "Shield", "Ariadne" };
        public static readonly string[] ArtKeys = { "10", "J", "Q", "K", "A", "yarn", "helmet", "shield", "heroine" };
        // pays for 3 / 4 / 5 of a kind on a line (x total bet, before PayScale)
        public static readonly double[,] Pay = {
            {.1,.25,1},{.1,.25,1},{.15,.4,1.5},{.15,.4,1.5},{.2,.6,2},{.4,1,4},{.5,1.5,6},{.75,2.5,10},{1.5,5,25} };
        public static readonly int[][] Lines = {
            new[]{1,1,1,1,1}, new[]{0,0,0,0,0}, new[]{2,2,2,2,2}, new[]{0,1,2,1,0}, new[]{2,1,0,1,2},
            new[]{0,0,1,2,2}, new[]{2,2,1,0,0}, new[]{1,0,0,0,1}, new[]{1,2,2,2,1}, new[]{0,1,1,1,0} };

        // tunables (sim)
        public static double[] SymW = { 30, 30, 26, 26, 22, 12, 9, 6, 3 };
        public static double ToroChance = 0.011;           // per paid spin
        public static double[] ToroReelW = { 50, 32, 18 };  // reel 2 / 3 / 4 (config TL_ToroReelWeights)
        public static double PayScale = 14.79;
        /// v1.2.0 expanding-style partial Minotaur: lands shifted so only 1 or 2 cells of reel 2-4 are visible.
        /// Visible cells are WILD, no re-spin feature. Shift: +1/+2 = figure pushed down (head shows at the bottom),
        /// -1/-2 = pushed up (legs hang from the top). Only a full landing (shift 0) starts MINOTAUR RE-SPINS.
        public static double PartialChance = 0.03;
        public static readonly int[] PartialShifts = { -2, -1, 1, 2 };
        public static double[] PartialShiftW = { 1, 1, 1, 1 };
        /// Bonus Pop price per chosen reel (x bet), tuned to ~96% RTP in the sim
        public static double[] BuyCostX = { 14, 16.5, 53.5 };

        [Serializable] public class Step { public int[] g; public int[] ln; public int[] lc; public double w; public int x; public double mw; }
        public class Spin { public Step first; public List<Step> respins = new List<Step>(); public int toro = -1; public int ptoro = -1; public int ps; public int xEnd; public double win; }
        /// rows of reel covered by a partial figure with shift sh
        public static bool PartialRow(int row, int sh) { int k = row - sh; return k >= 0 && k < Rows; }
        public class Round { public Spin baseSpin; public double total; public bool capped; }

        static int Pick(Random r, double[] w) { double s = 0; foreach (var x in w) s += x; double v = r.NextDouble() * s; for (int i = 0; i < w.Length; i++) { v -= w[i]; if (v < 0) return i; } return w.Length - 1; }
        public static int Idx(int c, int row) => c * Rows + row;
        static void FillCol(Random r, int[] g, int c) { for (int row = 0; row < Rows; row++) g[Idx(c, row)] = Pick(r, SymW); }

        public static Step Eval(int[] g)
        {
            var ln = new List<int>(); var lc = new List<int>(); double w = 0;
            for (int l = 0; l < Lines.Length; l++)
            {
                int sym = -1, cnt = 0;
                for (int c = 0; c < Cols; c++)
                {
                    int s = g[Idx(c, Lines[l][c])];
                    if (s == WILD) { cnt++; continue; }
                    if (sym < 0) { sym = s; cnt++; continue; }
                    if (s == sym) cnt++; else break;
                }
                if (sym < 0 || cnt < 3) continue; // a wild can never cover reel 1, so sym is always set
                w += Pay[sym, cnt - 3] * PayScale; ln.Add(l); lc.Add(cnt);
            }
            return new Step { g = (int[])g.Clone(), ln = ln.ToArray(), lc = lc.ToArray(), w = w, x = 0 };
        }

        /// forceToro: 1..3 = Toro on reel 2..4 (debug / Bonus Pop), 0 = natural
        public static Spin PlaySpin(Random r, int forceToro = 0)
        {
            var s = new Spin(); var g = new int[Cells];
            if (forceToro >= 1) s.toro = Math.Min(3, forceToro);
            else { double u = r.NextDouble(); if (u < ToroChance) s.toro = 1 + Pick(r, ToroReelW); else if (u < ToroChance + PartialChance) { s.ptoro = 1 + Pick(r, ToroReelW); s.ps = PartialShifts[Pick(r, PartialShiftW)]; } }
            for (int c = 0; c < Cols; c++)
            {
                if (c == s.toro) { for (int row = 0; row < Rows; row++) g[Idx(c, row)] = WILD; }
                else { FillCol(r, g, c); if (c == s.ptoro) for (int row = 0; row < Rows; row++) if (PartialRow(row, s.ps)) g[Idx(c, row)] = WILD; }
            }
            s.first = Eval(g); s.win = s.first.w;
            if (s.toro < 0) return s;
            int x = 1;
            for (int k = 0; ; k++)
            {
                for (int c = 0; c < Cols; c++) if (c != s.toro) FillCol(r, g, c);
                var st = Eval(g);
                if (st.w <= 0 && k >= MaxRespins - 1)
                {   // safety net: force the cheapest 3-of-a-kind on line 1 (never reached in practice)
                    for (int c = 0; c < 3; c++) if (c != s.toro) g[Idx(c, Lines[0][c])] = 0;
                    st = Eval(g);
                }
                st.x = x;
                if (st.w > 0) { st.mw = st.w * x; s.win += st.mw; s.respins.Add(st); break; }
                s.respins.Add(st); x++;
            }
            s.xEnd = x;
            return s;
        }

        static Round Wrap(Spin b) { var rd = new Round { baseSpin = b, total = b.win }; if (rd.total > MaxWinX) { rd.total = MaxWinX; rd.capped = true; } return rd; }
        public static Round Play(Random r, int forceToro = 0) => Wrap(PlaySpin(r, forceToro));
        /// Bonus Pop: Toro dropped on the chosen reel (1..3 = reel 2..4); the drop spin pays too, then respins.
        public static Round PlayBuy(Random r, int reel) => Wrap(PlaySpin(r, Math.Max(1, Math.Min(3, reel))));
    }
}
