using System;
using System.Collections.Generic;

namespace ReelKingLake
{
    /// 5x4, 12 fixed lines, Bigger Bass Bonanza rules. Pure logic, shared by the plugin (host) and the offline simulator.
    public static class FishEngine
    {
        public const int Cols = 5, Rows = 4, Cells = 20;
        public const int FISH = 9, SCATTER = 10, WILD = 11, NPAY = 10;
        /// original Bigger Bass Bonanza round cap: 4 000x bet
        public static double MaxWinX = 4000;
        public static readonly string[] Names = { "10", "J", "Q", "K", "A", "Tackle Box", "Lure", "Rod", "Boat", "Fish" };
        public static readonly string[] ArtKeys = { "10", "J", "Q", "K", "A", "tackle_box", "lure", "rod", "boat" };
        /// x TOTAL bet for 2/3/4/5 of a kind on a line (Bigger Bass Bonanza paytable; 5 fish = sum of the fish values on that line)
        public static readonly double[,] Pay = {
            {0,0.5,2.5,10}, {0,0.5,2.5,10}, {0,0.5,2.5,10}, {0,0.5,2.5,10}, {0,0.5,2.5,10},   // 10 J Q K A
            {0,2,10,50},    // tackle box
            {0,2,10,50},    // lure
            {0,3,15,100},   // rod
            {0.5,5,20,200}, // boat (pays from 2)
            {0,1,5,0} };    // fish: 3 = 1x, 4 = 5x, 5 = total money value of the line
        /// 12 fixed lines (row per reel, 0 = top)
        public static readonly int[][] Lines = {
            new[]{1,1,1,1,1}, new[]{2,2,2,2,2}, new[]{0,0,0,0,0}, new[]{3,3,3,3,3},
            new[]{0,1,2,1,0}, new[]{3,2,1,2,3}, new[]{1,2,3,2,1}, new[]{2,1,0,1,2},
            new[]{1,0,0,0,1}, new[]{2,3,3,3,2}, new[]{0,1,1,1,0}, new[]{3,2,2,2,3} };
        /// money values (x total bet), as in the original
        public static readonly int[] FishVals = { 2, 5, 10, 15, 20, 25, 50, 4000 };
        public static double[] FishW = { 50, 22, 12, 6, 4, 3, 2, 0.01 };
        public static double[] FishWFree = { 50, 22, 12, 6, 4, 3, 2, 0.01 };
        // per-cell weights for 10 J Q K A tackle lure rod boat fish
        public static double[] SymW = { 40, 30, 20, 12, 8, 8, 6, 4, 2, 10 };
        public static double[] SymWFree = { 16, 16, 15, 15, 14, 8, 8, 6, 4, 10.7 };
        public static double ScatterChance = 0.072;    // per reel (max 1 scatter per reel)
        public static double WildChanceFree = 0.0135;   // per cell in free spins
        public static double AddFishChance = 0.25;    // FS: exactly 1 wild and no fish -> fish may appear
        public const int BuyCostX = 100, BuyFreeSpins = 10, RetriggerSpins = 10, MaxLevel = 3;
        public static readonly int[] LevelMult = { 1, 2, 3, 10 };
        public static int FreeSpinsFor(int sc) => sc >= 5 ? 20 : sc == 4 ? 15 : sc == 3 ? 10 : 0;

        [Serializable] public class Lw { public int l; public int s; public int n; public float w; }
        [Serializable] public class Spin
        {
            public int[] g;          // landed grid
            public int[] fv;         // fish value per cell (0 = not a fish)
            public int[] add;        // FS: cells where extra fish appeared (pairs cell,value)
            public Lw[] lines;
            public float lw;         // line wins (x bet)
            public int sc;           // scatters
            public int wd;           // wilds on screen
            public float fs;         // fish money sum on screen (after added fish)
            public int mult;         // collection multiplier used this spin
            public float col;        // collected = wd * fs * mult
            public float win;        // spin win (x bet) before the round cap
            public int wt;           // FS: wilds collected so far (after this spin)
            public int lvl;          // FS: level reached after this spin (0..3)
            public int rt;           // FS: 1 = a retrigger (+10) was earned on this spin
            public int left;         // FS: spins left after this spin
            public int tot;          // FS: spins awarded so far
        }
        public class Round { public Spin baseSpin; public List<Spin> free = new List<Spin>(); public int fsAwarded; public double total; public bool capped; }

        static int Pick(Random r, double[] w) { double s = 0; foreach (var x in w) s += x; double v = r.NextDouble() * s; for (int i = 0; i < w.Length; i++) { v -= w[i]; if (v < 0) return i; } return w.Length - 1; }
        public static int Idx(int c, int row) => c * Rows + row;

        public static Spin PlaySpin(Random r, bool free, int forceScatters = 0)
        {
            var g = new int[Cells]; var fv = new int[Cells];
            for (int i = 0; i < Cells; i++)
            {
                if (free && r.NextDouble() < WildChanceFree) { g[i] = WILD; continue; }
                g[i] = Pick(r, free ? SymWFree : SymW);
                if (g[i] == FISH) fv[i] = FishVals[Pick(r, free ? FishWFree : FishW)];
            }
            if (!free)
            {
                var have = new bool[Cols];
                for (int c = 0; c < Cols; c++) if (r.NextDouble() < ScatterChance) { int i = Idx(c, r.Next(Rows)); g[i] = SCATTER; fv[i] = 0; have[c] = true; }
                int n = 0; foreach (var h in have) if (h) n++;
                for (int guard = 0; n < forceScatters && guard < 100; guard++)
                {
                    int c = r.Next(Cols); if (have[c]) continue;
                    int i = Idx(c, r.Next(Rows)); g[i] = SCATTER; fv[i] = 0; have[c] = true; n++;
                }
            }
            var s = new Spin { g = g, fv = (int[])fv.Clone() };
            // line wins on the landed grid
            var lws = new List<Lw>();
            for (int l = 0; l < Lines.Length; l++)
            {
                int sym = -1;
                for (int c = 0; c < Cols; c++) { int x = g[Idx(c, Lines[l][c])]; if (x != WILD) { sym = x; break; } }
                if (sym == SCATTER) continue;
                if (sym < 0) sym = 8; // 5 wilds pay as the top symbol
                int n = 0; double fishSum = 0;
                for (int c = 0; c < Cols; c++) { int i = Idx(c, Lines[l][c]); int x = g[i]; if (x == sym || x == WILD) { n++; fishSum += fv[i]; } else break; }
                if (n < 2) continue;
                double w = n == 5 && sym == FISH ? fishSum : Pay[sym, n - 2];
                if (w > 0) lws.Add(new Lw { l = l, s = sym, n = n, w = (float)w });
            }
            s.lines = lws.ToArray(); foreach (var x in lws) s.lw += x.w;
            foreach (var x in g) { if (x == SCATTER) s.sc++; if (x == WILD) s.wd++; }
            if (free)
            {
                bool anyFish = false; foreach (var v in fv) if (v > 0) anyFish = true;
                // original: "randomly, when there is only 1 WILD on screen, fish MONEY symbols can appear in random positions"
                if (s.wd == 1 && !anyFish && r.NextDouble() < AddFishChance)
                {
                    int k = 1 + r.Next(3); var add = new List<int>();
                    for (int guard = 0; add.Count < k * 2 && guard < 60; guard++)
                    {
                        int i = r.Next(Cells); if (g[i] == WILD || fv[i] > 0) continue;
                        fv[i] = FishVals[Pick(r, FishWFree)]; add.Add(i); add.Add(fv[i]);
                    }
                    s.add = add.ToArray();
                }
                foreach (var v in fv) s.fs += v;
            }
            return s;
        }

        public static Round Play(Random r, bool forceBonus = false) => PlayInner(r, forceBonus ? 3 : 0);
        public static Round PlayBuy(Random r) => PlayInner(r, 3, true);

        static Round PlayInner(Random r, int force, bool buy = false)
        {
            var rd = new Round();
            var b = PlaySpin(r, false, force);
            b.win = b.lw;
            rd.baseSpin = b;
            double run = Math.Min(b.win, MaxWinX);
            int fsN = buy ? BuyFreeSpins : FreeSpinsFor(b.sc);
            if (fsN > 0 && run < MaxWinX)
            {
                rd.fsAwarded = fsN;
                int batchLeft = fsN, pending = 0, level = 0, wildTotal = 0;
                while (batchLeft > 0 && rd.free.Count < 200)
                {
                    batchLeft--;
                    var f = PlaySpin(r, true);
                    f.mult = LevelMult[level];
                    f.col = f.wd > 0 ? f.wd * f.fs * f.mult : 0;
                    f.win = f.lw + f.col;
                    wildTotal += f.wd;
                    // every 4th collected wild: +10 spins, played after the current batch with the next multiplier (max 3 retriggers)
                    while (level + pending < MaxLevel && wildTotal >= 4 * (level + pending + 1)) { pending++; rd.fsAwarded += RetriggerSpins; f.rt = 1; }
                    if (batchLeft == 0 && pending > 0) { pending--; level++; batchLeft = RetriggerSpins; }
                    f.wt = wildTotal; f.lvl = level + pending; f.left = batchLeft + pending * RetriggerSpins; f.tot = rd.fsAwarded;
                    rd.free.Add(f); run += f.win;
                    if (run >= MaxWinX) break;   // cap reached: round ends, remaining spins forfeited
                }
            }
            double t = b.win; foreach (var f in rd.free) t += f.win;
            if (t >= MaxWinX) { t = MaxWinX; rd.capped = true; }
            rd.total = t;
            return rd;
        }
    }
}
