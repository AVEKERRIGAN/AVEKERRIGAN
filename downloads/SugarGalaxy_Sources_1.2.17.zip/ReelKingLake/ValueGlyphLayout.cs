using System;

namespace GwyfShared
{
    public static class ValueGlyphLayout
    {
        public static readonly int[] X = { 25, 232, 394, 591, 789, 990, 1183, 1384, 1563, 1761, 1938 };
        public static readonly int[] Width = { 184, 144, 184, 184, 184, 178, 184, 180, 184, 184, 216 };
        public const int Height = 284, Gap = 8;
        public static int Glyph(char c) => c == 'X' ? 10 : c - '0';
        public static int NaturalWidth(string label)
        {
            int total = Math.Max(0, label.Length - 1) * Gap;
            foreach (char c in label) total += Width[Glyph(c)];
            return total;
        }
        public static float Scale(string label, int maxWidth, int maxHeight)
            => Math.Min((float)maxWidth / NaturalWidth(label), (float)maxHeight / Height);
    }
}
