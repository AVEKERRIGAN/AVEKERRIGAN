using System;
using System.Collections.Generic;

namespace ThunderOlympus
{
    /// 6x5 pays-anywhere tumble slot (Gates of Olympus rules). Pure logic, shared by the plugin (host) and the offline simulator.
    public static class ZeusEngine
    {
        public const int Cols = 6, Rows = 5, Cells = 30;
        public const int SCATTER = 9, ORB = 10, NSYM = 9;
        /// original Gates of Olympus max win: 5 000x bet per round
        public static double MaxWinX = 5000;
        // rank low -> high (same order as the original paytable)
        public static readonly string[] Names = { "Blue Gem", "Green Gem", "Yellow Gem", "Purple Gem", "Red Gem", "Chalice", "Ring", "Hourglass", "Crown" };
        public static readonly string[] ArtKeys = { "gem_blue", "gem_green", "gem_yellow", "gem_purple", "gem_red", "chalice", "ring", "hourglass", "crown" };
        /// original rule = 8+ anywhere. Configurable 8..12 (below 8 the math explodes).
        public static int MinMatch = 8;
        /// original Gates of Olympus paytable (x total bet), tiers 8-9 / 10-11 / 12+ (verified against several published GoO paytables)
        public static readonly double[,] Pay = {
            {0.25,0.75,2},   // blue
            {0.4,0.9,4},     // green
            {0.5,1,5},       // yellow
            {0.8,1.2,8},     // purple
            {1,1.5,10},      // red
            {1.5,2,12},      // chalice
            {2,5,15},        // ring
            {2.5,10,25},     // hourglass
            {10,25,50} };    // crown
        /// multiplier orb values (one art file each: sym_orb_x{v}.png)
        public static readonly int[] OrbVals = { 2, 3, 5, 10, 15, 25, 50, 100, 250, 500 };
        public static double[] OrbW = { 40, 25, 16, 9, 4.5, 2.5, 1.5, 0.6, 0.12, 0.04 };
        public static double[] OrbWFree = { 40, 25, 16, 9, 4.5, 2.5, 1.5, 0.6, 0.12, 0.04 };

        public static double[] SymW = { 16.859, 14.512, 12.829, 10.753, 8.771, 6.619, 5.140, 3.611, 1.612 };
        public static double[] SymWFree = { 16.859, 14.512, 12.829, 10.753, 8.771, 6.619, 5.140, 3.611, 1.612 };
        public static double ScatterChance = 0.014;      // per cell, base: bonus ~1 in 445 spins
        public static double ScatterChanceFree = 0.006;
        public static double OrbChanceBase = 0.00103;    // per cell, base game (orbs multiply only that spin)
        public static double OrbChanceFree = 0.01342;    // per cell, free spins (orbs add to the bonus total multiplier)
        public static double AnteScatterMult = 1.267;    // ~2.3x bonus frequency (original: "chance to win free spins naturally doubled")
        public const double AnteCost = 1.25;
        public const int BuyCostX = 100, FreeSpins = 15, Retrigger = 5;

        [Serializable] public class Step { public int[] g; public int[] bv; public int[] win; public double w; public int[] ws; }
        public class Spin
        {
            public List<Step> steps = new List<Step>();
            public double tumbleWin;     // sum of tumble steps (before orbs)
            public int orbSum;           // orbs on the final grid (counted only when tumbleWin > 0)
            public double scatterPay;
            public int scatters;
            public double win;           // final spin win (x bet)
            public int totalMulti;       // FS: accumulated total multiplier AFTER this spin
        }
        public class Round { public Spin baseSpin; public List<Spin> free = new List<Spin>(); public int fsAwarded; public double total; public bool capped; }

        static int Pick(Random r, double[] w) { double s = 0; foreach (var x in w) s += x; double v = r.NextDouble() * s; for (int i = 0; i < w.Length; i++) { v -= w[i]; if (v < 0) return i; } return w.Length - 1; }

        static void Fill(Random r, int[] g, int[] bv, int cell, bool free, bool ante)
        {
            double sc = (free ? ScatterChanceFree : ScatterChance) * (ante && !free ? AnteScatterMult : 1);
            double oc = free ? OrbChanceFree : OrbChanceBase;
            double v = r.NextDouble();
            if (v < sc) { g[cell] = SCATTER; bv[cell] = 0; return; }
            if (v < sc + oc) { g[cell] = ORB; bv[cell] = OrbVals[Pick(r, free ? OrbWFree : OrbW)]; return; }
            g[cell] = Pick(r, free ? SymWFree : SymW); bv[cell] = 0;
        }
        public static int Idx(int c, int row) => c * Rows + row; // row 0 = top

        public static Spin PlaySpin(Random r, bool free, bool ante, int forceScatters = 0)
        {
            var g = new int[Cells]; var bv = new int[Cells];
            for (int i = 0; i < Cells; i++) Fill(r, g, bv, i, free, ante);
            if (forceScatters > 0)
            {
                int have = 0; foreach (var x in g) if (x == SCATTER) have++;
                var used = new bool[Cols]; for (int i = 0; i < Cells; i++) if (g[i] == SCATTER) used[i / Rows] = true;
                for (int guard = 0; have < forceScatters && guard < 500; guard++)
                {
                    int c = r.Next(Cells); if (g[c] == SCATTER || (used[c / Rows] && guard < 400)) continue;
                    g[c] = SCATTER; bv[c] = 0; used[c / Rows] = true; have++;
                }
            }
            var s = new Spin();
            for (int guard = 0; guard < 60; guard++)
            {
                var cnt = new int[NSYM]; for (int i = 0; i < Cells; i++) if (g[i] < NSYM) cnt[g[i]]++;
                var win = new List<int>(); var ws = new List<int>(); double w = 0;
                for (int k = 0; k < NSYM; k++) if (cnt[k] >= MinMatch)
                    {
                        w += Pay[k, cnt[k] >= 12 ? 2 : cnt[k] >= 10 ? 1 : 0]; ws.Add(k);
                        for (int i = 0; i < Cells; i++) if (g[i] == k) win.Add(i);
                    }
                s.steps.Add(new Step { g = (int[])g.Clone(), bv = (int[])bv.Clone(), win = win.ToArray(), w = w, ws = ws.ToArray() });
                if (w <= 0) break;
                s.tumbleWin += w;
                var dead = new bool[Cells]; foreach (var i in win) dead[i] = true;
                for (int c = 0; c < Cols; c++)
                {
                    var keepG = new List<int>(); var keepB = new List<int>();
                    for (int row = Rows - 1; row >= 0; row--) { int i = Idx(c, row); if (!dead[i]) { keepG.Add(g[i]); keepB.Add(bv[i]); } }
                    for (int row = Rows - 1, k = 0; row >= 0; row--, k++)
                    {
                        int i = Idx(c, row);
                        if (k < keepG.Count) { g[i] = keepG[k]; bv[i] = keepB[k]; } else Fill(r, g, bv, i, free, ante);
                    }
                }
            }
            for (int i = 0; i < Cells; i++) { if (g[i] == SCATTER) s.scatters++; if (g[i] == ORB) s.orbSum += bv[i]; }
            if (!free) s.scatterPay = s.scatters >= 6 ? 100 : s.scatters == 5 ? 5 : s.scatters == 4 ? 3 : 0;
            return s;
        }

        public static Round Play(Random r, bool ante, bool forceBonus = false) => PlayInner(r, ante, forceBonus ? 4 : 0);
        public static Round PlayBuy(Random r) => PlayInner(r, false, 4);

        static Round PlayInner(Random r, bool ante, int force)
        {
            var rd = new Round();
            var b = PlaySpin(r, false, ante, force);
            // base game: orbs on screen multiply the tumble win of this spin only
            b.win = b.tumbleWin * (b.tumbleWin > 0 && b.orbSum > 0 ? b.orbSum : 1) + b.scatterPay;
            rd.baseSpin = b;
            double run = Math.Min(b.win, MaxWinX);
            if (b.scatters >= 4 && run < MaxWinX)
            {
                int left = FreeSpins; rd.fsAwarded = FreeSpins; int total = 0;
                while (left > 0 && rd.free.Count < 300)
                {
                    left--;
                    var f = PlaySpin(r, true, false);
                    // Gates of Olympus FS rule: orbs that land in a winning spin are ADDED to the total multiplier for the
                    // whole bonus, and that spin's win is multiplied by the (new) total. Spins without a new orb pay x1.
                    if (f.tumbleWin > 0 && f.orbSum > 0) { total += f.orbSum; f.win = f.tumbleWin * total; }
                    else f.win = f.tumbleWin;
                    f.totalMulti = total;
                    if (f.scatters >= 3) { left += Retrigger; rd.fsAwarded += Retrigger; }
                    rd.free.Add(f); run += f.win;
                    if (run >= MaxWinX) break;   // max win reached: the bonus ends immediately (original behaviour)
                }
            }
            double t = b.win; foreach (var f in rd.free) t += f.win;
            if (t >= MaxWinX) { rd.capped = t > MaxWinX || rd.capped; t = MaxWinX; rd.capped = true; }
            rd.total = t;
            return rd;
        }
    }
}
