// ReelFx — shared premium reel-spin renderer for GWYF slot mods (UGUI, RectMask2D grid).
// Pure presentation: never changes durations, so host/client timing parity is untouched.
// Usage per column: var col = new ReelFx.Column(cells, topHome, rowStep, size, parent, makeImage);
//   each frame while spinning: col.Spin(el, speed, sharp, blur, rnd)
//   when stop phase starts:   col.BeginLand(finalSprites)
//   each frame while landing: col.Land(p)      (p 0..1 over the land window)
//   finally:                  col.Finish()
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace GwyfShared
{
    public static class ReelFx
    {
        public const float RampTime = .3f, KickTime = .14f, KickAmt = .12f;

        /// strip position in cells: short upward kick, smooth ramp to full speed, then constant.
        /// strip position in cells: tiny smooth upward kick, then smoothstep (C2) velocity ramp to full speed over RampTime.
        public static float SpinPos(float el, float speed)
        {
            const float a = RampUp; float pos;
            if (el < a) { float q = el / a; pos = speed * a * (q * q * q - q * q * q * q * .5f); }
            else pos = speed * (el - a * .5f);
            if (el < KickTime) { float k = el / KickTime; pos -= KickAmt * Mathf.Sin(Mathf.PI * k) * (1 - k * .3f); }
            return pos;
        }
        public const float RampUp = .3f;
        public static float SpinVel(float el, float speed) { float q = Mathf.Clamp01(el / RampUp); return speed * q * q * (3 - 2 * q); }
        /// remaining offset (cells above home, negative = overshoot below) during a stop.
        /// Starts at off0 moving down at v0n cells per unit p (velocity-matched, no jump), cubic Hermite into a gentle
        /// overshoot at p = .62, then ease-in-out cubic back to 0.
        public static float LandOff(float p, float off0, float v0n, float overshoot = .14f)
        {
            p = Mathf.Clamp01(p); const float a = .62f;
            if (p < a)
            {
                float t = p / a, t2 = t * t, t3 = t2 * t;
                float h00 = 2 * t3 - 3 * t2 + 1, h10 = t3 - 2 * t2 + t, h01 = -2 * t3 + 3 * t2;
                return h00 * off0 + h10 * (-v0n * a) + h01 * (-overshoot);
            }
            float b = (p - a) / (1 - a), e = b < .5f ? 4 * b * b * b : 1 - Mathf.Pow(-2 * b + 2, 3) / 2;
            return -overshoot * (1 - e);
        }
        public static float EaseOutBack(float x, float s = 1.9f) { x = Mathf.Clamp01(x) - 1; return 1 + (s + 1) * x * x * x + s * x * x; }

        /// land curve: 0 = strip one cell above, 1 = home. overshoots below home, then settles.
        public static float LandCurve(float p) { return 1f - LandOff(p, 1f, 0f); }

        /// tumble / cascade fall: returns remaining height fraction (1 = start, 0 = home). gravity accel to 72%,
        /// then a two-hop decaying bounce (negative = squashed below is never used; hops go upward).
        public static float GravityFall(float p)
        {
            p = Mathf.Clamp01(p); const float a = .72f;
            if (p < a) { float q = p / a; return 1 - q * q; }
            float b = (p - a) / (1 - a);
            return b < .6f ? .09f * Mathf.Sin(b / .6f * Mathf.PI) : .025f * Mathf.Sin((b - .6f) / .4f * Mathf.PI);
        }
        /// squash/stretch matching GravityFall: stretched while falling fast, squashed on each impact
        public static Vector3 FallScale(float p)
        {
            p = Mathf.Clamp01(p); const float a = .72f;
            if (p < a) { float q = p / a; float st = .08f * q; return new Vector3(1 - st * .5f, 1 + st, 1); }
            float b = (p - a) / (1 - a), k = Mathf.Max(0, 1 - b / .25f) * .16f; return new Vector3(1 + k, 1 - k, 1);
        }
        /// true while a falling cell should use its motion-blurred sprite
        public static bool FallBlur(float p, float fromCells) => fromCells > .9f && p > .25f && p < .66f;

        public static void ConfigureTexture(Texture2D t) { if (t == null) return; t.filterMode = FilterMode.Trilinear; t.anisoLevel = 8; t.mipMapBias = -.4f; t.wrapMode = TextureWrapMode.Clamp; }

        /// sharper machine screen: replacement RT at up to 2x, 4x MSAA, trilinear + anisotropic sampling.
        public static RenderTexture MakeScreenRT(RenderTexture src, string name, int maxW = 2048)
        {
            int k = Mathf.Max(1, Mathf.Min(2, maxW / Mathf.Max(1, src.width)));
            try
            {   // mips (no MSAA: Unity cannot mip multisampled RTs) -> no shimmer/pixelation at distance
                var d = new RenderTextureDescriptor(src.width * k, src.height * k, src.graphicsFormat, src.depth) { msaaSamples = 1, useMipMap = false, autoGenerateMips = false };
                var rt = new RenderTexture(d) { name = name, filterMode = FilterMode.Bilinear, anisoLevel = 8, wrapMode = TextureWrapMode.Clamp };
                if (rt.Create()) return rt;
                rt.Release(); UnityEngine.Object.Destroy(rt);
            }
            catch (Exception) { }
            var f = new RenderTexture(src.width, src.height, src.depth, src.graphicsFormat) { name = name };
            f.Create(); return f;
        }

        public class Column
        {
            readonly Image[] _cells; readonly Image _top, _bot, _bot2; readonly Vector2 _h0, _step; readonly int R;
            float _prev, _lastPos, _lastT, _vel, _fr, _off0, _v0n; Sprite[] _final, _finalBlur;
            Func<int, Sprite> _sharp, _blur; readonly int[] _ids;
            public readonly Image Shade = null; // cylinder shading removed (v1.0.4): looked like grey bars in game

            public Column(Image[] cells, Vector2 home0, Vector2 rowStep, Vector2 cellSize, RectTransform parent, Func<string, RectTransform, Image> make, Sprite shade, float colWidth, float colHeight)
            {
                _cells = cells; R = cells.Length; _h0 = home0; _step = rowStep;
                _top = make("ReelTop", parent); _bot = make("ReelBot", parent); _bot2 = make("ReelBot2", parent);
                foreach (var e in new[] { _top, _bot, _bot2 }) { e.preserveAspect = true; e.raycastTarget = false; var rt = e.rectTransform; rt.anchorMin = rt.anchorMax = rt.pivot = new Vector2(.5f, .5f); rt.sizeDelta = cellSize; e.enabled = false; }
                _ids = new int[R + 1];
            }
            Vector2 Row(float k) => _h0 + _step * k;
            // extra strip cells are only drawn while they actually overlap the reel window (no peeking outside it)
            void PlaceExtra(Image im, float k) { im.rectTransform.anchoredPosition = Row(k); im.enabled = k > -1f && k < R; }

            public void Start(Func<int, Sprite> sharp, Func<int, Sprite> blur, Func<int> rnd)
            {
                _sharp = sharp; _blur = blur; _prev = 0; _lastPos = 0; _lastT = Time.time; _vel = 0; _final = null;
                // seamless start: the strip begins with the symbols currently on screen (captured sprites, negative ids);
                // only the slot above the window gets a random filler. Final symbols are assigned at BeginLand.
                if (_cap == null) { _cap = new Sprite[R]; _capBlur = new Sprite[R]; }
                _ids[0] = rnd();
                for (int r = 0; r < R; r++)
                {
                    _cap[r] = _cells[r].enabled ? _cells[r].sprite : null; _capBlur[r] = _cap[r] != null && BlurOf != null ? BlurOf(_cap[r]) : null;
                    _ids[r + 1] = _cap[r] != null ? -1 - r : rnd();
                }
                _bot.enabled = _bot2.enabled = false;
            }
            Image Slot(int k) => k == 0 ? _top : _cells[k - 1];
            Sprite[] _cap, _capBlur;
            /// optional sharp->blurred sprite map for the captured on-screen symbols
            public Func<Sprite, Sprite> BlurOf;
            Sprite Pick(int id, bool blurred)
            {
                if (id < 0) { int r = -1 - id; var c = _cap != null && r < _cap.Length ? _cap[r] : null; return blurred && _capBlur != null && _capBlur[r] != null ? _capBlur[r] : c; }
                return blurred ? (_blur(id) ?? _sharp(id)) : _sharp(id);
            }

            public void Spin(float el, float speed, Func<int> rnd)
            {
                // clamp: the backward 'kick' made pos negative -> floor(-0.1) = -1, fr = .9 -> the whole column was drawn one row
                // lower on the first frames (looked like the board got replaced by new symbols). Strip only ever moves down.
                float pos = Mathf.Max(0f, SpinPos(el, speed)), now = Time.time, dt = now - _lastT;
                if (dt > 1e-4f) { float v = (pos - _lastPos) / dt; _vel = Mathf.Lerp(_vel, v, Mathf.Clamp01(dt * 20f)); _lastT = now; _lastPos = pos; }
                float fr = pos - Mathf.Floor(pos); int steps = Mathf.FloorToInt(pos) - Mathf.FloorToInt(_prev); _prev = pos; _fr = fr;
                for (int s = 0; s < Mathf.Min(steps, R + 1); s++) { for (int k = R; k > 0; k--) _ids[k] = _ids[k - 1]; _ids[0] = rnd(); }
                bool blurred = Mathf.Abs(_vel) > speed * .4f;
                for (int k = 0; k <= R; k++)
                {
                    var im = Slot(k); im.sprite = Pick(_ids[k], blurred); im.color = Color.white; im.rectTransform.localScale = Vector3.one;
                    if (k == 0) PlaceExtra(im, k - 1 + fr); else { im.enabled = im.sprite != null; im.rectTransform.anchoredPosition = Row(k - 1 + fr); }
                }
            }

            /// final sprites for rows 0..R-1. Continues from the current strip position and velocity (no jump):
            /// final row r takes over the slot where strip symbol r-1 was; two exit cells fill the bottom.
            public void BeginLand(Sprite[] final, float landDur = .27f, Func<Sprite, Sprite> blurOf = null)
            {
                _final = final; _finalBlur = new Sprite[R];
                for (int r = 0; r < R; r++) _finalBlur[r] = blurOf != null && final[r] != null ? blurOf(final[r]) : null;
                _off0 = 2f - _fr; _v0n = Mathf.Max(0f, _vel) * landDur;
                bool blurred = _v0n > 0;
                _bot.sprite = Pick(_ids[R - 1], blurred); _bot2.sprite = Pick(_ids[R], blurred); _top.sprite = Pick(_ids[0], blurred);
            }

            public void Land(float p)
            {
                float off = LandOff(p, _off0, _v0n);
                bool fast = p < .45f; // swap to sharp art while the reel is already slow (no visible stutter)
                for (int r = 0; r < R; r++)
                {
                    var im = _cells[r]; im.sprite = fast && _finalBlur != null && _finalBlur[r] != null ? _finalBlur[r] : _final[r];
                    im.enabled = _final[r] != null; im.color = Color.white; var rt = im.rectTransform; rt.anchoredPosition = Row(r - off); rt.localScale = Vector3.one;
                }
                PlaceExtra(_top, -1 - off); PlaceExtra(_bot, R - off); PlaceExtra(_bot2, R + 1 - off);
                if (!fast) { _bot.sprite = Pick(_ids[R - 1], false); _bot2.sprite = Pick(_ids[R], false); }
                if (p >= 1) Finish();
            }
            public float LandingOffset(float p)=>LandOff(p,_off0,_v0n);

            public void Finish()
            {
                _top.enabled = _bot.enabled = _bot2.enabled = false;
                for (int r = 0; r < R; r++) { var rt = _cells[r].rectTransform; rt.anchoredPosition = Row(r); rt.localScale = Vector3.one; }
            }
        }
    }

    /// Per-machine screen render texture (game 1.0.33+). The vanilla slot screen camera has NO targetTexture in the prefab;
    /// DynamicRenderTextureResolution assigns the ONE shared RT asset a frame after OnEnable. All machines then render into the
    /// same texture, so every cabinet shows whichever camera rendered last (static / foreign screen). This component removes
    /// that script, gives each camera its own RT, re-points the screen materials / RawImages and keeps it that way (checked 2x/s).
    public class ScreenIso : MonoBehaviour
    {
        public string Suffix = "_own"; public Action<string> Log;
        readonly Dictionary<Camera, RenderTexture> _own = new Dictionary<Camera, RenderTexture>();
        readonly Dictionary<Camera, RenderTexture> _src = new Dictionary<Camera, RenderTexture>();
        Camera[] _cams; float _next; int _fixes;
        static Type _drtr; static System.Reflection.FieldInfo _fCam, _fAsset, _fPrev;
        static void InitRefl()
        {
            if (_drtr != null) return;
            foreach (var a in AppDomain.CurrentDomain.GetAssemblies()) { try { _drtr = a.GetType("DynamicRenderTextureResolution"); } catch { } if (_drtr != null) break; }
            if (_drtr == null) { _drtr = typeof(void); return; }
            var bf = System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Public;
            _fCam = _drtr.GetField("sourceCamera", bf); _fAsset = _drtr.GetField("renderTextureAsset", bf); _fPrev = _drtr.GetField("previewImage", bf);
        }
        /// the screen RT of a machine: a camera's targetTexture, or (1.0.33+) the asset its DynamicRenderTextureResolution will assign
        public static RenderTexture FindRT(GameObject go)
        {
            if (go != null) return null; // slot screens have no RT pipeline (only the keypad camera has one)
            foreach (var c in go.GetComponentsInChildren<Camera>(true)) if (c.targetTexture != null) return c.targetTexture;
            InitRefl(); if (_fAsset == null) return null;
            foreach (var mb in go.GetComponentsInChildren(_drtr, true)) { var rt = _fAsset.GetValue(mb) as RenderTexture; if (rt != null) return rt; }
            return null;
        }
        void Start() { KillDrtr(); Check(); }
        void KillDrtr()
        {
            InitRefl(); if (_fAsset == null) return;
            foreach (var mb in GetComponentsInChildren(_drtr, true))
            {
                var cam = _fCam?.GetValue(mb) as Camera; var rt = _fAsset.GetValue(mb) as RenderTexture;
                if (cam != null && rt != null && !_src.ContainsKey(cam)) _src[cam] = rt;
                var b = mb as Behaviour; if (b != null) b.enabled = false;
                Destroy(mb); // stops its pending "assign shared RT next frame" coroutine
                Log?.Invoke($"removed DynamicRenderTextureResolution on '{mb.name}' (shared RT '{(rt != null ? rt.name : "-")}')");
            }
        }
        void Update() { if (Time.unscaledTime < _next) return; _next = Time.unscaledTime + .5f; Check(); }
        void Check()
        {
            try
            {
                if (_cams == null || _cams.Length == 0) _cams = GetComponentsInChildren<Camera>(true);
                foreach (var cam in _cams)
                {
                    if (cam == null) continue;
                    var cur = cam.targetTexture;
                    if (_own.TryGetValue(cam, out var mine))
                    {
                        if (cur == mine) continue;
                        if (cur != null && cur != mine) { _src[cam] = cur; Swap(cur, mine); }
                        cam.targetTexture = mine; _fixes++; if (_fixes <= 5) Log?.Invoke($"screen camera '{cam.name}' was re-pointed to a shared RT - fixed");
                        continue;
                    }
                    var shared = cur ?? (_src.TryGetValue(cam, out var s) ? s : null);
                    if (shared == null) continue;
                    var nrt = ReelFx.MakeScreenRT(shared, shared.name + Suffix);
                    _own[cam] = nrt; _src[cam] = shared; cam.targetTexture = nrt;
                    int n = Swap(shared, nrt);
                    if (!cam.enabled) cam.enabled = true;
                    Log?.Invoke($"screen camera '{cam.name}' -> own RT {nrt.width}x{nrt.height} ({n} material slots)");
                }
            }
            catch (Exception e) { Log?.Invoke("screen RT isolation error: " + e.Message); }
        }
        int Swap(RenderTexture from, RenderTexture to)
        {
            int swaps = 0;
            foreach (var r in GetComponentsInChildren<Renderer>(true))
            {
                bool uses = false;
                foreach (var m in r.sharedMaterials) if (m != null) foreach (var p in m.GetTexturePropertyNames()) if (m.GetTexture(p) == from) uses = true;
                if (!uses) continue;
                var inst = r.materials;
                foreach (var m in inst) foreach (var p in m.GetTexturePropertyNames()) if (m.GetTexture(p) == from) { m.SetTexture(p, to); swaps++; }
                r.materials = inst;
            }
            foreach (var ri in GetComponentsInChildren<RawImage>(true)) if (ri.texture == from) { ri.texture = to; swaps++; }
            return swaps;
        }
        void OnDestroy() { foreach (var rt in _own.Values) if (rt != null) { rt.Release(); Destroy(rt); } _own.Clear(); }
    }

    public static class ButtonFit
    {
        /// visible width of a button (renderers) along rightLocal, in its parent's space; fallback when nothing renders
        public static float Measure(Transform pt, Vector3 rightLocal, float fallback)
        {
            var parent = pt.parent; float mn = float.MaxValue, mx = float.MinValue;
            foreach (var r in pt.GetComponentsInChildren<Renderer>(true))
            {
                if (r is ParticleSystemRenderer || r.GetComponent<TMPro.TMP_Text>() != null || !(r is MeshRenderer || r is SkinnedMeshRenderer)) continue;
                var b = r.bounds; if (b.size == Vector3.zero) continue;
                for (int i = 0; i < 8; i++)
                {
                    var c = new Vector3((i & 1) == 0 ? b.min.x : b.max.x, (i & 2) == 0 ? b.min.y : b.max.y, (i & 4) == 0 ? b.min.z : b.max.z);
                    var l = parent != null ? parent.InverseTransformPoint(c) : c; float d = Vector3.Dot(l, rightLocal.normalized);
                    mn = Mathf.Min(mn, d); mx = Mathf.Max(mx, d);
                }
            }
            float w = mx - mn; return (w > 1e-4f && w < 1e4f) ? w : fallback;
        }
        /// physical cabinet button label: undo the button's x-squash, clamp the text box to maxW (parent units, along the button's
        /// right axis) and let TMP auto-size inside it, so labels never spill onto the neighbour buttons.
        public static void FitLabel(TMPro.TMP_Text t, Transform parent, float maxW, float frac)
        {
            if (t == null) return;
            var ls = t.transform.localScale; t.transform.localScale = new Vector3(ls.x / Mathf.Max(.01f, frac), ls.y, ls.z);
            float px = parent != null ? Mathf.Abs(parent.lossyScale.x) : 1f;
            float sx = Mathf.Abs(t.transform.lossyScale.x) / Mathf.Max(1e-5f, px);
            var rt = t.rectTransform; float w = maxW / Mathf.Max(1e-5f, sx);
            if (w > 0 && (rt.rect.width <= 0 || w < rt.rect.width)) rt.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, w);
            float fs = t.fontSize > 0 ? t.fontSize : 36f;
            t.textWrappingMode = TMPro.TextWrappingModes.NoWrap; t.enableAutoSizing = true; t.fontSizeMax = Mathf.Max(t.fontSizeMax, fs); t.fontSizeMin = Mathf.Min(1f, fs * .05f);
            t.overflowMode = TMPro.TextOverflowModes.Overflow; t.alignment = TMPro.TextAlignmentOptions.Center;
        }
    }
}

namespace GwyfShared
{
    /// ON/OFF look for toggle buttons: physical button turns glowing gold when active, neutral grey when off;
    /// on-screen HUD images get a gold tint + glow outline when active.
    public static class ToggleTint
    {
        static readonly UnityEngine.Color Gold = new UnityEngine.Color(1f, .78f, .12f), Grey = new UnityEngine.Color(.55f, .55f, .58f);
        static UnityEngine.MaterialPropertyBlock _mpb;
        public static void Physical(UnityEngine.Component btn, bool on)
        {
            if (btn == null) return;
            if (_mpb == null) _mpb = new UnityEngine.MaterialPropertyBlock();
            foreach (var r in btn.GetComponentsInChildren<UnityEngine.Renderer>(true))
            {
                if (r is UnityEngine.ParticleSystemRenderer || r.GetComponent<TMPro.TMP_Text>() != null) continue;
                r.GetPropertyBlock(_mpb);
                var c = on ? Gold : Grey;
                _mpb.SetColor("_Color", c); _mpb.SetColor("_BaseColor", c); _mpb.SetColor("_MainColor", c); _mpb.SetColor("_Tint", c);
                _mpb.SetColor("_EmissionColor", on ? Gold * 2.2f : UnityEngine.Color.black);
                _mpb.SetColor("_EmissiveColor", on ? Gold * 2.2f : UnityEngine.Color.black);
                r.SetPropertyBlock(_mpb);
                foreach (var m in r.sharedMaterials) if (m != null && on) m.EnableKeyword("_EMISSION");
            }
            foreach (var t in btn.GetComponentsInChildren<TMPro.TMP_Text>(true))
                t.color = on ? new UnityEngine.Color(1f, .93f, .35f) : new UnityEngine.Color(.88f, .88f, .88f);
        }
        public static void Ui(UnityEngine.UI.Graphic g, bool on)
        {
            if (g == null) return;
            g.color = on ? new UnityEngine.Color(1f, .9f, .45f) : new UnityEngine.Color(.78f, .78f, .78f);
            var o = g.GetComponent<UnityEngine.UI.Outline>() ?? g.gameObject.AddComponent<UnityEngine.UI.Outline>();
            o.effectColor = new UnityEngine.Color(1f, .8f, .15f, .9f); o.effectDistance = new UnityEngine.Vector2(6, -6); o.enabled = on;
        }
    }
}

namespace GwyfShared
{
    /// Server-side cabinet enlargement (scale is sent to clients in the spawn message). Keeps the base on the floor
    /// and pushes the cabinet forward by the extra depth so the back does not sink into a wall.
    public static class CabinetScaler
    {
        static readonly System.Collections.Generic.Dictionary<string, float> _base = new System.Collections.Generic.Dictionary<string, float>();
        public static string Apply(UnityEngine.Transform t, float s, UnityEngine.Transform frontRef, string key)
        {
            if (t == null || s <= 1.001f || s > 3f || !Mirror.NetworkServer.active) return null;
            float cur = t.localScale.x;
            if (!_base.TryGetValue(key, out var b)) { b = cur; _base[key] = b; }
            if (cur > b * 1.01f) return null; // already scaled (prefab or earlier pass)
            var rs = t.GetComponentsInChildren<UnityEngine.Renderer>(true);
            UnityEngine.Bounds Bb() { var bb = new UnityEngine.Bounds(t.position, UnityEngine.Vector3.zero); bool f = false; foreach (var r in rs) { if (r == null || r is UnityEngine.ParticleSystemRenderer) continue; if (!f) { bb = r.bounds; f = true; } else bb.Encapsulate(r.bounds); } return bb; }
            var b0 = Bb();
            var front = UnityEngine.Vector3.ProjectOnPlane(frontRef != null ? frontRef.position - b0.center : t.forward, UnityEngine.Vector3.up);
            if (front.sqrMagnitude < 1e-4f) front = t.forward; front.Normalize();
            float halfD = UnityEngine.Mathf.Abs(b0.extents.x * front.x) + UnityEngine.Mathf.Abs(b0.extents.z * front.z);
            t.localScale = t.localScale * s;
            var b1 = Bb();
            t.position += UnityEngine.Vector3.up * (b0.min.y - b1.min.y) + front * (halfD * (s - 1f));
            return $"cabinet scaled x{s:0.##} (floor kept, moved forward {halfD * (s - 1f):0.00} m)";
        }
    }
}

namespace GwyfShared
{
    /// Keeps TMP labels inside their boxes: inner margin proportional to the box, thinner outline, autosize.
    public static class TextFit
    {
        public static void Pad(UnityEngine.Transform root, float frac = .07f)
        {
            if (root == null) return;
            foreach (var t in root.GetComponentsInChildren<TMPro.TextMeshProUGUI>(true))
            {
                var sz = t.rectTransform.sizeDelta; float m = UnityEngine.Mathf.Min(sz.x, sz.y) * frac;
                if (m <= 0) continue;
                t.margin = new UnityEngine.Vector4(m, m * .5f, m, m * .5f);
                if (t.outlineWidth > .16f) t.outlineWidth = .16f;
                t.enableAutoSizing = true; t.overflowMode = TMPro.TextOverflowModes.Truncate;
            }
        }
    }
}

namespace GwyfShared
{
    /// Fits the UI to the visible screen glass: projects the cabinet's screen/glass mesh into canvas space and
    /// intersects it with the canvas rect (canvas can be larger than the bezel window).
    public static class ScreenFit
    {
        public static float Fallback = .09f, GlassInset = .04f;
        static void Inset(ref UnityEngine.Vector2 min, ref UnityEngine.Vector2 max, float f) { var d = (max - min) * f; min += d; max -= d; }
        public static string Fit(UnityEngine.Transform root, UnityEngine.RectTransform croot, ref UnityEngine.Vector2 min, ref UnityEngine.Vector2 max)
        {
            if (root == null || croot == null) { Inset(ref min, ref max, Fallback); return "no root -> conservative inset"; }
            UnityEngine.Vector2 bestMin = default, bestMax = default; float bestA = 0; string bestN = null;
            foreach (var mf in root.GetComponentsInChildren<UnityEngine.MeshFilter>(true))
            {
                var r = mf.GetComponent<UnityEngine.MeshRenderer>(); var mesh = mf.sharedMesh;
                if (r == null || mesh == null) continue;
                string n = (mf.name + " " + (r.sharedMaterial != null ? r.sharedMaterial.name : "")).ToLowerInvariant();
                if (!(n.Contains("screen") || n.Contains("glass")) || n.Contains("keypad")) continue;
                UnityEngine.Vector3[] vs;
                if (mesh.isReadable) vs = mesh.vertices;
                else { var lb = mesh.bounds; vs = new UnityEngine.Vector3[8]; for (int k = 0; k < 8; k++) vs[k] = lb.center + UnityEngine.Vector3.Scale(lb.extents, new UnityEngine.Vector3((k & 1) == 0 ? -1 : 1, (k & 2) == 0 ? -1 : 1, (k & 4) == 0 ? -1 : 1)); }
                if (vs.Length == 0) continue;
                float x0 = float.MaxValue, y0 = float.MaxValue, x1 = float.MinValue, y1 = float.MinValue, z0 = float.MaxValue, z1 = float.MinValue;
                foreach (var v in vs)
                {
                    var p = croot.InverseTransformPoint(mf.transform.TransformPoint(v));
                    if (p.x < x0) x0 = p.x; if (p.x > x1) x1 = p.x; if (p.y < y0) y0 = p.y; if (p.y > y1) y1 = p.y; if (p.z < z0) z0 = p.z; if (p.z > z1) z1 = p.z;
                }
                float w = x1 - x0, h = y1 - y0; if (w <= 0 || h <= 0) continue;
                if (z1 - z0 > UnityEngine.Mathf.Max(w, h) * .5f) continue; // not facing the canvas plane
                float a = w * h; if (a > bestA) { bestA = a; bestMin = new UnityEngine.Vector2(x0, y0); bestMax = new UnityEngine.Vector2(x1, y1); bestN = mf.name; }
            }
            if (bestN == null) { Inset(ref min, ref max, Fallback); return $"no screen/glass mesh found -> conservative {Fallback * 100:0}% inset {min}-{max}"; }
            var nmin = UnityEngine.Vector2.Max(min, bestMin); var nmax = UnityEngine.Vector2.Min(max, bestMax);
            var cs = max - min; var ns = nmax - nmin;
            if (ns.x < cs.x * .3f || ns.y < cs.y * .3f) { Inset(ref min, ref max, Fallback); return $"glass '{bestN}' rect {bestMin}-{bestMax} implausible -> conservative {Fallback * 100:0}% inset {min}-{max}"; }
            Inset(ref nmin, ref nmax, GlassInset); // the bezel overlaps the glass edge a little
            string res = $"fitted to glass '{bestN}' (+{GlassInset * 100:0}% inset): canvas {min}-{max} -> {nmin}-{nmax}";
            min = nmin; max = nmax; return res;
        }
    }
}

namespace GwyfShared
{
    /// Camera zoom for slot effects (v-camzoom): the slot screen stays fixed in the cabinet; instead the LOCAL player's
    /// camera narrows its FOV and turns slightly toward the target, then eases back.
    /// Vanilla GWYF has no slot-machine camera focus; its only camera zoom is PlayerCameraController (zoom key: lerps
    /// fieldOfView every LateUpdate). We reuse that camera and apply our factor on top of it right before URP renders it
    /// and restore right after, so vanilla zoom/run FOV, mouse look and interaction raycasts are untouched.
    public static class CamZoom
    {
        static object _key; static Vector3 _target; static float _s = 1f, _stamp; static bool _hooked;
        static Camera _cam; static float _savedFov; static Quaternion _savedRot; static bool _applied;
        public static float MaxDist = 8f;

        /// s = zoom factor (1 = none, 1.3 = FOV narrowed 1.3x). Call every frame while animating.
        public static void Set(object key, Vector3 worldTarget, float s)
        {
            Hook(); _key = key; _target = worldTarget; _s = Mathf.Max(1f, s); _stamp = Time.unscaledTime;
        }
        public static void Clear(object key) { if (_key == key) { _key = null; _s = 1f; } }

        static void Hook()
        {
            if (_hooked) return; _hooked = true;
            UnityEngine.Rendering.RenderPipelineManager.beginCameraRendering += Begin;
            UnityEngine.Rendering.RenderPipelineManager.endCameraRendering += End;
        }

        static void Begin(UnityEngine.Rendering.ScriptableRenderContext ctx, Camera cam)
        {
            _applied = false;
            if (_key == null || cam == null || cam != Camera.main) return;
            if (_key is UnityEngine.Object o && o == null) { _key = null; return; }
            if (Time.unscaledTime - _stamp > 0.5f) { _key = null; return; } // interrupted animation: let go
            Vector3 d = _target - cam.transform.position;
            if (d.magnitude > MaxDist || Vector3.Dot(cam.transform.forward, d.normalized) < 0.35f) return; // only the player looking at this slot
            _cam = cam; _savedFov = cam.fieldOfView; _savedRot = cam.transform.rotation; _applied = true;
            cam.fieldOfView = _savedFov / _s;
            float w = Mathf.Clamp01((_s - 1f) * 2.5f) * 0.6f;
            cam.transform.rotation = Quaternion.Slerp(_savedRot, Quaternion.LookRotation(d, Vector3.up), w);
        }

        static void End(UnityEngine.Rendering.ScriptableRenderContext ctx, Camera cam)
        {
            if (!_applied || cam != _cam) return;
            cam.fieldOfView = _savedFov; cam.transform.rotation = _savedRot; _applied = false;
        }
    }
}
