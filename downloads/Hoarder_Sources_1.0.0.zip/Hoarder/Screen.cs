using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Mirror;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
namespace Hoarder
{
    public partial class HoarderGame
    {
        RectTransform _ui,window,grid,fx,menuRoot;TMP_FontAsset font;
        Image[] cells=new Image[15],glows=new Image[15];TMP_Text[] values=new TMP_Text[15],names=new TMP_Text[15];Vector2[] home=new Vector2[15];
        Image[][] strips=new Image[5][];TMP_Text[][] stripValues=new TMP_Text[5][],stripNames=new TMP_Text[5][];
        TMP_Text totalX,totalMoney,spinCountLabel,levelLabel,betLabel,winLabel,statusLabel,waysLabel,menuTitle;
        TMP_Text[] menuText=new TMP_Text[4];Image[] menuCard=new Image[4];Image beam;TMP_Text popup,popupSub;
        readonly List<Material> ownedMaterials=new List<Material>();
        static readonly Dictionary<string,Sprite> sprites=new Dictionary<string,Sprite>();
        Vector2 size;float step;Coroutine animation;int lastAnimated=-1;HoarderMsg displayed;
        int lastMenu=int.MinValue;double lastMenuBet=-1;bool clientTurbo;double betNumber,shownTotal;string shownBet="-";int[] previous=HoarderEngine.InitialGrid();
        static readonly Color Lime=new Color(.68f,1f,.20f),Gold=new Color(1,.84f,.33f);
        public struct BtnDef {public string id,tip;public float cx,cy,w,h;public BtnDef(string id,string tip,float x,float y,float w,float h){this.id=id;this.tip=tip;cx=x;cy=y;this.w=w;this.h=h;}}
        public static readonly BtnDef[] Buttons={
            new BtnDef("Buy","Hoarder: bonus buy",.10f,.655f,.13f,.12f),new BtnDef("Info","Hoarder: rules / next page",.10f,.33f,.12f,.065f),
            new BtnDef("Minus","Bet -",.61f,.145f,.045f,.065f),new BtnDef("Plus","Bet +",.68f,.145f,.045f,.065f),
            new BtnDef("Turbo","Turbo",.735f,.145f,.047f,.065f),new BtnDef("Spin","Spin / confirm selected bonus",.82f,.145f,.075f,.12f),new BtnDef("Auto","Auto",.884f,.145f,.043f,.065f),
            new BtnDef("Buy0","Buy 7 Bunker Raid Spins, 110x bet",.34f,.64f,.27f,.22f),new BtnDef("Buy1","Buy 10 Bunker Raid Spins, 180x bet",.66f,.64f,.27f,.22f),
            new BtnDef("Buy2","Buy Super Raid, 145x bet",.34f,.37f,.27f,.22f),new BtnDef("Buy3","Buy Mystery Raid, 145x bet",.66f,.37f,.27f,.22f),
            new BtnDef("Close","Close menu",.90f,.86f,.06f,.055f)};
        static Sprite Spr(string key)
        {
            if(sprites.TryGetValue(key,out var sp))return sp;
            using(var stream=typeof(HoarderGame).Assembly.GetManifestResourceStream("Hoarder.art."+key+".png"))
            {
                if(stream==null)throw new InvalidOperationException("Missing embedded art: "+key);
                using(var mem=new System.IO.MemoryStream())
                {stream.CopyTo(mem);var tex=new Texture2D(2,2,TextureFormat.RGBA32,true);if(!ImageConversion.LoadImage(tex,mem.ToArray()))throw new InvalidOperationException("Bad PNG: "+key);
                    tex.name="HO_"+key;GwyfShared.ReelFx.ConfigureTexture(tex);sp=Sprite.Create(tex,new Rect(0,0,tex.width,tex.height),new Vector2(.5f,.5f),100);sprites[key]=sp;return sp;}
            }
        }
        public static Texture2D LoadPng(string key)=>Spr(key).texture;
        static Sprite Symbol(int sym)=>Spr(HoarderEngine.ArtKeys[Mathf.Clamp(sym,0,14)]);
        static Image Img(string n,Transform parent,Sprite sprite=null)
        {var go=new GameObject(n,typeof(RectTransform),typeof(Image));go.layer=parent.gameObject.layer;go.transform.SetParent(parent,false);var im=go.GetComponent<Image>();im.sprite=sprite;im.raycastTarget=false;im.preserveAspect=sprite!=null;return im;}
        static void Place(RectTransform rt,Vector2 pos,Vector2 dims)
        {rt.anchorMin=rt.anchorMax=rt.pivot=new Vector2(.5f,.5f);rt.sizeDelta=dims;rt.anchoredPosition=pos;}
        void N(RectTransform rt,float x,float y,float w,float h)=>Place(rt,new Vector2((x-.5f)*size.x,(y-.5f)*size.y),new Vector2(w*size.x,h*size.y));
        TMP_Text Text(string n,Transform parent,Color color,float pixels)
        {
            var go=new GameObject(n,typeof(RectTransform),typeof(CanvasRenderer));go.layer=parent.gameObject.layer;go.transform.SetParent(parent,false);var t=go.AddComponent<TextMeshProUGUI>();
            t.font=font;t.fontSharedMaterial=font.material;t.color=color;t.alignment=TextAlignmentOptions.Center;t.enableAutoSizing=true;t.fontSizeMax=pixels;t.fontSizeMin=1;t.textWrappingMode=TextWrappingModes.NoWrap;t.overflowMode=TextOverflowModes.Truncate;t.raycastTarget=false;
            t.fontStyle=FontStyles.Bold;return t;
        }
        TMP_Text Label(string n,string text,float x,float y,float w,float h,Color color,float fontFraction)
        {var t=Text(n,_ui,color,size.y*fontFraction);N(t.rectTransform,x,y,w,h);t.text=text;return t;}
        static void Layer(GameObject go,int layer){go.layer=layer;foreach(Transform t in go.transform)Layer(t.gameObject,layer);}
        void EnsureUi()
        {
            if(_ui!=null)return;
            var anchors=(symbolLocations??new List<Image>()).Where(i=>i!=null).ToList();
            if(anchors.Count==0&&reels!=null)anchors=reels.Where(r=>r!=null).SelectMany(r=>r.symbols??new Image[0]).Where(i=>i!=null).ToList();
            if(anchors.Count==0||anchors[0].canvas==null)throw new InvalidOperationException("Vanilla slot screen anchors not ready");
            var root=(RectTransform)anchors[0].canvas.transform;
            font=payoutText!=null?payoutText.font:TMP_Settings.defaultFontAsset;
            if(font==null)font=Resources.FindObjectsOfTypeAll<TMP_FontAsset>().FirstOrDefault(f=>f!=null&&f.material!=null);
            if(font==null||font.material==null)throw new InvalidOperationException("TMP font not ready");
            var min=root.rect.min;var max=root.rect.max;GwyfShared.ScreenFit.Fit(transform,root,ref min,ref max);
            size=(max-min)*(1-2*Mathf.Clamp(HoarderPlugin.ScreenMargin.Value,0,.2f));if(size.x<1||size.y<1)throw new InvalidOperationException("Screen dimensions invalid");
            var go=new GameObject("HoarderScreenWindow",typeof(RectTransform),typeof(RectMask2D));window=(RectTransform)go.transform;go.layer=root.gameObject.layer;window.SetParent(root,false);
            Place(window,(min+max)*.5f-root.rect.center,size);
            try
            {
                var bg=Img("HoarderUI",window,Spr("bg"));bg.preserveAspect=false;_ui=bg.rectTransform;Place(_ui,Vector2.zero,size);
                _ui.gameObject.AddComponent<RectMask2D>();BuildPanel();Layer(go,root.gameObject.layer);
                foreach(var r in reels??new List<SlotReel>())if(r!=null)foreach(var graphic in r.GetComponentsInChildren<Graphic>(true))graphic.enabled=false;
                foreach(var im in anchors)im.enabled=false;if(payoutText!=null){payoutText.text="";var oldTextRenderer=payoutText.GetComponent<MeshRenderer>();if(oldTextRenderer!=null)oldTextRenderer.enabled=false;}window.SetAsLastSibling();
            }
            catch{Destroy(go);window=null;_ui=null;throw;}
        }
        void BuildPanel()
        {
            Label("Title","HOARDER",.50f,.913f,.54f,.079f,Gold,.073f);
            Label("Subtitle","xWAYS · xSPLIT · BUNKER RAID",.5f,.860f,.52f,.025f,Lime,.021f);
            step=Mathf.Min(size.x*.60f/5,size.y*.53f/3);
            var gr=new GameObject("Reels",typeof(RectTransform),typeof(RectMask2D));grid=(RectTransform)gr.transform;grid.SetParent(_ui,false);N(grid,.49f,.526f,step*5/size.x,step*3/size.y);
            for(int c=0;c<5;c++)
            {
                var col=new GameObject("Column"+c,typeof(RectTransform),typeof(RectMask2D));var rt=(RectTransform)col.transform;rt.SetParent(grid,false);Place(rt,new Vector2((c-2)*step,0),new Vector2(step*.98f,step*3));
                strips[c]=new Image[5];stripValues[c]=new TMP_Text[5];stripNames[c]=new TMP_Text[5];
                for(int row=0;row<5;row++)MakeSymbol("Strip"+row,rt,out strips[c][row],out stripValues[c][row],out stripNames[c][row]);
                for(int row=0;row<3;row++)
                {
                    int i=c*3+row;home[i]=new Vector2((c-2)*step,(1-row)*step);
                    glows[i]=Img("HeldGlow"+i,grid,Spr("px"));Place(glows[i].rectTransform,home[i],Vector2.one*step*.98f);glows[i].color=Color.clear;
                    MakeSymbol("Cell"+i,grid,out cells[i],out values[i],out names[i]);Place(cells[i].rectTransform,home[i],Vector2.one*step*.94f);
                }
            }
            var fg=new GameObject("ScreenEffects",typeof(RectTransform));fx=(RectTransform)fg.transform;fx.SetParent(grid,false);Place(fx,Vector2.zero,new Vector2(step*5,step*3));fx.SetAsLastSibling();
            beam=Img("SplitRay",fx,Spr("px"));beam.color=Color.clear;
            waysLabel=Label("Ways","243 WAYS",.49f,.225f,.57f,.028f,Lime,.025f);
            Label("Buy","BUY FEATURE",.10f,.675f,.12f,.045f,Gold,.024f);Label("BuySub","110x – 180x BET",.10f,.631f,.125f,.028f,Color.white,.019f);
            Label("Info","RULES / NEXT",.10f,.33f,.125f,.04f,Color.white,.021f);
            Label("TotalTitle","TOTAL WIN",.90f,.716f,.12f,.028f,Gold,.023f);
            totalX=Label("TotalX","0x",.90f,.662f,.13f,.055f,Lime,.045f);
            totalMoney=Label("TotalMoney","$0",.90f,.610f,.12f,.030f,Color.white,.025f);
            Label("SpinsTitle","SPINS LEFT",.9f,.515f,.12f,.028f,Gold,.021f);
            spinCountLabel=Label("Spins","—",.9f,.464f,.12f,.057f,Color.white,.050f);
            levelLabel=Label("Level","BASE GAME",.9f,.412f,.12f,.033f,Lime,.020f);
            Label("BetTitle","BET",.285f,.171f,.14f,.025f,Gold,.021f);betLabel=Label("Bet","-",.285f,.13f,.18f,.039f,Color.white,.033f);
            Label("WinTitle","WIN",.47f,.171f,.16f,.025f,Gold,.021f);winLabel=Label("Win","$0",.47f,.13f,.18f,.039f,Lime,.033f);
            statusLabel=Label("Status","SPIN TO HOARD",.5f,.076f,.72f,.028f,Color.white,.021f);
            foreach(var b in Buttons.Where(b=>new[]{"Minus","Plus","Turbo","Spin","Auto"}.Contains(b.id)))
            {
                var button=Img("Hud"+b.id,_ui,Spr("button"));N(button.rectTransform,b.cx,b.cy,b.w,b.h);button.preserveAspect=true;
                var text=Text("Text",button.transform,Gold,size.y*(b.id=="Spin"?.025f:.020f));Place(text.rectTransform,Vector2.zero,new Vector2(size.x*b.w*.86f,size.y*b.h*.75f));text.text=b.id=="Minus"?"-":b.id=="Plus"?"+":b.id=="Turbo"?"FAST":b.id=="Auto"?"AUTO":"SPIN";
            }
            var pg=new GameObject("Popup",typeof(RectTransform),typeof(Image));var dim=pg.GetComponent<Image>();dim.color=new Color(.02f,.035f,.01f,.91f);dim.raycastTarget=false;
            var pr=(RectTransform)pg.transform;pr.SetParent(_ui,false);N(pr,.5f,.53f,.76f,.47f);
            popup=Text("PopupTitle",pr,Gold,size.y*.070f);Place(popup.rectTransform,new Vector2(0,size.y*.040f),new Vector2(size.x*.70f,size.y*.09f));
            popupSub=Text("PopupSub",pr,Lime,size.y*.034f);Place(popupSub.rectTransform,new Vector2(0,-size.y*.050f),new Vector2(size.x*.66f,size.y*.06f));pg.SetActive(false);
            var mg=new GameObject("Menu",typeof(RectTransform),typeof(Image));menuRoot=(RectTransform)mg.transform;menuRoot.SetParent(_ui,false);N(menuRoot,.5f,.52f,.88f,.80f);
            mg.GetComponent<Image>().color=new Color(.045f,.06f,.025f,.97f);mg.GetComponent<Image>().raycastTarget=false;
            menuTitle=Text("MenuTitle",menuRoot,Gold,size.y*.035f);Place(menuTitle.rectTransform,new Vector2(0,size.y*.30f),new Vector2(size.x*.76f,size.y*.055f));
            for(int i=0;i<4;i++)
            {
                var d=Buttons.First(b=>b.id=="Buy"+i);menuCard[i]=Img("Option"+i,menuRoot,Spr("panel"));menuCard[i].preserveAspect=false;
                Place(menuCard[i].rectTransform,new Vector2((d.cx-.5f)*size.x,(d.cy-.52f)*size.y),new Vector2(d.w*size.x,d.h*size.y));
                menuText[i]=Text("OptionText"+i,menuCard[i].transform,Gold,size.y*.023f);menuText[i].textWrappingMode=TextWrappingModes.Normal;
                Place(menuText[i].rectTransform,Vector2.zero,new Vector2(size.x*d.w*.9f,size.y*d.h*.87f));
            }
            var close=Text("Close",menuRoot,Color.white,size.y*.022f);Place(close.rectTransform,new Vector2(.4f*size.x,.34f*size.y),new Vector2(.05f*size.x,.05f*size.y));close.text="×";
            menuRoot.gameObject.SetActive(false);ShowBuyMenu(-1);
        }
        void MakeSymbol(string n,Transform parent,out Image image,out TMP_Text value,out TMP_Text name)
        {
            image=Img(n,parent);Place(image.rectTransform,Vector2.zero,Vector2.one*step*.94f);image.preserveAspect=true;
            var plate=Img("ValuePlate",image.transform,Spr("px"));plate.preserveAspect=false;plate.color=new Color(.045f,.065f,.015f,.94f);Place(plate.rectTransform,new Vector2(step*.20f,-step*.32f),new Vector2(step*.46f,step*.21f));plate.gameObject.SetActive(false);
            value=Text("Multiplicity",image.transform,Gold,step*.19f);Place(value.rectTransform,new Vector2(step*.20f,-step*.32f),new Vector2(step*.46f,step*.21f));
            name=Text("SpecialLabel",image.transform,Color.white,step*.16f);Place(name.rectTransform,Vector2.zero,new Vector2(step*.80f,step*.38f));name.textWrappingMode=TextWrappingModes.Normal;
        }
        void SymbolView(Image im,TMP_Text val,TMP_Text tag,int symbol,int mult,float scaleX=1)
        {
            im.sprite=Symbol(symbol);im.color=Color.white;im.rectTransform.localScale=new Vector3(scaleX,1,1);
            im.transform.GetChild(0).gameObject.SetActive(mult>1);val.text=mult>1?"x"+mult:"";
            tag.text=symbol==HoarderEngine.XWays?"WAYS":symbol==HoarderEngine.Split?"SPLIT":symbol==HoarderEngine.Wild?"WILD":symbol==HoarderEngine.Scatter?"FALLOUT\nSCATTER":symbol==HoarderEngine.Super?"SUPER\nSCATTER":"";
        }
        void SetIdle()
        {if(_ui==null)return;DrawGrid(previous,Enumerable.Repeat(1,15).ToArray());}
        void DrawGrid(int[] symbols,int[] weights)
        {
            for(int c=0;c<5;c++)foreach(var im in strips[c])im.gameObject.SetActive(false);
            for(int i=0;i<15;i++){cells[i].gameObject.SetActive(true);SymbolView(cells[i],values[i],names[i],symbols[i],weights[i]);cells[i].rectTransform.anchoredPosition=home[i];glows[i].color=Color.clear;}
        }
        static float Smooth(float p){p=Mathf.Clamp01(p);return p*p*p*(p*(p*6-15)+10);}
        static string X(double v)=>v.ToString(v<100?"0.##":"0.#",CultureInfo.InvariantCulture)+"x";
        static string Money(double n){if(double.IsNaN(n)||double.IsInfinity(n))return "—";double a=Math.Abs(n);return "$"+(a>=1e9?(n/1e9).ToString("0.##",CultureInfo.InvariantCulture)+"B":a>=1e6?(n/1e6).ToString("0.##",CultureInfo.InvariantCulture)+"M":a>=1e3?(n/1e3).ToString("0.##",CultureInfo.InvariantCulture)+"K":n.ToString("0.##",CultureInfo.InvariantCulture));}
        void Totals(double total){shownTotal=total;totalX.text=X(total);totalMoney.text=Money(total*betNumber);winLabel.text=Money(total*betNumber);}
        public void UserRpcShowSpin(string json)
        {
            if(!NetworkClient.active)return;
            HoarderMsg msg;try{msg=GwyfShared.MiniJson.FromJson<HoarderMsg>(json);EnsureUi();}catch(Exception e){HoarderPlugin.Log.LogError("[HO] Client packet: "+e);return;}
            if(!string.IsNullOrEmpty(msg.bet))shownBet=msg.bet;if(msg.bn>0)betNumber=msg.bn;clientTurbo=msg.settingTurbo==1;betLabel.text=shownBet;ShowBuyMenu(msg.menu);
            foreach(string button in new[]{"Turbo","Auto"})
            {
                var tr=_ui.Find("Hud"+button);if(tr==null)continue;var image=tr.GetComponent<Image>();bool on=button=="Turbo"?clientTurbo:msg.auto>0;
                if(image!=null)image.color=on?new Color(.75f,1,.40f):Color.white;
                var text=tr.GetComponentInChildren<TMP_Text>();if(text!=null)text.text=button=="Turbo"?(on?"FAST\nON":"FAST"):(on?"AUTO\n"+msg.auto:"AUTO");
            }
            if(msg.t=="control"){statusLabel.text=msg.auto>0?"AUTO · "+msg.auto+" SPINS":msg.busy==1?"ROUND IN PROGRESS":"SPIN TO HOARD";return;}
            if(msg.seq<=lastAnimated)return;lastAnimated=msg.seq;
            ClientAbort();displayed=msg;float elapsed=HoarderTiming.Elapsed(NetworkTime.time,msg.sent,msg.duration);
            if(elapsed>=msg.duration){if(msg.s!=null){DrawGrid(msg.s.g,msg.s.m);previous=(int[])msg.s.g.Clone();}Totals(msg.total);UpdateFeatureHud(msg.s);statusLabel.text=msg.t=="end"?"ROUND COMPLETE · "+X(msg.total):"ROUND IN PROGRESS";return;}
            animation=StartCoroutine(SafeAnimate(msg,(float)elapsed));
        }
        void UpdateFeatureHud(HoarderEngine.Spin s)
        {
            if(s==null)return;waysLabel.text=s.ways.ToString("N0",CultureInfo.InvariantCulture)+" WIN WAYS";
            spinCountLabel.text=s.bonus==1||s.scatters>=3?s.left.ToString():"—";
            levelLabel.text=s.bonus==1||s.scatters>=3?(s.level==3?"WASTELAND":"LEVEL "+s.level+" · "+s.collected+" / 9"):"BASE GAME";
        }
        IEnumerator SafeAnimate(HoarderMsg msg,float elapsed)
        {
            var stack=new Stack<IEnumerator>();stack.Push(Animate(msg,elapsed));
            while(stack.Count>0)
            {
                object current;var top=stack.Peek();
                try{if(!top.MoveNext()){stack.Pop();(top as IDisposable)?.Dispose();continue;}current=top.Current;}
                catch(Exception e){HoarderPlugin.Log.LogError("[HO] Animation: "+e);break;}
                if(current is IEnumerator nested){stack.Push(nested);continue;}yield return current;
            }
            while(stack.Count>0)(stack.Pop() as IDisposable)?.Dispose();
            if(msg.s!=null)DrawGrid(msg.s.g,msg.s.m);Totals(msg.total);UpdateFeatureHud(msg.s);animation=null;
        }
        IEnumerator Animate(HoarderMsg m,float startElapsed)
        {
            bool tb=m.tb==1;float origin=Time.unscaledTime-startElapsed;bool soundStarted=false,revealSound=false;int sliceSound=0;var stops=new bool[5];
            try
            {
                if(m.t=="intro")
                {
                    popup.transform.parent.gameObject.SetActive(true);popup.text=m.buyVariant>=0?"FEATURE BOUGHT":"BUNKER RAID";
                    popupSub.text=m.s.left+" SPINS · "+(m.s.superSeed>0?m.s.superSeed+" STICKY xWAYS":"COLLECT xWAYS");
                    while(Time.unscaledTime-origin<m.duration){float p=(Time.unscaledTime-origin)/m.duration;popup.transform.parent.localScale=Vector3.one*(.94f+.06f*Smooth(Mathf.Min(p*4,1)));yield return null;}
                    popup.transform.parent.gameObject.SetActive(false);UpdateFeatureHud(m.s);yield break;
                }
                if(m.t=="end")
                {
                    if(m.s!=null)DrawGrid(m.s.g,m.s.m);Totals(m.total);UpdateFeatureHud(m.s);
                    statusLabel.text=m.total>=HoarderEngine.MaxWinX?"KING OF WASTE · MAX WIN 11030x":"ROUND COMPLETE · "+X(m.total);
                    yield break;
                }
                double from=Math.Max(0,m.total-m.s.win);
                while(true)
                {
                    float elapsed=Time.unscaledTime-origin;if(!soundStarted&&elapsed<HoarderTiming.ReelEnd(4,tb)){soundStarted=true;Sfx(spinReelSFX);}
                    for(int c=0;c<5;c++)if(!stops[c]&&elapsed>=HoarderTiming.ReelEnd(c,tb)){stops[c]=true;Sfx(spinDoneSFX);}
                    while(sliceSound<m.s.splits.Count&&elapsed>=HoarderTiming.ReelEnd(4,tb)+sliceSound*HoarderTiming.Slice(tb))
                    {var act=m.s.splits[sliceSound++];Sfx(multiplierSFX,act.weights.Length>0?act.weights.Max():2);}
                    if(!revealSound&&m.s.reveal>=0&&elapsed>=HoarderTiming.ReelEnd(4,tb)+m.s.splits.Count*HoarderTiming.Slice(tb))
                    {revealSound=true;Sfx(multiplierSFX,m.s.m.Max());}
                    DrawSpin(m.s,elapsed,tb,from);if(elapsed>=m.duration)break;yield return null;
                }
                DrawGrid(m.s.g,m.s.m);previous=(int[])m.s.g.Clone();if(m.s.win>0)Sfx(finaltextSFX,(float)m.s.win);Totals(m.total);UpdateFeatureHud(m.s);
            }
            finally{beam.color=Color.clear;if(popup!=null)popup.transform.parent.gameObject.SetActive(false);animation=null;}
        }
        void DrawSpin(HoarderEngine.Spin s,float elapsed,bool tb,double from)
        {
            var working=(int[])s.raw.Clone();var weights=Enumerable.Repeat(1,15).ToArray();
            for(int i=0;i<15;i++)if(working[i]==HoarderEngine.XWays)weights[i]=s.size[i];
            float landing=HoarderTiming.ReelEnd(4,tb),cursor=landing;beam.color=Color.clear;
            foreach(var action in s.splits)
            {
                float q=Mathf.Clamp01((elapsed-cursor)/HoarderTiming.Slice(tb));
                if(q>0)
                {
                    float endX=home[action.source].x-step*(action.source/3)*Smooth(q); // all effects in reel-local coordinates
                    if(q<1){Place(beam.rectTransform,new Vector2((home[action.source].x+endX)*.5f,home[action.source].y),new Vector2(Mathf.Max(1,home[action.source].x-endX),step*.035f));beam.color=new Color(.7f,1,.25f,.9f*Mathf.Sin(q*Mathf.PI));}
                    for(int k=0;k<action.changed.Length;k++)if(q>=(action.source/3-action.changed[k]/3)/(float)(action.source/3+1)){weights[action.changed[k]]=action.weights[k];}
                    foreach(int i in action.supers)if(q>.45f)working[i]=HoarderEngine.Super;
                    if(q>.55f)working[action.source]=HoarderEngine.Wild;
                }
                cursor+=HoarderTiming.Slice(tb);
            }
            float revealQ=s.reveal>=0?Mathf.Clamp01((elapsed-cursor)/HoarderTiming.Reveal(tb)):0;
            for(int i=0;i<15;i++)
            {
                bool becomesWay=working[i]==HoarderEngine.XWays||(working[i]==HoarderEngine.Super&&s.scatters<3);
                if(becomesWay&&revealQ>=.5f){working[i]=s.g[i];weights[i]=s.m[i];}
            }
            for(int c=0;c<5;c++)
            {
                float end=HoarderTiming.ReelEnd(c,tb);bool moving=elapsed<end;int travel=Math.Max(4,(int)Math.Round(end*6));float p=CellReelMotion.Position(elapsed,end,travel);
                foreach(var im in strips[c])im.gameObject.SetActive(moving);
                if(moving)
                {
                    for(int j=0;j<5;j++)
                    {
                        int idx=(int)Math.Floor(p)+1-j;int endRow=travel-idx,startRow=-idx;
                        int sym=endRow>=0&&endRow<3?s.raw[c*3+endRow]:startRow>=0&&startRow<3?previous[c*3+startRow]:Math.Abs(idx+c*3)%10;
                        int mult=endRow>=0&&endRow<3&&sym==HoarderEngine.XWays?s.size[c*3+endRow]:1;
                        SymbolView(strips[c][j],stripValues[c][j],stripNames[c][j],sym,mult);
                        Place(strips[c][j].rectTransform,new Vector2(0,step+(idx-p)*step),Vector2.one*step*.94f);
                    }
                }
                for(int row=0;row<3;row++)
                {
                    int i=c*3+row;bool held=s.bonus==1&&s.stickyBefore[i]>0;
                    cells[i].gameObject.SetActive(!moving||held);glows[i].rectTransform.anchoredPosition=home[i];glows[i].color=held?new Color(.30f,.60f,.05f,.35f):Color.clear;
                    if(!moving||held)
                    {
                        float sx=1;if(s.reveal>=0&&(s.raw[i]==HoarderEngine.XWays||(HoarderEngine.IsScatter(s.raw[i])&&s.g[i]<HoarderEngine.Regular&&s.scatters<3))&&revealQ>0&&revealQ<1)sx=Mathf.Max(.04f,Mathf.Abs(Mathf.Cos(revealQ*Mathf.PI)));
                        SymbolView(cells[i],values[i],names[i],moving&&held?HoarderEngine.XWays:working[i],moving&&held?s.stickyBefore[i]:weights[i],sx);
                    }
                }
            }
            if(s.reveal>=0)cursor+=HoarderTiming.Reveal(tb);
            if(s.bonus==1&&s.newWays>0)
            {
                float q=Mathf.Clamp01((elapsed-cursor)/HoarderTiming.Reveal(tb));
                for(int i=0;i<15;i++)if(s.raw[i]==HoarderEngine.XWays&&s.stickyBefore[i]==0&&q>0&&q<1)
                {glows[i].color=new Color(.4f,1,.10f,.30f*Mathf.Sin(q*Mathf.PI));glows[i].rectTransform.anchoredPosition=Vector2.Lerp(home[i],home[i/3*3+2],Smooth(q));}
                cursor+=HoarderTiming.Reveal(tb);
            }
            bool levelUp=s.bonus==1&&s.level>HoarderEngine.Level(s.collected-s.newWays);
            if(levelUp)
            {
                float levelQ=Mathf.Clamp01((elapsed-cursor)/HoarderTiming.Reveal(tb));
                popup.transform.parent.gameObject.SetActive(levelQ>0&&levelQ<1);
                if(levelQ>0&&levelQ<1){popup.text="HOARDER LEVEL "+s.level;popupSub.text=s.level==3?"WASTELAND · 4 SYMBOLS":"LOW SYMBOLS REMOVED";popup.transform.parent.localScale=Vector3.one*(.96f+.04f*Smooth(Mathf.Min(1,levelQ*4)));}
                cursor+=HoarderTiming.Reveal(tb);
            }
            float count=Mathf.Clamp01((elapsed-cursor)/HoarderTiming.Count(tb));Totals(from+s.win*Smooth(count));
            for(int i=0;i<15;i++)
            {
                if(count>0&&Array.IndexOf(s.winning,i)>=0)glows[i].color=new Color(.72f,1,.22f,.20f*Mathf.Sin(count*Mathf.PI));
                if(count>=1){glows[i].color=Color.clear;glows[i].rectTransform.anchoredPosition=home[i];}
            }
            UpdateFeatureHud(s);statusLabel.text=elapsed<landing?(s.bonus==1?"BUNKER RAID · SPINNING":"SPINNING"):
                elapsed<landing+s.splits.Count*HoarderTiming.Slice(tb)?"xSPLIT · DOUBLE TO THE LEFT":s.newWays>0?"+"+s.newWays+" SPIN · xWAYS COLLECTED":s.win>0?"WIN "+X(s.win):"HOARD MORE";
        }
        void ShowBuyMenu(int selected)
        {
            if(menuRoot==null)return;
            if(selected==lastMenu&&lastMenuBet==betNumber)return;lastMenu=selected;lastMenuBet=betNumber;
            menuRoot.gameObject.SetActive(selected!=-1);
            foreach(var trig in GetComponentsInChildren<InteractableEventTrigger>(true))
            {if(trig.name.StartsWith("HOScr_Buy")&&trig.name.Length>9)trig.gameObject.SetActive(selected>=0);else if(trig.name=="HOScr_Close")trig.gameObject.SetActive(selected!=-1);}
            for(int i=menuRoot.childCount-1;i>=0;i--){var t=menuRoot.GetChild(i);if(t.name.StartsWith("Rule"))Destroy(t.gameObject);}
            foreach(var card in menuCard)card.gameObject.SetActive(selected>=0);
            if(selected==-1)return;
            if(selected>=0)
            {
                menuTitle.text="BUY FEATURE · SELECT, THEN SPIN";
                for(int i=0;i<4;i++)
                {menuText[i].text=HoarderEngine.BuyNames[i]+"\n\n"+HoarderEngine.BuyCost[i]+"x BET\n"+Money(betNumber*HoarderEngine.BuyCost[i])+"\n"+(i==selected?"SELECTED · SPIN TO BUY":"[E] BUY THIS FEATURE");menuCard[i].color=i==selected?new Color(.60f,.85f,.25f):Color.white;}
                return;
            }
            menuTitle.text=selected==-2?"PAYOUT · 1 UNIT = 0.02x BET":selected==-3?"xWAYS / xSPLIT":"BUNKER RAID / WASTELAND";
            if(selected==-2)
            {
                for(int i=0;i<10;i++)
                {
                    float x=(i%5-2)*size.x*.15f,y=(i/5==0?.12f:-.13f)*size.y;
                    var icon=Img("RuleIcon"+i,menuRoot,Symbol(i));Place(icon.rectTransform,new Vector2(x,y),Vector2.one*size.y*.135f);
                    var t=Text("RulePay"+i,menuRoot,Color.white,size.y*.018f);Place(t.rectTransform,new Vector2(x,y-size.y*.11f),new Vector2(size.x*.145f,size.y*.065f));t.textWrappingMode=TextWrappingModes.Normal;
                    t.text="3: "+HoarderEngine.Pays[i][0]+"  4: "+HoarderEngine.Pays[i][1]+"\n5: "+HoarderEngine.Pays[i][2];
                }
            }
            else
            {
                var t=Text("RuleText",menuRoot,Color.white,size.y*.027f);t.alignment=TextAlignmentOptions.Left;t.textWrappingMode=TextWrappingModes.Normal;
                Place(t.rectTransform,new Vector2(0,-size.y*.02f),new Vector2(size.x*.75f,size.y*.53f));
                t.text=selected==-3?"xWAYS\nReels 2–4. Each tile reveals 2–4 matching symbols. All xWays in a spin reveal the same symbol.\n\nxSPLIT\nBase game, reels 3–5. Splits every symbol to its left on the same row. Each blade doubles multiplicity. Scatter becomes SUPER SCATTER.\n\nWILD replaces regular symbols. Ways pay left to right on adjacent reels, starting at reel 1.":
                    "3 SCATTERS → 7 SPINS\n4 SCATTERS → 10 SPINS\nSuper Scatter and cells below become sticky xWays.\n\nEach new xWays awards +1 spin and joins the sticky stack at the bottom of its reel.\n\n3 / 6 / 9 collected → HOARDER LEVEL UP\nRemove the weakest character and object at each level. Level 3: WASTELAND, four regular symbols.\n\nKING OF WASTE · MAX ROUND WIN 11030x\nMod uses its own reel frequencies and feature prices.";
            }
        }
        void ClientAbort()
        {
            if(animation!=null){StopCoroutine(animation);animation=null;}
            if(_ui==null)return;foreach(var col in strips)if(col!=null)foreach(var im in col)if(im!=null)im.gameObject.SetActive(false);
            for(int i=0;i<15;i++)if(cells[i]!=null){cells[i].gameObject.SetActive(true);cells[i].rectTransform.localScale=Vector3.one;cells[i].rectTransform.anchoredPosition=home[i];glows[i].color=Color.clear;glows[i].rectTransform.anchoredPosition=home[i];}
            if(beam!=null)beam.color=Color.clear;if(popup!=null)popup.transform.parent.gameObject.SetActive(false);
        }
    }
}
