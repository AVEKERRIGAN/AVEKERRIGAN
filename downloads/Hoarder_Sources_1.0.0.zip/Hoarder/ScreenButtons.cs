using System;using System.Linq;using HarmonyLib;using UnityEngine;using UnityEngine.UI;
namespace Hoarder
{
    public partial class HoarderGame
    {
        // Drawn controls and colliders use the SAME canvas rectangle and inset,
        // avoiding the old independent UV-fit that drifted on slanted screens.
        public static void CreateScreenButtons(HoarderGame game,GameObject clone)
        {
            var play=game.playButtons.FirstOrDefault();var anchor=game.symbolLocations.FirstOrDefault(i=>i!=null&&i.canvas!=null);
            if(play==null||anchor==null){HoarderPlugin.Log.LogWarning("[HO] No screen anchors: use physical controls");return;}
            var root=(RectTransform)anchor.canvas.transform;Vector2 min=root.rect.min,max=root.rect.max;
            GwyfShared.ScreenFit.Fit(game.transform,root,ref min,ref max);
            float margin=Mathf.Clamp(HoarderPlugin.ScreenMargin.Value,0,.2f);var dimensions=(max-min)*(1-2*margin);var centre=(min+max)*.5f;
            float sx=HoarderPlugin.ScreenFlipX.Value?-1:1,sy=HoarderPlugin.ScreenFlipY.Value?-1:1;
            foreach(var def in Buttons)
            {
                var go=UnityEngine.Object.Instantiate(play.gameObject,root);go.name="HOScr_"+def.id;
                for(int i=go.transform.childCount-1;i>=0;i--)UnityEngine.Object.DestroyImmediate(go.transform.GetChild(i).gameObject);
                foreach(var c in go.GetComponents<Collider>())UnityEngine.Object.DestroyImmediate(c);
                foreach(var c in go.GetComponents<Renderer>())UnityEngine.Object.DestroyImmediate(c);
                foreach(var c in go.GetComponents<MeshFilter>())UnityEngine.Object.DestroyImmediate(c);
                go.transform.localScale=Vector3.one;go.transform.localRotation=Quaternion.identity;
                go.transform.localPosition=new Vector3(centre.x+sx*(def.cx-.5f)*dimensions.x,centre.y+sy*(def.cy-.5f)*dimensions.y,0);
                var box=go.AddComponent<BoxCollider>();box.size=new Vector3(def.w*dimensions.x,def.h*dimensions.y,.035f/Mathf.Max(1e-5f,Mathf.Abs(root.lossyScale.z)));
                var trigger=go.GetComponent<InteractableEventTrigger>();
                if(trigger!=null)
                {
                    foreach(var ev in new UnityEngine.Events.UnityEventBase[]{trigger.onInteractEvent,trigger.serverOnInteractEvent,trigger.rpcOnInteractEvent,trigger.onHoverEvent,trigger.onHoverExitEvent,trigger.onHoldEvent,trigger.onHoldExitEvent})
                        if(ev!=null)for(int i=0;i<ev.GetPersistentEventCount();i++)ev.SetPersistentListenerState(i,UnityEngine.Events.UnityEventCallState.Off);
                    AccessTools.Field(typeof(InteractableBase),"tooltipMessage")?.SetValue(trigger,"[E] "+def.tip);
                    AccessTools.Field(typeof(InteractableBase),"interactableName")?.SetValue(trigger,"Hoarder: "+def.tip);
                }
                if(def.id=="Close"||def.id.Length==4&&def.id.StartsWith("Buy"))go.SetActive(false);
            }
        }
    }
}
