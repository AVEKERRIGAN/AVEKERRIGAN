from PIL import Image,ImageDraw,ImageFont
from pathlib import Path
import json,shutil,hashlib
root=Path(__file__).parent
atlas=root/'inputs'/'symbol-atlas.png'
background=root/'inputs'/'background.png'
keys=['hazmat','mask','karen','cowboy','prepper','detector','medkit','fuel','jug','paper','xways','split','wild','scatter','super']
im=Image.open(atlas);w,h=im.size
# Equal-square atlas extraction only: do not stretch the generated illustrations.
for n,key in enumerate(keys):
 c=n%5;r=n//5;cx=(c+.5)*w/5;cy=(r+.5)*h/3;side=min(w/5,h/3)*.955
 tile=im.crop((round(cx-side/2),round(cy-side/2),round(cx+side/2),round(cy+side/2))).convert('RGBA')
 tile.resize((512,512),Image.Resampling.LANCZOS).save(root/'art'/f'{key}.png')
shutil.copy2(background,root/'art'/'bg.png')
Image.new('RGBA',(4,4),'white').save(root/'art'/'px.png')
button=Image.new('RGBA',(256,256));d=ImageDraw.Draw(button)
d.ellipse((7,7,249,249),fill='#1a2013',outline='#ac873d',width=12);d.ellipse((23,23,233,233),outline='#566539',width=4);button.save(root/'art'/'button.png')
panel=Image.new('RGBA',(512,256),'#30351b');d=ImageDraw.Draw(panel);d.rounded_rectangle((3,3,509,253),radius=20,outline='#b7a14f',width=5)
for x in(16,496):
 for y in(16,240):d.ellipse((x-4,y-4,x+4,y+4),fill='#d0b371')
panel.save(root/'art'/'panel.png')
# UV-matched marquee dimensions taken from prior cabinet skin, original content.
marquee_size=(512,512)
top=Image.new('RGBA',marquee_size,'#181e10');d=ImageDraw.Draw(top);fontpath='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
font=ImageFont.truetype(fontpath,max(16,int(top.height*.075)))
label='HOARDER';bbox=d.textbbox((0,0),label,font=font);d.text(((top.width-bbox[2])/2,(top.height-bbox[3])/2),label,font=font,fill='#dfc35d',stroke_width=2,stroke_fill='#070a03')
top.save(root/'art'/'topscreen.png')
(root/'research'/'art-provenance.json').write_text(json.dumps({'created':'2026-10-14','type':'original generated illustrations + procedural UI primitives','atlas':atlas.name,'atlas_sha256':hashlib.sha256(atlas.read_bytes()).hexdigest(),'background':background.name,'background_sha256':hashlib.sha256(background.read_bytes()).hexdigest(),'game_original_assets_copied':False,'extraction':'15 uniform square tile crops, Lanczos 512px, preserve aspect'},indent=2))
print('PASS: 15 square symbols, background, button, panel, marquee; atlas',im.size,'marquee',marquee_size)
