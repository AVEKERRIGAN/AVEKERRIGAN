from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,json,shutil,subprocess
root=Path(__file__).parent;out=Path('/workspace/outputs');repo=Path('/workspace/AVEKERRIGAN')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
engine=json.loads((out/'Hoarder_Engine_Checks_1.0.0.json').read_text());native=json.loads((out/'Hoarder_Assembly_Layout_Checks_1.0.0.json').read_text());browser=json.loads((out/'Hoarder_Browser_Checks_1.0.0.json').read_text())
assert engine['pass'] and engine['rounds']==12000 and native['pass'] and browser['pass'] and browser['frames']==540
binary=root/'bin/Release/netstandard2.1/Hoarder.dll'
assert native['binary_sha256']==sha(binary)
assert browser['html_sha256']==sha(out/'Hoarder_Preview_1.0.0.html')
for name,hash_ in native['sha256'].items():assert sha(root/name)==hash_,name
build=(root.parent/'hoarder-build.log').read_text();assert '0 Warning(s)' in build and '0 Error(s)' in build and 'Build succeeded.' in build
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_entries','stream=width,height,nb_frames,duration','-of','json',str(out/'Hoarder_Animations_1.0.0.mp4')]))['streams'][0]
assert int(probe['nb_frames'])==540 and float(probe['duration'])==18 and probe['width']==1280 and probe['height']==800
install={'BepInEx/plugins/Hoarder/Hoarder.dll':binary,'README_RU.md':root/'README_RU.md'}
for name in ['Hoarder_Preview_1.0.0.html','Hoarder_Animations_1.0.0.mp4','Hoarder_Screen_1.0.0.png']:
 install['preview/'+name]=out/name
for name in ['Hoarder_Engine_Checks_1.0.0.json','Hoarder_Assembly_Layout_Checks_1.0.0.json','Hoarder_Browser_Checks_1.0.0.json']:
 install['validation/'+name]=out/name
manifest={'name':'Hoarder','version':'1.0.0','plugin_guid':'com.avekerrigan.hoarder','game':'Gamble With Your Friends','created':'2026-10-14','type':'BepInEx 5 Mono plugin','all_coop_players_need_same_version':True,'live_unity_verified':False,'live_coop_verified':False,'math':'Original mod adaptation of supplied xWays Hoarder xSplit rules; custom probabilities, prices and payout unit. Original RTP not claimed.','files':{name:{'bytes':p.stat().st_size,'sha256':sha(p)} for name,p in install.items()}}
installZip=out/'Hoarder_1.0.0.zip'
with ZipFile(installZip,'w',ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in install.items():z.write(p,name)
 z.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2))
sources=out/'Hoarder_Sources_1.0.0.zip'
with ZipFile(sources,'w',ZIP_DEFLATED,compresslevel=9) as z:
 for folder in [root,root.parent/'HoarderChecks',root.parent/'HoarderPreview']:
  for p in folder.rglob('*'):
   if not p.is_file() or any(part in {'bin','obj','__pycache__'} for part in p.relative_to(folder).parts):continue
   z.write(p,str(p.relative_to(root.parent)))
 z.write(root.parent/'global.json','global.json')
 z.write(out/'Hoarder_Demo_1.0.0.json','validation/Hoarder_Demo_1.0.0.json')
 for p in [root.parent/'hoarder-build.log',root.parent/'hoarder-checks.log',root.parent/'hoarder-preview-final.log']:
  z.write(p,'validation/'+p.name)
 for p in out.glob('Hoarder_*Checks_1.0.0.json'):z.write(p,'validation/'+p.name)
for archive in [installZip,sources]:
 with ZipFile(archive) as z:assert z.testzip() is None
public=[installZip,sources,out/'Hoarder_Animations_1.0.0.mp4',out/'Hoarder_Preview_1.0.0.html',out/'Hoarder_Screen_1.0.0.png',out/'Hoarder_Wasteland_1.0.0.png']
for p in public:shutil.copy2(p,repo/'downloads'/p.name)
shutil.copy2(root/'README_RU.md',repo/'README_Hoarder_RU.md')
readme=repo/'README.md';text=readme.read_text();title='## Hoarder 1.0.0 — новый отдельный автомат'
section='''## Hoarder 1.0.0 — новый отдельный автомат

- [Установка — ZIP](downloads/Hoarder_1.0.0.zip)
- [Анимации — MP4, 18 секунд](downloads/Hoarder_Animations_1.0.0.mp4)
- [Офлайн-превью с меню и кнопками — HTML](downloads/Hoarder_Preview_1.0.0.html)
- [Оформление — изображение](downloads/Hoarder_Screen_1.0.0.png)
- [Wasteland — изображение](downloads/Hoarder_Wasteland_1.0.0.png)
- [Исходники и графика — ZIP](downloads/Hoarder_Sources_1.0.0.zip)
- [Установка, управление, правила и ограничения](README_Hoarder_RU.md)

Пять барабанов, три ряда, собственные рисунки персонажей и припасов,
xWays/xSplit, Super Scatter, Bunker Raid и Wasteland. Меню покупки и правил,
плавные цельные ленты, отдельные множители, общий выигрыш справа в иксах и деньгах.
Хост создаёт автомат клавишей **End**. Распаковать папку BepInEx в игру.
У всех участников коопа должна быть одна и та же версия.

Сборка без ошибок/предупреждений, 12 000 раундов движка, более 2.2 млн проверок,
540 кадров 2D-превью. Реальная сцена Unity и живой кооп здесь не запускались.
Это неофициальная адаптация с собственными ценами, частотами и нормировкой
выплат; оригинальный RTP и точный предел ways не заявляются.

'''
if title in text:
 start=text.index(title);end=text.index('## Cartoon Hands',start);text=text[:start]+text[end:]
text=text.replace('## Cartoon Hands',section+'## Cartoon Hands',1);readme.write_text(text)
sums=repo/'SHA256SUMS.txt';lines=sums.read_text().splitlines();names={p.name for p in public}
lines=[line for line in lines if line.split('  ')[-1].split('/')[-1] not in names]
lines.extend(sha(p)+'  downloads/'+p.name for p in public);sums.write_text('\n'.join(lines)+'\n')
for p in public:print(p.name,p.stat().st_size,sha(p))
print('PASS: archives CRC, binary/source/HTML hashes, 540-frame MP4, reports, install path')
