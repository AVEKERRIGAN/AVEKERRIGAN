using System;
using System.Collections.Generic;
using System.Linq;
namespace Hoarder
{
    // Public rules from the supplied screenshots; reel frequencies and feature
    // prices are original mod balancing, not the proprietary casino maths.
    public static class HoarderEngine
    {
        public const int Cols=5,Rows=3,Cells=15,Regular=10,Wild=10,XWays=11,Split=12,Scatter=13,Super=14;
        public const double MaxWinX=11030,PayUnit=.02;
        public static readonly string[] ArtKeys={"hazmat","mask","karen","cowboy","prepper","detector","medkit","fuel","jug","paper","wild","xways","split","scatter","super"};
        public static readonly string[] BuyNames={"BUNKER RAID · 7 SPINS","BUNKER RAID · 10 SPINS","SUPER RAID · 7 SPINS","MYSTERY RAID"};
        public static readonly double[] BuyCost={110,180,145,145};
        public const int Variants=4;
        public static readonly double[][] Pays={
            new[]{1.0,2.0,5.0},new[]{.75,1.5,3.75},new[]{.5,1.25,2.5},new[]{.4,1.1,2.0},new[]{.3,1.0,1.5},
            new[]{.25,.75,1.25},new[]{.25,.70,1.15},new[]{.20,.60,1.10},new[]{.20,.55,1.05},new[]{.20,.50,1.0}};
        [Serializable] public class SplitAction {public int source;public int[] changed;public int[] weights;public int[] supers;}
        [Serializable] public class Win {public int symbol,length;public long ways;public double amount;}
        [Serializable] public class Spin
        {
            public int[] raw,size,g,m,stickyBefore,stickyAfter,winning;
            public List<SplitAction> splits=new List<SplitAction>();
            public List<Win> wins=new List<Win>();
            public int reveal=-1,scatters,newWays,collected,level,left,bonus,superSeed;
            public double win,total;public long ways;public bool capped;
        }
        [Serializable] public class Round {public List<Spin> spins=new List<Spin>();public double total;public bool capped;public int variant=-1;}
        public static int Level(int collected)=>Math.Min(3,collected/3);
        public static bool Allowed(int sym,int level)=>sym>=0&&sym<Regular&&!(level>=1&&(sym==4||sym==9))&&!(level>=2&&(sym==3||sym==8))&&!(level>=3&&(sym==2||sym==7));
        static int Pick(Random r,int level) {var pool=Enumerable.Range(0,Regular).Where(s=>Allowed(s,level)).ToArray();return pool[r.Next(pool.Length)];}
        public static bool IsScatter(int sym)=>sym==Scatter||sym==Super;
        public static int[] Empty()=>new int[Cells];
        public static int[] InitialGrid()=>new[]{5,9,6,1,7,3,0,8,4,2,6,9,4,5,8};
        public static Spin Draw(Random r,int[] held,int collected,int left,bool bonus,int buy=-1,bool force=false)
        {
            var raw=new int[Cells];var size=Enumerable.Repeat(1,Cells).ToArray();
            int level=bonus?Level(collected):0;
            for(int c=0;c<Cols;c++)
            {
                for(int row=0;row<Rows;row++)
                {
                    int i=c*Rows+row;raw[i]=Pick(r,level);
                    if(bonus&&held[i]>0){raw[i]=XWays;size[i]=held[i];continue;}
                    if(c>=1&&c<=3&&r.NextDouble()<(bonus?.115:.062)){raw[i]=XWays;size[i]=r.Next(2,5);}
                    else if(r.NextDouble()<.016)raw[i]=Wild;
                }
                if(!bonus&&c>=1&&r.NextDouble()<.13){int row=r.Next(Rows);raw[c*Rows+row]=Scatter;size[c*Rows+row]=1;}
                if(!bonus&&c>=2&&r.NextDouble()<.056)
                {
                    int count=c-1,top=r.Next(Rows-count+1);
                    for(int row=top;row<top+count;row++){raw[c*Rows+row]=Split;size[c*Rows+row]=1;}
                }
            }
            if(buy>=0||force)
            {
                // Purchase confirmation lands real scatters through the same reels.
                for(int i=0;i<Cells;i++)if(IsScatter(raw[i])||raw[i]==Split){raw[i]=Pick(r,0);size[i]=1;}
                int v=buy<0?0:buy;int sc=v==1?4:3;
                for(int c=1;c<=sc;c++){int i=c*Rows+r.Next(Rows);raw[i]=v==2?Super:Scatter;size[i]=1;}
            }
            return Resolve(r,raw,size,held,collected,left,bonus);
        }
        public static Spin Resolve(Random r,int[] raw,int[] size,int[] held,int collected,int left,bool bonus)
        {
            if(raw==null||size==null||held==null||raw.Length!=Cells||size.Length!=Cells||held.Length!=Cells)throw new ArgumentException("15 cells required");
            var s=new Spin{raw=(int[])raw.Clone(),size=(int[])size.Clone(),g=(int[])raw.Clone(),m=Enumerable.Repeat(1,Cells).ToArray(),stickyBefore=(int[])held.Clone(),stickyAfter=(int[])held.Clone(),collected=collected,left=left,bonus=bonus?1:0};
            for(int i=0;i<Cells;i++)if(s.g[i]==XWays)s.m[i]=Math.Max(2,size[i]);
            // Left-to-right: an earlier split has already become a wild and can
            // itself be doubled by the next blade on the same row.
            for(int c=2;c<Cols;c++)for(int row=0;row<Rows;row++)
            {
                int src=c*Rows+row;if(s.g[src]!=Split)continue;
                var change=new List<int>();var weights=new List<int>();var supers=new List<int>();
                for(int cc=0;cc<c;cc++)
                {
                    int i=cc*Rows+row;
                    if(IsScatter(s.g[i])){s.g[i]=Super;supers.Add(i);}
                    else{s.m[i]*=2;change.Add(i);weights.Add(s.m[i]);}
                }
                s.g[src]=Wild;
                s.splits.Add(new SplitAction{source=src,changed=change.ToArray(),weights=weights.ToArray(),supers=supers.ToArray()});
            }
            s.scatters=s.g.Count(IsScatter);
            bool trigger=!bonus&&s.scatters>=3;
            bool hasWays=false;
            for(int i=0;i<Cells;i++)
            {
                if(s.g[i]==XWays)hasWays=true;
                if(s.g[i]==Super&&!trigger){s.g[i]=XWays;s.m[i]=r.Next(2,5);hasWays=true;}
            }
            if(hasWays)
            {
                s.reveal=Pick(r,bonus?Level(collected):0);
                for(int i=0;i<Cells;i++)if(s.g[i]==XWays)s.g[i]=s.reveal;
            }
            if(bonus)
            {
                for(int c=1;c<=3;c++)
                {
                    int sum=0;for(int row=0;row<Rows;row++)sum+=held[c*Rows+row];
                    for(int row=0;row<Rows;row++)
                    {
                        int i=c*Rows+row;
                        if(raw[i]==XWays&&held[i]==0){s.newWays++;sum+=Math.Max(2,size[i]);}
                    }
                    sum=Math.Min(12,sum);
                    for(int row=0;row<Rows;row++)s.stickyAfter[c*Rows+row]=0;
                    int occupied=(sum+3)/4;
                    for(int k=0;k<occupied;k++)s.stickyAfter[c*Rows+Rows-1-k]=sum/occupied+(k<sum%occupied?1:0);
                }
                s.collected+=s.newWays;s.left=Math.Max(0,left-1+s.newWays);s.level=Level(s.collected);
            }
            Evaluate(s);return s;
        }
        public static void Evaluate(Spin s)
        {
            s.wins.Clear();s.win=0;var hit=new HashSet<int>();long all=1;
            for(int c=0;c<Cols;c++){long n=0;for(int row=0;row<Rows;row++)n+=s.m[c*Rows+row];all*=n;}
            s.ways=all;
            int pureDepth=0;long pure=1;
            for(int c=0;c<Cols;c++){long w=0;for(int row=0;row<Rows;row++)if(s.g[c*Rows+row]==Wild)w+=s.m[c*Rows+row];if(w==0)break;pure*=w;pureDepth++;}
            for(int symbol=0;symbol<Regular;symbol++)
            {
                long ways=1,wildWays=1;int length=0;var ids=new List<int>();
                for(int c=0;c<Cols;c++)
                {
                    long n=0,w=0;
                    for(int row=0;row<Rows;row++){int i=c*Rows+row;if(s.g[i]==symbol||s.g[i]==Wild){n+=s.m[i];ids.Add(i);if(s.g[i]==Wild)w+=s.m[i];}}
                    if(n==0)break;ways*=n;wildWays*=w;length++;
                }
                if(length<3)continue;
                ways-=wildWays; // pure-wild paths are resolved once, below
                if(ways<=0)continue;
                double amount=ways*Pays[symbol][length-3]*PayUnit;
                s.wins.Add(new Win{symbol=symbol,length=length,ways=ways,amount=amount});s.win+=amount;
                foreach(int i in ids)if(i/Rows<length)hit.Add(i);
            }
            bool nextRegular=pureDepth<Cols&&Enumerable.Range(pureDepth*Rows,Rows).Any(i=>s.g[i]<Regular||s.g[i]==Wild);
            if(pureDepth>=3&&!nextRegular)
            {
                double amount=pure*Pays[0][pureDepth-3]*PayUnit;s.win+=amount;s.wins.Add(new Win{symbol=0,length=pureDepth,ways=pure,amount=amount});
                for(int i=0;i<pureDepth*Rows;i++)if(s.g[i]==Wild)hit.Add(i);
            }
            s.winning=hit.OrderBy(i=>i).ToArray();
        }
        static void SeedSuper(Spin trigger,int[] held,Random r)
        {
            for(int c=1;c<=3;c++)
            {
                int top=-1;for(int row=0;row<Rows;row++)if(trigger.g[c*Rows+row]==Super){top=row;break;}
                if(top<0)continue;
                for(int row=top;row<Rows;row++)held[c*Rows+row]=r.Next(2,5);
            }
        }
        public static Round Play(Random r,bool force=false)=>PlayRound(r,-1,force);
        public static Round PlayBuyVariant(Random r,int variant)
        {if(variant<0||variant>=Variants)throw new ArgumentOutOfRangeException(nameof(variant));return PlayRound(r,variant,false);}
        static Round PlayRound(Random r,int buy,bool force)
        {
            var round=new Round{variant=buy};int actual=buy==3?r.Next(3):buy;
            var held=Empty();var first=Draw(r,held,0,0,false,actual,force);round.spins.Add(first);AddWin(round,first);
            if(first.scatters<3||round.capped)return round;
            SeedSuper(first,held,r);int collected=held.Count(v=>v>0),left=first.scatters>=4?10:7;
            first.stickyAfter=(int[])held.Clone();first.superSeed=collected;first.collected=collected;first.level=Level(collected);first.left=left;
            // Capacity is finite (three middle reels, 12 sub-symbols each), so
            // sticky packing and +1 awards cannot produce an endless feature.
            for(int step=0;left>0&&!round.capped;step++)
            {
                if(step>=96)throw new InvalidOperationException("Feature exceeded finite capacity guard");
                var s=Draw(r,held,collected,left,true);held=(int[])s.stickyAfter.Clone();left=s.left;collected=s.collected;
                round.spins.Add(s);AddWin(round,s);
            }
            return round;
        }
        static void AddWin(Round r,Spin s)
        {s.win=Math.Min(s.win,Math.Max(0,MaxWinX-r.total));r.total+=s.win;r.capped=r.total>=MaxWinX;s.total=r.total;s.capped=r.capped;}
    }
    [Serializable] public class HoarderMsg
    {
        public string t,bet;public HoarderEngine.Spin s;public int seq,round,bi,buyVariant=-1,tb,settingTurbo,menu=-1,auto,busy;
        public double bn,sent,total;public float duration;public bool snapshot;
    }
    public static class HoarderTiming
    {
        public static float Elapsed(double networkNow,double sent,float duration)=>(float)Math.Min(Math.Max(0,networkNow-sent),Math.Max(0,duration));
        public static float ReelEnd(int c,bool turbo)=> (turbo?.65f:1.15f)+(turbo?.11f:.18f)*c;
        public static float Reveal(bool turbo)=>turbo?.34f:.65f;
        public static float Slice(bool turbo)=>turbo?.32f:.58f;
        public static float Count(bool turbo)=>turbo?.48f:.90f;
        public static float Intro(bool turbo)=>turbo?1.05f:1.85f;
        public static float Duration(HoarderEngine.Spin s,bool turbo)
        {return ReelEnd(4,turbo)+s.splits.Count*Slice(turbo)+(s.reveal>=0?Reveal(turbo):0)+(s.bonus==1&&s.newWays>0?Reveal(turbo):0)+(s.bonus==1&&s.level>HoarderEngine.Level(s.collected-s.newWays)?Reveal(turbo):0)+Count(turbo)+.15f;}
    }
}
