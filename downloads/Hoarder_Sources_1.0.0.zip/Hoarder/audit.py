from pathlib import Path
import hashlib,json,re,struct,sys
sys.path.insert(0,'/workspace/setup-tools')
import dnfile
from PIL import Image
root=Path(__file__).parent
binary=root/'bin/Release/netstandard2.1/Hoarder.dll'
pe=dnfile.dnPE(str(binary));rva=pe.net.struct.ResourcesRva
resources={str(r.Name):r for r in pe.net.mdtables.ManifestResource.rows}
checks=0
for file in (root/'art').glob('*.png'):
 name='Hoarder.art.'+file.name
 assert name in resources,name
 row=resources[name];offset=rva+row.Offset;n=struct.unpack('<I',pe.get_data(offset,4))[0];data=pe.get_data(offset+4,n)
 assert data==file.read_bytes(),name+' embedded bytes mismatch'
 with Image.open(file) as im:
  im.verify()
 checks+=1
source=(root/'Screen.cs').read_text();labels=[];buttons=[]
for m in re.finditer(r'(?:Label\("[^"]+","[^"]*",|Label\("[^"]+",[\s\S]*?,)(\.\d+f),(\.\d+f),(\.\d+f),(\.\d+f)',source):
 vals=[float(m[i][:-1]) for i in range(1,5)];x,y,w,h=vals
 assert 0<=x-w/2<x+w/2<=1 and 0<=y-h/2<y+h/2<=1,vals
 labels.append(vals);checks+=1
for m in re.finditer(r'new BtnDef\("([^"]+)","([^"]+)",([^\)]+)\)',source):
 vals=[float(x.strip().rstrip('f')) for x in m[3].split(',')];x,y,w,h=vals
 assert 0<=x-w/2<x+w/2<=1 and 0<=y-h/2<y+h/2<=1,m[1]
 buttons.append({'id':m[1],'rect':vals});checks+=1
assert len(buttons)==12
# Measured boxes of TOTAL/title/money in the actual production layout.
right=[(.90,.716,.12,.028),(.90,.662,.13,.055),(.90,.610,.12,.030)]
for a,b in zip(right,right[1:]):assert a[1]-a[3]/2>b[1]+b[3]/2;checks+=1
assert 'GwyfShared.ScreenFit.Fit' in (root/'ScreenButtons.cs').read_text() and 'GwyfShared.ScreenFit.Fit' in source
assert source.count('typeof(RectMask2D)')>=3 and 'fontSizeMax=pixels' in source
assert 'new WaitForSecondsRealtime(duration)' in (root/'Game.cs').read_text()
assert 'KeyCode.End' in (root/'Plugin.cs').read_text();checks+=4
# Compare RPC hashes with shipped slot source signatures and original game strings.
def stable(s):
 h=23
 for c in s:h=(h*31+ord(c))&0xffffffff
 return h&65535
sig='System.Void Hoarder.HoarderGame::UserRpcShowSpin(System.String)';h=stable(sig);seen={}
for file in root.parent.glob('*/Game.cs'):
 for s in re.findall(r'"(System.Void [^"\n]+)"',file.read_text()):
  if s!=sig:assert stable(s)!=h,('RPC collision',file,s)
  seen[s]=stable(s)
gameDll=Path('/workspace/library-files/gamble-with-your-friends/managed/Assembly-CSharp.dll')
strings=gameDll.read_bytes().decode('utf-16le',errors='ignore')
for s in re.findall(r'System\.Void [\w.]+::\w+\([^\x00]{0,500}\)',strings):
 assert stable(s)!=h,('Game RPC collision',s);seen[s]=stable(s)
checks+=len(seen)
report={'pass':True,'checks':checks,'embedded_pngs':len(resources),'production_labels_in_bounds':len(labels),'screen_controls':len(buttons),'rpc_hash':h,'other_rpc_signatures_checked':len(seen),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'assembly_scope':'Compiled mod and original managed API; no live Unity scene','sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in root.glob('*.cs')}}
Path('/workspace/outputs/Hoarder_Assembly_Layout_Checks_1.0.0.json').write_text(json.dumps(report,indent=2))
print('PASS:',checks,'resource/layout/registration checks;',len(resources),'embedded PNGs; RPC',h)
