using Hoarder;using GwyfShared;using System.Globalization;
if(args.Contains("--balance"))
{
 foreach(int variant in new[]{-1,0,1,2,3})
 {
  double balanceSum=0,balanceSumBase=0;int hit=0,cap=0,count=variant<0?50000:2000;
  for(int seed=0;seed<count;seed++){var r=variant<0?HoarderEngine.Play(new Random(seed)):HoarderEngine.PlayBuyVariant(new Random(seed),variant);balanceSum+=r.total;balanceSumBase+=r.spins[0].win;if(r.spins.Count>1)hit++;if(r.capped)cap++;}
  Console.WriteLine($"variant={variant} rounds={count} mean={balanceSum/count:0.0000} base={balanceSumBase/count:0.0000} bonus={hit} capped={cap}");
 }
 return;
}
int assertions=0,rounds=0,steps=0;double sum=0;int largest=0;
void Check(bool v,string msg){assertions++;if(!v)throw new Exception(msg);}
int[] Ones()=>Enumerable.Repeat(1,15).ToArray();
HoarderEngine.Spin Fixed(int[] raw,int[] sizes=null,int[] held=null,int collected=0,int left=0,bool bonus=false)=>HoarderEngine.Resolve(new Random(12),raw,sizes??Ones(),held??new int[15],collected,left,bonus);
void Near(double a,double b,string n)=>Check(Math.Abs(a-b)<1e-6,n+" "+a+" != "+b);
// Straight 5-of-kind, 243 ways, one highest award per way.
var full=Fixed(Enumerable.Repeat(0,15).ToArray());Near(full.win,1215*HoarderEngine.PayUnit,"full hazmat pays 243*5");Check(full.wins.Count==1,"one winning regular");
var wild=Fixed(Enumerable.Repeat(10,15).ToArray());Near(wild.win,1215*HoarderEngine.PayUnit,"pure wild paid once at highest symbol");Check(wild.wins.Count==1,"no wild double count");
var gap=Enumerable.Repeat(9,15).ToArray();for(int i=0;i<3;i++)gap[i]=0;for(int i=6;i<9;i++)gap[i]=0;var no=Fixed(gap);Near(no.win,0,"adjacency missing reel 2");
var three=Enumerable.Repeat(9,15).ToArray();for(int i=0;i<9;i++)three[i]=0;Near(Fixed(three).win,27*HoarderEngine.PayUnit,"3 adjacent reels * 1x");
// Exercise the production cap branch with an oversized award, then another
// award after the cap: never credit beyond 11030x and never credit twice.
var capRound=new HoarderEngine.Round{total=11000};var oversized=new HoarderEngine.Spin{win=100000};
var accumulate=typeof(HoarderEngine).GetMethod("AddWin",System.Reflection.BindingFlags.Static|System.Reflection.BindingFlags.NonPublic);
accumulate.Invoke(null,new object[]{capRound,oversized});Near(capRound.total,11030,"round capped exactly");Near(oversized.win,30,"only cap remainder credited");Check(capRound.capped&&oversized.capped,"cap flags");
var extra=new HoarderEngine.Spin{win=400};accumulate.Invoke(null,new object[]{capRound,extra});Near(extra.win,0,"no credit after cap");Near(capRound.total,11030,"cap retained");
// xWays all reveal one regular, only input multiplicity changes counts.
var waysRaw=HoarderEngine.InitialGrid();waysRaw[3]=11;waysRaw[7]=11;var waySizes=Ones();waySizes[3]=2;waySizes[7]=4;var ways=Fixed(waysRaw,waySizes);
Check(ways.g[3]==ways.g[7]&&ways.reveal>=0,"one shared reveal");Check(ways.m[3]==2&&ways.m[7]==4,"xWays size 2,4");
var splitRaw=Enumerable.Repeat(9,15).ToArray();splitRaw[6]=12;splitRaw[9]=12;splitRaw[12]=12;splitRaw[3]=11;splitRaw[0]=0;var splitSizes=Ones();splitSizes[3]=3;var split=Fixed(splitRaw,splitSizes);
Check(split.m[0]==8&&split.m[3]==24&&split.m[6]==4&&split.m[9]==2,"successive split doubles earlier wild and xWays");Check(split.g[6]==10&&split.g[9]==10&&split.g[12]==10,"blades become wild");
splitRaw[3]=13;var super=Fixed(splitRaw);Check(super.raw[3]==13&&super.g[3]<10&&super.m[3]>=2,"super outside feature reveals xWays");Check(super.splits.Any(x=>x.supers.Contains(3)),"scatter upgrades, never doubles");
var seedRaw=Enumerable.Repeat(9,15).ToArray();seedRaw[3]=13;seedRaw[6]=13;seedRaw[9]=13;seedRaw[12]=12;var supers=Fixed(seedRaw);Check(supers.scatters==3&&supers.g[3]==14&&supers.g[6]==14&&supers.g[9]==14,"three super trigger retained");
var held=new int[15];held[5]=3;var collectRaw=HoarderEngine.InitialGrid();collectRaw[3]=11;collectRaw[5]=11;var collectSize=Ones();collectSize[3]=2;collectSize[5]=3;
var collect=Fixed(collectRaw,collectSize,held,2,7,true);Check(collect.newWays==1&&collect.left==7&&collect.collected==3&&collect.level==1,"new xWay gives +1 and level1");Check(collect.stickyAfter[4]==2&&collect.stickyAfter[5]==3,"balanced bottom packing preserves 5 sub-symbols");
Check(Enumerable.Range(0,10).Count(s=>HoarderEngine.Allowed(s,0))==10,"base pool");Check(Enumerable.Range(0,10).Count(s=>HoarderEngine.Allowed(s,1))==8,"level1 pool");Check(Enumerable.Range(0,10).Count(s=>HoarderEngine.Allowed(s,2))==6,"level2 pool");Check(Enumerable.Range(0,10).Count(s=>HoarderEngine.Allowed(s,3))==4,"wasteland pool");
for(int seed=0;seed<2400;seed++)
{
 foreach(int variant in new[]{-1,0,1,2,3})
 {
  var round=variant<0?HoarderEngine.Play(new Random(seed)):HoarderEngine.PlayBuyVariant(new Random(seed),variant);rounds++;sum+=variant<0?round.total:0;
  Check(round.total>=0&&round.total<=11030,"round cap");Near(round.spins.Sum(s=>s.win),round.total,"sum = total");Check(round.spins.Count<=97,"finite feature");largest=Math.Max(largest,round.spins.Count);
  if(variant>=0)Check(round.spins[0].scatters>=3&&round.spins.Count>1||round.capped,"buy really triggers");
  if(variant==0)Check(round.spins[0].left==7||round.capped,"7 spin purchase");if(variant==1)Check(round.spins[0].left==10||round.capped,"10 spin purchase");if(variant==2)Check(round.spins[0].superSeed>0||round.capped,"super seeded");
  double running=0;int prevLeft=round.spins[0].left;
  foreach(var s in round.spins)
  {
   steps++;running+=s.win;Near(s.total,running,"running cumulative win");Check(s.raw.Length==15&&s.g.Length==15&&s.m.Length==15,"wire grid lengths");Check(s.g.All(x=>x>=0&&x<=14)&&s.g.All(x=>x!=11&&x!=12),"no unresolved xWays or split after reveal");Check(s.m.All(m=>m>=1&&m<=32),"bounded symbol multiplicity");
   Check(s.stickyAfter.All(x=>x==0||x>=2&&x<=4),"2–4 sub-symbols per sticky slot");Check(s.stickyAfter.Where((x,i)=>i/3==0||i/3==4).All(x=>x==0),"sticky middle reels");
   for(int c=1;c<4;c++)Check(s.stickyAfter.Skip(c*3).Take(3).Sum()<=12,"sticky reel finite capacity");
   if(s.bonus==1){Check(s.left==prevLeft-1+s.newWays,"bonus award equation");prevLeft=s.left;Check(s.left>=0,"spins nonnegative");Check(s.level==HoarderEngine.Level(s.collected),"level follows collector");Check(s.g.Where(x=>x<10).All(x=>HoarderEngine.Allowed(x,HoarderEngine.Level(s.collected-s.newWays))),"removed symbols absent at spin start");}
   foreach(bool turbo in new[]{false,true})Check(HoarderTiming.Duration(s,turbo)>HoarderTiming.ReelEnd(4,turbo),"server budget includes all effects");
  }
 }
}
// Reflection serialisation: actual nested feature, actions and timing survive RPC.
var wire=new HoarderMsg{t="spin",seq=17,round=4,buyVariant=2,s=split,total=12.5,sent=98.123,duration=HoarderTiming.Duration(split,false),tb=0,settingTurbo=1,bn=700,bet="$700",snapshot=true};
CultureInfo.CurrentCulture=new CultureInfo("ru-RU");var encoded=MiniJson.ToJson(wire);var decoded=MiniJson.FromJson<HoarderMsg>(encoded);
Check(decoded.s.splits.Count==3&&decoded.s.g.SequenceEqual(split.g)&&decoded.s.m.SequenceEqual(split.m),"RPC nested arrays survive");Near(decoded.sent,98.123,"network clock invariant culture");Check(decoded.tb==0&&decoded.settingTurbo==1,"live turbo separate from phase turbo");
// Network latency advances the same host-timed phase rather than restarting it.
Near(HoarderTiming.Elapsed(100.25,100,2),.25,"network phase accounts for latency");
Near(HoarderTiming.Elapsed(99.8,100,2),0,"negative clock skew clamped");
Near(HoarderTiming.Elapsed(108,100,2),2,"late phase settles immediately");
Near(HoarderTiming.Elapsed(100,100,0),0,"zero duration state");
// Identical seed produces identical complete round and payments.
Check(MiniJson.ToJson(HoarderEngine.PlayBuyVariant(new Random(81),2))==MiniJson.ToJson(HoarderEngine.PlayBuyVariant(new Random(81),2)),"deterministic replay");
for(int col=0;col<5;col++)foreach(bool turbo in new[]{false,true})
{
 float duration=HoarderTiming.ReelEnd(col,turbo);int travel=Math.Max(4,(int)Math.Round(duration*6));float last=0;
 for(int frame=0;frame<=600;frame++){float elapsed=duration*frame/600;float p=CellReelMotion.Position(elapsed,duration,travel);Check(p>=last-1e-5&&p<=travel+1e-5,"monotonic smooth strip");last=p;}
 Near(last,travel,"integer landing");for(int row=0;row<3;row++){int index=travel-row;Near(1+(index-travel),1-row,"final symbol centre");}
 Check((CellReelMotion.Position(.001f,duration,travel)-0)/.001f<.02,"starts at rest");Check((travel-CellReelMotion.Position(duration-.001f,duration,travel))/.001f<.05,"stops at rest");
}
Directory.CreateDirectory("/workspace/outputs");
var report=new {pass=true,assertions,rounds,steps,largest_round_spins=largest,base_mean_win_x=sum/2400,original_rtp_claimed=false,scope="Actual production engine and wire format; no Unity runtime / live coop"};
File.WriteAllText("/workspace/outputs/Hoarder_Engine_Checks_1.0.0.json",System.Text.Json.JsonSerializer.Serialize(report,new System.Text.Json.JsonSerializerOptions{WriteIndented=true}));
// Deterministic examples feed the independent browser presentation preview.
var demoRound=HoarderEngine.PlayBuyVariant(new Random(182),2);var pool=Enumerable.Range(0,4).Select(v=>Enumerable.Range(0,12).Select(seed=>HoarderEngine.PlayBuyVariant(new Random(300+seed),v)).ToArray()).ToArray();
var baseRounds=Enumerable.Range(0,24).Select(seed=>HoarderEngine.Play(new Random(900+seed))).ToArray();
var waste=pool.SelectMany(list=>list).SelectMany(r=>r.spins).First(s=>s.bonus==1&&s.level==3&&s.newWays>0);
var showcaseRaw=new[]{0,5,4,11,1,7,12,6,2,12,3,9,12,0,8};var showcaseSize=Ones();showcaseSize[3]=3;
int showcaseSeed=Enumerable.Range(0,100).First(seed=>new Random(seed).Next(10)==0);
var showcase=HoarderEngine.Resolve(new Random(showcaseSeed),showcaseRaw,showcaseSize,new int[15],0,0,false);showcase.total=showcase.win;
var demo=new {split=showcase,ways,super=supers,round=demoRound,waste,pool,@base=baseRounds,pays=HoarderEngine.Pays,buyNames=HoarderEngine.BuyNames,buyCost=HoarderEngine.BuyCost};
File.WriteAllText("/workspace/outputs/Hoarder_Demo_1.0.0.json",System.Text.Json.JsonSerializer.Serialize(demo,new System.Text.Json.JsonSerializerOptions{IncludeFields=true}));
Console.WriteLine($"PASS: {assertions} assertions, {rounds} rounds, {steps} spin steps; longest round {largest}, mod base mean {sum/2400:0.000}x (not original RTP)");
