from pathlib import Path
import json,re,base64
root=Path('/workspace/mod-work');art=root/'Hoarder'/'art'
assets={p.stem:'data:image/png;base64,'+base64.b64encode(p.read_bytes()).decode() for p in art.glob('*.png') if p.stem!='topscreen'}
source=(root/'Hoarder'/'Screen.cs').read_text()
buttons=[]
for m in re.finditer(r'new BtnDef\("([^"]+)","([^"]+)",([^\)]+)\)',source):
 nums=[float(x.strip().rstrip('f')) for x in m[3].split(',')];buttons.append(dict(zip(['id','tip','cx','cy','w','h'],[m[1],m[2]]+nums)))
assert len(buttons)==12
data=json.loads(Path('/workspace/outputs/Hoarder_Demo_1.0.0.json').read_text())
for group in data['pool']:
 for round_ in group:
  if data['waste'] in round_['spins']:
   ix=round_['spins'].index(data['waste']);data['wasteNext']=round_['spins'][ix+1]
assert data['wasteNext']['level']==3 and set(data['wasteNext']['g']).issubset({0,1,5,6,10,13,14})
html=(root/'HoarderPreview' /'viewer.html').read_text().replace('/*ASSETS*/',json.dumps(assets)).replace('/*DEMO*/',json.dumps(data)).replace('/*BUTTONS*/',json.dumps(buttons))
Path('/workspace/outputs/Hoarder_Preview_1.0.0.html').write_text(html)
print('Offline preview built:',len(html),'bytes;',len(assets),'textures;',len(buttons),'controls')
