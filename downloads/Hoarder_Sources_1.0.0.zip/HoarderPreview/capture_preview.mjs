import fs from 'node:fs/promises';import http from 'node:http';import path from 'node:path';import os from 'node:os';import {spawn} from 'node:child_process';
const root='/workspace/outputs',profile=await fs.mkdtemp(path.join(os.tmpdir(),'hoarder-preview-'));
const html=await fs.readFile(path.join(root,'Hoarder_Preview_1.0.0.html'));
const server=http.createServer((req,res)=>{res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});res.end(html);});
await new Promise(r=>server.listen(0,'127.0.0.1',r));const url='http://127.0.0.1:'+server.address().port+'/?capture=1';
const browser=spawn('/usr/bin/chromium',['--headless=new','--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader','--disable-gpu-sandbox','--disable-backgrounding-occluded-windows','--disable-renderer-backgrounding','--remote-debugging-port=0','--user-data-dir='+profile,'--no-first-run','--no-default-browser-check','--window-size=1280,880','about:blank'],{stdio:['ignore','ignore','pipe']});let errors='';browser.stderr.on('data',d=>errors=(errors+d).slice(-10000));
let ws;const pending=new Map();let next=0;
try{
 let port;const started=Date.now();while(!port){try{port=Number((await fs.readFile(path.join(profile,'DevToolsActivePort'),'utf8')).split('\n')[0]);}catch{}if(Date.now()-started>15000)throw Error('Browser start failed: '+errors);await new Promise(r=>setTimeout(r,50));}
 const targets=await(await fetch('http://127.0.0.1:'+port+'/json/list')).json();const target=targets.find(t=>t.type==='page');
 ws=new WebSocket(target.webSocketDebuggerUrl);await new Promise((r,j)=>{ws.addEventListener('open',r,{once:true});ws.addEventListener('error',j,{once:true});});
 ws.addEventListener('message',e=>{const m=JSON.parse(e.data),p=pending.get(m.id);if(m.method==='Runtime.exceptionThrown')console.error(m.params.exceptionDetails.exception?.description?.slice(0,600));if(p){clearTimeout(p.timer);pending.delete(m.id);m.error?p.reject(Error(m.error.message)):p.resolve(m.result);}});
 const call=(method,params={})=>new Promise((resolve,reject)=>{const id=++next,timer=setTimeout(()=>{pending.delete(id);reject(Error('CDP timeout '+method));},30000);pending.set(id,{resolve,reject,timer});ws.send(JSON.stringify({id,method,params}));});
 const evalJS=async expression=>{const r=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));return r.result.value;};
 await call('Page.enable');await call('Runtime.enable');await call('Emulation.setFocusEmulationEnabled',{enabled:true});await call('Emulation.setDeviceMetricsOverride',{width:1280,height:800,deviceScaleFactor:1,mobile:false});await call('Page.navigate',{url});
 let ready=false;for(let i=0;i<200&&!ready;i++){ready=await evalJS('window.hoarderPreview?.ready===true');if(!ready)await new Promise(r=>setTimeout(r,100));}if(!ready)throw Error('Viewer did not initialize');
 const start=await evalJS('window.hoarderPreview.render(0)');const stop=await evalJS('window.hoarderPreview.render(5.2)');
 if(start.total!==0||Math.abs(stop.total-stop.spin.win)>1e-6||new Set(stop.labels.map(x=>x.font)).size!==1)throw Error('Preview total or stable multiplier font failed');
 for(const label of stop.labels){if(label.sx!==1)throw Error('Unfinished reveal scale at final stop');}
 async function screenshot(file,jpeg=false){const r=await call('Page.captureScreenshot',{format:jpeg?'jpeg':'png',...(jpeg?{quality:92}:{}),captureBeyondViewport:false,fromSurface:true});await fs.writeFile(file,Buffer.from(r.data,'base64'));}
 const stills=[['Hoarder_Screen_1.0.0.png',5.2],['Hoarder_BuyMenu_1.0.0.png',6.2],['Hoarder_BonusIntro_1.0.0.png',8.3],['Hoarder_Wasteland_1.0.0.png',17.9]];
 for(const [name,t] of stills){await evalJS('window.hoarderPreview.render('+t+')');await screenshot(path.join(root,name));}
 await evalJS('window.hoarderPreview.showMenu(-2)');await screenshot(path.join(root,'Hoarder_Paytable_1.0.0.png'));
 // Exercise the real canvas pointer controls, not helper actions only.
 async function click(x,y){await call('Input.dispatchMouseEvent',{type:'mousePressed',x,y,button:'left',clickCount:1});await call('Input.dispatchMouseEvent',{type:'mouseReleased',x,y,button:'left',clickCount:1});}
 await click(1280*.90,800*(1-.86));if((await evalJS('window.hoarderPreview.inspect()')).menu!==-1)throw Error('Close menu control failed');
 await click(1280*.1,800*(1-.655));if((await evalJS('window.hoarderPreview.inspect()')).menu!==0)throw Error('BUY control failed');
 await click(1280*.82,800*(1-.145));if((await evalJS('window.hoarderPreview.inspect()')).phase!=='spin')throw Error('SPIN purchase did not start scatter reels');
 const frames=path.join(root,'hoarder-preview-frames-final');await fs.mkdir(frames,{recursive:true});
 for(let i=0;i<540;i++){await evalJS('window.hoarderPreview.render('+Math.min(17.966,i/30)+')');await screenshot(path.join(frames,String(i).padStart(6,'0')+'.jpg'),true);}
 await fs.writeFile(path.join(root,'Hoarder_Browser_Checks_1.0.0.json'),JSON.stringify({pass:true,frames:540,fps:30,width:1280,height:800,html_sha256:(await import('node:crypto')).createHash('sha256').update(html).digest('hex'),scope:'Independent 2D presentation preview with actual production engine result grids; not Unity footage',controls:['BUY','SPIN purchase','Close'],settled_total:stop.total,stable_multiplier_font:stop.labels[0].font},null,2));
 console.log('PASS: 540 preview frames, aligned centres, stable multiplier font, real BUY/SPIN/Close pointer controls. Independent 2D preview, not game footage.');
}finally{ws?.close();browser.kill('SIGTERM');server.close();setTimeout(()=>browser.kill('SIGKILL'),1500).unref();}
