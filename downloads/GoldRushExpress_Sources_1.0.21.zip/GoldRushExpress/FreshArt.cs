using UnityEngine;
namespace GoldRushExpress
{
    public partial class TrainGame
    {
        static Texture2D _freshSheet, _freshLogos;
        static Sprite RawCleanCoin(string key){var texture=LoadPng(key);return Sprite.Create(texture,new Rect(0,0,texture.width,texture.height),new Vector2(.5f,.5f),100,0,SpriteMeshType.FullRect);}
        static Sprite FreshSpriteKey(string key)
        {
            if (key.StartsWith("blur_")) key = "sym_" + key.Substring(5);
            if (key == "logo" || key == "topper")
            {
                if (_freshLogos == null) _freshLogos = LoadPng("fresh_logos");
                return GwyfShared.FreshAtlas.Logo(_freshLogos, 4);
            }
            if (_freshSheet == null) _freshSheet = LoadPng("fresh_atlas");

            int index;
            switch (key)
            {
                case "sym_J": index = 0; break;
                case "sym_Q": index = 1; break;
                case "sym_K": index = 2; break;
                case "sym_A": index = 3; break;
                case "sym_hat": index = 4; break;
                case "sym_moneybag": index = 5; break;
                case "sym_revolver": index = 6; break;
                case "sym_loco_scatter": index = 7; break;
                case "sym_loco_gold": index = 8; break;
                case "coin_gold": return RawCleanCoin("clean_coin_gold");
                case "coin_teal": return RawCleanCoin("clean_coin_teal");
                case "coin_blue": return RawCleanCoin("clean_coin_teal");
                case "sp_banker": index = 11; break;
                case "sp_marshal": index = 12; break;
                case "sp_tycoon": index = 13; break;
                case "sp_outlaw": index = 14; break;
                case "sp_spirit": index = 15; break;
                case "sp_iron_banker": index = 16; break;
                case "sp_iron_marshal": index = 17; break;
                case "sp_iron_outlaw": index = 18; break;
                case "sp_outlaw_fire": index = 19; break;
                case "sign_wagon": index = 23; break;
                case "plaque_wagon": index = 23; break;
                default: return null;
            }
            if(index==10)
            {
                // The next red portrait bleeds into the bottom of this atlas tile.
                // Crop only that gutter, retaining the complete silver circle.
                int tile=_freshSheet.width/5,height=_freshSheet.height/5;
                var rect=new Rect(index%5*tile+2,_freshSheet.height-(index/5+1)*height+22,tile-4,height-24);
                return Sprite.Create(_freshSheet,rect,new Vector2(.5f,.5f),100f,0,SpriteMeshType.FullRect);
            }
            return GwyfShared.FreshAtlas.Sprite(_freshSheet, 5, 5, index);
        }
    }
}
