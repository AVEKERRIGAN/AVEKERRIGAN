using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Mirror;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
namespace FruitParty
{
    public partial class FruitPartyGame
    {
        RectTransform _ui,window,grid,menuRoot,popRoot;TMP_FontAsset font;Vector2 size;float step;
        readonly List<Material> ownedMaterials=new List<Material>();
        Image[] cells=new Image[49],glows=new Image[49];TMP_Text[] values=new TMP_Text[49];Vector2[] home=new Vector2[49];
        Image[][] strips=new Image[7][];TMP_Text[][] stripValues=new TMP_Text[7][];
        TMP_Text totalX,totalMoney,betLabel,winLabel,spinCountLabel,statusLabel,blockLabel,bonusLabel,menuTitle,popup,popupSub,buyCostText;
        Coroutine animation;int lastAnimated=-1,lastMenu=int.MinValue;double shownTotal,betNumber,lastMenuBet=-1;string shownBet="—";int[] previous=FruitPartyEngine.InitialGrid();
        static readonly Color Gold=new Color(1,.89f,.24f),Pink=new Color(1,.22f,.68f),Lime=new Color(.64f,1,.24f);
        static readonly Dictionary<string,Sprite> sprites=new Dictionary<string,Sprite>();
        public struct BtnDef {public string id,tip;public float cx,cy,w,h;public BtnDef(string id,string tip,float x,float y,float w,float h){this.id=id;this.tip=tip;cx=x;cy=y;this.w=w;this.h=h;}}
        public static readonly BtnDef[] Buttons={
            new BtnDef("Buy","Buy 10 free spins for 100x bet",.10f,.67f,.14f,.14f),new BtnDef("Info","Rules / next page",.10f,.20f,.11f,.080f),
            new BtnDef("Spin","Spin / confirm bonus purchase",.49f,.105f,.09f,.11f),new BtnDef("Minus","Bet -",.61f,.105f,.045f,.065f),new BtnDef("Plus","Bet +",.68f,.105f,.045f,.065f),
            new BtnDef("Turbo","Normal / quick / turbo",.75f,.105f,.058f,.070f),new BtnDef("Auto","Automatic play / stop",.884f,.105f,.06f,.070f),
            new BtnDef("Buy0","Confirm 10 free spins for 100x bet",.50f,.54f,.60f,.28f),new BtnDef("Close","Close menu",.90f,.86f,.06f,.055f)};
        static Sprite Spr(string key)
        {
            if(sprites.TryGetValue(key,out var sprite))return sprite;
            using(var stream=typeof(FruitPartyGame).Assembly.GetManifestResourceStream("FruitParty.art."+key+".png"))
            {
                if(stream==null)throw new InvalidOperationException("Missing art "+key);
                using(var mem=new System.IO.MemoryStream())
                {stream.CopyTo(mem);var tex=new Texture2D(2,2,TextureFormat.RGBA32,true);if(!ImageConversion.LoadImage(tex,mem.ToArray()))throw new InvalidOperationException("Invalid PNG "+key);
                    tex.name="FP_"+key;GwyfShared.ReelFx.ConfigureTexture(tex);sprite=Sprite.Create(tex,new Rect(0,0,tex.width,tex.height),new Vector2(.5f,.5f),100);sprites[key]=sprite;return sprite;}
            }
        }
        public static Texture2D LoadPng(string key)=>Spr(key).texture;
        static Sprite Symbol(int sym)=>Spr(FruitPartyEngine.ArtKeys[Mathf.Clamp(sym,0,7)]);
        static Image Img(string n,Transform parent,Sprite sprite=null)
        {var go=new GameObject(n,typeof(RectTransform),typeof(Image));go.layer=parent.gameObject.layer;go.transform.SetParent(parent,false);var im=go.GetComponent<Image>();im.sprite=sprite;im.preserveAspect=sprite!=null;im.raycastTarget=false;return im;}
        static void Place(RectTransform r,Vector2 position,Vector2 dimensions)
        {r.anchorMin=r.anchorMax=r.pivot=new Vector2(.5f,.5f);r.sizeDelta=dimensions;r.anchoredPosition=position;}
        void N(RectTransform r,float x,float y,float w,float h)=>Place(r,new Vector2((x-.5f)*size.x,(y-.5f)*size.y),new Vector2(w*size.x,h*size.y));
        TMP_Text Text(string n,Transform parent,Color color,float pixels)
        {
            var go=new GameObject(n,typeof(RectTransform),typeof(CanvasRenderer));go.layer=parent.gameObject.layer;go.transform.SetParent(parent,false);var t=go.AddComponent<TextMeshProUGUI>();
            t.font=font;t.fontSharedMaterial=font.material;t.color=color;t.alignment=TextAlignmentOptions.Center;t.enableAutoSizing=true;t.fontSizeMax=pixels;t.fontSizeMin=1;
            t.textWrappingMode=TextWrappingModes.NoWrap;t.overflowMode=TextOverflowModes.Truncate;t.raycastTarget=false;t.fontStyle=FontStyles.Bold;return t;
        }
        TMP_Text Label(string n,string text,float x,float y,float w,float h,Color color,float fontFraction)
        {var t=Text(n,_ui,color,size.y*fontFraction);N(t.rectTransform,x,y,w,h);t.text=text;return t;}
        static void Layer(GameObject go,int layer){go.layer=layer;foreach(Transform child in go.transform)Layer(child.gameObject,layer);}
        void EnsureUi()
        {
            if(_ui!=null)return;var anchors=(symbolLocations??new List<Image>()).Where(i=>i!=null).ToList();
            if(anchors.Count==0&&reels!=null)anchors=reels.Where(r=>r!=null).SelectMany(r=>r.symbols??new Image[0]).Where(i=>i!=null).ToList();
            if(anchors.Count==0||anchors[0].canvas==null)throw new InvalidOperationException("Slot canvas anchors not ready");
            var root=(RectTransform)anchors[0].canvas.transform;font=payoutText!=null?payoutText.font:TMP_Settings.defaultFontAsset;
            if(font==null)font=Resources.FindObjectsOfTypeAll<TMP_FontAsset>().FirstOrDefault(f=>f!=null&&f.material!=null);
            if(font==null||font.material==null)throw new InvalidOperationException("TMP font not ready");
            var min=root.rect.min;var max=root.rect.max;GwyfShared.ScreenFit.Fit(transform,root,ref min,ref max);
            size=(max-min)*(1-2*Mathf.Clamp(FruitPartyPlugin.ScreenMargin.Value,0,.2f));if(size.x<1||size.y<1)throw new InvalidOperationException("Invalid screen bounds");
            var go=new GameObject("FruitPartyWindow",typeof(RectTransform),typeof(RectMask2D));window=(RectTransform)go.transform;go.layer=root.gameObject.layer;window.SetParent(root,false);Place(window,(min+max)*.5f-root.rect.center,size);
            try
            {
                var bg=Img("FruitPartyUI",window,Spr("bg"));bg.preserveAspect=false;_ui=bg.rectTransform;Place(_ui,Vector2.zero,size);_ui.gameObject.AddComponent<RectMask2D>();BuildPanel();Layer(go,root.gameObject.layer);
                foreach(var r in reels??new List<SlotReel>())if(r!=null)foreach(var g in r.GetComponentsInChildren<Graphic>(true))g.enabled=false;
                foreach(var im in anchors)im.enabled=false;if(payoutText!=null){payoutText.text="";var old=payoutText.GetComponent<MeshRenderer>();if(old!=null)old.enabled=false;}window.SetAsLastSibling();
            }
            catch{Destroy(go);window=null;_ui=null;throw;}
        }
        void BuildPanel()
        {
            var logo=Img("Logo",_ui,Spr("logo"));N(logo.rectTransform,.50f,.947f,.50f,.082f);
            step=Mathf.Min(size.x*.64f/7,size.y*.70f/7);
            var gr=new GameObject("Reels",typeof(RectTransform),typeof(RectMask2D));grid=(RectTransform)gr.transform;grid.SetParent(_ui,false);N(grid,.49f,.535f,step*7/size.x,step*7/size.y);
            var background=Img("Tiles",grid,Spr("grid"));background.preserveAspect=false;Place(background.rectTransform,Vector2.zero,Vector2.one*step*7);
            for(int c=0;c<7;c++)
            {
                var column=new GameObject("Column"+c,typeof(RectTransform),typeof(RectMask2D));var rt=(RectTransform)column.transform;rt.SetParent(grid,false);Place(rt,new Vector2((c-3)*step,0),new Vector2(step,step*7));
                strips[c]=new Image[9];stripValues[c]=new TMP_Text[9];for(int j=0;j<9;j++)MakeSymbol("Strip"+j,rt,out strips[c][j],out stripValues[c][j]);
            }
            for(int i=0;i<49;i++)
            {
                home[i]=new Vector2((i/7-3)*step,(3-i%7)*step);glows[i]=Img("WinGlow"+i,grid,Spr("px"));glows[i].preserveAspect=false;Place(glows[i].rectTransform,home[i],Vector2.one*step*.95f);glows[i].color=Color.clear;
                MakeSymbol("Fruit"+i,grid,out cells[i],out values[i]);Place(cells[i].rectTransform,home[i],Vector2.one*step*.84f);
            }
            var buy=Img("BuyFeature",_ui,Spr("panel"));buy.preserveAspect=false;N(buy.rectTransform,.10f,.67f,.14f,.14f);
            Label("BuyTitle","BUY FREE\nSPINS",.10f,.693f,.125f,.065f,Gold,.024f).textWrappingMode=TextWrappingModes.Normal;
            Label("BuyCost","100x BET",.10f,.638f,.125f,.030f,Color.white,.023f);
            Label("MaxTitle","MAX WIN",.10f,.52f,.13f,.028f,Color.white,.023f);Label("MaxX","5000x",.10f,.475f,.13f,.046f,Gold,.040f);
            Label("ClusterTitle","CLUSTERS",.10f,.37f,.13f,.027f,Color.white,.020f);Label("ClusterCount","5+ CONNECTED",.10f,.332f,.14f,.025f,Color.white,.018f);
            Label("TotalTitle","TOTAL WIN",.91f,.76f,.13f,.028f,Gold,.023f);totalX=Label("TotalX","0x",.91f,.71f,.14f,.055f,Color.white,.041f);
            totalMoney=Label("TotalMoney","$0",.91f,.657f,.14f,.032f,Color.white,.025f);
            Label("FreeTitle","FREE SPINS",.91f,.565f,.14f,.025f,Color.white,.023f);spinCountLabel=Label("FreeCount","—",.91f,.52f,.14f,.055f,Gold,.050f);
            bonusLabel=Label("Mode","BASE GAME",.91f,.46f,.14f,.031f,Color.white,.020f);blockLabel=Label("BlockWin","",.91f,.355f,.14f,.10f,Gold,.023f);blockLabel.textWrappingMode=TextWrappingModes.Normal;
            Label("BetTitle","BET",.285f,.15f,.16f,.020f,Gold,.020f);betLabel=Label("Bet","—",.285f,.108f,.18f,.038f,Color.white,.030f);
            Label("WinTitle","WIN",.10f,.15f,.15f,.020f,Gold,.020f);winLabel=Label("Win","$0",.10f,.108f,.17f,.038f,Color.white,.030f);
            statusLabel=Label("Status","PLACE YOUR BETS",.5f,.025f,.70f,.020f,Color.white,.018f);
            foreach(var b in Buttons.Where(b=>new[]{"Spin","Minus","Plus","Turbo","Auto","Info"}.Contains(b.id)))
            {var im=Img("Hud"+b.id,_ui,Spr("button_"+b.id.ToLowerInvariant()));N(im.rectTransform,b.cx,b.cy,b.w,b.h);}
            popRoot=Img("Popup",_ui,Spr("panel")).rectTransform;popRoot.GetComponent<Image>().preserveAspect=false;N(popRoot,.5f,.535f,.76f,.35f);
            popup=Text("PopupTitle",popRoot,Gold,size.y*.062f);Place(popup.rectTransform,new Vector2(0,size.y*.03f),new Vector2(size.x*.70f,size.y*.08f));
            popupSub=Text("PopupSubtitle",popRoot,Color.white,size.y*.028f);Place(popupSub.rectTransform,new Vector2(0,-size.y*.05f),new Vector2(size.x*.70f,size.y*.05f));popRoot.gameObject.SetActive(false);
            menuRoot=Img("Menu",_ui,Spr("px")).rectTransform;menuRoot.GetComponent<Image>().preserveAspect=false;menuRoot.GetComponent<Image>().color=new Color(.035f,.015f,.045f,.96f);N(menuRoot,.50f,.52f,.86f,.80f);menuRoot.gameObject.AddComponent<RectMask2D>();
            menuTitle=Text("MenuTitle",menuRoot,Gold,size.y*.038f);Place(menuTitle.rectTransform,new Vector2(0,size.y*.30f),new Vector2(size.x*.72f,size.y*.05f));
            var close=Img("Close",menuRoot,Spr("button_close"));Place(close.rectTransform,new Vector2(size.x*.40f,size.y*.34f),new Vector2(size.x*.052f,size.y*.052f));
            menuRoot.gameObject.SetActive(false);ShowBuyMenu(-1);
        }
        void MakeSymbol(string n,Transform parent,out Image im,out TMP_Text val)
        {
            im=Img(n,parent);im.preserveAspect=true;Place(im.rectTransform,Vector2.zero,Vector2.one*step*.84f);
            var plate=Img("MultiplierPlate",im.transform,Spr("px"));plate.preserveAspect=false;plate.color=new Color(.12f,.035f,.16f,.90f);Place(plate.rectTransform,Vector2.zero,new Vector2(step*.70f,step*.40f));plate.gameObject.SetActive(false);
            val=Text("Multiplier",im.transform,Gold,step*.30f);val.enableAutoSizing=false;val.fontSize=step*.30f;Place(val.rectTransform,Vector2.zero,new Vector2(step*.70f,step*.40f));
        }
        void SymbolView(Image im,TMP_Text val,int symbol,int mult=1,float alpha=1,float scale=1)
        {
            im.sprite=Symbol(symbol);im.color=new Color(1,1,1,alpha);im.rectTransform.localScale=Vector3.one*scale;
            im.transform.GetChild(0).gameObject.SetActive(mult>1);im.transform.GetChild(0).GetComponent<Image>().color=new Color(.12f,.035f,.16f,.90f*alpha);
            val.text=mult>1?"x"+mult:"";val.color=new Color(Gold.r,Gold.g,Gold.b,alpha);
        }
        void SetIdle(){if(_ui!=null)DrawGrid(previous);}
        void DrawGrid(int[] g)
        {
            foreach(var column in strips)if(column!=null)foreach(var im in column)im.gameObject.SetActive(false);
            for(int i=0;i<49;i++){cells[i].gameObject.SetActive(true);SymbolView(cells[i],values[i],g[i]);cells[i].rectTransform.anchoredPosition=home[i];glows[i].color=Color.clear;}
        }
        static string X(double v)=>v.ToString(v<100?"0.##":"0.#",CultureInfo.InvariantCulture)+"x";
        static string Money(double n)
        {if(double.IsNaN(n)||double.IsInfinity(n))return "—";double a=Math.Abs(n);return "$"+(a>=1e9?(n/1e9).ToString("0.##",CultureInfo.InvariantCulture)+"B":a>=1e6?(n/1e6).ToString("0.##",CultureInfo.InvariantCulture)+"M":a>=1e3?(n/1e3).ToString("0.##",CultureInfo.InvariantCulture)+"K":n.ToString("0.##",CultureInfo.InvariantCulture));}
        void Totals(double total){shownTotal=total;totalX.text=X(total);totalMoney.text=Money(total*betNumber);winLabel.text=Money(total*betNumber);}
        void FeatureHud(FruitPartyEngine.Spin s)
        {if(s==null)return;_ui.GetComponent<Image>().sprite=Spr(s.bonus==1?"bonusbg":"bg");spinCountLabel.text=s.bonus==1||s.awarded>0?s.left.ToString():"—";bonusLabel.text=s.bonus==1?"FRUIT FREE SPINS":"BASE GAME";}
        public void UserRpcShowSpin(string json)
        {
            if(!NetworkClient.active)return;FruitPartyMsg m;
            try{m=GwyfShared.MiniJson.FromJson<FruitPartyMsg>(json);EnsureUi();}catch(Exception e){FruitPartyPlugin.Log.LogError("[FP] Client packet: "+e);return;}
            if(!string.IsNullOrEmpty(m.bet))shownBet=m.bet;if(m.bn>0)betNumber=m.bn;betLabel.text=shownBet;ShowBuyMenu(m.menu);
            var fast=_ui.Find("HudTurbo");if(fast!=null)fast.GetComponent<Image>().color=m.settingSpeed==0?Color.white:m.settingSpeed==1?Lime:Pink;
            var auto=_ui.Find("HudAuto");if(auto!=null)auto.GetComponent<Image>().color=m.auto>0?Lime:Color.white;
            if(m.t=="control"){statusLabel.text=m.busy==1?"ROUND IN PROGRESS":m.auto>0?"AUTO · "+m.auto:"PLACE YOUR BETS";return;}
            if(m.seq<=lastAnimated)return;lastAnimated=m.seq;ClientAbort();float elapsed=FruitPartyTiming.Elapsed(NetworkTime.time,m.sent,m.duration);
            if(elapsed>=m.duration){if(m.s!=null){DrawGrid(m.s.Final);previous=(int[])m.s.Final.Clone();FeatureHud(m.s);}Totals(m.total);return;}
            animation=StartCoroutine(SafeAnimate(m,elapsed));
        }
        IEnumerator SafeAnimate(FruitPartyMsg m,float elapsed)
        {
            var iterator=Animate(m,elapsed);
            while(true)
            {
                object current;try{if(!iterator.MoveNext())break;current=iterator.Current;}catch(Exception e){FruitPartyPlugin.Log.LogError("[FP] Animation: "+e);break;}yield return current;
            }
            (iterator as IDisposable)?.Dispose();if(m.s!=null){DrawGrid(m.s.Final);previous=(int[])m.s.Final.Clone();FeatureHud(m.s);}Totals(m.total);animation=null;
        }
        IEnumerator Animate(FruitPartyMsg m,float elapsed)
        {
            float origin=Time.unscaledTime-elapsed;var sounds=new bool[7];int lastStep=-1;FruitPartyTimeline.Phase last=FruitPartyTimeline.Phase.Done;
            try
            {
                if(m.t=="intro")
                {
                    popRoot.gameObject.SetActive(true);popup.text="10 FREE SPINS";popupSub.text="MORE x2 / x4 MULTIPLIERS · MAX WIN 5000x";
                    while(Time.unscaledTime-origin<m.duration){popRoot.localScale=Vector3.one*(.94f+.06f*FruitPartyTimeline.Ease(Mathf.Min(1,(Time.unscaledTime-origin)*4)));yield return null;}yield break;
                }
                if(m.t=="end")
                {if(m.s!=null)DrawGrid(m.s.Final);Totals(m.total);statusLabel.text=m.total>=5000?"MAX WIN · 5000x":"ROUND COMPLETE · "+X(m.total);yield break;}
                if(elapsed<FruitPartyTiming.ReelEnd(6,m.speed))Sfx(spinReelSFX);
                while(true)
                {
                    float t=Time.unscaledTime-origin;for(int c=0;c<7;c++)if(!sounds[c]&&t>=FruitPartyTiming.ReelEnd(c,m.speed)){sounds[c]=true;Sfx(spinDoneSFX);}
                    var frame=FruitPartyTimeline.At(m.s,t,m.speed);
                    if(frame.phase==FruitPartyTimeline.Phase.Hit&&(last!=frame.phase||lastStep!=frame.step))Sfx(multiplierSFX,m.s.steps[frame.step].clusters.Max(c=>c.multi));
                    DrawSpin(m.s,frame,t,m.speed,m.total-m.s.win);last=frame.phase;lastStep=frame.step;if(t>=m.duration)break;yield return null;
                }
                if(m.s.win>0)Sfx(finaltextSFX,(float)m.s.win);Totals(m.total);
            }
            finally{if(popRoot!=null)popRoot.gameObject.SetActive(false);animation=null;}
        }
        void DrawSpin(FruitPartyEngine.Spin s,FruitPartyTimeline.Frame frame,float elapsed,int speed,double from)
        {
            var state=s.steps[frame.step];blockLabel.text="";popRoot.gameObject.SetActive(false);
            foreach(var column in strips)foreach(var im in column)im.gameObject.SetActive(false);
            for(int i=0;i<49;i++){cells[i].gameObject.SetActive(true);cells[i].rectTransform.anchoredPosition=home[i];glows[i].color=Color.clear;}
            if(frame.phase==FruitPartyTimeline.Phase.Reels)
            {
                for(int c=0;c<7;c++)
                {
                    float end=FruitPartyTiming.ReelEnd(c,speed);bool moving=elapsed<end;int travel=Math.Max(8,(int)Math.Round(end*9));float p=CellReelMotion.Position(elapsed,end,travel);
                    for(int row=0;row<7;row++){int i=c*7+row;cells[i].gameObject.SetActive(!moving);if(!moving)SymbolView(cells[i],values[i],s.steps[0].g[i]);}
                    if(!moving)continue;
                    for(int j=0;j<9;j++)
                    {
                        int idx=(int)Math.Floor(p)+1-j,endRow=travel-idx,startRow=-idx;
                        int sym=endRow>=0&&endRow<7?s.steps[0].g[c*7+endRow]:startRow>=0&&startRow<7?previous[c*7+startRow]:Math.Abs(idx+c*3)%7;
                        var im=strips[c][j];im.gameObject.SetActive(true);SymbolView(im,stripValues[c][j],sym);Place(im.rectTransform,new Vector2(0,(3+idx-p)*step),Vector2.one*step*.84f);
                    }
                }
            }
            else if(frame.phase==FruitPartyTimeline.Phase.Drop)
            {
                for(int i=0;i<49;i++){SymbolView(cells[i],values[i],state.after[i]);cells[i].rectTransform.anchoredPosition=new Vector2(home[i].x,(3-FruitPartyTimeline.DropRow(state,i,frame.p))*step);}
            }
            else
            {
                bool hit=frame.phase==FruitPartyTimeline.Phase.Hit;float fade=hit?FruitPartyTimeline.Ease(Mathf.Clamp01((frame.p-.60f)/.40f)):0;
                var removed=new HashSet<int>(hit?state.removed:new int[0]);
                for(int i=0;i<49;i++)
                {
                    bool winning=removed.Contains(i);float alpha=winning?1-fade:1;int multi=hit&&frame.p>.10f?state.m[i]:1;
                    SymbolView(cells[i],values[i],state.g[i],multi,alpha,winning?1+.08f*Mathf.Sin(frame.p*Mathf.PI):1);
                    if(winning)glows[i].color=new Color(1,.82f,.22f,.35f*Mathf.Sin(frame.p*Mathf.PI));
                }
                if(hit){var best=state.clusters.OrderByDescending(c=>c.pay).First();blockLabel.text="BLOCK "+X(best.multi)+"\n"+X(state.win);}
                if(frame.phase==FruitPartyTimeline.Phase.Retrigger)
                {popRoot.gameObject.SetActive(true);popup.text="+"+s.awarded+" FREE SPINS";popupSub.text=s.scatters+" SCATTERS · "+s.left+" SPINS LEFT";popRoot.localScale=Vector3.one*(.94f+.06f*FruitPartyTimeline.Ease(Mathf.Min(1,frame.p*4)));}
            }
            FeatureHud(s);if(s.bonus==1&&frame.phase!=FruitPartyTimeline.Phase.Retrigger&&frame.phase!=FruitPartyTimeline.Phase.Done)spinCountLabel.text=Math.Max(0,s.left-s.awarded).ToString();
            Totals(Math.Max(0,from)+frame.win);statusLabel.text=frame.phase==FruitPartyTimeline.Phase.Reels?(s.bonus==1?"FREE SPIN · SPINNING":"SPINNING"):frame.phase==FruitPartyTimeline.Phase.Hit?"CLUSTER WIN · "+X(state.win):frame.phase==FruitPartyTimeline.Phase.Drop?"TUMBLE":s.capped?"MAX WIN · 5000x":"TUMBLE WIN · "+X(s.win);
        }
        void ShowBuyMenu(int selected)
        {
            if(menuRoot==null||selected==lastMenu&&lastMenuBet==betNumber)return;lastMenu=selected;lastMenuBet=betNumber;menuRoot.gameObject.SetActive(selected!=-1);
            foreach(var t in GetComponentsInChildren<InteractableEventTrigger>(true))
            {if(t.name=="FPScr_Buy0")t.gameObject.SetActive(selected>=0);else if(t.name=="FPScr_Close")t.gameObject.SetActive(selected!=-1);}
            for(int i=menuRoot.childCount-1;i>=0;i--){var child=menuRoot.GetChild(i);if(child.name.StartsWith("Content"))Destroy(child.gameObject);}
            if(selected==-1)return;
            menuTitle.text=selected>=0?"BUY FREE SPINS":selected==-2?"PAYOUT · x TOTAL BET":selected==-3?"CLUSTERS / TUMBLES / MULTIPLIERS":"FREE SPINS / CONTROLS";
            if(selected>=0)
            {
                var card=Img("ContentBuy",menuRoot,Spr("panel"));card.preserveAspect=false;Place(card.rectTransform,new Vector2(0,size.y*.02f),new Vector2(size.x*.60f,size.y*.28f));
                var title=Text("Title",card.transform,Gold,size.y*.045f);title.text="10 FREE SPINS";Place(title.rectTransform,new Vector2(0,size.y*.05f),new Vector2(size.x*.55f,size.y*.060f));
                buyCostText=Text("Price",card.transform,Color.white,size.y*.035f);buyCostText.text=Money(betNumber*100)+" · 100x BET";Place(buyCostText.rectTransform,new Vector2(0,-size.y*.012f),new Vector2(size.x*.55f,size.y*.050f));
                var hint=Text("Hint",card.transform,Color.white,size.y*.018f);hint.text="[E] CARD / SPIN TO CONFIRM";Place(hint.rectTransform,new Vector2(0,-size.y*.073f),new Vector2(size.x*.54f,size.y*.030f));return;
            }
            if(selected==-2)
            {
                for(int sym=0;sym<7;sym++)
                {
                    float x=(sym-3)*size.x*.108f;var icon=Img("ContentIcon"+sym,menuRoot,Symbol(sym));Place(icon.rectTransform,new Vector2(x,size.y*.205f),Vector2.one*size.y*.088f);
                    var pay=Text("ContentPay"+sym,menuRoot,Color.white,size.y*.020f);pay.textWrappingMode=TextWrappingModes.Normal;Place(pay.rectTransform,new Vector2(x,-size.y*.045f),new Vector2(size.x*.10f,size.y*.37f));
                    pay.text=string.Join("\n",Enumerable.Range(5,11).Select(n=>(n==15?"15+":n.ToString())+"  "+X(FruitPartyEngine.Pays[sym][n-5])));
                }
            }
            else
            {
                var text=Text("ContentRules",menuRoot,Color.white,size.y*.028f);text.textWrappingMode=TextWrappingModes.Normal;text.alignment=TextAlignmentOptions.Left;
                Place(text.rectTransform,new Vector2(0,-size.y*.020f),new Vector2(size.x*.76f,size.y*.55f));
                text.text=selected==-3?"7 × 7 · CLUSTERS\nFive or more identical symbols connected horizontally or vertically pay. Diagonals do not connect. Separate winning blocks all pay.\n\nTUMBLE\nWinning symbols disappear. Survivors fall down; new symbols enter from above. Tumbles continue until there are no winning clusters.\n\nRANDOM MULTIPLIERS\nWinning tiles may receive x2 in the base game, x2 or x4 more often in free spins. Multiply every tile multiplier inside its block, up to x256.\n\nMAX ROUND WIN · 5000x BET":
                "3+ SCATTERS → 10 FREE SPINS\nScatter can land on every reel and does not form clusters.\n\nRETRIGGER\n3 / 4 / 5 / 6 / 7 scatters award +10 / +11 / +12 / +13 / +14 free spins.\n\nBUY FREE SPINS · 100x BET\nA round stops immediately at the 5000x cap. Payout follows all tumbles/free spins.\n\nSPIN · start / confirm purchase\nSPEED · normal / quick / turbo\nAUTO · start / stop automatic play\nINFO · next rules page\nMod uses its own reel frequencies; original RTP is not claimed.";
            }
        }
        void ClientAbort()
        {
            if(animation!=null){StopCoroutine(animation);animation=null;}if(_ui==null)return;
            foreach(var column in strips)if(column!=null)foreach(var im in column)im.gameObject.SetActive(false);
            for(int i=0;i<49;i++)if(cells[i]!=null){cells[i].gameObject.SetActive(true);cells[i].rectTransform.anchoredPosition=home[i];cells[i].rectTransform.localScale=Vector3.one;glows[i].color=Color.clear;}
            if(popRoot!=null)popRoot.gameObject.SetActive(false);
        }
    }
}
