using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace FruitParty
{
    /// Restyle the original cabinet surfaces; no detached poles, arches or floating props.
    public partial class FruitPartyGame
    {

        static Texture2D _marqueeTex;

        void BuildCabinet()
        {
            foreach(var text in GetComponentsInChildren<TMPro.TextMeshPro>(true))
                if(text.name.Equals("GameName",StringComparison.OrdinalIgnoreCase)){var renderer=text.GetComponent<MeshRenderer>();if(renderer!=null)renderer.enabled=false;}
            var skip = new List<Transform>();
            if (keypadSpawnPoint != null) skip.Add(keypadSpawnPoint);
            foreach (var b in new[] { turboButton, buyButton, betMinusButton, betPlusButton }.Concat(playButtons)) if (b != null) skip.Add(b.transform);
            if (_ui != null) skip.Add(_ui);
            if (payoutText != null) skip.Add(payoutText.transform);
            var rends = GetComponentsInChildren<Renderer>(true).Where(r => !(r is ParticleSystemRenderer) && !(r is SpriteRenderer) && !skip.Any(t => r.transform == t || r.transform.IsChildOf(t))).ToList();
            int tint = 0, marq = 0;
            foreach (var r in rends)
            {
                var mats = r.materials; foreach(var owned in mats) if(owned!=null) ownedMaterials.Add(owned); bool ch = false;
                foreach (var m in mats)
                {
                    if (m == null) continue;
                    if (m.HasProperty("_AlbedoMap") && m.GetTexture("_AlbedoMap") != null && !(m.GetTexture("_AlbedoMap") is RenderTexture))
                    {   // vanilla neon marquee atlas (generic slot sign): UV-matched themed replacement with the slot's name (Puppy Palace 1.6.2 pattern)
                        if (_marqueeTex == null) _marqueeTex = LoadPng("topscreen");
                        if (_marqueeTex != null) { m.SetTexture("_AlbedoMap", _marqueeTex); ch = true; marq++; }
                        continue;
                    }
                    string colProp = m.HasProperty("_BaseColor") ? "_BaseColor" : m.HasProperty("_Color") ? "_Color" : null;
                    string mainProp = m.HasProperty("_BaseMap") ? "_BaseMap" : m.HasProperty("_MainTex") ? "_MainTex" : null;
                    if (colProp == null) continue;
                    if (mainProp != null && m.GetTexture(mainProp) is RenderTexture) continue;
                    string ln = (m.name + " " + r.name).ToLowerInvariant();
                    if (ln.Contains("glass") || ln.Contains("light") || ln.Contains("ligts") || ln.Contains("screen")) continue;
                    var col = m.GetColor(colProp); float lum = col.r * .3f + col.g * .59f + col.b * .11f;
                    var target = lum > .6f ? new Color(1f, .72f, .92f) : lum > .25f ? new Color(.38f, .75f, .20f) : new Color(.24f, .07f, .32f); // dust / copper / iron
                    m.SetColor(colProp, new Color(target.r, target.g, target.b, col.a)); ch = true; tint++;
                }
                if (ch) r.materials = mats;
            }
            FruitPartyPlugin.V($"Cabinet themed on original body: {tint} tinted slots, marquee={marq}");
        }

    }
}
