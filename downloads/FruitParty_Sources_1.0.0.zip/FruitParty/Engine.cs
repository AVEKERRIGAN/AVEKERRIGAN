using System;
using System.Collections.Generic;
using System.Linq;
namespace FruitParty
{
    public static class FruitPartyEngine
    {
        public const int Cols=7,Rows=7,Cells=49,Regular=7,Scatter=7,Variants=1;
        public const double MaxWinX=5000;
        public static readonly string[] ArtKeys={"strawberry","orange","apple","grapes","plum","star","heart","scatter"};
        public static readonly string[] BuyNames={"10 FREE SPINS"};public static readonly double[] BuyCost={100};
        // Reference paytable shows cash at BET $2; these are payouts / total bet.
        public static readonly double[][] Pays={
            new[]{1d,1.5,1.75,2,2.5,5,7.5,15,35,70,150},
            new[]{.75,1,1.25,1.5,2,4,6,12.5,30,60,100},
            new[]{.5,.75,1,1.25,1.5,3,4.5,10,25,50,90},
            new[]{.4,.5,.75,1,1.25,2,3,5,20,40,80},
            new[]{.3,.4,.5,.75,1,1.5,2.5,3.5,15,30,60},
            new[]{.25,.30,.40,.50,.75,1.25,2,3,10,20,40},
            new[]{.20,.25,.30,.40,.50,1,1.5,2.5,5,10,20}};
        static readonly int[] BaseWeights={8,10,12,14,16,18,20},BonusWeights={10,12,14,16,18,20,22};
        [Serializable] public class Cluster {public int symbol,multi;public int[] cells;public double baseWin,pay;}
        [Serializable] public class Step
        {public int[] g,m,removed,after,source;public List<Cluster> clusters=new List<Cluster>();public double win,total;public bool capped;}
        [Serializable] public class Spin
        {public List<Step> steps=new List<Step>();public int scatters,left,awarded,bonus;public double win,total;public bool capped;public int[] Final=>steps[steps.Count-1].g;}
        [Serializable] public class Round {public List<Spin> spins=new List<Spin>();public double total;public bool capped;public int variant=-1;}
        public static int Retrigger(int scatters)=>scatters>=3?Math.Min(7,scatters)+7:0;
        public static int[] InitialGrid()=>Enumerable.Range(0,Cells).Select(i=>(i*3+i/Rows)%Regular).ToArray();
        public static List<int[]> Clusters(int[] g)
        {
            if(g==null||g.Length!=Cells||g.Any(v=>v<0||v>Scatter))throw new ArgumentException("7x7 grid required");
            var seen=new bool[Cells];var result=new List<int[]>();var queue=new Queue<int>();
            for(int start=0;start<Cells;start++)
            {
                if(seen[start]||g[start]==Scatter)continue;var group=new List<int>();seen[start]=true;queue.Enqueue(start);
                while(queue.Count>0)
                {
                    int i=queue.Dequeue();group.Add(i);int c=i/Rows,row=i%Rows;
                    foreach(int next in new[]{c>0?i-Rows:-1,c<Cols-1?i+Rows:-1,row>0?i-1:-1,row<Rows-1?i+1:-1})
                        if(next>=0&&!seen[next]&&g[next]==g[start]){seen[next]=true;queue.Enqueue(next);}
                }
                if(group.Count>=5)result.Add(group.OrderBy(i=>i).ToArray());
            }
            return result;
        }
        public static Step Resolve(Random r,int[] grid,bool bonus,int[] forcedMultipliers=null)
        {
            var s=new Step{g=(int[])grid.Clone(),m=Enumerable.Repeat(1,Cells).ToArray()};var removed=new List<int>();
            foreach(var ids in Clusters(grid))
            {
                int multi=1;
                foreach(int i in ids)
                {
                    int m=forcedMultipliers!=null?forcedMultipliers[i]:r.NextDouble()<(bonus?.446:.055)?(bonus&&r.Next(2)==1?4:2):1;
                    if(m!=1&&m!=2&&m!=4||!bonus&&m==4)throw new ArgumentException("Invalid tile multiplier");s.m[i]=m;multi=Math.Min(256,multi*m);
                }
                int sym=grid[ids[0]];double pay=Pays[sym][Math.Min(15,ids.Length)-5];
                s.clusters.Add(new Cluster{symbol=sym,cells=ids,multi=multi,baseWin=pay,pay=pay*multi});s.win+=pay*multi;removed.AddRange(ids);
            }
            s.removed=removed.OrderBy(i=>i).ToArray();return s;
        }
        static int Pick(Random r,bool bonus)
        {var weights=bonus?BonusWeights:BaseWeights;int n=r.Next(weights.Sum());for(int i=0;i<Regular;i++){n-=weights[i];if(n<0)return i;}return Regular-1;}
        public static int[] Draw(Random r,bool bonus,bool force=false)
        {
            var g=Enumerable.Range(0,Cells).Select(i=>Pick(r,bonus)).ToArray();
            for(int c=0;c<Cols;c++)if(r.NextDouble()<(bonus?.070:.070))g[c*Rows+r.Next(Rows)]=Scatter;
            if(force)
            {for(int i=0;i<Cells;i++)if(g[i]==Scatter)g[i]=Pick(r,bonus);for(int c=1;c<=3;c++)g[c*Rows+r.Next(Rows)]=Scatter;}
            return g;
        }
        public static void Refill(Random r,Step s,bool bonus)
        {
            var gone=new HashSet<int>(s.removed);s.after=new int[Cells];s.source=Enumerable.Repeat(-1,Cells).ToArray();
            for(int c=0;c<Cols;c++)
            {
                int dest=Rows-1;bool scatter=false;
                for(int row=Rows-1;row>=0;row--)
                {
                    int i=c*Rows+row;if(gone.Contains(i))continue;int target=c*Rows+dest--;s.after[target]=s.g[i];s.source[target]=i;if(s.g[i]==Scatter)scatter=true;
                }
                for(int row=dest;row>=0;row--)
                {
                    int target=c*Rows+row;s.after[target]=Pick(r,bonus);
                    if(!scatter&&r.NextDouble()<(bonus?.008:.006)){s.after[target]=Scatter;scatter=true;}
                }
            }
        }
        public static void Credit(Step s,double remaining)
        {
            double credit=0;
            foreach(var c in s.clusters){c.pay=Math.Min(c.pay,Math.Max(0,remaining-credit));credit+=c.pay;}
            s.win=credit;s.capped=credit>=remaining&&remaining>0;
        }
        public static Spin PlaySpin(Random r,bool bonus,int left,double remaining,bool force=false)
        {
            var spin=new Spin{bonus=bonus?1:0};var g=Draw(r,bonus,force);
            for(int n=0;;n++)
            {
                if(n>=256)throw new InvalidOperationException("Tumble safety guard reached; refund round");
                var s=Resolve(r,g,bonus);Credit(s,remaining-spin.win);spin.win+=s.win;s.total=spin.win;spin.steps.Add(s);
                if(s.capped){spin.capped=true;break;}
                if(s.removed.Length==0)break;Refill(r,s,bonus);g=s.after;
            }
            spin.scatters=spin.Final.Count(v=>v==Scatter);spin.awarded=bonus?Retrigger(spin.scatters):spin.scatters>=3?10:0;
            spin.left=bonus?Math.Max(0,left-1+spin.awarded):spin.awarded;return spin;
        }
        public static Round Play(Random r,bool force=false)=>PlayRound(r,-1,force);
        public static Round PlayBuyVariant(Random r,int variant)
        {if(variant!=0)throw new ArgumentOutOfRangeException(nameof(variant));return PlayRound(r,variant,true);}
        static Round PlayRound(Random r,int variant,bool force)
        {
            var result=new Round{variant=variant};int left=0;
            for(int index=0;index==0||left>0;index++)
            {
                if(index>4096)throw new InvalidOperationException("Free spins safety guard reached; refund round");
                var spin=PlaySpin(r,index>0,left,MaxWinX-result.total,index==0&&force);result.spins.Add(spin);
                result.total+=spin.win;if(spin.capped)result.total=MaxWinX;spin.total=result.total;left=spin.left;
                if(spin.capped||result.total>=MaxWinX){result.capped=true;spin.capped=true;spin.left=0;break;}
            }
            return result;
        }
    }
    [Serializable] public class FruitPartyMsg
    {public string t,bet;public FruitPartyEngine.Spin s;public int seq,round,bi,buyVariant=-1,tb,speed,settingTurbo,settingSpeed,menu=-1,auto,busy;public double bn,sent,total;public float duration;public bool snapshot;}
    public static class FruitPartyTiming
    {
        public static float Elapsed(double now,double sent,float duration)=>(float)Math.Min(Math.Max(0,now-sent),Math.Max(0,duration));
        public static float ReelEnd(int c,int speed)=>(speed==2?.48f:speed==1?.78f:1.15f)+(speed==2?.045f:speed==1?.070f:.110f)*c;
        public static float Hit(int speed)=>speed==2?.29f:speed==1?.48f:.75f;
        public static float Drop(int speed)=>speed==2?.23f:speed==1?.38f:.54f;
        public static float Count(int speed)=>speed==2?.18f:speed==1?.30f:.48f;
        public static float Intro(int speed)=>speed==2?1.05f:speed==1?1.4f:1.85f;
        public static float Duration(FruitPartyEngine.Spin s,int speed)=>ReelEnd(6,speed)+s.steps.Count(st=>st.removed.Length>0)*Hit(speed)+s.steps.Count(st=>st.after!=null)*Drop(speed)+Count(speed)+(s.bonus==1&&s.awarded>0?Intro(speed):0)+.15f;
    }
}
namespace FruitParty
{
    public static class FruitPartyTimeline
    {
        public enum Phase { Reels,Hit,Drop,Count,Retrigger,Done }
        public struct Frame {public Phase phase;public int step;public float p;public double win;}
        static float Clamp(float p)=>Math.Max(0,Math.Min(1,p));
        public static float Ease(float q){q=Clamp(q);return q*q*q*(q*(q*6-15)+10);}
        public static Frame At(FruitPartyEngine.Spin s,float elapsed,int speed)
        {
            float cursor=FruitPartyTiming.ReelEnd(6,speed);double won=0;
            if(elapsed<cursor)return new Frame{phase=Phase.Reels,p=Clamp(elapsed/cursor)};
            for(int i=0;i<s.steps.Count;i++)
            {
                var step=s.steps[i];if(step.removed.Length>0)
                {
                    float d=FruitPartyTiming.Hit(speed);if(elapsed<cursor+d){float p=Clamp((elapsed-cursor)/d);return new Frame{phase=Phase.Hit,step=i,p=p,win=won+step.win*Ease(p)};}cursor+=d;won+=step.win;
                }
                if(step.after!=null)
                {float d=FruitPartyTiming.Drop(speed);if(elapsed<cursor+d)return new Frame{phase=Phase.Drop,step=i,p=Clamp((elapsed-cursor)/d),win=won};cursor+=d;}
            }
            float count=FruitPartyTiming.Count(speed);if(elapsed<cursor+count)return new Frame{phase=Phase.Count,step=s.steps.Count-1,p=Clamp((elapsed-cursor)/count),win=won};cursor+=count;
            if(s.bonus==1&&s.awarded>0)
            {float d=FruitPartyTiming.Intro(speed);if(elapsed<cursor+d)return new Frame{phase=Phase.Retrigger,step=s.steps.Count-1,p=Clamp((elapsed-cursor)/d),win=won};}
            return new Frame{phase=Phase.Done,step=s.steps.Count-1,p=1,win=s.win};
        }
        public static float FromRow(FruitPartyEngine.Step s,int i)
        {
            int src=s.source[i];if(src>=0)return src%7;int col=i/7;int empty=0;
            for(int row=0;row<7;row++)if(s.source[col*7+row]<0)empty++;
            return i%7-empty;
        }
        public static float DropRow(FruitPartyEngine.Step s,int i,float progress)=>FromRow(s,i)+(i%7-FromRow(s,i))*Ease(progress);
    }
}
