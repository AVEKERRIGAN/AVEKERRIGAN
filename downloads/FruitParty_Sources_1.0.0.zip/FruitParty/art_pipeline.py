from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import math,random,json,hashlib,shutil
root=Path(__file__).parent;art=root/'art';art.mkdir(exist_ok=True)
atlas=root/'inputs'/'symbols.png'
im=Image.open(atlas).convert('RGBA');w,h=im.size
keys=['strawberry','orange','apple','grapes','plum','star','heart','scatter']
# Extract each complete atlas cell; preserve the original fruit proportions.
for i,key in enumerate(keys):
 tile=im.crop((int(i%4*w/4),int(i//4*h/2),int((i%4+1)*w/4),int((i//4+1)*h/2)))
 box=tile.getbbox();assert box
 tile=tile.crop(box);tile.thumbnail((436,436),Image.Resampling.LANCZOS)
 canvas=Image.new('RGBA',(512,512));canvas.alpha_composite(tile,((512-tile.width)//2,(512-tile.height)//2));canvas.save(art/f'{key}.png')
# Original procedural scene/UI illustrations. No edits to reference images.
for bonus in [False,True]:
 bg=Image.new('RGBA',(1280,800));px=bg.load()
 top=(134,73,222) if bonus else (66,172,242);bottom=(243,142,215) if bonus else (138,227,75)
 for y in range(800):
  p=y/799;c=tuple(round(a+(b-a)*p) for a,b in zip(top,bottom))+(255,)
  for x in range(1280):px[x,y]=c
 d=ImageDraw.Draw(bg)
 for box in [(-130,265,750,1050),(430,255,1550,1140),(-250,570,1450,1300)]:
  d.ellipse(box,fill=('#dd8af0' if bonus else '#75c73e'),outline=('#bd6cd8' if bonus else '#50a927'),width=8)
 rng=random.Random(82)
 for x in range(-70,1390,150):
  y=rng.randrange(500,730);d.ellipse((x-48,y-70,x+48,y+40),fill=('#f5b1f4' if bonus else '#a4dc45'),outline=('#d976d2' if bonus else '#71b936'),width=4)
  for k in range(5):
   sx=x+rng.randint(-30,30);sy=y+rng.randint(-48,10);d.ellipse((sx-4,sy-4,sx+4,sy+4),fill='#ffffa8')
 bg.save(art/('bonusbg.png' if bonus else 'bg.png'))
# White pastel tiles with thin purple lines and a gold outer rim.
grid=Image.new('RGBA',(896,896),'#c949b2');d=ImageDraw.Draw(grid)
for col in range(7):
 for row in range(7):
  x=col*128;y=row*128;d.rectangle((x+4,y+4,x+124,y+124),fill='#fffbdf' if (col+row)%2 else '#f7f3ff',outline='#d4a9e2',width=2)
d.rounded_rectangle((3,3,893,893),radius=20,outline='#efb02a',width=7);d.rounded_rectangle((10,10,886,886),radius=16,outline='#6e286c',width=3);grid.save(art/'grid.png')
Image.new('RGBA',(4,4),'white').save(art/'px.png')
font='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
logo=Image.new('RGBA',(1300,190));d=ImageDraw.Draw(logo);f=ImageFont.truetype(font,142);word='FRUIT PARTY';width=d.textlength(word,font=f);xx=(1300-width)/2
colors=['#37deec','#72ed41','#ff7630','#ffdf39','#ec40c8','#60e939','#ff5159','#ffd734','#73ef38','#4ed6ef','#e761ed']
for k,ch in enumerate(word):
 d.text((xx+4,14),ch,font=f,fill='#39153d',stroke_width=12,stroke_fill='#39153d');d.text((xx,3),ch,font=f,fill=colors[k],stroke_width=8,stroke_fill='#cb2abb');d.text((xx,3),ch,font=f,fill=colors[k],stroke_width=3,stroke_fill='#263723');xx+=d.textlength(ch,font=f)
logo.save(art/'logo.png')
top=Image.new('RGBA',(512,512),'#632181');small=logo.copy();small.thumbnail((480,130));top.alpha_composite(small,((512-small.width)//2,(512-small.height)//2));top.save(art/'topscreen.png')
for name,label in [('spin',''),('minus','-'),('plus','+'),('turbo','>>>'),('auto','AUTO'),('info','i'),('close','X')]:
 button=Image.new('RGBA',(256,256));d=ImageDraw.Draw(button);d.ellipse((9,9,247,247),fill='#3f732ada',outline='#fefae2',width=10)
 if name=='spin':d.arc((53,47,204,199),195,485,fill='white',width=17);d.polygon([(207,159),(209,206),(162,189)],fill='white')
 else:
  f=ImageFont.truetype(font,72 if len(label)>1 else 124);box=d.textbbox((0,0),label,font=f);d.text(((256-box[2])/2,(256-box[3])/2-6),label,font=f,fill='#fffadc')
 button.save(art/f'button_{name}.png')
panel=Image.new('RGBA',(768,256),'#65265de8');d=ImageDraw.Draw(panel);d.rounded_rectangle((4,4,764,252),radius=40,fill='#632956ee',outline='#ffe98d',width=10);d.rounded_rectangle((19,19,749,237),radius=31,outline='#ed45bd',width=5);panel.save(art/'panel.png')
(root/'art-provenance.json').write_text(json.dumps({'symbols':'original generated glossy fruit illustrations','atlas_sha256':hashlib.sha256(atlas.read_bytes()).hexdigest(),'original_game_art_copied':False,'extraction':'alpha bounding-box per cell; aspect-preserving thumbnail on equal 512px transparent canvases','scene_and_ui':'original procedural vector shapes and typography'},indent=2))
print('Art ready:',len(list(art.glob('*.png'))),'textures')
