using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using System.Text;

namespace GwyfShared
{
    /// Self-contained reflection JSON for RPC messages. Replaces UnityEngine.JsonUtility, which in the current
    /// game build silently drops nested class fields of plugin-defined types (spin grids arrived empty -> static screens).
    /// Public instance fields only; supports primitives, enums, string, arrays, List<T>, nested classes. Null-safe.
    public static class MiniJson
    {
        static readonly CultureInfo Inv = CultureInfo.InvariantCulture;
        static readonly Dictionary<Type, FieldInfo[]> _fields = new Dictionary<Type, FieldInfo[]>();

        static FieldInfo[] Fields(Type t)
        {
            if (_fields.TryGetValue(t, out var f)) return f;
            var l = new List<FieldInfo>();
            foreach (var fi in t.GetFields(BindingFlags.Public | BindingFlags.Instance))
                if (!fi.IsNotSerialized && !fi.IsInitOnly) l.Add(fi);
            f = l.ToArray(); _fields[t] = f; return f;
        }

        public static string ToJson(object o) { var sb = new StringBuilder(256); Write(sb, o, 0); return sb.ToString(); }

        static void Write(StringBuilder sb, object o, int depth)
        {
            if (o == null || depth > 32) { sb.Append("null"); return; }
            var t = o.GetType();
            if (o is string s) { WriteStr(sb, s); return; }
            if (o is bool b) { sb.Append(b ? "true" : "false"); return; }
            if (t.IsEnum) { sb.Append(System.Convert.ToInt64(o).ToString(Inv)); return; }
            if (o is float fl) { sb.Append(float.IsNaN(fl) || float.IsInfinity(fl) ? "0" : fl.ToString("R", Inv)); return; }
            if (o is double d) { sb.Append(double.IsNaN(d) || double.IsInfinity(d) ? "0" : d.ToString("R", Inv)); return; }
            if (t.IsPrimitive || o is decimal) { sb.Append(System.Convert.ToString(o, Inv)); return; }
            if (o is IList list)
            {
                sb.Append('[');
                for (int i = 0; i < list.Count; i++) { if (i > 0) sb.Append(','); Write(sb, list[i], depth + 1); }
                sb.Append(']'); return;
            }
            sb.Append('{'); bool first = true;
            foreach (var fi in Fields(t))
            {
                var v = fi.GetValue(o); if (v == null) continue;
                if (!first) sb.Append(','); first = false;
                WriteStr(sb, fi.Name); sb.Append(':'); Write(sb, v, depth + 1);
            }
            sb.Append('}');
        }

        static void WriteStr(StringBuilder sb, string s)
        {
            sb.Append('"');
            foreach (char c in s)
            {
                switch (c)
                {
                    case '"': sb.Append("\\\""); break;
                    case '\\': sb.Append("\\\\"); break;
                    case '\n': sb.Append("\\n"); break;
                    case '\r': sb.Append("\\r"); break;
                    case '\t': sb.Append("\\t"); break;
                    default: if (c < 32) sb.Append("\\u").Append(((int)c).ToString("x4")); else sb.Append(c); break;
                }
            }
            sb.Append('"');
        }

        public static T FromJson<T>(string json) where T : class
        {
            int i = 0; var tree = Parse(json, ref i);
            return (T)Convert(tree, typeof(T));
        }

        static object Convert(object v, Type t)
        {
            if (v == null) return t.IsValueType ? Activator.CreateInstance(t) : null;
            if (t == typeof(string)) return v as string ?? System.Convert.ToString(v, Inv);
            if (t == typeof(object)) return v;
            if (t.IsEnum) return Enum.ToObject(t, System.Convert.ToInt64(v is bool bb ? (bb ? 1 : 0) : v, Inv));
            if (t == typeof(bool)) return v is bool b ? b : System.Convert.ToDouble(v, Inv) != 0;
            if (t.IsPrimitive || t == typeof(decimal))
            {
                if (v is bool b2) v = b2 ? 1.0 : 0.0;
                if (v is string s2) v = double.Parse(s2, Inv);
                return System.Convert.ChangeType(v, t, Inv);
            }
            if (t.IsArray)
            {
                var src = v as List<object>; if (src == null) return null;
                var et = t.GetElementType(); var arr = Array.CreateInstance(et, src.Count);
                for (int k = 0; k < src.Count; k++) arr.SetValue(Convert(src[k], et), k);
                return arr;
            }
            if (t.IsGenericType && t.GetGenericTypeDefinition() == typeof(List<>))
            {
                var src = v as List<object>; if (src == null) return null;
                var et = t.GetGenericArguments()[0]; var l = (IList)Activator.CreateInstance(t);
                foreach (var e in src) l.Add(Convert(e, et));
                return l;
            }
            var dict = v as Dictionary<string, object>; if (dict == null) return null;
            var o = Activator.CreateInstance(t, true);
            foreach (var fi in Fields(t))
            {
                if (dict.TryGetValue(fi.Name, out var fv) && fv != null) fi.SetValue(o, Convert(fv, fi.FieldType));
                else if (fi.GetValue(o) == null)
                {   // JsonUtility semantics for missing values: empty arrays/lists/strings, nested classes stay null
                    var ft = fi.FieldType;
                    if (ft == typeof(string)) fi.SetValue(o, "");
                    else if (ft.IsArray) fi.SetValue(o, Array.CreateInstance(ft.GetElementType(), 0));
                    else if (ft.IsGenericType && ft.GetGenericTypeDefinition() == typeof(List<>)) fi.SetValue(o, Activator.CreateInstance(ft));
                }
            }
            return o;
        }

        static void Ws(string s, ref int i) { while (i < s.Length && char.IsWhiteSpace(s[i])) i++; }

        static object Parse(string s, ref int i)
        {
            Ws(s, ref i); if (i >= s.Length) throw new FormatException("unexpected end");
            char c = s[i];
            if (c == '{')
            {
                var d = new Dictionary<string, object>(); i++; Ws(s, ref i);
                if (s[i] == '}') { i++; return d; }
                while (true)
                {
                    Ws(s, ref i); var k = (string)Parse(s, ref i); Ws(s, ref i);
                    if (s[i] != ':') throw new FormatException("':' expected at " + i); i++;
                    d[k] = Parse(s, ref i); Ws(s, ref i);
                    if (s[i] == ',') { i++; continue; }
                    if (s[i] == '}') { i++; return d; }
                    throw new FormatException("',' or '}' expected at " + i);
                }
            }
            if (c == '[')
            {
                var l = new List<object>(); i++; Ws(s, ref i);
                if (s[i] == ']') { i++; return l; }
                while (true)
                {
                    l.Add(Parse(s, ref i)); Ws(s, ref i);
                    if (s[i] == ',') { i++; continue; }
                    if (s[i] == ']') { i++; return l; }
                    throw new FormatException("',' or ']' expected at " + i);
                }
            }
            if (c == '"')
            {
                var sb = new StringBuilder(); i++;
                while (s[i] != '"')
                {
                    char ch = s[i++];
                    if (ch == '\\')
                    {
                        char e = s[i++];
                        switch (e)
                        {
                            case 'n': sb.Append('\n'); break;
                            case 'r': sb.Append('\r'); break;
                            case 't': sb.Append('\t'); break;
                            case 'b': sb.Append('\b'); break;
                            case 'f': sb.Append('\f'); break;
                            case 'u': sb.Append((char)int.Parse(s.Substring(i, 4), NumberStyles.HexNumber)); i += 4; break;
                            default: sb.Append(e); break;
                        }
                    }
                    else sb.Append(ch);
                }
                i++; return sb.ToString();
            }
            if (s.Length - i >= 4 && string.CompareOrdinal(s, i, "true", 0, 4) == 0) { i += 4; return true; }
            if (s.Length - i >= 5 && string.CompareOrdinal(s, i, "false", 0, 5) == 0) { i += 5; return false; }
            if (s.Length - i >= 4 && string.CompareOrdinal(s, i, "null", 0, 4) == 0) { i += 4; return null; }
            int st = i;
            while (i < s.Length && "+-0123456789.eE".IndexOf(s[i]) >= 0) i++;
            if (st == i) throw new FormatException("bad token at " + i);
            return double.Parse(s.Substring(st, i - st), NumberStyles.Float, Inv);
        }
    }
}

namespace GwyfShared
{
    /// Registers a Mirror ClientRpc and reports 16-bit hash collisions (Mirror only logs them via Debug.LogError,
    /// which BepInEx does not capture, and then overwrites the other handler).
    public static class RpcGuard
    {
        static BepInEx.Logging.ManualLogSource _log;
        public static void Register(Type type, string sig, Mirror.RemoteCalls.RemoteCallDelegate func)
        {
            if (_log == null) _log = BepInEx.Logging.Logger.CreateLogSource("GwyfRpc");
            ushort h = (ushort)((uint)Mirror.Extensions.GetStableHashCode(sig) & 0xFFFFu);
            try
            {
                var f = typeof(Mirror.RemoteCalls.RemoteProcedureCalls).GetField("remoteCallDelegates", System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.NonPublic);
                var d = f?.GetValue(null) as System.Collections.IDictionary;
                if (d != null && d.Contains(h))
                {
                    var inv = d[h]; var ct = inv?.GetType().GetField("componentType")?.GetValue(inv) as Type;
                    if (ct != null && ct != type) { _log.LogError($"RPC hash collision {h} for {sig} with {ct.FullName} - NOT registered"); return; }
                }
            }
            catch (Exception e) { _log.LogWarning("RPC collision check failed: " + e.Message); }
            Mirror.RemoteCalls.RemoteProcedureCalls.RegisterRpc(type, sig, func);
            _log.LogInfo($"RPC registered {sig} hash={h}");
        }
    }
}
