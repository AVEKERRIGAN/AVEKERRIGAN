using GoldRushExpress;
using GwyfShared;
using System.Globalization;
using System.Text.Json;
int checks=0,rounds=0,steps=0;
void Check(bool okay,string name){checks++;if(!okay)throw new Exception(name);}
// Reel windows must stay covered through every wrap and end on a whole symbol.
foreach(float duration in new[]{.5f,.65f,1f,1.2f,1.92f,4.5f})
foreach(int fps in new[]{25,30,60,144})
{
 int travel=CellReelMotion.Travel(duration);float previous=0;
 for(int frame=0;frame<=Math.Ceiling(duration*fps)+1;frame++)
 {
  float elapsed=(float)frame/fps,position=CellReelMotion.Position(elapsed,duration,travel);
  Check(float.IsFinite(position)&&position>=previous-1e-5&&position<=travel+1e-5,"strip stays finite and moves forward");previous=position;
  var slots=Enumerable.Range(0,3).Select(i=>CellReelMotion.Slot(position,i)).ToArray();
  float covered=slots.Sum(s=>Math.Max(0,Math.Min(.5f,s.Offset+.5f)-Math.Max(-.5f,s.Offset-.5f)));
  Check(Math.Abs(covered-1)<1e-5,"reel mask has no blank hole at a wrap");
  Check(slots.Select(s=>s.Index).Distinct().Count()==3,"no duplicated strip symbols in window");
  if(elapsed>=duration)
  {
   Check(slots[1].Index==travel&&slots[1].Offset==0,"final symbol stops at exact center");
   Check(slots[0].Offset==-1&&slots[2].Offset==1,"neighbour symbols are wholly outside stopped cell");
  }
 }
 float h=duration*1e-4f;
 float velocityStart=CellReelMotion.Position(h,duration,travel)/h;
 float velocityEnd=(travel-CellReelMotion.Position(duration-h,duration,travel))/h;
 Check(Math.Abs(velocityStart)<.03f&&Math.Abs(velocityEnd)<.03f,"start and stop have zero velocity");
 foreach(float boundary in new[]{duration*.18f,duration*.64f})
 {
  float v1=(CellReelMotion.Position(boundary,duration,travel)-CellReelMotion.Position(boundary-h,duration,travel))/h;
  float v2=(CellReelMotion.Position(boundary+h,duration,travel)-CellReelMotion.Position(boundary,duration,travel))/h;
  Check(Math.Abs(v1-v2)<.08f,"velocity is continuous between acceleration/cruise/braking");
 }
 Check(CellReelMotion.Slot(travel-.1f,2).Index==travel&&CellReelMotion.Slot(travel-.1f,2).Offset>0,"result enters from above before stop");
}
// A column is a single ordered strip; final rows enter together and retain order.
foreach(float duration in new[]{.5f,.65f,1f,1.2f,1.92f,4.5f})
foreach(int fps in new[]{25,30,60,144})
{
 int travel=ColumnReelMotion.Travel(duration,4);
 Check(travel>=5,"initial and result sequences never overlap");
 for(int frame=0;frame<=Math.Ceiling(duration*fps)+1;frame++)
 {
  float elapsed=(float)frame/fps,pos=CellReelMotion.Position(elapsed,duration,travel);
  var slots=Enumerable.Range(0,6).Select(i=>ColumnReelMotion.Slot(pos,i)).ToArray();
  Check(slots.Zip(slots.Skip(1),(a,b)=>a.Index-b.Index).All(d=>d==1),"one coherent ordered column, no separate cell phases");
  float covered=slots.Sum(s=>Math.Max(0,Math.Min(.5f,s.Offset+.5f)-Math.Max(-3.5f,s.Offset-.5f)));
  Check(Math.Abs(covered-4)<1e-5,"entire four-row window remains filled through every wrap");
  if(elapsed>=duration)
   for(int row=0;row<4;row++)
    Check(ColumnReelMotion.FinalRow(slots[row+1].Index,travel,4)==row&&slots[row+1].Offset==-row,"all result rows stop on their own center together");
 }
 for(int row=0;row<4;row++)Check(ColumnReelMotion.InitialRow(-row,4)==row,"spin starts with previous visible row sequence");
}
Check(TrainPresentation.ValueFont==.16f,"shared maximum digit size for coins and characters");
Check(TrainPresentation.CoinValueFor(3).Y<0&&TrainPresentation.CoinValueFor(24).Y<0,"labels follow the different atlas inner circle centers");
var rows=new[]{TrainPresentation.TotalMoney,TrainPresentation.TotalMultiplier,TrainPresentation.TotalTitle};
foreach(var box in rows.Concat(new[]{TrainPresentation.CoinValue,TrainPresentation.CardValue}))
 Check(Math.Abs(box.X)+box.Width/2<=.48f&&Math.Abs(box.Y)+box.Height/2<=.48f,"text box stays inside its texture");
for(int i=0;i<2;i++)Check(rows[i].Y+rows[i].Height/2<rows[i+1].Y-rows[i+1].Height/2,"total title/value/money have separate nonoverlapping rows");
CultureInfo.CurrentCulture=CultureInfo.GetCultureInfo("ru-RU");
Check(TrainPresentation.Multiplier(14.2f)=="14.2x","fractional total preserved under Russian locale");
Check(TrainPresentation.CellValue(1.5f)=="x1.5"&&TrainPresentation.CellValue(.2f)=="x0.2","cell label never rounds fractional award to integer");
Check(TrainPresentation.Multiplier(50000)=="50000x"&&TrainPresentation.CellValue(99999)=="x100K","large labels fit by autosize/abbreviation");
Check(TrainPresentation.Total(2,12)==14&&TrainPresentation.Total(2,60000)==50000,"total includes base win and respects cap");
Check(TrainPresentation.Total(2,20,500)==522,"full board award counted once");
float Q(float seconds,int fps)=>(float)Math.Ceiling(seconds*fps-.0001f)/fps;
float RenderedBonus(GrMsg msg,int fps)
{
 var b=msg.b;bool turbo=msg.tb==1;
 float duration=Q(msg.bi==0?GrTiming.Reveal(turbo):GrTiming.BSpin(turbo)+GrTiming.Stagger(turbo)*6,fps);
 duration+=GrTiming.Specials(b)*Q(GrTiming.LandEach(turbo),fps);
 foreach(var e in b.ev??Array.Empty<TrainEngine.Ev>())
  duration+=(e.k==TrainEngine.OUTLAW||e.k==TrainEngine.IOUTLAW)?Q(GrTiming.ActBase(turbo)*.5f,fps)+Math.Min(12,e.tg.Length)*Q(GrTiming.Shot(turbo),fps):Q(GrTiming.ActDur(e,turbo),fps);
 duration+=Math.Max(0,b.cols-b.cols0)*Q(GrTiming.Unlock(turbo),fps)+(b.full==1?Q(GrTiming.Full(turbo),fps):0)+Q(GrTiming.Settle(turbo),fps);
 return duration;
}
var random=new Random(20261019);int persistent=0,outlaws=0,unlocks=0;
for(int variant=0;variant<TrainEngine.Variants;variant++)
for(int run=0;run<1000;run++)
{
 var round=TrainEngine.PlayBuyVariant(random,variant);rounds++;
 Check(round.bought&&round.bonus.Count>0&&round.total>=0&&round.total<=TrainEngine.MaxWinX,"all purchased variants produce valid capped bonus");
 float previous=round.baseSpin.win;
 for(int index=0;index<round.bonus.Count;index++)
 {
  var b=round.bonus[index];steps++;
  Check(b.bt.Length==28&&b.bv.Length==28&&b.bt.All(t=>t>=-1&&t<=9)&&b.cols0>=5&&b.cols<=7,"bonus snapshot and lock dimensions");
  var visible=(float[])b.bv.Clone();
  foreach(var e in b.ev)
  {
   Check(e.s>=0&&e.s<28&&e.tg.All(i=>i>=0&&i<28)&&e.after.Length==28,"event maps to valid cells");
   visible=e.after;if(e.k>=7)persistent++;if(e.k==5||e.k==9)outlaws++;
  }
  float calculated=Enumerable.Range(0,28).Where(i=>b.bt[i]>=0).Sum(i=>visible[i])+(b.full==1?500:0);
  Check(Math.Abs(calculated-b.tot)<=Math.Max(.02f,b.tot*1e-5f),"displayed board after actions matches host bonus total");
  if(b.cols>b.cols0)unlocks++;
  foreach(bool turbo in new[]{false,true})
  {
   float capped=TrainPresentation.Total(round.baseSpin.win,b.tot);
   var msg=new GrMsg{t="bstep",b=b,bi=index,bw=round.baseSpin.win,tot=capped,tb=turbo?1:0,by=1,buyVariant=variant,bet="$550",bn=550};
   foreach(int fps in new[]{25,30,60,144})Check(RenderedBonus(msg,fps)<GrTiming.BStep(msg)+GrTiming.FrameSlack(msg),"host waits for every landing/action including frame quantization");
   var copy=MiniJson.FromJson<GrMsg>(MiniJson.ToJson(msg));
   Check(copy.tot==msg.tot&&copy.bw==msg.bw&&copy.buyVariant==variant&&copy.b.nw.SequenceEqual(b.nw)&&copy.b.ev.Length==b.ev.Length&&copy.b.bv.SequenceEqual(b.bv),"RPC preserves purchased variant, totals and complete animation snapshot");
  }
  Check(TrainPresentation.Total(round.baseSpin.win,b.tot)>=previous-.01f,"total advances through the bonus");previous=TrainPresentation.Total(round.baseSpin.win,b.tot);
 }
}
Check(persistent>0&&outlaws>0&&unlocks>0,"exercise persistent effects, shots and reel unlocks");
for(int run=0;run<2000;run++)
{
 var round=TrainEngine.Play(random);rounds++;
 Check(double.IsFinite(round.total)&&round.total>=0&&round.total<=50000,"base round payout stays valid");
 foreach(bool turbo in new[]{false,true})
 {
  var msg=new GrMsg{t="spin",s=round.baseSpin,tb=turbo?1:0,w=round.baseSpin.win};
  Check(GrTiming.Spin(msg)>GrTiming.SpinIn(msg.s.g,turbo)&&GrTiming.FrameSlack(msg)>.15f,"base and respin host timing includes result/settle phases");
 }
}
if(args.Length==2&&args[0]=="--export")
{
 var export=new {title=TrainPresentation.TotalTitle,multiplier=TrainPresentation.TotalMultiplier,money=TrainPresentation.TotalMoney,card=TrainPresentation.CardValue,coin=TrainPresentation.CoinValue,
 valueFont=TrainPresentation.ValueFont,gold=TrainPresentation.CoinValueFor(3),silver=TrainPresentation.CoinValueFor(24),
 columns=Enumerable.Range(0,5).Select(c=>new{duration=1.2f+.12f*c,travel=ColumnReelMotion.Travel(1.2f+.12f*c,4),frames=Enumerable.Range(0,145).Select(frame=>new{time=frame/60f,slots=Enumerable.Range(0,6).Select(slot=>ColumnReelMotion.Slot(CellReelMotion.Position(frame/60f,1.2f+.12f*c,ColumnReelMotion.Travel(1.2f+.12f*c,4)),slot))})})};
 File.WriteAllText(args[1],JsonSerializer.Serialize(export,new JsonSerializerOptions{IncludeFields=true}));
}
Console.WriteLine($"PASS: {checks} assertions; {rounds} rounds ({TrainEngine.Variants*1000} purchased variants), {steps} bonus steps. Whole column order/coverage/centering, consistent value size/atlas centers, motion at 25/30/60/144 FPS, text rows/locale, running totals, frame timing and real RPC codec. Persistent events {persistent}, shots {outlaws}, unlocks {unlocks}. Unity rendering and live co-op not executed.");
