from pathlib import Path
import zipfile,hashlib,json,shutil
root=Path('/workspace/mod-work');out=Path('/workspace/outputs');repo=Path('/workspace/AVEKERRIGAN')
checks=(root/'train-1.0.20-checks.log').read_text()
assert 'PASS: 626475 assertions;' in checks and 'Unity rendering and live co-op not executed.' in checks
build=(root/'train-1.0.20-build.log').read_text();assert 'Build succeeded.' in build and '0 Error(s)' in build
assert (root/'GoldRushExpress/TrainEngine.cs').read_bytes()==Path('/workspace/mod-work-backups/v3-before-followups/GoldRushExpress/TrainEngine.cs').read_bytes()
plugin=root/'GoldRushExpress/bin/Release/netstandard2.1/GoldRushExpress.dll';assert plugin.read_bytes()[:2]==b'MZ'
with zipfile.ZipFile(repo/'downloads/GoldRushExpress_1.0.19.zip') as previous:
 assert hashlib.sha256(previous.read('BepInEx/plugins/GoldRushExpress/GoldRushExpress.dll')).digest()!=hashlib.sha256(plugin.read_bytes()).digest()
manifest={'BepInEx/plugins/GoldRushExpress/GoldRushExpress.dll':{'version':'1.0.20','networkLayout':'gr-net-1.2','sha256':hashlib.sha256(plugin.read_bytes()).hexdigest()}}
names=['GoldRushExpress_1.0.20.zip','GoldRushExpress_Sources_1.0.20.zip']
with zipfile.ZipFile(out/names[0],'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 z.write(plugin,next(iter(manifest)))
 z.write(root/'GoldRushExpress/README_RU.md','README_RU.md')
 z.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2))
with zipfile.ZipFile(out/names[1],'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for folder in ['GoldRushExpress','TrainChecks','TrainPreview']:
  for file in sorted((root/folder).rglob('*')):
   if file.is_file() and not {'bin','obj'}&set(file.relative_to(root/folder).parts) and file.suffix in {'.cs','.csproj','.md','.png','.py','.html','.mjs'}:
    z.write(file,str(file.relative_to(root)))
 for file in ['global.json','train-1.0.20-build.log','train-1.0.20-checks.log','train-1.0.20-preview.log','package_train_1_0_20.py']:
  z.write(root/file,file)
 z.write(out/'train-1.0.20-presentation.json','validation/presentation.json')
names+=['MoneyTrain_Scroll_1.0.20.mp4','MoneyTrain_Scroll_1.0.20.gif','MoneyTrain_Centered_1.0.20.png','MoneyTrain_Preview_1.0.20.html']
assert 'PASS: 90 preview frames' in (root/'train-1.0.20-preview.log').read_text()
for name in names:
 p=out/name
 if name.endswith('.zip'):
  with zipfile.ZipFile(p) as z:
   assert z.testzip() is None
   assert not any('..' in Path(n).parts or n.startswith('/') for n in z.namelist())
 shutil.copy2(p,repo/'downloads'/name)
 print(name,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
shutil.copy2(root/'GoldRushExpress/README_RU.md',repo/'README_MoneyTrain_RU.md')
p=repo/'README.md';s=p.read_text();a=s.index('## Money Train');b=s.index('## Бумбокс',a)
header="""## Money Train / Gold Rush Express 1.0.20 — цельные барабаны и ровные иксы

- [Установка / обновление — ZIP](downloads/GoldRushExpress_1.0.20.zip)
- [Изменения, управление и кооп](README_MoneyTrain_RU.md)
- [Исходники, графика и результаты проверок](downloads/GoldRushExpress_Sources_1.0.20.zip)
- [Предпросмотр прокрутки — MP4, 30 FPS](downloads/MoneyTrain_Scroll_1.0.20.mp4)
- [Предпросмотр прокрутки — GIF](downloads/MoneyTrain_Scroll_1.0.20.gif)
- [Стопкадр](downloads/MoneyTrain_Centered_1.0.20.png)
- [Офлайн-предпросмотр — HTML с ползунком времени](downloads/MoneyTrain_Preview_1.0.20.html)

Одна лента на столбец вместо отдельных прокруток каждой ячейки. Согласованные
скорость и положение строк, остановка в центре, неподвижные уже выпавшие символы.
Общий размер и цвет цифр, отдельный слой значений, центровка внутри золотых и
серебристых кругов. У серебристой монеты удалён фрагмент соседнего портрета из вырезки.
Справа раздельные строки TOTAL / общий икс / деньги; эффекты ограничены экраном.

У всех участников должна стоять 1.0.20; после замены DLL создайте новое лобби.
Если устанавливаете общий архив автоматов v3, распакуйте **это обновление после него**.
626 475 офлайн-проверок, 6 000 раундов, 45 247 бонусных шагов; DLL собрана без ошибок.
Предпросмотр — отдельный 2D-рендер на текстурах мода и кадрах из рабочего кода,
с приближённым шрифтом. Unity-отрисовка в Windows и живой кооп здесь не запускались.

"""
s=s[:a]+header+s[b:]
s=s.replace('- [GoldRushExpress 1.0.19](downloads/GoldRushExpress_1.0.19.zip)','- [GoldRushExpress 1.0.20](downloads/GoldRushExpress_1.0.20.zip)');p.write_text(s)
p=repo/'SHA256SUMS.txt';lines=p.read_text().splitlines()
lines=[line for line in lines if not any(line.endswith('downloads/'+name) for name in names)]
for name in names:lines.append(hashlib.sha256((out/name).read_bytes()).hexdigest()+'  downloads/'+name)
p.write_text('\n'.join(lines)+'\n')
