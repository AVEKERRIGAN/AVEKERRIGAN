from pathlib import Path
import json,base64
root=Path('/workspace/mod-work');out=Path('/workspace/outputs')
assets={name:'data:image/png;base64,'+base64.b64encode((root/'GoldRushExpress/art'/file).read_bytes()).decode() for name,file in {'atlas':'fresh_atlas.png','bg':'bg_bonus.png','empty':'sym_empty.png','lock':'locked.png','respins':'sign_respins.png'}.items()}
s=(root/'TrainPreview/viewer.html').read_text().replace('__DATA__',(out/'train-1.0.20-presentation.json').read_text()).replace('__ASSETS__',json.dumps(assets))
(out/'MoneyTrain_Preview_1.0.20.html').write_text(s)
