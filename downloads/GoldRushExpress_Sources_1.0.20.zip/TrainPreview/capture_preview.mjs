import fs from 'node:fs/promises';import http from 'node:http';import path from 'node:path';import os from 'node:os';import {spawn} from 'node:child_process';
const root='/workspace/outputs',profile=await fs.mkdtemp(path.join(os.tmpdir(),'train-preview-'));
const html=await fs.readFile(path.join(root,'MoneyTrain_Preview_1.0.20.html'));
const server=http.createServer((req,res)=>{res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});res.end(html);});
await new Promise(r=>server.listen(0,'127.0.0.1',r));const url='http://127.0.0.1:'+server.address().port+'/?capture=1';
const browser=spawn('/usr/bin/chromium',['--headless=new','--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader','--disable-gpu-sandbox','--disable-backgrounding-occluded-windows','--disable-renderer-backgrounding','--remote-debugging-port=0','--user-data-dir='+profile,'--no-first-run','--no-default-browser-check','--window-size=1280,880','about:blank'],{stdio:['ignore','ignore','pipe']});let errors='';browser.stderr.on('data',d=>errors=(errors+d).slice(-10000));
let ws;const pending=new Map();let next=0;
try{
 let port;const started=Date.now();while(!port){try{port=Number((await fs.readFile(path.join(profile,'DevToolsActivePort'),'utf8')).split('\n')[0]);}catch{}if(Date.now()-started>15000)throw Error('Browser start failed: '+errors);await new Promise(r=>setTimeout(r,50));}
 const targets=await(await fetch('http://127.0.0.1:'+port+'/json/list')).json();const target=targets.find(t=>t.type==='page');
 ws=new WebSocket(target.webSocketDebuggerUrl);await new Promise((r,j)=>{ws.addEventListener('open',r,{once:true});ws.addEventListener('error',j,{once:true});});
 ws.addEventListener('message',e=>{const m=JSON.parse(e.data),p=pending.get(m.id);if(m.method==='Runtime.exceptionThrown')console.error(m.params.exceptionDetails.exception?.description?.slice(0,600));if(p){clearTimeout(p.timer);pending.delete(m.id);m.error?p.reject(Error(m.error.message)):p.resolve(m.result);}});
 const call=(method,params={})=>new Promise((resolve,reject)=>{const id=++next,timer=setTimeout(()=>{pending.delete(id);reject(Error('CDP timeout '+method));},30000);pending.set(id,{resolve,reject,timer});ws.send(JSON.stringify({id,method,params}));});
 const evalJS=async expression=>{const r=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));return r.result.value;};
 await call('Page.enable');await call('Runtime.enable');await call('Emulation.setFocusEmulationEnabled',{enabled:true});await call('Emulation.setDeviceMetricsOverride',{width:1280,height:880,deviceScaleFactor:1,mobile:false});await call('Page.navigate',{url});
 let ready=false;for(let i=0;i<200&&!ready;i++){ready=await evalJS('window.trainPreview?.ready===true');if(!ready)await new Promise(r=>setTimeout(r,100));}if(!ready)throw Error('Viewer did not initialize');
 const start=await evalJS('window.trainPreview.render(0)');const stop=await evalJS('window.trainPreview.render(2.4)');
 if(start.total!==112||stop.total!==127||new Set(stop.fonts).size!==1)throw Error('Preview totals or fonts fail');
 async function screenshot(file){const r=await call('Page.captureScreenshot',{format:'png',captureBeyondViewport:false,fromSurface:true});await fs.writeFile(file,Buffer.from(r.data,'base64'));}
 await evalJS('window.trainPreview.render(2.4)');await screenshot(path.join(root,'MoneyTrain_Centered_1.0.20.png'));
 const frames=path.join(root,'train-preview-frames');await fs.mkdir(frames,{recursive:true});
 for(let i=0;i<90;i++){await evalJS('window.trainPreview.render('+Math.min(2.4,i/30)+')');await screenshot(path.join(frames,String(i).padStart(6,'0')+'.png'));}
 console.log('PASS: 90 preview frames, stable label size, running total 112x -> 127x. Separate 2D render, approximate font, not game footage.');
}finally{ws?.close();browser.kill('SIGTERM');server.close();setTimeout(()=>browser.kill('SIGKILL'),1500).unref();}
