"""Export the same PhoneDesign mesh as a static, portable GLB model."""
import bpy,json,math,sys
from pathlib import Path
args=sys.argv[sys.argv.index('--')+1:];data=json.loads(Path(args[0]).read_text())
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
root=bpy.data.objects.new('PocketPhone Pro Max — model 1.3.0',None);bpy.context.collection.objects.link(root)
root['source']='PhoneDesign.cs procedural geometry';root['notice']='Static model; no game footage, hands or browser UI.'
materials={}
for f in data['Finishes']:
    material=bpy.data.materials.new(f['Name']);material.use_nodes=True
    node=material.node_tree.nodes.get('Principled BSDF')
    def linear(c):return c/12.92 if c<=.04045 else ((c+.055)/1.055)**2.4
    node.inputs['Base Color'].default_value=tuple(linear(f[k]) for k in ['R','G','B'])+(1,)
    node.inputs['Metallic'].default_value=f['Metallic'];node.inputs['Roughness'].default_value=1-f['Smoothness']
    materials[f['Name']]=material
for p in data['Parts']:
    mesh=bpy.data.meshes.new(p['Name']);t=p['Mesh']['Triangles']
    mesh.from_pydata([(v['X'],v['Y'],-v['Z']) for v in p['Mesh']['Vertices']],[],[(t[i],t[i+2],t[i+1]) for i in range(0,len(t),3)]);mesh.update()
    mesh.normals_split_custom_set_from_vertices([(v['X'],v['Y'],-v['Z']) for v in p['Mesh']['Normals']])
    for face in mesh.polygons:face.use_smooth=True
    obj=bpy.data.objects.new(p['Name'],mesh);bpy.context.collection.objects.link(obj);obj.parent=root
    obj.location=(p['X'],p['Y'],-p['Z']);obj.rotation_mode='ZXY';obj.rotation_euler=(-math.radians(p['Rx']),-math.radians(p['Ry']),math.radians(p['Rz']))
    obj.data.materials.append(materials[p['Finish']])
bpy.ops.export_scene.gltf(filepath=args[1],export_format='GLB',export_animations=False,export_extras=True,export_yup=False)
print('Exported static GLB from exact PhoneDesign vertices.')
