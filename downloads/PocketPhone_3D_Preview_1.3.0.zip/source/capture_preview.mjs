import fs from 'node:fs/promises';import http from 'node:http';import path from 'node:path';import os from 'node:os';import {spawn} from 'node:child_process';
const root='/workspace/outputs',profile=await fs.mkdtemp(path.join(os.tmpdir(),'phone-3d-preview-'));
const html=await fs.readFile(path.join(root,'PocketPhone_3D_Preview.html'));
const server=http.createServer((req,res)=>{res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});res.end(html);});
await new Promise(r=>server.listen(0,'127.0.0.1',r));const url='http://127.0.0.1:'+server.address().port+'/?capture=1';
const browser=spawn('/usr/bin/chromium',['--headless=new','--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader','--disable-gpu-sandbox','--disable-backgrounding-occluded-windows','--disable-renderer-backgrounding','--remote-debugging-port=0','--user-data-dir='+profile,'--no-first-run','--no-default-browser-check','--window-size=1280,720','about:blank'],{stdio:['ignore','ignore','pipe']});let errors='';browser.stderr.on('data',d=>errors=(errors+d).slice(-10000));
let ws;const pending=new Map();let next=0;
try{
 let port;const started=Date.now();while(!port){try{port=Number((await fs.readFile(path.join(profile,'DevToolsActivePort'),'utf8')).split('\n')[0]);}catch{}if(Date.now()-started>15000)throw Error('Browser start failed: '+errors);await new Promise(r=>setTimeout(r,50));}
 const targets=await(await fetch('http://127.0.0.1:'+port+'/json/list')).json();const target=targets.find(t=>t.type==='page');
 ws=new WebSocket(target.webSocketDebuggerUrl);await new Promise((r,j)=>{ws.addEventListener('open',r,{once:true});ws.addEventListener('error',j,{once:true});});
 ws.addEventListener('message',e=>{const m=JSON.parse(e.data),p=pending.get(m.id);if(p){clearTimeout(p.timer);pending.delete(m.id);m.error?p.reject(Error(m.error.message)):p.resolve(m.result);}});
 const call=(method,params={})=>new Promise((resolve,reject)=>{const id=++next,timer=setTimeout(()=>{pending.delete(id);reject(Error('CDP timeout '+method));},30000);pending.set(id,{resolve,reject,timer});ws.send(JSON.stringify({id,method,params}));});
 const evalJS=async expression=>{const r=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));return r.result.value;};
 await call('Page.enable');await call('Emulation.setFocusEmulationEnabled',{enabled:true});await call('Emulation.setDeviceMetricsOverride',{width:1280,height:720,deviceScaleFactor:1,mobile:false});await call('Page.navigate',{url});
 let ready=false;for(let i=0;i<200&&!ready;i++){ready=await evalJS('window.preview?.ready===true');if(!ready)await new Promise(r=>setTimeout(r,100));}if(!ready)throw Error('Viewer did not initialize');
 const info=await evalJS('window.preview.getInfo()');if(info.renderers!==11||info.triangles!==46211||!info.webgl)throw Error('Unexpected model '+JSON.stringify(info));console.log('Model ready:',JSON.stringify(info));

 await evalJS("document.body.classList.remove('capture')");
 async function clickButton(id){const p=await evalJS(`(()=>{const r=document.getElementById('${id}').getBoundingClientRect();return{x:r.x+r.width/2,y:r.y+r.height/2}})()`);await call('Input.dispatchMouseEvent',{type:'mouseMoved',...p});await call('Input.dispatchMouseEvent',{type:'mousePressed',...p,button:'left',clickCount:1});await call('Input.dispatchMouseEvent',{type:'mouseReleased',...p,button:'left',clickCount:1});}
 await clickButton('back');let state=await evalJS('window.preview.getInfo()');if(Math.abs(state.rotation[1]-Math.PI)>1e-6)throw Error('Back button failed');
 await clickButton('front');state=await evalJS('window.preview.getInfo()');if(state.mode!=='inspect'||state.rotation[1]!==0)throw Error('Front button failed');
 await call('Input.dispatchMouseEvent',{type:'mousePressed',x:1100,y:460,button:'left',clickCount:1});await call('Input.dispatchMouseEvent',{type:'mouseMoved',x:1180,y:420,button:'left',buttons:1});await call('Input.dispatchMouseEvent',{type:'mouseReleased',x:1180,y:420,button:'left',clickCount:1});
 state=await evalJS('window.preview.getInfo()');if(Math.abs(state.rotation[1])<.5)throw Error('Mouse rotation failed');const scale=state.scale;
 await call('Input.dispatchMouseEvent',{type:'mouseWheel',x:1100,y:460,deltaX:0,deltaY:-120});await new Promise(r=>setTimeout(r,80));state=await evalJS('window.preview.getInfo()');if(state.scale<=scale)throw Error('Wheel scale failed');
 if(await evalJS('window.scrollY')!==0)throw Error('Viewer page scrolls');
 await clickButton('motion');for(let i=0;i<60;i++){state=await evalJS('window.preview.getInfo()');if(state.mode==='motion'&&state.time>0)break;await new Promise(r=>setTimeout(r,100));}if(state.mode!=='motion'||state.time<=0)throw Error('Playback button failed '+JSON.stringify(state)+' visibility='+await evalJS('document.visibilityState'));
 await clickButton('pause');const paused=(await evalJS('window.preview.getInfo()')).time;await new Promise(r=>setTimeout(r,100));if((await evalJS('window.preview.getInfo()')).time!==paused)throw Error('Pause failed');
 await evalJS("document.getElementById('time').value=6.8;document.getElementById('time').dispatchEvent(new Event('input',{bubbles:true}));");state=await evalJS('window.preview.getInfo()');if(Math.abs(state.time-6.8)>1e-6||Math.abs(state.position[2]+.45)>1e-6)throw Error('Animation scrub failed');
 await clickButton('reset');await evalJS("document.body.classList.add('capture')");
 console.log('PASS: native mouse rotation, wheel scale, front/back controls, playback/pause and timeline scrubbing. No page scroll.');
 async function screenshot(file){const r=await call('Page.captureScreenshot',{format:'png',captureBeyondViewport:false,fromSurface:true});await fs.writeFile(file,Buffer.from(r.data,'base64'));}
 await evalJS("window.preview.inspect('back')");await screenshot(path.join(root,'PocketPhone_3D_Back.png'));
 await evalJS("window.preview.inspect('front')");await screenshot(path.join(root,'PocketPhone_3D_Front.png'));
 await evalJS('window.preview.setTime(6.8)');await screenshot(path.join(root,'PocketPhone_3D_Zoom.png'));
 if(process.argv.includes('--stills-only')){console.log('Still views verified.');}
 else{
  const frames=path.join(root,'phone-preview-frames');await fs.mkdir(frames,{recursive:true});
  const count=360,fps=30;for(let i=0;i<count;i++){await evalJS('window.preview.setTime('+i/fps+')');await screenshot(path.join(frames,String(i).padStart(6,'0')+'.png'));if(i%30===0)console.log('Captured',i,'/',count);}
  await fs.writeFile(path.join(root,'phone-preview-capture-info.json'),JSON.stringify({source:'PocketPhone 1.3.0 PhoneDesign mesh; Plugin.LateUpdate motion formulas',frames:count,fps,duration:count/fps,model:info,notice:'Separate render. No game footage, native hands or browser UI.'},null,2)+'\n');console.log('Captured all 360 frames.');
 }
}finally{ws?.close();browser.kill('SIGTERM');server.close();setTimeout(()=>browser.kill('SIGKILL'),1500).unref();}
