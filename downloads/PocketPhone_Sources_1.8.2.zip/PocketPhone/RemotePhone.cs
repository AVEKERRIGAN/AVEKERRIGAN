using System;using UnityEngine;using UnityEngine.UI;
namespace PocketPhone;
public sealed class RemotePhone:MonoBehaviour
{
 public PhoneHeldV17 State;public float Received;public readonly SharedFrames Frames=new();readonly AudioQueue samples=new();
 Texture2D texture;RawImage image;FmodPcmOutput audio;uint audioSequence;bool audioSeen;
 public void Initialize(PhoneHeldV17 state,Camera camera){
  State=state;gameObject.AddComponent<PhoneModel>().Build();texture=new Texture2D(2,2,TextureFormat.RGB24,false);texture.SetPixels(new[]{Color.black,Color.black,Color.black,Color.black});texture.Apply();
  var go=new GameObject("FriendPhoneDisplay",typeof(RectTransform),typeof(Canvas));go.transform.SetParent(transform,false);var root=(RectTransform)go.transform;root.sizeDelta=new Vector2(480,960);root.localPosition=new Vector3(0,0,PhoneDesign.DisplayZ);root.localScale=Vector3.one*(PhoneModel.DisplayWidth/480);var canvas=go.GetComponent<Canvas>();canvas.renderMode=RenderMode.WorldSpace;canvas.worldCamera=camera;
  var bg=new GameObject("Background",typeof(RectTransform),typeof(Image));bg.transform.SetParent(root,false);var rect=(RectTransform)bg.transform;rect.anchorMin=Vector2.zero;rect.anchorMax=Vector2.one;rect.offsetMin=rect.offsetMax=Vector2.zero;bg.GetComponent<Image>().color=new Color(.03f,.04f,.055f);
  var screen=new GameObject("PublicVideo",typeof(RectTransform),typeof(RawImage),typeof(AspectRatioFitter));screen.transform.SetParent(root,false);image=screen.GetComponent<RawImage>();image.texture=texture;image.raycastTarget=false;image.color=Color.black;var fit=screen.GetComponent<AspectRatioFitter>();fit.aspectMode=AspectRatioFitter.AspectMode.FitInParent;fit.aspectRatio=432f/768;
  Apply(state);transform.SetPositionAndRotation(state.position,state.rotation);
 }
 public void Apply(PhoneHeldV17 state){if(State.epoch!=state.epoch){Frames.Reset();samples.Reset();audioSeen=false;}State=state;Received=Time.unscaledTime;transform.localScale=Vector3.one*state.scale;if(!state.sharing){image.color=Color.black;samples.Reset();StopAudio();}}
 public void Video(PhoneVideoV17 packet){if(!State.sharing||packet.epoch!=State.epoch)return;var bytes=Frames.Accept(packet.sequence,packet.index,packet.count,packet.data,Time.unscaledTime);if(bytes==null||!SharedFrames.SafeJpeg(bytes))return;try{if(ImageConversion.LoadImage(texture,bytes,false)){image.color=Color.white;image.GetComponent<AspectRatioFitter>().aspectRatio=(float)texture.width/texture.height;}}catch{}}
 public void Audio(PhoneAudioV17 packet,float volume,float distance){if(!State.sharing||packet.epoch!=State.epoch||packet.data==null||packet.data.Length!=960||audioSeen&&(int)(packet.sequence-audioSequence)<=0)return;audioSeen=true;audioSequence=packet.sequence;samples.Push(packet.data);if(audio==null)try{audio=new FmodPcmOutput(samples,true,volume,distance);}catch(Exception e){Debug.LogWarning("PocketPhone FMOD: "+e.Message);}}
 public void Tick(float volume,float distance){float blend=1-Mathf.Exp(-24*Time.unscaledDeltaTime);transform.position=Vector3.Lerp(transform.position,State.position,blend);transform.rotation=Quaternion.Slerp(transform.rotation,State.rotation,blend);audio?.Update(transform.position,volume,distance);}
 void StopAudio(){audio?.Dispose();audio=null;}
 void OnDestroy(){StopAudio();samples.Reset();if(texture!=null)Destroy(texture);}
}
