#nullable enable
using System.Diagnostics;
using System.Net;using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using PocketPhone;

namespace PhoneBrowser;
public static class Program
{
    static readonly object output = new();
    static readonly JsonSerializerOptions outputJson=new(){Encoder=System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping};
    static Process? browser;
    static long nextFrame;
    static string fullFrame="";
    static int maximumFps=24;
    static bool casting; static volatile bool publicMedia; static IDisposable? captureAudio;
    static float volume = .6f;
    static readonly CancellationTokenSource lifetime = new();
    static void Send(object value) { lock (output) { Console.WriteLine(JsonSerializer.Serialize(value,outputJson)); Console.Out.Flush(); } }
    static void Status(string text) => Send(new { type = "status", text });
    public static async Task<int> Main(string[] args)
    {
        Console.OutputEncoding = new UTF8Encoding(false); Console.InputEncoding = new UTF8Encoding(false);
        bool test = args.Contains("--test-headless");
        string profile = args.Length > 0 ? Path.GetFullPath(args[0]) : throw new ArgumentException("Profile required");
        int parent = args.Length > 1 && int.TryParse(args[1], out int pid) ? pid : 0;
        string Option(string flag,string fallback=""){int index=Array.IndexOf(args,flag);return index>=0&&index+1<args.Length?args[index+1]:fallback;}
        bool guestMode=!string.Equals(Option("--guest-mode","true"),"false",StringComparison.OrdinalIgnoreCase);
        try
        {
            string executable="/usr/bin/chromium",browserName="Chromium (test)";
            if(!test)
            {
                var choice=BrowserFinder.Find(Option("--browser","auto"),Option("--browser-path"),out bool fallback);
                executable=choice.Executable;browserName=choice.Name;
                profile=Path.Combine(profile,"EngineProfiles",choice.Family);
                Status(fallback?"Браузер по умолчанию не поддерживает Chromium/CDP; выбран "+browserName:"Выбран браузер: "+browserName);
            }
            Directory.CreateDirectory(profile);
            var start = new ProcessStartInfo { FileName = executable, UseShellExecute = false, CreateNoWindow = true, RedirectStandardError = true, RedirectStandardOutput = true };
            using var reservation=new TcpListener(IPAddress.Loopback,0);reservation.Start();int port=((IPEndPoint)reservation.LocalEndpoint).Port;reservation.Stop();
            var flags = new[] { "--user-data-dir=" + profile, "--remote-debugging-port="+port, "--remote-debugging-address=127.0.0.1", "--no-first-run", "--disable-background-mode", "--no-default-browser-check", "--disable-backgrounding-occluded-windows", "--disable-renderer-backgrounding", "--autoplay-policy=no-user-gesture-required", "--window-position=-2400,-2400", "--window-size=480,840", "--app=about:blank" };
            foreach (string flag in flags) start.ArgumentList.Add(flag);
            if (test) { start.ArgumentList.Add("--headless=new"); start.ArgumentList.Add("--no-sandbox"); }
            string portFile = Path.Combine(profile, "DevToolsActivePort");
            if (File.Exists(portFile)) File.Delete(portFile);
            browser = Process.Start(start) ?? throw new IOException("Не удалось запустить браузер.");
            browser.OutputDataReceived += (_, _) => { }; browser.ErrorDataReceived += (_, _) => { };
            browser.BeginOutputReadLine(); browser.BeginErrorReadLine(); Status("Запускаю браузер…");
            _ = Task.Run(async () => { while (!lifetime.IsCancellationRequested) { if (parent > 0) { try { if (Process.GetProcessById(parent).HasExited) lifetime.Cancel(); } catch { lifetime.Cancel(); } } await Task.Delay(1000); } });
            var deadline=Stopwatch.StartNew();using var http=new HttpClient{Timeout=TimeSpan.FromSeconds(3)};string targetJson;
            while(true){try{targetJson=await http.GetStringAsync("http://127.0.0.1:"+port+"/json/list",lifetime.Token);if(targetJson.Contains("webSocketDebuggerUrl"))break;}catch(HttpRequestException){}catch(TaskCanceledException){lifetime.Token.ThrowIfCancellationRequested();}if(browser.HasExited||deadline.Elapsed.TotalSeconds>30)throw new IOException("Браузер не запустился за 30 секунд.");await Task.Delay(100,lifetime.Token);}
            // Preserve the existing helper diagnostics contract without port=0's automation flag.
            await File.WriteAllTextAsync(portFile,port+"\n",lifetime.Token);using var targets=JsonDocument.Parse(targetJson);
            var target = targets.RootElement.EnumerateArray().First(t => t.GetProperty("type").GetString() == "page");
            await using var cdp = new Cdp(); await cdp.Connect(target.GetProperty("webSocketDebuggerUrl").GetString()!);
            cdp.Closed += () => { Status("Браузер закрыл соединение. Нажмите «Перезапуск»."); lifetime.Cancel(); };
            cdp.Event += (method, data) =>
            {
                if (method == "Page.screencastFrame")
                {
                    long now = Stopwatch.GetTimestamp();
                    if (now >= Interlocked.Read(ref nextFrame))
                    { Interlocked.Exchange(ref nextFrame, now+Stopwatch.Frequency/maximumFps);string jpeg=data.GetProperty("data").GetString()!;Interlocked.Exchange(ref fullFrame,jpeg);Send(new { type = "frame", data = jpeg }); }
                    _ = Ack(cdp, data.GetProperty("sessionId").GetInt32());
                }
                if (method == "Page.loadEventFired") { _ = ApplyVolume(cdp);_ = RefreshFrame(cdp); Status("Страница загружена. Нажимайте кнопки прямо на экране телефона."); }
                if (method == "Inspector.detached") { Status("Соединение с браузером закрыто. Перезапустите телефон."); lifetime.Cancel(); }
            };
            await cdp.Call("Page.enable");
            await cdp.Call("Emulation.setDeviceMetricsOverride", new { width = PhoneProtocol.Width, height = PhoneProtocol.Height, deviceScaleFactor = 1, mobile = false, screenWidth = PhoneProtocol.Width, screenHeight = PhoneProtocol.Height });
            await cdp.Call("Emulation.setEmulatedMedia",new{features=new[]{new{name="prefers-color-scheme",value="dark"}}});
            await cdp.Call("Emulation.setPageScaleFactor",new{pageScaleFactor=1});
            await cdp.Call("Emulation.setScrollbarsHidden",new{hidden=true});
            await cdp.Call("Emulation.setFocusEmulationEnabled", new { enabled = true });
            await cdp.Call("Page.addScriptToEvaluateOnNewDocument",new{source=FeedViewport.Script});
            await cdp.Call("Runtime.evaluate",new{expression=FeedViewport.Script});
            var guestScript=await cdp.Call("Page.addScriptToEvaluateOnNewDocument",new{source=GuestMode.Script(guestMode)});
            string guestScriptId=guestScript.GetProperty("identifier").GetString()!;
            await cdp.Call("Runtime.evaluate",new{expression=GuestMode.Script(guestMode)});
            await cdp.Call("Page.addScriptToEvaluateOnNewDocument", new { source = "(()=>{function v(){document.querySelectorAll('video,audio').forEach(e=>{e.volume=window.__pocketPhoneVolume??" + volume.ToString(System.Globalization.CultureInfo.InvariantCulture) + ";});}new MutationObserver(v).observe(document,{subtree:true,childList:true});document.addEventListener('DOMContentLoaded',v);})();" });
            await cdp.Call("Page.startScreencast", new { format = "jpeg", quality = 72, maxWidth = PhoneProtocol.Width, maxHeight = PhoneProtocol.Height, everyNthFrame = 2 }); casting = true;
            await RefreshFrame(cdp);
            if(!test&&OperatingSystem.IsWindows()){
                try{var capture=new BrowserAudio(browser.Id);capture.Pcm+=pcm=>{if(publicMedia)Send(new{type="audio",data=Convert.ToBase64String(pcm)});};capture.Start();captureAudio=capture;}
                catch(Exception error){Send(new{type="audio_status",text="Звук друзьям недоступен: "+error.Message});}
            }
            // Share the public video rectangle only, never login or account pages.
            _=Task.Run(async()=>{
                while(!lifetime.IsCancellationRequested){
                    try{
                        var result=await cdp.Call("Runtime.evaluate",new{expression="window.__pocketPhoneFeed?.sharedVideo()??null",returnByValue=true});
                        var value=result.GetProperty("result");JsonElement rectangle=default;publicMedia=casting&&value.TryGetProperty("value",out rectangle)&&rectangle.ValueKind==JsonValueKind.Object;
                        if(publicMedia){string jpeg=Volatile.Read(ref fullFrame);string cropped=FrameCrop.Crop(jpeg,rectangle.GetProperty("x").GetDouble(),rectangle.GetProperty("y").GetDouble(),rectangle.GetProperty("width").GetDouble(),rectangle.GetProperty("height").GetDouble());Send(new{type="shareframe",data=cropped});}
                        else Send(new{type="shareframe",data=""});
                    }catch{publicMedia=false;}
                    try{await Task.Delay(125,lifetime.Token);}catch{break;}
                }
            });
            MoveOffscreen(parent); Send(new { type = "ready",browser=browserName }); Status(browserName+" готов. Выберите TikTok или Instagram.");
            var inbox=new CommandInbox();
            var stdin=Task.Run(()=>inbox.Read(Console.In,lifetime.Token,()=>Status("Очередь действий заполнена; повторите нажатие.")));
            while (!lifetime.IsCancellationRequested)
            {
                var command=await inbox.Next(lifetime.Token);if(command==null)break;
                try
                {
                    var cmd=command.Value;
                    string action = cmd.GetProperty("type").GetString()!;
                    if (action == "close") break;
                    switch (action)
                    {
                        case "navigate":
                            if (!PhoneProtocol.Website(cmd.GetProperty("url").GetString()!, out string url)) { Status("Введите адрес HTTPS."); break; }
                            Status("Загружаю страницу…"); var navigation = await cdp.Call("Page.navigate", new { url });
                            if(navigation.TryGetProperty("errorText",out var navigationError)) Status("Сайт не загрузился: "+navigationError.GetString()); break;
                        case "click":
                            int x = Math.Clamp(cmd.GetProperty("x").GetInt32(), 0, PhoneProtocol.Width - 1), y = Math.Clamp(cmd.GetProperty("y").GetInt32(), 0, PhoneProtocol.Height - 1);
                            await FeedViewport.Click(cdp,x,y);break;
                        case "scroll":
                            if(cmd.TryGetProperty("sent",out var sent)&&DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()-sent.GetInt64()>500)break;
                            int delta=Math.Clamp(cmd.GetProperty("delta").GetInt32(),-900,900);
                            if(delta!=0)await FeedViewport.Scroll(cdp,Math.Clamp(cmd.GetProperty("x").GetInt32(),0,PhoneProtocol.Width-1),Math.Clamp(cmd.GetProperty("y").GetInt32(),0,PhoneProtocol.Height-1),delta);break;
                        case "text": await cdp.Call("Input.insertText", new { text = cmd.GetProperty("text").GetString() }); break;
                        case "key":
                            string key = cmd.GetProperty("key").GetString()!;
                            if (key is "Backspace" or "Enter" or "Tab" or "ArrowUp" or "ArrowDown" or "ArrowLeft" or "ArrowRight")
                            {
                                await FeedViewport.Key(cdp,key);
                            } break;
                        case "fps": maximumFps = Math.Clamp(cmd.GetProperty("value").GetInt32(), 8, 30); break;
                        case "volume": volume = Math.Clamp(cmd.GetProperty("value").GetSingle(), 0, 1); await ApplyVolume(cdp); break;
                        case "guest":
                            guestMode=cmd.GetProperty("value").GetBoolean();
                            await cdp.Call("Page.removeScriptToEvaluateOnNewDocument",new{identifier=guestScriptId});
                            guestScript=await cdp.Call("Page.addScriptToEvaluateOnNewDocument",new{source=GuestMode.Script(guestMode)});
                            guestScriptId=guestScript.GetProperty("identifier").GetString()!;
                            await cdp.Call("Runtime.evaluate",new{expression="window.__pocketPhoneGuest?.setEnabled("+(guestMode?"true":"false")+")"});break;
                        case "signin":
                            if(test){Status("Вход в отдельном окне доступен в Windows.");break;}
                            var loginStart=new ProcessStartInfo{FileName=executable,UseShellExecute=false};loginStart.ArgumentList.Add("--user-data-dir="+profile);loginStart.ArgumentList.Add("--new-window");loginStart.ArgumentList.Add("https://www.tiktok.com/login");Process.Start(loginStart)?.Dispose();Status("Войдите в открытом окне браузера. Телефон использует тот же профиль. После входа обновите страницу.");break;
                        case "reload": await cdp.Call("Page.reload"); break;
                        case "back":
                            var history = await cdp.Call("Page.getNavigationHistory"); int index = history.GetProperty("currentIndex").GetInt32();
                            if (index > 0) await cdp.Call("Page.navigateToHistoryEntry", new { entryId = history.GetProperty("entries")[index - 1].GetProperty("id").GetInt32() }); break;
                        case "active":
                            bool active = cmd.GetProperty("value").GetBoolean();bool wasCasting=casting;
                            if (active && !casting) { await cdp.Call("Page.startScreencast", new { format = "jpeg", quality = 72, maxWidth = PhoneProtocol.Width, maxHeight = PhoneProtocol.Height, everyNthFrame = 2 }); casting = true;await RefreshFrame(cdp); }
                            if (!active && casting) { await cdp.Call("Page.stopScreencast"); casting = false; }
                            if(!active||!wasCasting)await cdp.Call("Runtime.evaluate", new { expression = "document.querySelectorAll('video,audio').forEach(e=>e." + (active ? "play().catch(()=>{})" : "pause()") + ");" }); break;
                    }
                }
                catch (Exception e) { Status("Не удалось выполнить действие: " + e.GetType().Name + ". Попробуйте обновить страницу."); }
            }
            try { await cdp.Call("Browser.close").WaitAsync(TimeSpan.FromSeconds(3)); await browser.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(2)); } catch { }
            return 0;
        }
        catch (OperationCanceledException) { return 0; }
        catch (Exception e) { Status(e.Message); return 1; }
        finally { publicMedia=false;captureAudio?.Dispose();captureAudio=null;lifetime.Cancel(); if (browser != null) { try { if (!browser.HasExited) browser.Kill(true); } catch { } browser.Dispose(); } }
    }
    static async Task Ack(Cdp cdp, int id) { try { await cdp.Call("Page.screencastFrameAck", new { sessionId = id }); } catch { } }
    static async Task RefreshFrame(Cdp cdp)
    {
        if(!casting)return;
        try{var snapshot=await cdp.Call("Page.captureScreenshot",new{format="jpeg",quality=72,fromSurface=true,captureBeyondViewport=false});if(casting){string jpeg=snapshot.GetProperty("data").GetString()!;Interlocked.Exchange(ref fullFrame,jpeg);Send(new{type="frame",data=jpeg});}}catch{}
    }
    static async Task ApplyVolume(Cdp cdp) { try { await cdp.Call("Runtime.evaluate", new { expression = "window.__pocketPhoneVolume=" + volume.ToString(System.Globalization.CultureInfo.InvariantCulture) + ";document.querySelectorAll('video,audio').forEach(e=>e.volume=window.__pocketPhoneVolume);" }); } catch { } }
    delegate bool EnumProc(IntPtr hwnd, IntPtr unused);
    [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc callback, IntPtr unused);
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint pid);
    [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr hwnd, IntPtr after, int x, int y, int width, int height, uint flags);
    [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr hwnd);
    static void MoveOffscreen(int parent)
    {
        if (!OperatingSystem.IsWindows() || browser == null) return;
        EnumWindows((hwnd, _) => { GetWindowThreadProcessId(hwnd, out uint id); if (id == browser.Id) SetWindowPos(hwnd, IntPtr.Zero, -2400, -2400, 480, 840, 0x14); return true; }, IntPtr.Zero);
        try { if (parent > 0) SetForegroundWindow(Process.GetProcessById(parent).MainWindowHandle); } catch { }
    }
}
