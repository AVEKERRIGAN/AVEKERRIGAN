using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
namespace PocketPhone;
public sealed class PhoneModel : MonoBehaviour
{
    readonly List<Material> _materials = new(); readonly List<Mesh> _meshes = new();
    public const float Height=.212f,DisplayWidth=.092f;
    public void Build()
    {
        var body=Mat(new Color(.025f,.034f,.056f));var rim=Mat(new Color(.25f,.31f,.40f));var lens=Mat(new Color(.015f,.022f,.04f));var ring=Mat(new Color(.08f,.12f,.20f));
        if(rim.HasProperty("_Metallic"))rim.SetFloat("_Metallic",.8f);
        Rounded("Titanium frame",.106f,Height,.015f,.014f,rim,0);
        Rounded("Midnight case",.102f,.208f,.014f,.013f,body,-.0001f);
        Rounded("Black glass",.098f,.196f,.001f,.011f,lens,-.0074f);
        Rounded("Front camera",.022f,.003f,.001f,.0015f,lens,-.0085f,.091f);
        Rounded("Camera island",.043f,.075f,.002f,.009f,body,.008f,.058f,-.024f);
        for(int i=0;i<3;i++)
        {
            Rounded("Camera bezel",.020f,.020f,.003f,.0095f,rim,.009f,.082f-i*.024f,-.024f);
            Rounded("Camera lens",.015f,.015f,.003f,.007f,ring,.011f,.082f-i*.024f,-.024f);
        }
        Rounded("Volume rocker",.002f,.031f,.003f,.001f,rim,0,.028f,-.054f);
        Rounded("Power key",.002f,.022f,.003f,.001f,rim,0,.018f,.054f);
        foreach(var r in GetComponentsInChildren<MeshRenderer>()){r.shadowCastingMode=ShadowCastingMode.Off;r.receiveShadows=false;}
    }
    Material Mat(Color color,bool unlit=false)
    {
        var shader = unlit ? Shader.Find("Universal Render Pipeline/Unlit") ?? Shader.Find("Unlit/Texture") : Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard");
        var mat=new Material(shader); mat.color=color;
        if(mat.HasProperty("_BaseColor")) mat.SetColor("_BaseColor",color);
        if(mat.HasProperty("_Smoothness")) mat.SetFloat("_Smoothness",.7f);
        _materials.Add(mat); return mat;
    }
    void Rounded(string name,float w,float h,float d,float radius,Material material,float z,float y=0,float x=0)
    {
        const int n=8; var vertices=new List<Vector3>(); var triangles=new List<int>();
        for(int face=0;face<2;face++) for(int corner=0;corner<4;corner++) for(int k=0;k<n;k++)
        {
            float angle=(corner*90f+k*90f/(n-1))*Mathf.Deg2Rad;
            float cx=(corner==0||corner==3?1:-1)*(w*.5f-radius), cy=(corner<2?1:-1)*(h*.5f-radius);
            vertices.Add(new Vector3(cx+radius*Mathf.Cos(angle),cy+radius*Mathf.Sin(angle),(face==0?-1:1)*d*.5f));
        }
        int ring=n*4;
        for(int i=1;i<ring-1;i++) { triangles.AddRange(new[]{0,i+1,i,ring,ring+i,ring+i+1}); }
        for(int i=0;i<ring;i++) { int j=(i+1)%ring; triangles.AddRange(new[]{i,j,ring+j,i,ring+j,ring+i}); }
        var mesh=new Mesh();mesh.SetVertices(vertices);mesh.SetTriangles(triangles,0);mesh.RecalculateNormals();mesh.RecalculateBounds();_meshes.Add(mesh);
        var go=new GameObject(name);go.transform.SetParent(transform,false);go.transform.localPosition=new Vector3(x,y,z);go.AddComponent<MeshFilter>().sharedMesh=mesh;go.AddComponent<MeshRenderer>().sharedMaterial=material;
    }
    void OnDestroy() { foreach(var m in _materials) Destroy(m); foreach(var m in _meshes) Destroy(m); }
}
