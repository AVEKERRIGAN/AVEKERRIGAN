using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using HarmonyLib;
using Mirror;
using MoreMountains.Tools;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.InputSystem;

namespace Blackjack3Hand;

[BepInPlugin("com.malenki.blackjack3hand", "Blackjack 3-Hand", "1.6.0")]
public class BJ3Plugin : BaseUnityPlugin
{
	[HarmonyPatch(typeof(NetworkServer), "Spawn", new Type[]
	{
		typeof(GameObject),
		typeof(NetworkConnectionToClient)
	})]
	internal static class SpawnReplacePatch
	{
		private static bool Prefix(GameObject obj)
		{
			try
			{
				if (_replacing || obj == null || !NetworkServer.active)
				{
					return true;
				}
				if (obj.GetComponent<BJ3Game>() != null)
				{
					Log.LogInfo($"[BJ3] Server spawning 3-hand table at {obj.transform.position}");
					return true;
				}
				if (obj.GetComponent<Blackjack>() == null)
				{
					return true;
				}
				V($"Vanilla blackjack spawn seen: '{obj.name}' at {obj.transform.position} (replace={ReplaceVanilla?.Value})");
				if (ReplaceVanilla == null || !ReplaceVanilla.Value || !EnsurePrefab(null))
				{
					return true;
				}
				if (BJ3Runner.Inst != null)
				{
					BJ3Runner.Inst.StartCoroutine(ReplaceLater(obj));
				}
				return true;
			}
			catch (Exception ex)
			{
				_replacing = false;
				Log.LogError("[BJ3] Spawn replace failed: " + ex);
				return true;
			}
		}
	}

	[HarmonyPatch(typeof(StampManager), "GetLootTableForFloor")]
	internal static class LootPatch
	{
		private static void Postfix(CasinoFloor floor, MMLootTableGameObjectSO __result)
		{
			try
			{
				List<MMLootGameObject> list = __result?.LootTable?.ObjectsToLoot;
				if (list == null)
				{
					return;
				}
				string text = ((floor != null) ? (floor.name + "#" + floor.floorIndex) : "null");
				MMLootGameObject mMLootGameObject = list.FirstOrDefault((MMLootGameObject x) => IsVanillaBJ(x?.Loot));
				if (mMLootGameObject == null)
				{
					return;
				}
				V("Loot table " + text + ": blackjack entry '" + mMLootGameObject.Loot.name + "'");
				if (EnsurePrefab(mMLootGameObject.Loot, quiet: true) && InjectIntoFloors != null && InjectIntoFloors.Value && !list.Any((MMLootGameObject x) => x != null && x.Loot == Prefab))
				{
					list.Add(new MMLootGameObject
					{
						Loot = Prefab,
						Weight = mMLootGameObject.Weight,
						ChancePercentage = 0f
					});
					if (_loggedFloors.Add(text))
					{
						V("Injected 3-hand table into floor " + text);
					}
				}
			}
			catch (Exception ex)
			{
				Log.LogError("[BJ3] Loot injection failed: " + ex);
			}
		}
	}

	[HarmonyPatch(typeof(StampManager), "GetCappedLootForFloor")]
	internal static class CappedLootPatch
	{
		private static void Postfix(ref GameObject __result)
		{
			try
			{
				if (ReplaceVanilla != null && ReplaceVanilla.Value && __result != null && __result.GetComponent<Blackjack>() != null && EnsurePrefab(__result))
				{
					__result = Prefab;
					V("Replaced vanilla blackjack with 3-hand table");
				}
			}
			catch (Exception ex)
			{
				Log.LogError("[BJ3] CappedLoot patch failed: " + ex);
			}
		}
	}

	public const string GUID = "com.malenki.blackjack3hand";

	public const string Version = "1.6.0";

	public const string PrefabName = "Blackjack3Hand_Table";

	public static BJ3Plugin Instance;

	public static ManualLogSource Log;

	public static GameObject Prefab;

	public static uint AssetId;

	public static ConfigEntry<KeyCode> SpawnKey;

	public static ConfigEntry<KeyCode> SpawnKey2;

	public static ConfigEntry<bool> ReplaceVanilla;

	public static ConfigEntry<bool> InjectIntoFloors;

	public static ConfigEntry<bool> Verbose;

	public static ConfigEntry<bool> OwnKeypadScreen;

	public static ConfigEntry<bool> KeypadScreenFlip;

	public static ConfigEntry<float> WalkAwayDistance;

	public static ConfigEntry<float> ChipSize;

	public static ConfigEntry<float> LabelSize;

	public static ConfigEntry<float> TableScale;
    public static ConfigEntry<float> TableHeight;

	public static ConfigEntry<float> CardSpread;

	public static ConfigEntry<float> ArcDegrees;

	public static ConfigEntry<float> ButtonScale;

	public static ConfigEntry<float> SeatSign;

	public static ConfigEntry<float> SeatSpacing;

	public static ConfigEntry<float> TurnTime;

	public static ConfigEntry<float> BetTime;

	public static ConfigEntry<float> SplitOffset;

	public static ConfigEntry<float> LabelHeight;

	public static ConfigEntry<float> CardGap;

	public static ConfigEntry<float> TotalSize;

	public static ConfigEntry<float> CardStair;

	public static ConfigEntry<int> Decks;

	private static GameObject _holder;

	private float _nextCheck;

	private float _nextBuild;

	private static readonly HashSet<string> _loggedFloors = new HashSet<string>();

	private static bool _legacyBroken;

	private static int _lastFrame = -1;

	private static bool _tickLogged;

	private static readonly string[] Actions = new string[5] { "BET", "HIT", "STAND", "DOUBLE", "SPLIT" };

	private static Font _lf;

	private static bool _replacing;

	public static void V(string s)
	{
		if (Verbose == null || Verbose.Value)
		{
			Log.LogInfo("[BJ3] " + s);
		}
	}

	private void Awake()
	{
		Instance = this;
		Log = base.Logger;
		base.Logger.LogInfo("[BJ3] Awake start 1.6.0");
		Step("runner", delegate
		{
			GameObject obj = new GameObject("Blackjack3HandRunner")
			{
				hideFlags = HideFlags.HideAndDontSave
			};
			UnityEngine.Object.DontDestroyOnLoad(obj);
			obj.AddComponent<BJ3Runner>();
		});
		Step("config", delegate
		{
			SpawnKey = base.Config.Bind("Debug", "SpawnKey", KeyCode.F9, "Host only: spawn a 3-hand blackjack table 3 m in front of you. None = off.");
			ReplaceVanilla = base.Config.Bind("Spawn", "ReplaceVanillaTables", defaultValue: true, "Host: every vanilla blackjack table spawns as a 3-hand table instead (TEST default = true).");
			InjectIntoFloors = base.Config.Bind("Spawn", "AddToRandomFloorPool", defaultValue: false, "Host: ALSO add the 3-hand table as an extra random spawn (can land in odd spots). Default off.");
			SeatSpacing = base.Config.Bind("Layout", "SeatSpacing", 0f, "Override for the button panel scale (0 = auto). All players must use the same value.");
			CardSpread = base.Config.Bind("Layout", "CardSpread", 1f, "How far apart the seat card spots are, relative to the button sections. Same for all players.");
			ButtonScale = base.Config.Bind("Layout", "ButtonScale", 1f, "Extra multiplier for seat button size. Same for all players.");
			SeatSign = base.Config.Bind("Layout", "SeatOrder", 1f, "1 or -1: flips which side is seat 1. Same for all players.");
			SplitOffset = base.Config.Bind("Layout", "SplitHandOffset", 0.3f, "Split hand is drawn this fraction of the dealer-player distance towards the dealer. Same for all players.");
			LabelHeight = base.Config.Bind("Layout", "LabelHeight", 0.35f, "Height of the floating seat info text above the cards (m).");
			WalkAwayDistance = base.Config.Bind("Rules", "WalkAwayMeters", 7f, "Host: a seated player farther than this from the table for 4 s leaves the seat (bet refunded while betting; during a round the hand stands). 0 = off.");
			ChipSize = base.Config.Bind("Layout", "ChipStackSize", 1f, "Size of the chip stack + $ label at each seat.");
			TurnTime = base.Config.Bind("Rules", "TurnSeconds", 20f, "Host: seconds per hand to act; on timeout the hand stands.");
			BetTime = base.Config.Bind("Rules", "AutoDealSeconds", 0f, "Host: 0 = cards are dealt ONLY when someone presses DEAL. >0 = also auto-deal this many seconds after the first bet.");
			LabelSize = base.Config.Bind("Layout", "LabelTextSize", 0.045f, "Height of one line of the floating seat text in metres (client side).");
			OwnKeypadScreen = base.Config.Bind("Layout", "OwnKeypadScreen", defaultValue: true, "Draw the bet amount on the keypad screen with the mod's own text (fixes the black keypad screen).");
			KeypadScreenFlip = base.Config.Bind("Layout", "KeypadScreenFlip", defaultValue: false, "Set true only if the keypad amount appears mirrored or is invisible (drawn on the back side).");
			CardGap = base.Config.Bind("Layout", "CardGapMultiplier", 1f, "Spacing between cards in one hand (1 = card width + 5%).");
			TotalSize = base.Config.Bind("Layout", "HandTotalSize", 1f, "Size of the big hand-total numbers above each hand.");
			CardStair = base.Config.Bind("Layout", "CardStairStep", 1f, "How much each next card in a hand moves up the table (1 = 28% of card height).");
			TableHeight = base.Config.Bind("Layout", "HeightMultiplier", .72f, "Vertical height relative to TableScale (0.6..1); cards remain visible from the floor. Same for all players.");
            var heightVersion=base.Config.Bind("Layout","HeightPresetVersion",0,"Migration marker for the lower table height.");
            if(heightVersion.Value<1){if(Mathf.Abs(TableHeight.Value-.78f)<.001f)TableHeight.Value=.72f;heightVersion.Value=1;}
            TableScale = base.Config.Bind("Layout", "TableScale", 1.5f, "Size of the 3-hand table compared to the vanilla one. Same for all players.");
			Decks = base.Config.Bind("Rules", "Decks", 6, "Host: number of decks in the shoe (1-8).");
			SpawnKey2 = base.Config.Bind("Debug", "SpawnKeyAlt", KeyCode.F10, "Second spawn key (host).");
			Verbose = base.Config.Bind("Debug", "VerboseLogging", defaultValue: true, "Write detailed [BJ3] lines to LogOutput.log.");
		});
		Step("assetId", delegate
		{
			using (MD5 mD = MD5.Create())
			{
				AssetId = BitConverter.ToUInt32(mD.ComputeHash(Encoding.UTF8.GetBytes("Blackjack3Hand_Table|net1.6")), 0);
			}
			if (AssetId == 0)
			{
				AssetId = 1112158977u;
			}
		});
		Step("rpc", delegate
		{
			BJ3Game.RegisterRpcs();
		});
		Step("harmony", delegate
		{
			Harmony harmony = new Harmony("com.malenki.blackjack3hand");
			Type[] array = new Type[2]
			{
				typeof(LootPatch),
				typeof(SpawnReplacePatch)
			};
			foreach (Type type in array)
			{
				try
				{
					harmony.CreateClassProcessor(type).Patch();
				}
				catch (Exception ex)
				{
					base.Logger.LogError("[BJ3] Patch " + type.Name + " failed: " + ex);
				}
			}
			foreach (MethodBase patchedMethod in harmony.GetPatchedMethods())
			{
				base.Logger.LogInfo("[BJ3] Harmony patched: " + patchedMethod.DeclaringType?.Name + "." + patchedMethod.Name);
			}
		});
		base.Logger.LogInfo(string.Format("[BJ3] Blackjack 3-Hand {0} loaded, assetId={1}, spawnKey={2}, replaceVanilla={3}", "1.6.0", AssetId, SpawnKey?.Value, ReplaceVanilla?.Value));
	}

	private void Step(string name, Action a)
	{
		try
		{
			a();
			base.Logger.LogInfo("[BJ3] init step OK: " + name);
		}
		catch (Exception ex)
		{
			base.Logger.LogError("[BJ3] init step FAILED: " + name + ": " + ex);
		}
	}

	private void Update()
	{
		Tick();
	}

	public void Tick()
	{
		if (Time.frameCount == _lastFrame)
		{
			return;
		}
		_lastFrame = Time.frameCount;
		if (!_tickLogged)
		{
			_tickLogged = true;
			Log.LogInfo("[BJ3] Tick running (hotkey " + (SpawnKey?.Value).ToString() + " active)");
		}
		try
		{
			TickInner();
		}
		catch (Exception ex)
		{
			if (Time.frameCount % 600 == 0)
			{
				Log.LogError("[BJ3] Tick error: " + ex);
			}
		}
	}

	private void TickInner()
	{
		if ((SpawnKey != null && KeyPressed(SpawnKey.Value)) || (SpawnKey2 != null && KeyPressed(SpawnKey2.Value)))
		{
			SpawnInFront();
		}
		if (Time.unscaledTime < _nextCheck)
		{
			return;
		}
		_nextCheck = Time.unscaledTime + 1f;
		try
		{
			if (!((Dictionary<uint, SpawnHandlerDelegate>)AccessTools.Field(typeof(NetworkClient), "spawnHandlers").GetValue(null)).ContainsKey(AssetId))
			{
				NetworkClient.RegisterSpawnHandler(AssetId, ClientSpawn, ClientUnspawn);
				V("Client spawn handler registered");
			}
		}
		catch (Exception ex)
		{
			base.Logger.LogError("Spawn handler registration failed: " + ex);
			_nextCheck += 30f;
		}
		if (Prefab == null && NetworkClient.active && Time.unscaledTime > _nextBuild)
		{
			_nextBuild = Time.unscaledTime + 10f;
			EnsurePrefab(null, quiet: true);
		}
	}

	private static bool KeyPressed(KeyCode k)
	{
		if (k == KeyCode.None)
		{
			return false;
		}
		try
		{
			Keyboard current = Keyboard.current;
			if (current != null && Enum.TryParse<Key>(k.ToString(), out var result) && current[result].wasPressedThisFrame)
			{
				return true;
			}
		}
		catch
		{
		}
		if (_legacyBroken)
		{
			return false;
		}
		try
		{
			return Input.GetKeyDown(k);
		}
		catch
		{
			_legacyBroken = true;
			return false;
		}
	}

	private void SpawnInFront()
	{
		Log.LogInfo($"[BJ3] Spawn key pressed (host={NetworkServer.active})");
		if (!NetworkServer.active)
		{
			Log.LogWarning("[BJ3] Spawn key works only for the HOST.");
			return;
		}
		if (!EnsurePrefab(null))
		{
			Log.LogError("[BJ3] Cannot spawn: no vanilla blackjack table prefab loaded yet (enter the casino first).");
			return;
		}
		NetworkIdentity localPlayer = NetworkClient.localPlayer;
		Transform transform = ((localPlayer != null) ? localPlayer.transform : ((Camera.main != null) ? Camera.main.transform : null));
		if (transform == null)
		{
			Log.LogError("[BJ3] No local player.");
			return;
		}
		Vector3 vector = Vector3.ProjectOnPlane(transform.forward, Vector3.up);
		if (vector.sqrMagnitude < 0.01f)
		{
			vector = Vector3.forward;
		}
		vector.Normalize();
		Vector3 vector2 = transform.position + vector * 3f;
		float y = transform.position.y;
		List<RaycastHit> list = (from h in Physics.RaycastAll(new Vector3(vector2.x, y + 1f, vector2.z), Vector3.down, 4f, -1, QueryTriggerInteraction.Ignore)
			where h.normal.y > 0.8f && h.collider.GetComponentInParent<PlayerProfile>() == null
			orderby h.distance
			select h).ToList();
		vector2.y = ((list.Count > 0) ? list[0].point.y : y);
		V($"F9 floor: feet y={y:0.##}, hits={list.Count}, placed y={vector2.y:0.##}");
		try
		{
			GameObject obj = UnityEngine.Object.Instantiate(Prefab, vector2, Quaternion.LookRotation(-vector, Vector3.up));
			obj.name = "Blackjack3Hand_Table";
			obj.transform.localScale = Prefab.transform.localScale;
			NetworkServer.Spawn(obj);
			Log.LogInfo($"[BJ3] Spawned 3-hand table at {vector2}. If it faces away, walk around it.");
		}
		catch (Exception ex)
		{
			Log.LogError("[BJ3] Spawn failed: " + ex);
		}
	}

	private static GameObject ClientSpawn(SpawnMessage msg)
	{
		if (!EnsurePrefab(null))
		{
			Log.LogError("[BJ3] Client cannot build table (no vanilla blackjack prefab loaded).");
			return null;
		}
		GameObject obj = UnityEngine.Object.Instantiate(Prefab, msg.position, msg.rotation);
		obj.transform.localScale = msg.scale;
		obj.name = "Blackjack3Hand_Table";
		V("Client spawned 3-hand table");
		return obj;
	}

	private static void ClientUnspawn(GameObject go)
	{
		UnityEngine.Object.Destroy(go);
	}

	private static GameObject FindTemplate()
	{
		Blackjack blackjack = Resources.FindObjectsOfTypeAll<Blackjack>().FirstOrDefault((Blackjack b) => b != null && !b.gameObject.scene.IsValid() && b.transform.root.GetComponent<NetworkIdentity>() != null);
		if (!(blackjack != null))
		{
			return null;
		}
		return blackjack.transform.root.gameObject;
	}

	public static bool EnsurePrefab(GameObject template, bool quiet = false)
	{
		if (Prefab != null)
		{
			return true;
		}
		if (template != null)
		{
			Blackjack componentInChildren = template.GetComponentInChildren<Blackjack>(includeInactive: true);
			NetworkIdentity networkIdentity = ((componentInChildren != null) ? componentInChildren.GetComponentInParent<NetworkIdentity>(includeInactive: true) : null);
			if (networkIdentity == null || networkIdentity.gameObject != template)
			{
				V("Template '" + template.name + "' is a cluster/not a single table, searching loaded prefabs instead");
				template = null;
			}
		}
		if (template == null)
		{
			template = FindTemplate();
		}
		if (template == null)
		{
			if (!quiet)
			{
				Log.LogError("[BJ3] No vanilla blackjack prefab loaded yet.");
			}
			return false;
		}
		V("Building prefab from '" + template.name + "'");
		try
		{
			if (_holder == null)
			{
				_holder = new GameObject("BJ3_PrefabHolder");
				_holder.SetActive(value: false);
				UnityEngine.Object.DontDestroyOnLoad(_holder);
			}
			GameObject gameObject = UnityEngine.Object.Instantiate(template, _holder.transform);
			gameObject.transform.position = Vector3.zero;
			gameObject.transform.rotation = Quaternion.identity;
			gameObject.name = "Blackjack3Hand_Table";
			Blackjack old = gameObject.GetComponentsInChildren<Blackjack>(includeInactive: true).FirstOrDefault();
			if (old == null)
			{
				Log.LogError("[BJ3] Template has no Blackjack component");
				UnityEngine.Object.Destroy(gameObject);
				return false;
			}
			BJ3Game bJ3Game = old.gameObject.AddComponent<BJ3Game>();
			int num = 0;
			FieldInfo[] fields = typeof(GameBase).GetFields(BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
			foreach (FieldInfo fieldInfo in fields)
			{
				try
				{
					fieldInfo.SetValue(bJ3Game, fieldInfo.GetValue(old));
					num++;
				}
				catch
				{
				}
			}
			bJ3Game.cardPrefab = Get<GameObject>("cardPrefab");
			bJ3Game.playerArea = Get<Transform>("playerCardArea");
			bJ3Game.dealerArea = Get<Transform>("dealerCardArea");
			bJ3Game.cardSpacing = Get<float>("cardSpacing");
			bJ3Game.cardMoveSpeed = Get<float>("cardMoveSpeed");
			bJ3Game.SetName();
			V(string.Format("Copied {0} GameBase fields; cardPrefab={1} playerArea={2} dealerArea={3} spacing={4}", num, (bJ3Game.cardPrefab != null) ? bJ3Game.cardPrefab.name : "NULL", bJ3Game.playerArea?.name, bJ3Game.dealerArea?.name, bJ3Game.cardSpacing));
			Dictionary<string, InteractableEventTrigger> byMethod = new Dictionary<string, InteractableEventTrigger>();
			InteractableEventTrigger[] componentsInChildren = gameObject.GetComponentsInChildren<InteractableEventTrigger>(includeInactive: true);
			foreach (InteractableEventTrigger interactableEventTrigger in componentsInChildren)
			{
				UnityEvent<PlayerInteract> serverOnInteractEvent = interactableEventTrigger.serverOnInteractEvent;
				if (serverOnInteractEvent == null)
				{
					continue;
				}
				for (int j = 0; j < serverOnInteractEvent.GetPersistentEventCount(); j++)
				{
					if (serverOnInteractEvent.GetPersistentTarget(j) == old)
					{
						string persistentMethodName = serverOnInteractEvent.GetPersistentMethodName(j);
						V($"Vanilla button '{interactableEventTrigger.name}' -> {persistentMethodName} at {interactableEventTrigger.transform.position}");
						serverOnInteractEvent.SetPersistentListenerState(j, UnityEventCallState.Off);
						if (!byMethod.ContainsKey(persistentMethodName))
						{
							byMethod[persistentMethodName] = interactableEventTrigger;
						}
					}
				}
			}
			byMethod.TryGetValue("TryStartGame", out bJ3Game.dealButton);
			InteractableEventTrigger value;
			InteractableEventTrigger[] array = new string[4] { "PlayerHit", "PlayerStand", "PlayerDouble", "PlayerSplit" }.Select((string m) => (!byMethod.TryGetValue(m, out value)) ? null : value).ToArray();
			InteractableEventTrigger interactableEventTrigger2 = array.FirstOrDefault((InteractableEventTrigger b) => b != null) ?? bJ3Game.dealButton;
			if (interactableEventTrigger2 == null)
			{
				Log.LogError("[BJ3] No buttons found on vanilla table");
				UnityEngine.Object.Destroy(gameObject);
				return false;
			}
			TMP_FontAsset font = (from tMP_Text in gameObject.GetComponentsInChildren<TMP_Text>(includeInactive: true)
				select tMP_Text.font).FirstOrDefault((TMP_FontAsset f) => f != null);
			Transform root = gameObject.transform;
			Transform transform = ((bJ3Game.playerArea != null) ? bJ3Game.playerArea : root);
			Transform transform2 = ((bJ3Game.dealerArea != null) ? bJ3Game.dealerArea : transform);
			List<InteractableEventTrigger> vanillaBtns = array.Where((InteractableEventTrigger b) => b != null).ToList();
			if (bJ3Game.dealButton != null)
			{
				vanillaBtns.Add(bJ3Game.dealButton);
			}
			List<Vector3> list = vanillaBtns.Select((InteractableEventTrigger b) => L(b.transform.position)).ToList();
			Vector3 vector = list.Aggregate(Vector3.zero, (Vector3 vector8, Vector3 y) => vector8 + y) / list.Count;
			float pitch = 0.4f;
			if (list.Count >= 2)
			{
				List<float> list2 = (from v in list
					select v.x into result
					orderby result
					select result).ToList();
				pitch = Mathf.Max(0.05f, (list2.Last() - list2.First()) / (float)(list2.Count - 1));
			}
			List<Renderer> list3 = (from r in gameObject.GetComponentsInChildren<Renderer>(includeInactive: true)
				where !(r is ParticleSystemRenderer) && !vanillaBtns.Any((InteractableEventTrigger bt) => r.transform.IsChildOf(bt.transform))
				select r).ToList();
			Bounds bounds = new Bounds(L(transform2.position), Vector3.zero);
			foreach (Renderer item in list3)
			{
				Bounds bounds2 = item.bounds;
				bounds.Encapsulate(L(bounds2.min));
				bounds.Encapsulate(L(bounds2.max));
			}
			Vector3 vector2 = new Vector3(bounds.center.x, 0f, bounds.center.z);
			Vector3 vector3 = vector - vector2;
			vector3.y = 0f;
			_ = vector3.magnitude;
			float num2 = list.Min((Vector3 v) => v.x) - pitch * 0.5f;
			float num3 = list.Max((Vector3 v) => v.x) + pitch * 0.5f;
			float num4 = (num3 - num2) / 3.45f;
			float num5 = ((SeatSpacing.Value > 0.01f) ? SeatSpacing.Value : (num4 * 0.96f / (5f * pitch)));
			num5 *= ButtonScale.Value;
			V($"Layout(local): row x {num2:0.###}..{num3:0.###} section={num4:0.###} btnCenter={vector} pitch={pitch:0.###} panelScale={num5:0.###} tableBounds c={bounds.center} size={bounds.size}");
			float num6 = ((bJ3Game.dealButton != null && array[2] != null) ? Mathf.Sign(L(bJ3Game.dealButton.transform.position).x - L(array[2].transform.position).x) : (-1f));
			if (SeatSign.Value < 0f)
			{
				num6 = 0f - num6;
			}
			V($"Player-right direction in local x: {num6}");
			List<Vector3> vanillaPos = vanillaBtns.Select((InteractableEventTrigger b) => b.transform.position).ToList();
			bJ3Game.areas.Clear();
			bJ3Game.areas.Add(transform2);
			Vector3 vector4 = L(transform.position);
			Quaternion localRotation = Quaternion.Inverse(root.rotation) * transform.rotation;
			Vector3 vector5 = L(transform2.position) - vector4;
			vector5.y = 0f;
			bJ3Game.seatButtons.Clear();
			Vector3[] array2 = new Vector3[3];
			List<Transform> mine = new List<Transform>();
			InteractableEventTrigger interactableEventTrigger3 = null;
			for (int num7 = 0; num7 < 3; num7++)
			{
				float num8 = ((num6 > 0f) ? num2 : num3) + num6 * num4 * ((float)num7 + 0.5f);
				float num9 = num8 - vector.x;
				for (int num10 = 0; num10 < 2; num10++)
				{
					Transform transform3 = new GameObject($"BJ3_Seat{num7 + 1}_Hand{num10 + 1}").transform;
					transform3.SetParent(root, worldPositionStays: false);
					transform3.localPosition = vector4 + new Vector3(num9 * CardSpread.Value, 0f, 0f) + vector5 * ((num10 == 1) ? SplitOffset.Value : 0f);
					transform3.localRotation = localRotation;
					transform3.localScale = Vector3.Scale(transform.lossyScale, new Vector3(1f / root.lossyScale.x, 1f / root.lossyScale.y, 1f / root.lossyScale.z));
					bJ3Game.areas.Add(transform3);
					mine.Add(transform3);
					V($"  seat {num7 + 1} hand {num10 + 1} card area local={transform3.localPosition}");
				}
				Transform transform4 = new GameObject($"BJ3_Seat{num7 + 1}_Panel").transform;
				transform4.SetParent(root, worldPositionStays: false);
				transform4.localPosition = new Vector3(num8, vector.y, vector.z);
				transform4.localScale = Vector3.one * num5;
				mine.Add(transform4);
				for (int num11 = 0; num11 < 5; num11++)
				{
					InteractableEventTrigger interactableEventTrigger4 = ((num11 == 0) ? (bJ3Game.dealButton ?? interactableEventTrigger2) : (array[Math.Min(num11 - 1, 3)] ?? interactableEventTrigger2));
					if (num11 == 4)
					{
						interactableEventTrigger4 = array[3] ?? array[0] ?? interactableEventTrigger2;
					}
					Vector3 vector6 = L(interactableEventTrigger4.transform.position);
					GameObject gameObject2 = UnityEngine.Object.Instantiate(interactableEventTrigger4.gameObject, transform4);
					gameObject2.name = $"BJ3_{Actions[num11]}_{num7 + 1}";
					gameObject2.SetActive(value: true);
					gameObject2.transform.localPosition = new Vector3(pitch * (float)(num11 - 2) * num6, (vector6.y - vector.y) / num5, (vector6.z - vector.z) / num5);
					gameObject2.transform.localRotation = Quaternion.Inverse(root.rotation) * interactableEventTrigger4.transform.rotation;
					gameObject2.transform.localScale = interactableEventTrigger4.transform.localScale;
					SetLabel(gameObject2, Actions[num11], font);
					bJ3Game.seatButtons.Add(gameObject2.GetComponent<InteractableEventTrigger>());
					V($"  seat {num7 + 1} {Actions[num11]} local={root.InverseTransformPoint(gameObject2.transform.position)}");
				}
				array2[num7] = new Vector3(num8, vector.y + LabelHeight.Value, vector.z);
			}
			InteractableEventTrigger interactableEventTrigger5 = bJ3Game.dealButton ?? interactableEventTrigger2;
			Vector3 vector7 = L(interactableEventTrigger5.transform.position);
			float x = ((num6 > 0f) ? num2 : num3) + num6 * num4 * 3.225f;
			Transform transform5 = new GameObject("BJ3_Deal_Panel").transform;
			transform5.SetParent(root, worldPositionStays: false);
			transform5.localPosition = new Vector3(x, vector.y, vector.z);
			float num12 = Mathf.Min(num4 * 0.45f * 0.95f / pitch, num5 * 2.2f);
			transform5.localScale = Vector3.one * num12;
			mine.Add(transform5);
			GameObject gameObject3 = UnityEngine.Object.Instantiate(interactableEventTrigger5.gameObject, transform5);
			gameObject3.name = "BJ3_DEAL";
			gameObject3.SetActive(value: true);
			gameObject3.transform.localPosition = new Vector3(0f, (vector7.y - vector.y) / num12, (vector7.z - vector.z) / num12);
			gameObject3.transform.localRotation = Quaternion.Inverse(root.rotation) * interactableEventTrigger5.transform.rotation;
			gameObject3.transform.localScale = interactableEventTrigger5.transform.localScale;
			SetLabel(gameObject3, "DEAL", font);
			interactableEventTrigger3 = gameObject3.GetComponent<InteractableEventTrigger>();
			V($"  DEAL button local={root.InverseTransformPoint(gameObject3.transform.position)} scale={num12:0.###}");
			foreach (InteractableEventTrigger item2 in vanillaBtns)
			{
				if (item2 != null)
				{
					V("Destroying vanilla button '" + item2.name + "'");
					UnityEngine.Object.DestroyImmediate(item2.gameObject);
				}
			}
			bJ3Game.dealButton = interactableEventTrigger3;
			Renderer[] componentsInChildren2 = gameObject.GetComponentsInChildren<Renderer>(includeInactive: true);
			foreach (Renderer renderer in componentsInChildren2)
			{
				if (!Mine(renderer.transform) && Near(renderer.bounds))
				{
					renderer.enabled = false;
					V("Hid vanilla visual '" + Path(renderer.transform, root) + "' (" + renderer.GetType().Name + ")");
				}
			}
			Collider[] componentsInChildren3 = gameObject.GetComponentsInChildren<Collider>(includeInactive: true);
			foreach (Collider collider in componentsInChildren3)
			{
				if (!Mine(collider.transform) && Near(collider.bounds))
				{
					collider.enabled = false;
					V("Disabled vanilla collider '" + Path(collider.transform, root) + "'");
				}
			}
			TMP_Text[] componentsInChildren4 = gameObject.GetComponentsInChildren<TMP_Text>(includeInactive: true);
			foreach (TMP_Text t in componentsInChildren4)
			{
				if (!Mine(t.transform) && vanillaPos.Any(delegate(Vector3 vp)
				{
					Vector3 vector8 = t.transform.position - vp;
					return Mathf.Abs(vector8.y) < 0.35f && new Vector2(vector8.x, vector8.z).magnitude < pitch * 0.75f;
				}))
				{
					t.enabled = false;
					V("Hid vanilla text '" + Path(t.transform, root) + "' = '" + t.text + "'");
				}
			}
			bJ3Game.labels.Clear();
			for (int num13 = 0; num13 < 4; num13++)
			{
				GameObject gameObject4 = new GameObject((num13 == 0) ? "BJ3_DealerLabel" : $"BJ3_Seat{num13}_Label");
				gameObject4.transform.SetParent(root, worldPositionStays: false);
				gameObject4.transform.localPosition = ((num13 == 0) ? (L(transform2.position) + Vector3.up * (LabelHeight.Value + 0.35f)) : array2[num13 - 1]);
				TextMesh textMesh = gameObject4.AddComponent<TextMesh>();
				Font font2 = LabelFont();
				if (font2 != null)
				{
					textMesh.font = font2;
					gameObject4.GetComponent<MeshRenderer>().sharedMaterial = font2.material;
				}
				textMesh.anchor = TextAnchor.LowerCenter;
				textMesh.alignment = TextAlignment.Center;
				textMesh.richText = true;
				textMesh.fontSize = 64;
				textMesh.characterSize = LabelSize.Value * ((num13 == 0) ? 1.2f : 1f) / 64f * 10f / Mathf.Max(TableScale.Value, 0.1f);
				textMesh.color = Color.white;
				textMesh.text = ((num13 == 0) ? "BLACKJACK 3-HAND" : $"SEAT {num13}\nfree");
				bJ3Game.labels.Add(textMesh);
				V($"  label {num13} local={gameObject4.transform.localPosition}");
			}
			gameObject.transform.localScale = new Vector3(1,Mathf.Clamp(TableHeight.Value,.6f,1f),1) * Mathf.Clamp(TableScale.Value, 0.5f, 3f);
			V($"Table scale {gameObject.transform.localScale.x}");
			UnityEngine.Object.DestroyImmediate(old);
			NetworkIdentity component = gameObject.GetComponent<NetworkIdentity>();
			AccessTools.Property(typeof(NetworkIdentity), "assetId").SetValue(component, AssetId);
			Prefab = gameObject;
			Log.LogInfo($"[BJ3] Prefab READY from '{template.name}', seat buttons={bJ3Game.seatButtons.Count}, deal={bJ3Game.dealButton != null}, assetId={component.assetId}");
			return true;
			T Get<T>(string n)
			{
				try
				{
					return (T)AccessTools.Field(typeof(Blackjack), n).GetValue(old);
				}
				catch
				{
					return default(T);
				}
			}
			Vector3 L(Vector3 w)
			{
				return root.InverseTransformPoint(w);
			}
			bool Mine(Transform transform6)
			{
				return mine.Any((Transform m) => transform6 == m || transform6.IsChildOf(m));
			}
			bool Near(Bounds bb)
			{
				if (Mathf.Max(bb.size.x, bb.size.z) > pitch * 1.6f)
				{
					return false;
				}
				foreach (Vector3 item3 in vanillaPos)
				{
					Vector3 vector8 = bb.center - item3;
					if (Mathf.Abs(vector8.y) < 0.35f && new Vector2(vector8.x, vector8.z).magnitude < pitch * 0.75f)
					{
						return true;
					}
				}
				return false;
			}
		}
		catch (Exception ex)
		{
			Log.LogError("[BJ3] Building prefab failed: " + ex);
			return false;
		}
	}

	internal static Font LabelFont()
	{
		if (_lf != null)
		{
			return _lf;
		}
		string[] array = new string[2] { "LegacyRuntime.ttf", "Arial.ttf" };
		foreach (string path in array)
		{
			try
			{
				_lf = Resources.GetBuiltinResource<Font>(path);
			}
			catch
			{
			}
			if (_lf != null)
			{
				break;
			}
		}
		V("Label font: " + ((_lf != null) ? _lf.name : "NONE"));
		return _lf;
	}

	private static string Path(Transform t, Transform root)
	{
		string text = t.name;
		while (t.parent != null && t.parent != root)
		{
			t = t.parent;
			text = t.name + "/" + text;
		}
		return text;
	}

	private static void SetLabel(GameObject go, string label, TMP_FontAsset font)
	{
		TMP_Text[] array = go.GetComponentsInChildren<TMP_Text>(includeInactive: true);
		if (array.Length == 0)
		{
			GameObject obj = new GameObject("BJ3_Label");
			obj.transform.SetParent(go.transform, worldPositionStays: false);
			obj.transform.localPosition = Vector3.up * 0.05f;
			TextMeshPro textMeshPro = obj.AddComponent<TextMeshPro>();
			if (font != null)
			{
				textMeshPro.font = font;
			}
			textMeshPro.fontSize = 0.6f;
			textMeshPro.alignment = TextAlignmentOptions.Center;
			array = new TMP_Text[1] { textMeshPro };
		}
		TMP_Text[] array2 = array;
		foreach (TMP_Text tMP_Text in array2)
		{
			MonoBehaviour[] components = tMP_Text.GetComponents<MonoBehaviour>();
			foreach (MonoBehaviour monoBehaviour in components)
			{
				if (monoBehaviour != null && monoBehaviour.GetType().Name.IndexOf("Locali", StringComparison.OrdinalIgnoreCase) >= 0)
				{
					UnityEngine.Object.DestroyImmediate(monoBehaviour);
				}
			}
			tMP_Text.text = label;
			tMP_Text.enableAutoSizing = true;
			tMP_Text.fontSizeMin = 0.05f;
		}
	}

	private static IEnumerator ReplaceLater(GameObject obj)
	{
		yield return null;
		yield return new WaitForSeconds(0.5f);
		if (obj == null || !NetworkServer.active)
		{
			yield break;
		}
		try
		{
			Transform transform = obj.transform;
			GameObject gameObject = UnityEngine.Object.Instantiate(Prefab, transform.parent, worldPositionStays: false);
			gameObject.name = "Blackjack3Hand_Table";
			gameObject.transform.localPosition = transform.localPosition;
			gameObject.transform.localRotation = transform.localRotation;
			gameObject.transform.localScale = Vector3.Scale(transform.localScale,new Vector3(1,Mathf.Clamp(TableHeight.Value,.6f,1f),1)) * Mathf.Clamp(TableScale.Value, 0.5f, 3f);
			gameObject.SetActive(value: true);
			_replacing = true;
			try
			{
				NetworkServer.Spawn(gameObject);
			}
			finally
			{
				_replacing = false;
			}
			Log.LogInfo(string.Format("[BJ3] Replaced '{0}' (parent '{1}') at world {2} rot {3} local {4}", obj.name, (transform.parent != null) ? transform.parent.name : "none", transform.position, transform.rotation.eulerAngles, transform.localPosition));
			try
			{
				Keypad keypad = obj.GetComponentInChildren<GameBase>(includeInactive: true)?.Keypad;
				if (keypad != null)
				{
					V("Destroying vanilla keypad '" + keypad.name + "' of replaced table");
					NetworkServer.Destroy(keypad.gameObject);
				}
			}
			catch (Exception ex)
			{
				Log.LogWarning("[BJ3] vanilla keypad destroy: " + ex.Message);
			}
			NetworkServer.Destroy(obj);
		}
		catch (Exception ex2)
		{
			_replacing = false;
			Log.LogError("[BJ3] Replace failed: " + ex2);
		}
	}

	private static bool IsVanillaBJ(GameObject g)
	{
		if (g != null)
		{
			return g.GetComponentInChildren<Blackjack>(includeInactive: true) != null;
		}
		return false;
	}
}
