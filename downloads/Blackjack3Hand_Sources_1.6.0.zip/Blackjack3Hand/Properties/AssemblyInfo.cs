using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;

[assembly: AssemblyCompany("Blackjack3Hand")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyFileVersion("1.6.0.0")]
[assembly: AssemblyInformationalVersion("1.6.0")]
[assembly: AssemblyProduct("Blackjack3Hand")]
[assembly: AssemblyTitle("Blackjack3Hand")]
[assembly: AssemblyVersion("1.6.0.0")]
