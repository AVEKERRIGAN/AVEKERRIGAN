using Mirror;using UnityEngine;
namespace PocketPhone;
public struct PhoneHeldV17:NetworkMessage {public uint owner,epoch;public bool held,sharing;public Vector3 position;public Quaternion rotation;public float scale;}
public struct PhoneVideoV17:NetworkMessage {public uint owner,epoch,sequence;public ushort index,count;public byte[] data;}
public struct PhoneAudioV17:NetworkMessage {public uint owner,epoch,sequence;public byte[] data;}
public static class PhoneWire
{
 public static void Install(){
  Writer<PhoneHeldV17>.write=(w,m)=>{w.WriteUInt(m.owner);w.WriteUInt(m.epoch);w.WriteBool(m.held);w.WriteBool(m.sharing);w.WriteVector3(m.position);w.WriteQuaternion(m.rotation);w.WriteFloat(m.scale);};
  Reader<PhoneHeldV17>.read=r=>new PhoneHeldV17{owner=r.ReadUInt(),epoch=r.ReadUInt(),held=r.ReadBool(),sharing=r.ReadBool(),position=r.ReadVector3(),rotation=r.ReadQuaternion(),scale=r.ReadFloat()};
  Writer<PhoneVideoV17>.write=(w,m)=>{w.WriteUInt(m.owner);w.WriteUInt(m.epoch);w.WriteUInt(m.sequence);w.WriteUShort(m.index);w.WriteUShort(m.count);w.WriteBytesAndSize(m.data);};
  Reader<PhoneVideoV17>.read=r=>new PhoneVideoV17{owner=r.ReadUInt(),epoch=r.ReadUInt(),sequence=r.ReadUInt(),index=r.ReadUShort(),count=r.ReadUShort(),data=r.ReadBytesAndSize()};
  Writer<PhoneAudioV17>.write=(w,m)=>{w.WriteUInt(m.owner);w.WriteUInt(m.epoch);w.WriteUInt(m.sequence);w.WriteBytesAndSize(m.data);};
  Reader<PhoneAudioV17>.read=r=>new PhoneAudioV17{owner=r.ReadUInt(),epoch=r.ReadUInt(),sequence=r.ReadUInt(),data=r.ReadBytesAndSize()};
 }
}
