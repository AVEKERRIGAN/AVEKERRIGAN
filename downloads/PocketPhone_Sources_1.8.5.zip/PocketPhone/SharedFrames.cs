using System;
namespace PocketPhone;
public sealed class SharedFrames
{
    public const int Chunk=900,Maximum=96*1024,MaximumParts=(Maximum+Chunk-1)/Chunk;
    uint sequence;bool seen;byte[][] parts;int received,bytes;float begun;
    public static bool SafeJpeg(byte[] data)
    {
        return data!=null&&data.Length<=Maximum&&TryJpegSize(data,out int width,out int height)&&width>=16&&height>=16&&width<=1024&&height<=1536&&width*height<=1024*1024;
    }
    public static bool TryJpegSize(byte[] data,out int width,out int height)
    {
        width=height=0;if(data==null||data.Length<12||data[0]!=255||data[1]!=216)return false;
        int i=2;
        while(i+3<data.Length){if(data[i++]!=255)return false;while(i<data.Length&&data[i]==255)i++;if(i>=data.Length)return false;int marker=data[i++];if(marker==217||marker==218)return false;if(marker==0x01||(marker>=0xd0&&marker<=0xd7))continue;if(i+1>=data.Length)return false;int n=data[i]*256+data[i+1];if(n<2||i+n>data.Length)return false;
            if(marker>=0xc0&&marker<=0xc3){if(n<7)return false;height=data[i+3]*256+data[i+4];width=data[i+5]*256+data[i+6];return width>0&&height>0;}
            i+=n;
        }
        return false;
    }
    public void Reset(){seen=false;parts=null;received=bytes=0;}
    public byte[] Accept(uint seq,int index,int count,byte[] data,float now)
    {
        if(count<1||count>MaximumParts||index<0||index>=count||data==null||data.Length<1||data.Length>Chunk)return null;
        if(!seen||(int)(seq-sequence)>0){seen=true;sequence=seq;parts=new byte[count][];received=bytes=0;begun=now;}
        if(seq!=sequence||parts==null||parts.Length!=count||now-begun>1||parts[index]!=null)return null;
        if(bytes+data.Length>Maximum){parts=null;return null;}
        parts[index]=data;bytes+=data.Length;received++;
        if(received!=count)return null;
        var frame=new byte[bytes];int offset=0;foreach(var p in parts){Buffer.BlockCopy(p,0,frame,offset,p.Length);offset+=p.Length;}parts=null;return frame;
    }
}
