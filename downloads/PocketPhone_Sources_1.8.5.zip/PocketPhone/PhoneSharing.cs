using System;using System.Collections.Generic;using System.Linq;using Mirror;using UnityEngine;
namespace PocketPhone;
public sealed class PhoneSharing:MonoBehaviour
{
 sealed class Peer {public PhoneHeldV17 state;public float last,window;public int audio,frames;public uint frame;public bool hasFrame;}
 Plugin plugin;bool serverReady,clientReady,wasHeld,publicVideo;uint epoch,videoSequence,audioSequence;float nextState,nextVideo;
 readonly Dictionary<NetworkConnectionToClient,Peer> peers=new();readonly Dictionary<uint,RemotePhone> phones=new();
 public void Initialize(Plugin owner){plugin=owner;PhoneWire.Install();}
 public void Suspend(){if(NetworkClient.active&&NetworkClient.isConnected&&NetworkClient.localPlayer!=null)NetworkClient.Send(new PhoneHeldV17{epoch=epoch,held=false,sharing=false});wasHeld=false;publicVideo=false;ClearPhones();}
 static bool Finite(float n)=>!float.IsNaN(n)&&!float.IsInfinity(n);
 static bool ValidPose(PhoneHeldV17 s,Vector3 player)=>Finite(s.position.x)&&Finite(s.position.y)&&Finite(s.position.z)&&Finite(s.rotation.x)&&Finite(s.rotation.y)&&Finite(s.rotation.z)&&Finite(s.rotation.w)&&(s.position-player).sqrMagnitude<16&&Finite(s.scale)&&s.scale>=.15f&&s.scale<=5;
 void Update(){
  if(plugin==null)return;
  if(NetworkServer.active&&!serverReady){NetworkServer.RegisterHandler<PhoneHeldV17>(Held,true);NetworkServer.RegisterHandler<PhoneVideoV17>(Video,true);NetworkServer.RegisterHandler<PhoneAudioV17>(Audio,true);serverReady=true;}
  if(!NetworkServer.active){serverReady=false;peers.Clear();}
  bool connected=NetworkClient.active&&NetworkClient.isConnected&&NetworkClient.localPlayer!=null;
  if(connected&&!clientReady){NetworkClient.RegisterHandler<PhoneHeldV17>(Receive,true);NetworkClient.RegisterHandler<PhoneVideoV17>(ReceiveVideo,true);NetworkClient.RegisterHandler<PhoneAudioV17>(ReceiveAudio,true);clientReady=true;}
  if(!connected){clientReady=false;wasHeld=false;ClearPhones();return;}
  float now=Time.unscaledTime;bool held=plugin.SharedHeld&&plugin.ShareEnabled;
  if(held!=wasHeld){wasHeld=held;if(held){epoch++;videoSequence=audioSequence=0;publicVideo=false;}nextState=0;}
  if(now>=nextState){nextState=now+.15f;var player=NetworkClient.localPlayer;var controller=player.GetComponent<PlayerController>();var head=controller!=null&&controller.head!=null?controller.head.transform:plugin.SharedView!=null?plugin.SharedView.transform:player.transform;var eye=head.position;var pose=new PhoneWorldPose(eye.x,eye.y,eye.z,head.eulerAngles.y);NetworkClient.Send(new PhoneHeldV17{epoch=epoch,held=held,sharing=held&&publicVideo,position=new Vector3(pose.X,pose.Y,pose.Z),rotation=Quaternion.Euler(8,pose.Yaw,-4),scale=PhoneWorldPose.Scale});}
  if(held){
   var frame=plugin.SharedBrowser.SharedFrame();if(frame!=null){bool old=publicVideo;publicVideo=frame.Length>0;if(old!=publicVideo)nextState=0;if(publicVideo&&now>=nextVideo){nextVideo=now+.125f;videoSequence++;int count=(frame.Length+SharedFrames.Chunk-1)/SharedFrames.Chunk;for(int i=0;i<count;i++){int n=Math.Min(SharedFrames.Chunk,frame.Length-i*SharedFrames.Chunk);var data=new byte[n];Buffer.BlockCopy(frame,i*SharedFrames.Chunk,data,0,n);NetworkClient.Send(new PhoneVideoV17{epoch=epoch,sequence=videoSequence,index=(ushort)i,count=(ushort)count,data=data},Channels.Unreliable);}}}
   for(int i=0;i<8;i++){var pcm=plugin.SharedBrowser.Audio();if(pcm==null)break;if(publicVideo)NetworkClient.Send(new PhoneAudioV17{epoch=epoch,sequence=++audioSequence,data=pcm},Channels.Unreliable);}
  }
  foreach(var pair in phones.ToArray()){if(pair.Value==null||!NetworkClient.spawned.ContainsKey(pair.Key)||now-pair.Value.Received>3){if(pair.Value!=null)Destroy(pair.Value.gameObject);phones.Remove(pair.Key);}else pair.Value.Tick(plugin.SharedVolume,plugin.SharedDistance);}
  if(NetworkServer.active)foreach(var pair in peers.ToArray())if(pair.Key==null||!pair.Key.isAuthenticated||pair.Key.identity==null||now-pair.Value.last>3){if(pair.Value.state.held){var gone=pair.Value.state;gone.held=gone.sharing=false;Broadcast(gone,pair.Key);}peers.Remove(pair.Key);}
 }
 Peer Get(NetworkConnectionToClient conn){if(!peers.TryGetValue(conn,out var p)){p=new Peer();peers[conn]=p;}return p;}
 void Held(NetworkConnectionToClient conn,PhoneHeldV17 message){if(conn.identity==null)return;var peer=Get(conn);if(message.held&&!ValidPose(message,conn.identity.transform.position))return;message.owner=conn.identity.netId;peer.state=message;peer.last=Time.unscaledTime;Broadcast(message,conn);}
 bool Accept(NetworkConnectionToClient conn,uint value,out Peer peer){peer=null;if(conn.identity==null||!peers.TryGetValue(conn,out peer)||!peer.state.held||!peer.state.sharing||peer.state.epoch!=value)return false;float now=Time.unscaledTime;if(now-peer.window>=1){peer.window=now;peer.audio=peer.frames=0;}return true;}
 void Video(NetworkConnectionToClient conn,PhoneVideoV17 m){if(!Accept(conn,m.epoch,out var p)||m.data==null||m.data.Length<1||m.data.Length>SharedFrames.Chunk||m.count<1||m.count>SharedFrames.MaximumParts||m.index>=m.count)return;if(!p.hasFrame||(int)(m.sequence-p.frame)>0){if(++p.frames>10)return;p.hasFrame=true;p.frame=m.sequence;}if(m.sequence!=p.frame)return;m.owner=conn.identity.netId;Broadcast(m,conn,Channels.Unreliable);}
 void Audio(NetworkConnectionToClient conn,PhoneAudioV17 m){if(!Accept(conn,m.epoch,out var p)||m.data==null||m.data.Length!=960||++p.audio>65)return;m.owner=conn.identity.netId;Broadcast(m,conn,Channels.Unreliable);}
 void Broadcast<T>(T message,NetworkConnectionToClient sender,int channel=Channels.Reliable)where T:struct,NetworkMessage{foreach(var receiver in peers.Keys.ToArray())if(receiver!=sender&&NetworkServer.connections.TryGetValue(receiver.connectionId,out var current)&&ReferenceEquals(current,receiver)&&receiver.identity!=null&&receiver.isAuthenticated&&(sender==null||sender.identity==null||(receiver.identity.transform.position-sender.identity.transform.position).sqrMagnitude<=24*24))receiver.Send(message,channel);}
 void Receive(PhoneHeldV17 s){if(!plugin.ApplicationActive)return;if(NetworkClient.localPlayer==null||s.owner==NetworkClient.localPlayer.netId)return;if(!s.held){if(phones.TryGetValue(s.owner,out var removed))Destroy(removed.gameObject);phones.Remove(s.owner);return;}if(!phones.TryGetValue(s.owner,out var phone)||phone==null){phone=new GameObject("FriendPhone_"+s.owner).AddComponent<RemotePhone>();phone.Initialize(s,plugin.SharedView);phones[s.owner]=phone;}else phone.Apply(s);}
 void ReceiveVideo(PhoneVideoV17 m){if(!plugin.ApplicationActive)return;if(phones.TryGetValue(m.owner,out var p))p.Video(m);}
 void ReceiveAudio(PhoneAudioV17 m){if(!plugin.ApplicationActive)return;if(phones.TryGetValue(m.owner,out var p))p.Audio(m,plugin.SharedVolume,plugin.SharedDistance);}
 void ClearPhones(){foreach(var phone in phones.Values)if(phone!=null)Destroy(phone.gameObject);phones.Clear();}
 void OnDestroy(){if(clientReady&&NetworkClient.active){NetworkClient.UnregisterHandler<PhoneHeldV17>();NetworkClient.UnregisterHandler<PhoneVideoV17>();NetworkClient.UnregisterHandler<PhoneAudioV17>();}if(serverReady&&NetworkServer.active){NetworkServer.UnregisterHandler<PhoneHeldV17>();NetworkServer.UnregisterHandler<PhoneVideoV17>();NetworkServer.UnregisterHandler<PhoneAudioV17>();}ClearPhones();peers.Clear();}
}
