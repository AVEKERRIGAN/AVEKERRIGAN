using System;
namespace PocketPhone;
public sealed class ScrollInput
{
    float pending;double next,updated;int x,y;
    public void Reset(){pending=0;next=0;updated=0;}
    public void Add(int px,int py,float delta,double now)
    {
        if(float.IsNaN(delta)||float.IsInfinity(delta))return;
        if(now-updated>.2||Math.Abs(px-x)>48||Math.Abs(py-y)>48)pending=0;
        x=px;y=py;updated=now;pending=Math.Max(-900,Math.Min(900,pending+delta));
    }
    public bool Take(double now,out int px,out int py,out int delta)
    {
        px=x;py=y;delta=0;
        if(now-updated>.2){pending=0;return false;}
        if(now<next||Math.Abs(pending)<1)return false;
        delta=(int)pending;pending-=delta;next=now+.08;return true;
    }
}
