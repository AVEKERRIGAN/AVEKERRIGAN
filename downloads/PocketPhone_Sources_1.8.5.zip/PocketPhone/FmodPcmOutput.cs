using System;
using System.Runtime.InteropServices;
namespace PocketPhone;
// The game routes sound through FMOD. A Unity AudioSource can have decoded PCM
// and still remain inaudible when Unity's own audio engine is disabled.
public sealed class FmodPcmOutput : IDisposable
{
    FMOD.Sound sound;FMOD.Channel channel;
    readonly FMOD.SOUND_PCMREAD_CALLBACK read;
    readonly AudioQueue samples;
    long readSamples;public long ReadSamples=>System.Threading.Interlocked.Read(ref readSamples);
    byte[] bytes=Array.Empty<byte>();float[] floats=Array.Empty<float>();
    public FmodPcmOutput(AudioQueue queue,bool spatial,float volume,float distance)
    {
        samples=queue;read=Read;
        var info=new FMOD.CREATESOUNDEXINFO{cbsize=Marshal.SizeOf(typeof(FMOD.CREATESOUNDEXINFO)),numchannels=1,defaultfrequency=24000,format=FMOD.SOUND_FORMAT.PCM16,length=48000,decodebuffersize=1200,pcmreadcallback=read};
        var mode=FMOD.MODE.OPENUSER|FMOD.MODE.CREATESTREAM|FMOD.MODE.LOOP_NORMAL|(spatial?FMOD.MODE._3D|FMOD.MODE._3D_LINEARROLLOFF:FMOD.MODE._2D);
        Check(FMODUnity.RuntimeManager.CoreSystem.createSound("",mode,ref info,out sound),"create stream");
        try {Check(FMODUnity.RuntimeManager.CoreSystem.playSound(sound,default(FMOD.ChannelGroup),true,out channel),"play stream");channel.setVolume(Math.Max(0,Math.Min(1,volume)));channel.set3DMinMaxDistance(1.2f,Math.Max(3,distance));Check(channel.setPaused(false),"start stream");}
        catch {sound.release();throw;}
    }
    static void Check(FMOD.RESULT result,string stage){if(result!=FMOD.RESULT.OK)throw new InvalidOperationException("FMOD "+stage+": "+result);}
    FMOD.RESULT Read(IntPtr pointer,IntPtr data,uint count)
    {
        try {
            if(count>1024*1024)return FMOD.RESULT.ERR_INVALID_PARAM;
            int length=(int)count,frames=length/2;
            if(bytes.Length!=length)bytes=new byte[length];if(floats.Length!=frames)floats=new float[frames];
            samples.Read(floats);
            Pcm16.Encode(floats,bytes);
            System.Threading.Interlocked.Add(ref readSamples,frames);
            Marshal.Copy(bytes,0,data,length);return FMOD.RESULT.OK;
        }catch{return FMOD.RESULT.ERR_INTERNAL;}
    }
    public void Update(UnityEngine.Vector3 position,float volume,float distance)
    {var p=new FMOD.VECTOR{x=position.x,y=position.y,z=position.z};var v=default(FMOD.VECTOR);channel.set3DAttributes(ref p,ref v);channel.setVolume(Math.Max(0,Math.Min(1,volume)));channel.set3DMinMaxDistance(1.2f,Math.Max(3,distance));}
    public void Dispose(){channel.stop();if(sound.hasHandle()){sound.release();sound.clearHandle();}GC.KeepAlive(read);}
}
