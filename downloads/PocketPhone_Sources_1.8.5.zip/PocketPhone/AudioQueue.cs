using System;
using System.Collections.Concurrent;
using System.Threading;

namespace PocketPhone;

public sealed class AudioQueue
{
    sealed class State { public readonly ConcurrentQueue<byte[]> Packets = new(); public int Count; public bool Buffered; }
    State _state = new(), _reading;
    byte[] _packet;
    int _offset;
    public void Reset() => Interlocked.Exchange(ref _state, new State());
    public void Push(byte[] pcm)
    {
        if (pcm == null || pcm.Length == 0 || (pcm.Length & 1) != 0 || pcm.Length > 960) return;
        var state = Volatile.Read(ref _state);
        if (Interlocked.Increment(ref state.Count) > 50) { Interlocked.Decrement(ref state.Count); return; }
        state.Packets.Enqueue(pcm);
    }
    public void Read(float[] output)
    {
        var state = Volatile.Read(ref _state);
        if (state != _reading) { _reading = state; _packet = null; _offset = 0; }
        if (!state.Buffered)
        {
            if (Volatile.Read(ref state.Count) < 8) { Array.Clear(output, 0, output.Length); return; }
            state.Buffered = true;
        }
        for (int i = 0; i < output.Length; i++)
        {
            if (_packet == null || _offset >= _packet.Length)
            {
                if (!state.Packets.TryDequeue(out _packet)) { state.Buffered = false; Array.Clear(output, i, output.Length - i); return; }
                Interlocked.Decrement(ref state.Count); _offset = 0;
            }
            output[i] = (short)(_packet[_offset] | _packet[_offset + 1] << 8) / 32768f; _offset += 2;
        }
    }
}
