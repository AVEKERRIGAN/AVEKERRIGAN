#nullable enable
using System.Text.Json;
namespace PhoneBrowser;
// One reader drains stdin; a bounded inbox merges consecutive wheel bursts.
public sealed class CommandInbox
{
    readonly LinkedList<JsonElement> commands=new();readonly SemaphoreSlim changed=new(0,1);readonly object sync=new();
    bool done;public const int Capacity=64;
    public int Count{get{lock(sync)return commands.Count;}}
    public bool Push(JsonElement command)
    {
        lock(sync)
        {
            if(done)return false;
            string? type=command.TryGetProperty("type",out var t)?t.GetString():null;
            if(type=="close"){commands.Clear();commands.AddLast(command.Clone());done=true;}
            else
            {
                if(type=="scroll"&&commands.Last is {} last&&last.Value.GetProperty("type").GetString()=="scroll"&&
                    Math.Abs(last.Value.GetProperty("x").GetInt32()-command.GetProperty("x").GetInt32())<48&&Math.Abs(last.Value.GetProperty("y").GetInt32()-command.GetProperty("y").GetInt32())<48)
                    commands.RemoveLast();
                if(commands.Count>=Capacity)return false;
                commands.AddLast(command.Clone());
            }
            Signal();return true;
        }
    }
    public void Complete(){lock(sync){done=true;Signal();}}
    void Signal(){if(changed.CurrentCount==0)changed.Release();}
    public async Task<JsonElement?> Next(CancellationToken cancellation)
    {
        while(true)
        {
            lock(sync){if(commands.First is {} first){commands.RemoveFirst();return first.Value;}if(done)return null;}
            await changed.WaitAsync(cancellation);
        }
    }
    public async Task Read(TextReader input,CancellationToken cancellation,Action overflow)
    {
        try
        {
            while(!cancellation.IsCancellationRequested)
            {
                string? line=await input.ReadLineAsync(cancellation);if(line==null)break;if(line.Length>65536)continue;
                try{using var document=JsonDocument.Parse(line);if(!Push(document.RootElement))overflow();if(document.RootElement.TryGetProperty("type",out var t)&&t.GetString()=="close")break;}catch(JsonException){}catch(InvalidOperationException){}
            }
        }
        catch(OperationCanceledException){}finally{Complete();}
    }
}
