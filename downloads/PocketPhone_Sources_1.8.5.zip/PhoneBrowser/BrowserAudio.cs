#nullable enable
using System.Runtime.Versioning;
namespace PhoneBrowser;
[SupportedOSPlatform("windows")]
public sealed class BrowserAudio : IDisposable
{
    readonly ProcessLoopback capture;readonly PhoneAudioConvert convert=new();
    public event Action<byte[]>? Pcm;
    public BrowserAudio(int pid)
    {
        capture=new ProcessLoopback(pid,true);convert.Pcm+=packet=>Pcm?.Invoke(packet);
        capture.Data+=(bytes,count)=>convert.Push(bytes,count);
    }
    public void Start()=>capture.Start();
    public void Dispose()=>capture.Dispose();
}
