#nullable enable
namespace PhoneBrowser;
public sealed class PhoneAudioConvert
{
 readonly byte[] packet=new byte[960];int used,previous;bool pending;
 public event System.Action<byte[]>? Pcm;
 public void Push(byte[] source,int count)
 {
  if(source==null||count<0||count>source.Length||count%4!=0)throw new System.ArgumentException("Stereo PCM block");
  for(int i=0;i<count;i+=4){int sum=(short)(source[i]|source[i+1]<<8)+(short)(source[i+2]|source[i+3]<<8);
   if(!pending){previous=sum;pending=true;continue;}
   short sample=(short)((previous+sum)/4);pending=false;packet[used++]=(byte)sample;packet[used++]=(byte)(sample>>8);
   if(used==packet.Length){used=0;Pcm?.Invoke((byte[])packet.Clone());}
  }
 }
}
