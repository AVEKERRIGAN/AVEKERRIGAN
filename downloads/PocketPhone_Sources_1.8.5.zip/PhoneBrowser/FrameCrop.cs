using PocketPhone;
using SkiaSharp;
namespace PhoneBrowser;
// Crop a copy of the existing full-frame stream. CDP clip screenshots resize
// Chromium's compositor surface and can leak cropped/enlarged frames into it.
public static class FrameCrop
{
    public static string Crop(string jpeg,double x,double y,double width,double height)
    {
        if(string.IsNullOrEmpty(jpeg)||jpeg.Length>1500000||!double.IsFinite(x+y+width+height)||width<1||height<1)return "";
        using var image=SKBitmap.Decode(Convert.FromBase64String(jpeg));
        if(image==null||image.Width>1024||image.Height>1536)return "";
        double sx=(double)image.Width/PhoneProtocol.Width,sy=(double)image.Height/PhoneProtocol.Height;
        int left=Math.Clamp((int)Math.Floor(x*sx),0,image.Width-1),top=Math.Clamp((int)Math.Floor(y*sy),0,image.Height-1);
        int right=Math.Clamp((int)Math.Ceiling((x+width)*sx),left+1,image.Width),bottom=Math.Clamp((int)Math.Ceiling((y+height)*sy),top+1,image.Height);
        using var crop=new SKBitmap();if(!image.ExtractSubset(crop,new SKRectI(left,top,right,bottom)))return "";
        using var result=SKImage.FromBitmap(crop);using var output=result.Encode(SKEncodedImageFormat.Jpeg,55);
        return output!=null&&output.Size<=96*1024?Convert.ToBase64String(output.ToArray()):"";
    }
}
