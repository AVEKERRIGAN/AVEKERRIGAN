#nullable enable
using Microsoft.Win32;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Text;

namespace PhoneBrowser;
public sealed record BrowserChoice(string Family,string Name,string Executable);
public static class BrowserFinder
{
    static readonly string[] Priority={"chrome","edge","opera","operagx","yandex","brave","vivaldi","chromium"};
    public static BrowserChoice Choose(string preference,string explicitPath,string? defaultPath,IEnumerable<string> installed,Func<string,bool> exists)
    {
        if(!string.IsNullOrWhiteSpace(explicitPath))
            return Identify(explicitPath,exists)??throw new IOException("Путь Browser.ExecutablePath не указывает на поддерживаемый браузер Chromium.");
        preference=preference.Trim().ToLowerInvariant();if(preference=="default")preference="auto";
        var choices=installed.Select(p=>Identify(p,exists)).Where(c=>c!=null).Cast<BrowserChoice>().ToList();
        var system=Identify(defaultPath,exists);
        if(system!=null)choices.Insert(0,system);
        if(preference=="auto")
        {
            if(system!=null)return system;
            foreach(string family in Priority)if(choices.FirstOrDefault(c=>c.Family==family) is {} c)return c;
            throw new FileNotFoundException("Не найден браузер Chromium. Поддерживаются Chrome, Edge, Opera/GX, Яндекс, Brave, Vivaldi и Chromium.");
        }
        if(!Priority.Contains(preference))throw new IOException("Browser.Selection: auto, chrome, edge, opera, operagx, yandex, brave, vivaldi или chromium.");
        return choices.FirstOrDefault(c=>c.Family==preference)??throw new FileNotFoundException("Выбранный браузер не найден: "+preference+". Укажите Browser.ExecutablePath или auto.");
    }
    public static BrowserChoice? Identify(string? path,Func<string,bool> exists)
    {
        if(string.IsNullOrWhiteSpace(path)||!exists(path))return null;
        string normalized=path.Replace('\\','/').ToLowerInvariant();string exe=normalized.Split('/').Last();
        return exe switch {
            "chrome.exe"=>normalized.Contains("/chromium/")?new("chromium","Chromium",path):new("chrome","Google Chrome",path),
            "msedge.exe"=>new("edge","Microsoft Edge",path),
            "opera.exe"=>normalized.Contains("opera gx")||normalized.Contains("operagx")?new("operagx","Opera GX",path):new("opera","Opera",path),
            "browser.exe" when normalized.Contains("yandex")=>new("yandex","Яндекс Браузер",path),
            "brave.exe"=>new("brave","Brave",path),
            "vivaldi.exe"=>new("vivaldi","Vivaldi",path),
            "chromium.exe"=>new("chromium","Chromium",path),_=>null};
    }
    public static string? CommandExecutable(string? command)
    {
        if(string.IsNullOrWhiteSpace(command))return null;
        command=Environment.ExpandEnvironmentVariables(command.Trim());
        if(command[0]=='"'){int end=command.IndexOf('"',1);return end>1?command.Substring(1,end-1):null;}
        int extension=command.IndexOf(".exe",StringComparison.OrdinalIgnoreCase);
        return extension>=0?command.Substring(0,extension+4):null;
    }
    public static string ResolveLauncher(string path)
    {
        path=Environment.ExpandEnvironmentVariables(path);
        if(!Path.GetFileName(path).Equals("launcher.exe",StringComparison.OrdinalIgnoreCase))return path;
        string? root=Path.GetDirectoryName(path);if(root==null)return path;
        try
        {
            string direct=Path.Combine(root,"opera.exe");if(File.Exists(direct))return direct;
            foreach(string dir in Directory.EnumerateDirectories(root).Where(d=>Version.TryParse(Path.GetFileName(d),out _)).OrderByDescending(d=>Version.Parse(Path.GetFileName(d))))
            {string executable=Path.Combine(dir,"opera.exe");if(File.Exists(executable))return executable;}
        }
        catch(IOException){}catch(UnauthorizedAccessException){}
        return path;
    }
    public static BrowserChoice Find(string preference,string explicitPath,out bool fallback)
    {
        if(!OperatingSystem.IsWindows())throw new PlatformNotSupportedException("Телефон рассчитан на Windows.");
        string? system=DefaultExecutable();if(system!=null)system=ResolveLauncher(system);
        fallback=string.IsNullOrWhiteSpace(explicitPath)&&(preference is "auto" or "default")&&Identify(system,File.Exists)==null;
        return Choose(preference,string.IsNullOrWhiteSpace(explicitPath)?"":ResolveLauncher(explicitPath),system,Installed().Select(ResolveLauncher),File.Exists);
    }
    [SupportedOSPlatform("windows")]
    static IEnumerable<string> Installed()
    {
        string[] relative={"Google/Chrome/Application/chrome.exe","Microsoft/Edge/Application/msedge.exe","Yandex/YandexBrowser/Application/browser.exe",
            "Programs/Opera/launcher.exe","Programs/Opera GX/launcher.exe","Opera/launcher.exe","Opera GX/launcher.exe",
            "BraveSoftware/Brave-Browser/Application/brave.exe","Vivaldi/Application/vivaldi.exe","Chromium/Application/chrome.exe"};
        foreach(var root in new[]{Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData)})
            if(!string.IsNullOrEmpty(root))foreach(var suffix in relative)yield return Path.Combine(root,suffix);
        var paths=new List<string>();
        foreach(var hive in new[]{RegistryHive.CurrentUser,RegistryHive.LocalMachine})foreach(var view in new[]{RegistryView.Registry64,RegistryView.Registry32})
        {
            try
            {
                using var registry=RegistryKey.OpenBaseKey(hive,view);
                foreach(var exe in new[]{"chrome.exe","msedge.exe","opera.exe","browser.exe","brave.exe","vivaldi.exe","chromium.exe","launcher.exe"})
                {using var key=registry.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\App Paths\"+exe);if(key?.GetValue("") is string path)paths.Add(path.Trim('"'));}
                using var clients=registry.OpenSubKey(@"Software\Clients\StartMenuInternet");
                if(clients!=null)foreach(var client in clients.GetSubKeyNames())
                {using var command=clients.OpenSubKey(client+@"\shell\open\command");var path=CommandExecutable(command?.GetValue("") as string);if(path!=null)paths.Add(path);}
            }
            catch(System.Security.SecurityException){}catch(UnauthorizedAccessException){}catch(IOException){}
        }
        foreach(string path in paths)yield return path;
    }
    [SupportedOSPlatform("windows")]
    static string? DefaultExecutable()
    {
        // Windows resolves the current HTTPS association, including per-user choices.
        uint size=32768;var value=new StringBuilder((int)size);
        if(AssocQueryString(0x1000,2,"https",null,value,ref size)==0&&!string.IsNullOrWhiteSpace(value.ToString()))return value.ToString();
        try
        {
            using var choice=Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\Shell\Associations\UrlAssociations\https\UserChoice");
            string? id=choice?.GetValue("ProgId") as string;
            if(id!=null){using var command=Registry.ClassesRoot.OpenSubKey(id+@"\shell\open\command");return CommandExecutable(command?.GetValue("") as string);}
        }
        catch(System.Security.SecurityException){}catch(UnauthorizedAccessException){}catch(IOException){}
        return null;
    }
    [DllImport("shlwapi.dll",CharSet=CharSet.Unicode,EntryPoint="AssocQueryStringW")]
    static extern int AssocQueryString(uint flags,uint str,string association,string? extra,StringBuilder result,ref uint size);
}
