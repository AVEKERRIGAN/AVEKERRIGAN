(() => {
  if (window.__pocketPhoneFeed) return;
  let anchorX = window.scrollX, anchorY = window.scrollY;
  let navigationUntil = performance.now() + 1200, lastAdvance = -1000, correcting = false;
  let syntheticArrowUntil = 0, wheelUntil = 0, wheelBefore = '', wheelX=0, wheelY=0;
  let currentPlayer = null, currentActions = null, layoutPending = false, focusedVideo = null;
  let mediaLayers = [], posterLayers = [], stageParents = [], backdrops = [];
  const videoSignature=()=>[...document.querySelectorAll('video')].map(v=>(v.currentSrc||'')+'~'+(v.src||'')+'~'+(v.closest('article')?.textContent||'')).join('|')+'|'+location.href;
  const feed = () => {
    const host = location.hostname.toLowerCase(), path = location.pathname;
    return ((host === 'tiktok.com' || host.endsWith('.tiktok.com')) &&
      (path === '/' || /^\/(foryou|following|explore|search)(\/|$)/.test(path) || /^\/@[^/]+\/video\//.test(path))) ||
      ((host === 'instagram.com' || host.endsWith('.instagram.com')) && /^\/reels?(\/|$)/.test(path));
  };
  const visible = e => {
    const r = e.getBoundingClientRect(),s=getComputedStyle(e);
    if(s.display==='none'||s.visibility==='hidden'||(s.opacity==='0'&&!e.matches('video.pp-source-video'))||e.getAttribute('aria-hidden')==='true')return false;
    return r.width > 1 && r.height > 1 && r.bottom > 0 && r.top < innerHeight && r.right > 0 && r.left < innerWidth;
  };
  const editable = e => e && (e.matches('input,textarea,[contenteditable="true"]') || e.closest('[contenteditable="true"]'));
  const scrollable = e => {
    const s = getComputedStyle(e);
    return e !== document.body && e !== document.documentElement &&
      /auto|scroll/.test(s.overflowY) && e.scrollHeight > e.clientHeight + 2;
  };
  const comment = e => {
    for (let p = e; p && p !== document.body; p = p.parentElement) {
      const marker = (p.getAttribute('data-e2e') || '') + ' ' + (p.getAttribute('aria-label') || '') + ' ' + p.className;
      if ((p.getAttribute('role') === 'dialog' && !p.querySelector('video')) || /comment|комментар/i.test(marker)) return true;
    }
    return false;
  };
  const label = e => e.getAttribute('aria-label') || e.getAttribute('title') || e.querySelector('svg[aria-label]')?.getAttribute('aria-label') || e.textContent.trim();
  const nextName = /next video|next reel|следующ.{0,12}(видео|ролик)|^next$|^далее$|^следующ(ее|ий)$/i;
  const previousName = /previous video|previous reel|предыдущ.{0,12}(видео|ролик)|^previous$|^назад$|^предыдущ(ее|ий)$/i;
  const nextSelector = '[data-e2e="arrow-right"],[data-e2e="arrow-down"],[data-e2e="video-switch-next"]';
  const previousSelector = '[data-e2e="arrow-left"],[data-e2e="arrow-up"],[data-e2e="video-switch-prev"]';
  function beforeClick(x,y) {
    if (!feed()) return;
    if(surface&&surface.style.display!=='none'&&sourceVideo){
      const target=document.elementFromPoint(x,y),r=surface.getBoundingClientRect();
      if(!comment(target)&&!target?.closest('button,[role="button"],a,input,textarea')&&x>=r.left&&x<r.right&&y>=r.top&&y<r.bottom){userPaused=!sourceVideo.paused;if(userPaused)sourceVideo.pause();else sourceVideo.play().catch(()=>{});return {handled:true};}
    }
    const element=document.elementFromPoint(x,y), button=element?.closest('button,[role="button"],'+nextSelector+','+previousSelector);
    if (button && !comment(button) && (button.matches(nextSelector+','+previousSelector) || nextName.test(label(button)) || previousName.test(label(button)))) {
      const now=performance.now();lastAdvance=now;navigationUntil=now+650;
    }
  }
  // Stop scroll chaining/zoom; leave the sites' own feed and comment containers intact.
  const style = document.createElement('style');style.id = 'pocket-phone-viewport';
  style.textContent = `
html.pp-feed,html.pp-feed body{color-scheme:dark;background:#08090d!important;color:#f4f4f5!important}
.pp-feed .pp-native-main{width:var(--pp-main-width)!important;max-width:var(--pp-main-width)!important;min-width:0!important;box-sizing:border-box!important}
.pp-feed video.pp-source-video{opacity:0!important}
#pocket-phone-video-surface{position:fixed!important;pointer-events:none!important;z-index:10!important;display:block;background:#000;border:0;border-radius:0;transform:none!important;margin:0!important;padding:0!important}
`;
  function activeVideo(){
    const area=e=>{const r=e.getBoundingClientRect();return Math.max(0,Math.min(innerWidth,r.right)-Math.max(0,r.left))*Math.max(0,Math.min(innerHeight,r.bottom)-Math.max(0,r.top));};
    const videos=[...document.querySelectorAll('video')].filter(v=>!v.closest('[class*="Background"],[class*="Blur"],[data-e2e="video-background"]'));
    if(focusedVideo?.isConnected&&!focusedVideo.paused&&videos.includes(focusedVideo))return focusedVideo;
    const playing=videos.filter(v=>!v.paused&&!v.ended&&v.readyState>1);
    if(playing.length===1)return playing[0];
    const active=videos.filter(visible).sort((a,b)=>area(b)-area(a))[0];
    if(active)return active;
    // React may replace a layer before its inner wrapper has acquired a height.
    // The outer visible stage still identifies the feed video during that commit.
    if(currentPlayer?.isConnected&&visible(currentPlayer))return currentPlayer.querySelector('video');
    return videos.find(v=>{for(let e=v.parentElement;e&&e!==document.body;e=e.parentElement){if(e.matches('[class*="DivPlayerContainer"],[class*="DivVideoContainer"],[class*="DivVideoWrapper"]')&&visible(e))return true;}return false;}) || videos.find(v=>v.currentSrc||v.src||v.readyState>0) || videos[0];
  }
  let surface=null,sourceVideo=null,lastTime=-1,lastPaint=0,lastLayout=0,lastPlay=0,userPaused=false,sourceKey='';
  const blocked=()=>[...document.querySelectorAll('[role="dialog"],[aria-modal="true"],input[type="password"],iframe[src*="captcha"],[data-e2e="comment-list"],[class*="DivCommentListContainer"]')].some(visible);
  function bounds(){
    let left=8,right=innerWidth-68,top=8;
    const side=[...document.querySelectorAll('nav,aside,[role="navigation"],[data-e2e="side-nav"],[data-e2e="side-nav-container"],[class*="SideNav"],[class*="SideBar"]')].find(e=>{const r=e.getBoundingClientRect();return visible(e)&&r.left<16&&r.width>24&&r.width<innerWidth*.4&&r.height>innerHeight*.4;});
    if(side)left=Math.max(left,side.getBoundingClientRect().right+8);
    const main=document.querySelector('main,[role="main"],#main-content,[class*="DivMainContainer"],[class*="DivMainContent"]');
    if(main){const x=Math.max(0,main.getBoundingClientRect().left);main.classList.add('pp-native-main');main.style.setProperty('--pp-main-width',Math.max(100,innerWidth-x)+'px');left=Math.max(left,x);}
    const action=[...document.querySelectorAll('[data-e2e="like-icon"],[data-e2e="browse-like"],[data-e2e="like-count"],button[aria-label*="like" i]')].find(e=>visible(e)&&e.getBoundingClientRect().left>innerWidth*.6);
    if(action)right=Math.min(right,action.getBoundingClientRect().left-10);
    const header=[...document.querySelectorAll('header,[role="banner"]')].find(e=>{const r=e.getBoundingClientRect();return visible(e)&&r.top<8&&r.height<100;});
    if(header)top=Math.max(top,header.getBoundingClientRect().bottom+8);
    return {left,right:Math.max(left+80,right),top,height:Math.max(80,innerHeight-top-8)};
  }
  function layout(){
    const enabled=feed();document.documentElement?.classList.toggle('pp-feed',enabled);
    const video=enabled?activeVideo():null;
    if(sourceVideo!==video){sourceVideo?.classList.remove('pp-source-video');sourceVideo=video;lastTime=-1;lastPlay=0;userPaused=false;}
    if(!video||!document.body){if(surface)surface.style.display='none';return;}
    if(!surface||!surface.isConnected){surface=document.createElement('canvas');surface.id='pocket-phone-video-surface';document.body.appendChild(surface);}
    video.classList.add('pp-source-video');const key=(video.currentSrc||'')+'~'+(video.src||'');if(key!==sourceKey){sourceKey=key;userPaused=false;lastTime=-1;}
    const r=bounds(),w=Math.round(r.right-r.left),h=Math.round(r.height);
    surface.style.left=r.left+'px';surface.style.top=r.top+'px';surface.style.width=w+'px';surface.style.height=h+'px';surface.style.display=blocked()?'none':'block';
    if(surface.width!==w||surface.height!==h){surface.width=w;surface.height=h;lastTime=-1;}
  }
  function paint(now){
    if(now-lastLayout>180){lastLayout=now;layout();}
    if(surface&&surface.style.display!=='none'&&sourceVideo?.isConnected){
      const v=sourceVideo;
      if(v.paused&&!userPaused&&now-lastPlay>1200){lastPlay=now;v.play().catch(()=>{});}
      if(v.readyState>=2&&v.videoWidth>0&&v.videoHeight>0&&now-lastPaint>1000/24&&v.currentTime!==lastTime){
        lastPaint=now;lastTime=v.currentTime;
        // Render decoded frames, independent of TikTok's animated wrappers,
        // aspect-ratio guesses, masks or comment-panel reflow. Tainted video is
        // drawable; pixels leave the browser through CDP, never canvas readback.
        const scale=Math.max(surface.width/v.videoWidth,surface.height/v.videoHeight),w=v.videoWidth*scale,h=v.videoHeight*scale;
        try{surface.getContext('2d',{alpha:false}).drawImage(v,(surface.width-w)/2,(surface.height-h)/2,w,h);}catch{}
      }
    }
    requestAnimationFrame(paint);
  }
  requestAnimationFrame(paint);
  function sharedVideo(){
    if(!feed()||blocked()||!surface||surface.style.display==='none'||!sourceVideo||sourceVideo.readyState<2)return null;
    const r=surface.getBoundingClientRect();return {x:r.left,y:r.top,width:r.width,height:r.height};
  }
  const install = () => { const root=document.head || document.documentElement;if (root && !style.isConnected && feed()) root.appendChild(style); };
  function scheduleLayout(){if(layoutPending)return;layoutPending=true;requestAnimationFrame(()=>{layoutPending=false;install();layout();});}
  document.addEventListener('DOMContentLoaded',scheduleLayout);install();
  document.addEventListener('loadedmetadata',scheduleLayout,true);document.addEventListener('resize',scheduleLayout,true);
  document.addEventListener('play',e=>{if(e.target?.matches?.('video'))focusedVideo=e.target;scheduleLayout();},true);
  document.addEventListener('pause',scheduleLayout,true);
  new MutationObserver(scheduleLayout).observe(document,{childList:true,subtree:true});
  window.addEventListener('resize',scheduleLayout);window.addEventListener('popstate',scheduleLayout);
  window.addEventListener('keydown',e=>{if(feed()&&!editable(e.target)&&performance.now()<syntheticArrowUntil&&/^Arrow(Up|Down)$/.test(e.key))e.preventDefault();});
  // Preserve wheel events for virtual feeds that have no next button. A key is only
  // attempted when that event did not change the video or a scroll container.
  function afterWheel() {
    if(videoSignature()!==wheelBefore||window.scrollX!==wheelX||window.scrollY!==wheelY||editable(document.activeElement))return false;
    const v=[...document.querySelectorAll('video')].find(visible);
    for(let e=v;e&&e!==document.body;e=e.parentElement)if(scrollable(e))return false;
    syntheticArrowUntil=performance.now()+500;return true;
  }
  function scroll(x,y,delta) {
    if (!feed()) return {mode:'wheel'};
    install();const target = document.elementFromPoint(x,y);
    if (!target) return {mode:'none'};
    // Comments, menus and login dialogs scroll locally, including at their end boundaries.
    const inComment = comment(target);
    for (let e = target; e && e !== document.body; e = e.parentElement) {
      if (scrollable(e) && (inComment || !e.querySelector('video'))) {
        e.style.overscrollBehavior = 'contain';e.scrollTop += delta;return {mode:'comment'};
      }
    }
    if (inComment || editable(target)) return {mode:'none'};
    if (!document.querySelector('video')) return {mode:'wheel'}; // Login/captcha stays a normal page.
    const now = performance.now();if (now - lastAdvance < 480) return {mode:'none'};
    lastAdvance = now;navigationUntil = now + 650;
    const forward = delta > 0;
    const exact = forward ? nextSelector : previousSelector;
    const candidates = [...document.querySelectorAll(exact), ...document.querySelectorAll('button,[role="button"]')];
    const name = forward ? nextName : previousName;
    const button = candidates.find(e => visible(e) && !e.disabled && !comment(e) && (e.matches(exact) || name.test(label(e))));
    if (button) {const r = button.getBoundingClientRect();return {mode:'click',x:r.left+r.width/2,y:r.top+r.height/2};}
    // Feeds containing several cards snap to the next complete card, never half a wheel step.
    let cards = [...document.querySelectorAll('[data-e2e="recommend-list-item-container"],article')].filter(e => e.querySelector('video'));
    if (cards.length < 2) cards = [...document.querySelectorAll('video')];
    cards=cards.filter(e=>{const r=e.getBoundingClientRect();return r.width>innerWidth*.35&&r.height>innerHeight*.25;});
    if (cards.length > 1) {
      let current = 0, distance = Infinity;
      cards.forEach((e,i) => {const r=e.getBoundingClientRect(),d=Math.abs(r.top+r.height/2-innerHeight/2);if(d<distance){distance=d;current=i;}});
      const next = cards[current+(forward?1:-1)];
      if (next) {next.scrollIntoView({block:'center',inline:'nearest',behavior:'smooth'});return {mode:'card'};}
    }
    const v=[...document.querySelectorAll('video')].find(visible);
    for(let e=v?.parentElement;e&&e!==document.body;e=e.parentElement){if(scrollable(e)){e.scrollTop+=delta;return {mode:'feed'};}}
    if(v){const r=v.getBoundingClientRect();x=Math.max(1,Math.min(innerWidth-1,r.left+r.width/2));y=Math.max(1,Math.min(innerHeight-1,r.top+r.height/2));}
    wheelBefore=videoSignature();wheelX=window.scrollX;wheelY=window.scrollY;wheelUntil=now+500;
    return {mode:'wheelKey',x,y,delta:forward?innerHeight:-innerHeight,key:forward?'ArrowDown':'ArrowUp'};
  }
  window.__pocketPhoneFeed = {scroll,beforeClick,afterWheel,sharedVideo,surface:()=>surface?.getBoundingClientRect().toJSON()??null};
})();
