using System;
using System.Runtime.InteropServices;
using System.Threading;
using NAudio.CoreAudioApi;
using NAudio.CoreAudioApi.Interfaces;
using NAudio.Wave;

// Process-tree capture requires Windows build 20348+ (Windows 11). Never falls back to system/microphone capture.
namespace PhoneBrowser;
[System.Runtime.Versioning.SupportedOSPlatform("windows")]
sealed class ProcessLoopback : IDisposable
{
    [StructLayout(LayoutKind.Sequential)]
    struct AUDIOCLIENT_ACTIVATION_PARAMS { public int ActivationType; public uint TargetProcessId; public int ProcessLoopbackMode; }
    [StructLayout(LayoutKind.Sequential)]
    struct BLOB { public int cbSize; public IntPtr pBlobData; }
    [StructLayout(LayoutKind.Explicit)]
    struct PROPVARIANT { [FieldOffset(0)] public ushort vt; [FieldOffset(8)] public BLOB blob; }

    [ComImport, Guid("72A22D78-CDE4-431D-B8CC-843A71199B6D"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IActivateAudioInterfaceAsyncOperation { void GetActivateResult(out int hr, [MarshalAs(UnmanagedType.IUnknown)] out object iface); }
    [ComImport, Guid("41D949AB-9862-444A-80F6-C261334DA5EB"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IActivateAudioInterfaceCompletionHandler { void ActivateCompleted(IActivateAudioInterfaceAsyncOperation op); }
    [ComImport, Guid("94ea2b94-e9cc-49e0-c0ff-ee64ca8f5b90"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IAgileObject { }

    [ClassInterface(ClassInterfaceType.None), ComVisible(true)]
    sealed class Handler : IActivateAudioInterfaceCompletionHandler, IAgileObject
    {
        public readonly ManualResetEvent Done = new ManualResetEvent(false);
        public int Hr; public object Iface;
        public void ActivateCompleted(IActivateAudioInterfaceAsyncOperation op)
        {
            try { op.GetActivateResult(out Hr, out Iface); } catch (Exception e) { Hr = Marshal.GetHRForException(e); }
            Done.Set();
        }
    }

    [DllImport("Mmdevapi.dll", ExactSpelling = true, PreserveSig = false)]
    static extern void ActivateAudioInterfaceAsync([MarshalAs(UnmanagedType.LPWStr)] string path, [MarshalAs(UnmanagedType.LPStruct)] Guid riid,
        ref PROPVARIANT p, IActivateAudioInterfaceCompletionHandler handler, out IActivateAudioInterfaceAsyncOperation op);

    public readonly WaveFormat Format = new WaveFormat(48000, 16, 2);
    AudioClient _client; AudioCaptureClient _cap; Thread _th; volatile bool _stop;
    public event Action<byte[], int> Data;
    public event Action<Exception> Stopped;

    public ProcessLoopback(int pid, bool tree)
    {
        var ap = new AUDIOCLIENT_ACTIVATION_PARAMS { ActivationType = 1, TargetProcessId = (uint)pid, ProcessLoopbackMode = tree ? 0 : 1 };
        IntPtr mem = Marshal.AllocHGlobal(Marshal.SizeOf(ap));
        try
        {
            Marshal.StructureToPtr(ap, mem, false);
            var pv = new PROPVARIANT { vt = 65 /*VT_BLOB*/, blob = new BLOB { cbSize = Marshal.SizeOf(ap), pBlobData = mem } };
            var h = new Handler();
            ActivateAudioInterfaceAsync("VAD\\Process_Loopback", typeof(IAudioClient).GUID, ref pv, h, out var op);
            if (!h.Done.WaitOne(5000)) throw new TimeoutException("ActivateAudioInterfaceAsync timed out");
            if (h.Hr != 0) Marshal.ThrowExceptionForHR(h.Hr);
            _client = new AudioClient((IAudioClient)h.Iface);
            GC.KeepAlive(op);
        }
        finally { Marshal.FreeHGlobal(mem); }
        // LOOPBACK | AUTOCONVERTPCM | SRC_DEFAULT_QUALITY
        var flags = (AudioClientStreamFlags)(0x00020000u | 0x80000000u | 0x08000000u);
        _client.Initialize(AudioClientShareMode.Shared, flags, 2000000 /*200ms*/, 0, Format, Guid.Empty);
        _cap = _client.AudioCaptureClient;
    }

    public void Start()
    {
        _client.Start();
        _th = new Thread(Loop) { IsBackground = true }; _th.Start();
    }

    void Loop()
    {
        Exception err = null; var buf = new byte[48000 * 4];
        try
        {
            int fsz = Format.BlockAlign;
            while (!_stop)
            {
                Thread.Sleep(10);
                int pk = _cap.GetNextPacketSize();
                while (pk > 0 && !_stop)
                {
                    IntPtr p = _cap.GetBuffer(out int frames, out AudioClientBufferFlags fl);
                    int n = frames * fsz; if (buf.Length < n) buf = new byte[n];
                    if ((fl & AudioClientBufferFlags.Silent) != 0) Array.Clear(buf, 0, n); else Marshal.Copy(p, buf, 0, n);
                    _cap.ReleaseBuffer(frames);
                    Data?.Invoke(buf, n);
                    pk = _cap.GetNextPacketSize();
                }
            }
        }
        catch (Exception e) { err = e; }
        Stopped?.Invoke(err);
    }

    public void Dispose() { _stop = true; try { _th?.Join(500); } catch { } try { _client?.Stop(); } catch { } try { _client?.Dispose(); } catch { } }
}
