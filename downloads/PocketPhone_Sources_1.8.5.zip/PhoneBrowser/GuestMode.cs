namespace PhoneBrowser;
public static class GuestMode
{
    static readonly string Source=Load();
    static string Load()
    {using var stream=typeof(GuestMode).Assembly.GetManifestResourceStream("PhoneBrowser.GuestMode.js")??throw new IOException("Missing guest mode script");using var reader=new StreamReader(stream);return reader.ReadToEnd();}
    public static string Script(bool enabled)=>"window.__pocketPhoneGuestEnabled="+(enabled?"true":"false")+";"+Source;
}
