# Сборка PocketPhone

Нужен .NET 8 SDK и ваши оригинальные managed DLL игры / BepInEx 5.
DLL игры не распространяются вместе с исходниками.

Из корня исходников:

    dotnet build PocketPhone/PocketPhone.csproj -c Release -p:Managed="ПУТЬ_К_Managed" -p:Core="ПУТЬ_К_BepInEx/core"
    dotnet publish PhoneBrowser/PhoneBrowser.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:DebugType=None -p:EnableCompressionInSingleFile=true -o PhoneBrowser/dist

В одну папку BepInEx/plugins/PocketPhone поместите PocketPhone.dll и
PhoneBrowser.exe из результатов сборки. Приложите LICENSE.TXT и
THIRD-PARTY-NOTICES.TXT из Microsoft.NETCore.App.Runtime.win-x64 8.0.31.
Один из поддерживаемых браузеров Chromium устанавливается пользователем отдельно.
Браузер выбирается через HTTPS-ассоциацию Windows или Browser.Selection.
FeedViewport.js встроен в помощник как ресурс; отдельная установка JS не нужна.

## Проверка / предпросмотр модели 1.2.0

Проверка геометрии не требует DLL игры; .NET 8 запускает тот же генератор,
который используется в Unity. Для отдельного рендера нужен Blender 4.3.

    dotnet run --project PhoneModelChecks/PhoneModelChecks.csproj -c Release -- phone-model.json
    blender --background --threads 4 --python PhoneModelChecks/render_model.py -- phone-model.json phone-model.png

Проверяются ориентация треугольников, нормали, замкнутость объёмных деталей,
положение камер и островка. Blender импортирует эти же вершины и материалы.
Рендер не включает интерфейс браузера, руки или игровой свет.

## Проверки браузерного моста в Linux

Нужен Chromium в /usr/bin/chromium. Тестовый режим использует headless Chromium
без песочницы только для запуска теста в контейнере; рабочий режим Windows
запускает обычный Edge/Chrome с его песочницей.

    dotnet publish PhoneBrowser/PhoneBrowser.csproj -c Release -r linux-x64 --self-contained true -o PhoneBrowser/test-dist
    dotnet run --project PhoneChecks/PhoneChecks.csproj -c Release -p:Managed="ПУТЬ_К_Managed" -- "АБСОЛЮТНЫЙ_ПУТЬ_К_КОРНЮ_ИСХОДНИКОВ"

Проверки запускают настоящий Chromium, вводят текст, нажимают кнопку,
прокручивают тестовую страницу, проверяют JPEG, IPC, громкость, остановку
кадров и повторный запуск профиля. Проверки также подменяют HTTPS-страницы TikTok / Reels локальными HTML
через CDP Fetch и проверяют переключение роликов, независимые комментарии,
привязку прокрутки и отсутствие накопления старых команд.
Это не проверка игры, реестра Windows или живого TikTok.
В Windows игровые проверки выполняются вручную:

1. Без телефона проверить обычный спин и ставку.
2. P и ПКМ: модель / экран видны, курсор свободен, камера не поворачивается.
3. Загрузить сайт, нажать воспроизведение и звук, открыть комментарии.
4. Режим клавиатуры: кириллица, Enter, Backspace, Ctrl+V; E не запускает слот.
5. Клавиатура выключена: E запускает только выбранный слот по обычной ставке.
6. При прокрутке видео меняется ролик; комментарии листаются отдельно без сдвига фона.
7. Переключить браузер Windows по умолчанию между Chrome/Edge/Opera/Яндексом,
   перезапустить телефон и проверить имя браузера в настройках, кадры, звук и ввод.
8. Esc, P, Q, выход из лобби: возвращаются управление и курсор, звук прекращается.
9. Два клиента в коопе: каждый видит и слышит свою страницу; спины учитываются хостом.
10. Повторный запуск сохраняет вход в отдельном профиле браузера.
