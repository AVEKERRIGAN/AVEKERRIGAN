using PhoneBrowser;
using PocketPhone;
using SkiaSharp;
int checks=0;
void Check(bool ok,string name){checks++;if(!ok)throw new Exception(name);}
using var original=new SKBitmap(PhoneProtocol.Width,PhoneProtocol.Height);
for(int y=0;y<original.Height;y++)for(int x=0;x<original.Width;x++)original.SetPixel(x,y,x<64?new SKColor(240,20,20):new SKColor(20,40,240));
using var originalImage=SKImage.FromBitmap(original);using var encoded=originalImage.Encode(SKEncodedImageFormat.Jpeg,85);string jpeg=Convert.ToBase64String(encoded.ToArray());
for(int frame=0;frame<120;frame++)
{
 string cropped=FrameCrop.Crop(jpeg,64,8,368,672);using var video=SKBitmap.Decode(Convert.FromBase64String(cropped));
 Check(video.Width==368&&video.Height==672,"native public-video crop preserves requested dimensions");
 var middle=video.GetPixel(video.Width/2,video.Height/2);Check(middle.Blue>200&&middle.Red<50,"desktop side panel excluded from video");
 using var full=SKBitmap.Decode(Convert.FromBase64String(jpeg));Check(full.Width==432&&full.Height==768,"sharing never mutates local full-frame stream");
}
Check(FrameCrop.Crop(jpeg,0,0,0,100)==""&&FrameCrop.Crop(jpeg,double.NaN,0,100,100)=="","invalid crop rejected");
using(var clipped=SKBitmap.Decode(Convert.FromBase64String(FrameCrop.Crop(jpeg,-20,-20,60,70))))Check(clipped.Width==40&&clipped.Height==50,"crop clamps to the full frame");
Check(FrameCrop.Crop("",0,0,100,100)=="","no previous frame is invented");
Console.WriteLine($"PASS: {checks} actual JPEG crop, pixel-content and stable full-frame checks.");
