using PocketPhone;using Mirror;using UnityEngine;
int checks=0;void Check(bool test,string name){checks++;if(!test)throw new Exception(name);}
PhoneWire.Install();
using(var w=NetworkWriterPool.Get()){var m=new PhoneHeldV17{owner=11,epoch=3,held=true,sharing=true,position=new Vector3(1,2,3),rotation=Quaternion.identity,scale=1.25f};Writer<PhoneHeldV17>.write(w,m);using var r=NetworkReaderPool.Get(w.ToArraySegment());var n=Reader<PhoneHeldV17>.read(r);Check(n.owner==11&&n.held&&n.sharing&&n.scale==1.25f&&n.position.y==2,"actual Mirror state/pose roundtrip");}
using(var w=NetworkWriterPool.Get()){var m=new PhoneAudioV17{owner=11,epoch=3,sequence=14,data=Enumerable.Repeat((byte)8,960).ToArray()};Writer<PhoneAudioV17>.write(w,m);using var r=NetworkReaderPool.Get(w.ToArraySegment());var n=Reader<PhoneAudioV17>.read(r);Check(n.sequence==14&&n.data.SequenceEqual(m.data)&&w.Position<1100,"audio packet remains below network MTU");}
using(var w=NetworkWriterPool.Get()){var m=new PhoneVideoV17{owner=11,epoch=3,sequence=2,index=9,count=10,data=new byte[900]};Writer<PhoneVideoV17>.write(w,m);using var r=NetworkReaderPool.Get(w.ToArraySegment());var n=Reader<PhoneVideoV17>.read(r);Check(n.owner==11&&n.count==10&&n.index==9&&n.data.Length==900&&w.Position<1100,"fragment metadata and MTU roundtrip");}
var random=new System.Random(32);for(int round=0;round<2000;round++){
 int length=random.Next(1,SharedFrames.Maximum+1),count=(length+899)/900;var data=new byte[length];random.NextBytes(data);var frames=new SharedFrames();byte[] result=null;var indexes=Enumerable.Range(0,count).OrderBy(_=>random.Next()).ToArray();
 foreach(int index in indexes){int n=Math.Min(900,length-index*900);var bytes=data.Skip(index*900).Take(n).ToArray();var value=frames.Accept(12,index,count,bytes,.1f);if(value!=null)result=value;Check(frames.Accept(12,index,count,bytes,.11f)==null,"duplicate fragment is ignored");}
 Check(result!=null&&result.SequenceEqual(data),"out-of-order frame assembles exactly");Check(frames.Accept(11,0,1,new byte[50],.2f)==null,"old sequence cannot overwrite current frame");
}
var lost=new SharedFrames();Check(lost.Accept(1,0,2,new byte[900],0)==null&&lost.Accept(1,1,2,new byte[900],2)==null,"stalled partial frame expires");Check(lost.Accept(2,0,1,new byte[500],2)!=null,"next frame recovers after packet loss");Check(lost.Accept(3,0,999,new byte[1],3)==null&&lost.Accept(3,0,1,new byte[901],3)==null,"unbounded fragments rejected");
byte[] Header(int width,int height)=>new byte[]{255,216,255,192,0,17,8,(byte)(height>>8),(byte)height,(byte)(width>>8),(byte)width,3,1,0x11,0,2,0x11,0,3,0x11,0,255,217};
Check(SharedFrames.SafeJpeg(Header(432,768)),"normal shared dimensions accepted");Check(!SharedFrames.SafeJpeg(Header(30000,30000))&&!SharedFrames.SafeJpeg(new byte[]{1,2,3}),"oversized images rejected before Unity decode");
var audio=new AudioQueue();for(int p=0;p<10;p++){var bytes=new byte[960];for(int i=0;i<480;i++){short n=(short)(i%2==0?16000:-16000);bytes[i*2]=(byte)n;bytes[i*2+1]=(byte)(n>>8);}audio.Push(bytes);}var samples=new float[480];audio.Read(samples);Check(samples[0]>0.4f&&samples[1]<-0.4f,"phone PCM retains signal");audio.Reset();audio.Read(samples);Check(samples.All(s=>s==0),"hide/change epoch clears previous phone audio");
var convert=new PhoneBrowser.PhoneAudioConvert();var output=new List<byte[]>();convert.Pcm+=p=>output.Add(p);
var stereo=new byte[960*4];for(int i=0;i<960;i++){short value=(short)(i%2==0?12000:8000);for(int c=0;c<2;c++){stereo[i*4+c*2]=(byte)value;stereo[i*4+c*2+1]=(byte)(value>>8);}}
// Odd-sized WASAPI packets must carry their final frame into the next callback.
convert.Push(stereo.Take(4).ToArray(),4);convert.Push(stereo.Skip(4).ToArray(),stereo.Length-4);
Check(output.Count==1&&output[0].Length==960,"48 kHz stereo converts to one 20 ms 24 kHz mono packet across odd blocks");Check(Enumerable.Range(0,480).All(i=>(short)(output[0][i*2]|output[0][i*2+1]<<8)==10000),"browser conversion preserves the full signal and packet boundary");
foreach(float yaw in new[]{0f,90f,180f,270f,360f}){
 var p=new PhoneWorldPose(4,2,6,yaw);double a=yaw*Math.PI/180;
 float right=(float)((p.X-4)*Math.Cos(a)-(p.Z-6)*Math.Sin(a)),forward=(float)((p.X-4)*Math.Sin(a)+(p.Z-6)*Math.Cos(a));
 Check(Math.Abs(right-PhoneWorldPose.Right)<1e-6&&Math.Abs(forward-PhoneWorldPose.Forward)<1e-6,"world phone remains in front of and beside the player at every cardinal direction");
 Check(Math.Abs(p.Y-(2-PhoneWorldPose.EyeDrop))<1e-6&&p.Y+.212f*PhoneWorldPose.Scale*.5f<1.8f,"whole phone remains below the face");
}
Check(.212f*PhoneWorldPose.Scale>.25f&&.212f*PhoneWorldPose.Scale<.35f,"world phone has a fixed readable size independent of FOV and zoom");
Console.WriteLine($"PASS: {checks} checks; real Mirror serializers, packet bounds, 2000 out-of-order/lost/duplicate frame cases, image sizes and PCM lifecycle.");
