using System;
namespace PocketPhone;
public readonly struct PhoneWorldPose
{
    public const float Scale=1.45f,Right=.20f,Forward=.44f,EyeDrop=.36f;
    public readonly float X,Y,Z,Yaw;
    public PhoneWorldPose(float eyeX,float eyeY,float eyeZ,float yaw)
    {
        double angle=yaw*Math.PI/180;
        X=eyeX+(float)(Math.Cos(angle)*Right+Math.Sin(angle)*Forward);
        Y=eyeY-EyeDrop;
        Z=eyeZ+(float)(-Math.Sin(angle)*Right+Math.Cos(angle)*Forward);
        Yaw=yaw;
    }
}
