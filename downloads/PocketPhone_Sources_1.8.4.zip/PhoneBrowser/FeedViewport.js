(() => {
  if (window.__pocketPhoneFeed) return;
  let anchorX = window.scrollX, anchorY = window.scrollY;
  let navigationUntil = performance.now() + 1200, lastAdvance = -1000, correcting = false;
  let syntheticArrowUntil = 0, wheelUntil = 0, wheelBefore = '', wheelX=0, wheelY=0;
  let currentPlayer = null, currentActions = null, layoutPending = false, focusedVideo = null;
  let mediaLayers = [], posterLayers = [], stageParents = [], backdrops = [];
  const videoSignature=()=>[...document.querySelectorAll('video')].map(v=>(v.currentSrc||'')+'~'+(v.src||'')+'~'+(v.closest('article')?.textContent||'')).join('|')+'|'+location.href;
  const feed = () => {
    const host = location.hostname.toLowerCase(), path = location.pathname;
    return ((host === 'tiktok.com' || host.endsWith('.tiktok.com')) &&
      (path === '/' || /^\/(foryou|following|explore|search)(\/|$)/.test(path) || /^\/@[^/]+\/video\//.test(path))) ||
      ((host === 'instagram.com' || host.endsWith('.instagram.com')) && /^\/reels?(\/|$)/.test(path));
  };
  const visible = e => {
    const r = e.getBoundingClientRect();
    return r.width > 1 && r.height > 1 && r.bottom > 0 && r.top < innerHeight && r.right > 0 && r.left < innerWidth;
  };
  const editable = e => e && (e.matches('input,textarea,[contenteditable="true"]') || e.closest('[contenteditable="true"]'));
  const scrollable = e => {
    const s = getComputedStyle(e);
    return e !== document.body && e !== document.documentElement &&
      /auto|scroll/.test(s.overflowY) && e.scrollHeight > e.clientHeight + 2;
  };
  const comment = e => {
    for (let p = e; p && p !== document.body; p = p.parentElement) {
      const marker = (p.getAttribute('data-e2e') || '') + ' ' + (p.getAttribute('aria-label') || '') + ' ' + p.className;
      if ((p.getAttribute('role') === 'dialog' && !p.querySelector('video')) || /comment|комментар/i.test(marker)) return true;
    }
    return false;
  };
  const label = e => e.getAttribute('aria-label') || e.getAttribute('title') || e.querySelector('svg[aria-label]')?.getAttribute('aria-label') || e.textContent.trim();
  const nextName = /next video|next reel|следующ.{0,12}(видео|ролик)|^next$|^далее$|^следующ(ее|ий)$/i;
  const previousName = /previous video|previous reel|предыдущ.{0,12}(видео|ролик)|^previous$|^назад$|^предыдущ(ее|ий)$/i;
  const nextSelector = '[data-e2e="arrow-right"],[data-e2e="arrow-down"],[data-e2e="video-switch-next"]';
  const previousSelector = '[data-e2e="arrow-left"],[data-e2e="arrow-up"],[data-e2e="video-switch-prev"]';
  function beforeClick(x,y) {
    if (!feed()) return;
    const element=document.elementFromPoint(x,y), button=element?.closest('button,[role="button"],'+nextSelector+','+previousSelector);
    if (button && !comment(button) && (button.matches(nextSelector+','+previousSelector) || nextName.test(label(button)) || previousName.test(label(button)))) {
      const now=performance.now();lastAdvance=now;navigationUntil=now+650;
    }
  }
  // Stop scroll chaining/zoom; leave the sites' own feed and comment containers intact.
  const style = document.createElement('style');style.id = 'pocket-phone-viewport';
  style.textContent = `
html.pp-feed,html.pp-feed body{color-scheme:dark;background:#08090d!important;color:#f4f4f5!important;overscroll-behavior:none}
/* Keep TikTok's own navigation, action buttons, captions and colours. Only
   make its video stage responsive; never move actions or lock page scrolling. */
.pp-feed .pp-native-main{width:var(--pp-main-width)!important;max-width:var(--pp-main-width)!important;min-width:0!important;box-sizing:border-box!important}
.pp-feed .pp-player{position:relative!important;top:0!important;left:0!important;transform:none!important;margin-top:0!important;margin-bottom:0!important;padding:0!important;width:100%!important;max-width:100%!important;min-width:0!important;height:calc(100vh - 16px)!important;max-height:calc(100vh - 16px)!important;min-height:0!important;box-sizing:border-box!important;overflow:hidden!important;clip-path:none!important;mask:none!important;-webkit-mask:none!important}
.pp-feed .pp-stage-parent{width:100%!important;max-width:100%!important;min-width:0!important;box-sizing:border-box!important;top:0!important;transform:none!important;margin-top:0!important;margin-bottom:0!important;padding-top:0!important;padding-bottom:0!important;min-height:0!important;height:auto!important;align-items:flex-start!important;justify-content:flex-start!important}
.pp-feed .pp-media-layer{position:absolute!important;inset:0!important;transform:none!important;margin:0!important;padding:0!important;width:100%!important;height:100%!important;min-width:0!important;max-width:none!important;min-height:0!important;max-height:none!important;overflow:visible!important;clip-path:none!important;mask:none!important;-webkit-mask:none!important}
.pp-feed .pp-player video{position:absolute!important;inset:0!important;transform:none!important;width:100%!important;height:100%!important;max-width:none!important;max-height:none!important;object-fit:cover!important;display:block!important}
.pp-feed .pp-player .pp-poster,.pp-feed .pp-player .pp-backdrop{display:none!important}
`;
  function activeVideo(){
    const area=e=>{const r=e.getBoundingClientRect();return Math.max(0,Math.min(innerWidth,r.right)-Math.max(0,r.left))*Math.max(0,Math.min(innerHeight,r.bottom)-Math.max(0,r.top));};
    const videos=[...document.querySelectorAll('video')].filter(v=>!v.closest('[class*="Background"],[class*="Blur"],[data-e2e="video-background"]'));
    if(focusedVideo?.isConnected&&!focusedVideo.paused&&videos.includes(focusedVideo))return focusedVideo;
    const playing=videos.filter(v=>!v.paused&&!v.ended&&v.readyState>1);
    if(playing.length===1)return playing[0];
    const active=videos.filter(visible).sort((a,b)=>area(b)-area(a))[0];
    if(active)return active;
    // React may replace a layer before its inner wrapper has acquired a height.
    // The outer visible stage still identifies the feed video during that commit.
    if(currentPlayer?.isConnected&&visible(currentPlayer))return currentPlayer.querySelector('video');
    return videos.find(v=>{for(let e=v.parentElement;e&&e!==document.body;e=e.parentElement){if(e.matches('[class*="DivPlayerContainer"],[class*="DivVideoContainer"],[class*="DivVideoWrapper"]')&&visible(e))return true;}return false;});
  }
  function layout() {
    const active=feed();document.documentElement?.classList.toggle('pp-feed',active);if(!active)return;
    const video=activeVideo();if(!video)return;
    const nav=document.querySelector('[data-e2e="side-nav"],[data-e2e="side-nav-container"],[class*="DivSideNavContainer"],[class*="DivCompactSideNavContainer"]');
    // The native side navigation stays visible.
    const playerSelector='[class*="DivPlayerContainer"],[class*="DivVideoContainer"],[class*="DivVideoWrapper"],[class*="DivBasicPlayerWrapper"],[class*="DivVideoPlayer"]';
    let player=video.closest(playerSelector);
    // TikTok nests several wrappers and an image cover around the same video.
    // Fit their common stage once; moving the video into normal flow draws it beside its cover.
    for(let e=player?.parentElement;e&&e!==document.body&&!e.matches('article,[data-e2e="recommend-list-item-container"],main,[role="main"]');e=e.parentElement){
      if(e.matches(playerSelector)&&e.querySelectorAll('video').length===1)player=e;
    }
    if(!nav&&!player)return;
    let region=player||video.parentElement;

    if(currentPlayer!==region){currentPlayer?.classList.remove('pp-player');currentPlayer=region;region?.classList.add('pp-player');}
    for(const e of mediaLayers)e.classList.remove('pp-media-layer');
    for(const e of posterLayers)e.classList.remove('pp-poster');
    for(const e of stageParents)e.classList.remove('pp-stage-parent');
    for(const e of backdrops)e.classList.remove('pp-backdrop');
    mediaLayers=[];posterLayers=[];stageParents=[];backdrops=[];
    for(let e=region.parentElement;e&&e!==document.body&&!e.matches('article,[data-e2e="recommend-list-item-container"],main,[role="main"]');e=e.parentElement){e.classList.add('pp-stage-parent');stageParents.push(e);}
    for(let e=video.parentElement;e&&e!==region;e=e.parentElement){e.classList.add('pp-media-layer');mediaLayers.push(e);}
    for(const e of region?.querySelectorAll('img,picture,canvas')||[]){
      if(e.closest('button,[role="button"]'))continue;
      const rect=e.getBoundingClientRect(),marker=(e.className||'')+' '+(e.getAttribute('data-e2e')||'');
      if((rect.width>100&&rect.height>100)||/poster|cover/i.test(marker)){e.classList.add('pp-poster');posterLayers.push(e);}
    }
    // Empty native blur/backing layers must not cover the resized foreground video.
    const stageRect=region.getBoundingClientRect();
    for(const e of region.querySelectorAll('div')){
      if(e.contains(video)||e.textContent.trim()||e.querySelector('video,button,[role="button"],a,input,svg'))continue;
      const rect=e.getBoundingClientRect();
      if(rect.width>stageRect.width*.25&&rect.height>stageRect.height*.7){e.classList.add('pp-backdrop');backdrops.push(e);}
    }
    const main=document.querySelector('main,[role="main"],#main-content,[class*="DivMainContainer"],[class*="DivMainContent"]');
    if(main?.contains(video)){const left=Math.max(0,main.getBoundingClientRect().left);main.classList.add('pp-native-main');main.style.setProperty('--pp-main-width',Math.max(100,innerWidth-left)+'px');}
  }
  function sharedVideo(){
    if(!feed())return null;
    if([...document.querySelectorAll('[role="dialog"],[aria-modal="true"],input[type="password"],iframe[src*="captcha"]')].some(visible))return null;
    const video=activeVideo();if(!video)return null;const r=video.getBoundingClientRect();
    const x=Math.max(0,r.left),y=Math.max(0,r.top),width=Math.min(innerWidth,r.right)-x,height=Math.min(innerHeight,r.bottom)-y;
    return width>32&&height>32?{x,y,width,height}:null;
  }
  const install = () => { const root=document.head || document.documentElement;if (root && !style.isConnected && feed()) root.appendChild(style); };
  function scheduleLayout(){if(layoutPending)return;layoutPending=true;requestAnimationFrame(()=>{layoutPending=false;install();layout();});}
  document.addEventListener('DOMContentLoaded',scheduleLayout);install();
  document.addEventListener('loadedmetadata',scheduleLayout,true);document.addEventListener('resize',scheduleLayout,true);
  document.addEventListener('play',e=>{if(e.target?.matches?.('video'))focusedVideo=e.target;scheduleLayout();},true);
  document.addEventListener('pause',scheduleLayout,true);
  new MutationObserver(scheduleLayout).observe(document,{childList:true,subtree:true});
  window.addEventListener('resize',scheduleLayout);window.addEventListener('popstate',scheduleLayout);
  window.addEventListener('keydown',e=>{if(feed()&&!editable(e.target)&&performance.now()<syntheticArrowUntil&&/^Arrow(Up|Down)$/.test(e.key))e.preventDefault();});
  // Preserve wheel events for virtual feeds that have no next button. A key is only
  // attempted when that event did not change the video or a scroll container.
  function afterWheel() {
    if(videoSignature()!==wheelBefore||window.scrollX!==wheelX||window.scrollY!==wheelY||editable(document.activeElement))return false;
    const v=[...document.querySelectorAll('video')].find(visible);
    for(let e=v;e&&e!==document.body;e=e.parentElement)if(scrollable(e))return false;
    syntheticArrowUntil=performance.now()+500;return true;
  }
  function scroll(x,y,delta) {
    if (!feed()) return {mode:'wheel'};
    install();const target = document.elementFromPoint(x,y);
    if (!target) return {mode:'none'};
    // Comments, menus and login dialogs scroll locally, including at their end boundaries.
    const inComment = comment(target);
    for (let e = target; e && e !== document.body; e = e.parentElement) {
      if (scrollable(e) && (inComment || !e.querySelector('video'))) {
        e.style.overscrollBehavior = 'contain';e.scrollTop += delta;return {mode:'comment'};
      }
    }
    if (inComment || editable(target)) return {mode:'none'};
    if (!document.querySelector('video')) return {mode:'wheel'}; // Login/captcha stays a normal page.
    const now = performance.now();if (now - lastAdvance < 480) return {mode:'none'};
    lastAdvance = now;navigationUntil = now + 650;
    const forward = delta > 0;
    const exact = forward ? nextSelector : previousSelector;
    const candidates = [...document.querySelectorAll(exact), ...document.querySelectorAll('button,[role="button"]')];
    const name = forward ? nextName : previousName;
    const button = candidates.find(e => visible(e) && !e.disabled && !comment(e) && (e.matches(exact) || name.test(label(e))));
    if (button) {const r = button.getBoundingClientRect();return {mode:'click',x:r.left+r.width/2,y:r.top+r.height/2};}
    // Feeds containing several cards snap to the next complete card, never half a wheel step.
    let cards = [...document.querySelectorAll('[data-e2e="recommend-list-item-container"],article')].filter(e => e.querySelector('video'));
    if (cards.length < 2) cards = [...document.querySelectorAll('video')];
    cards=cards.filter(e=>{const r=e.getBoundingClientRect();return r.width>innerWidth*.35&&r.height>innerHeight*.25;});
    if (cards.length > 1) {
      let current = 0, distance = Infinity;
      cards.forEach((e,i) => {const r=e.getBoundingClientRect(),d=Math.abs(r.top+r.height/2-innerHeight/2);if(d<distance){distance=d;current=i;}});
      const next = cards[current+(forward?1:-1)];
      if (next) {next.scrollIntoView({block:'center',inline:'nearest',behavior:'smooth'});return {mode:'card'};}
    }
    const v=[...document.querySelectorAll('video')].find(visible);
    for(let e=v?.parentElement;e&&e!==document.body;e=e.parentElement){if(scrollable(e)){e.scrollTop+=delta;return {mode:'feed'};}}
    if(v){const r=v.getBoundingClientRect();x=Math.max(1,Math.min(innerWidth-1,r.left+r.width/2));y=Math.max(1,Math.min(innerHeight-1,r.top+r.height/2));}
    wheelBefore=videoSignature();wheelX=window.scrollX;wheelY=window.scrollY;wheelUntil=now+500;
    return {mode:'wheelKey',x,y,delta:forward?innerHeight:-innerHeight,key:forward?'ArrowDown':'ArrowUp'};
  }
  window.__pocketPhoneFeed = {scroll,beforeClick,afterWheel,sharedVideo};
})();
